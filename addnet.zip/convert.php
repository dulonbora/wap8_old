<?php
include 'db.php';
include 'functions.php';

headtag("$SiteName - Convert Currency");


if($userlog==1){

include 'head.php'; 


$act=formget("act"); 


 if($act=='dollar2rs')

 { 
 
 echo '<div class="title">Dollar to Rupees</div>';
 

if(isset($_POST["amount"])){

$amount=formpost("amount");

 
$result=($amount*60);


 
 echo '<div class="ok">Your converted Dollar in Rupees <font color="red"><b>'.$result.'</b></font>Rs</div>'; 

}

echo '<div class="form"><form action="?act=dollar2rs" method="post">        
 Enter amount(In $): <input type="text" name="amount" /><br><input type="submit" value="Conver Now" /></div>'; 
} 

//end dollar2rs 

if($act=='rs2dollar') { 
 
 
 echo '<div class="title">Rupees to dollar</div>';
 
if(isset($_POST["amount"])){

$amount=formpost("amount");

 
$result=($amount/60); 

 
echo '<div class="ok">Your converted Rupees in Dollar <font color="red"><b>'.$result.'</b></font> $</div>';
}

echo '<div class="form"><form action="?act=rs2dollar" method="post">        
 Enter amount(In Rs): <input type="text" name="amount" /><br><input type="submit" value="Conver Now" /></div>'; 
} 
//end rs2dollar

if($act=='method') 
{ 
echo '<div class="title">Convert Currency</div>';

echo '<div class="catRow"> <table><tbody><tr><td> <img src="images/arrow.png"/></td><td> <b><a href="?act=rs2dollar">Rupees to Dollar.</a></b><br/> Convert Indian Rupees To Dollar.</td></tr></tbody></table></div>';

echo '<div class="catRow"> <table><tbody><tr><td> <img src="images/arrow.png"/></td><td> <b><a href="?act=dollar2rs">Dollar to Rupees</a></b><br/> Convert Dollars To Indian Ruppes.</td></tr></tbody></table></div>';
}
//end method
//end userlog


echo '<br/><div class="back"><a href="/">Go Back To Home</a></div>';
include 'foot.php';

} 

 else {

header('Location:/');

}
 

?>