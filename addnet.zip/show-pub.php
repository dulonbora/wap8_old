<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - Publisher");

echo '<div class="title">Publishers:</div>';

echo '<div class="right"><b><font color="red"> Discover our world class mobile Advertising platform. </font></b></div>'; echo 
'<div class="pleft"> 1. <b> Register for Free. </b></div>'; echo 
'<div class="pleft"> 2.  Start Earning in few minutes. </div>';
echo 
'<div class="pleft"> 3.  Earn <b> 0.009$ </b> Per valid click to <b> 0.02$ </b> Per valid click. </div>'; echo 
'<div class="pleft"> 4.  Upto 95%-98% Fill Rate. </div>'; echo 
'<div class="pleft"> 5.  Show most relevant ads only (Filter Ad). </div>'; echo 
'<div class="pleft"> 6.  Fast and easy to integrate.</div>'; echo 
'<div class="pleft"> 7.  Real Time reporting system.</div>'; echo 
'<div class="pleft"> 8.  Support Various programming language. </div>'; echo 
'<div class="pleft"> 9.  Support various ad format.</div>'; echo
'<div class="pleft"> 10.  Montior site traffic from your mobile. </div>'; 
    

echo '<div class="uright">
<a href="/user/registration">Start Earning Now!</a>
</div>';


echo '<div class="back"><img src="/home.png"/> <a href="/">HOME</a></div>';
include 'foot.php';

?>
