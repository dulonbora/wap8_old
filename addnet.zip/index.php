<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include 'db.php';
include 'functions.php';
headtag();


$news=mysqli_query("SELECT * FROM news ORDER BY id DESC"); $newsf=mysqli_fetch_array($news);

echo '<div class="ok"><b>NEWS:</b> <a href="news.php?nid='.$newsf["id"].'"><b>
'.$newsf["title"].'</b></a></div>';

if($userlog==1){


header('Location:/user/dashboard'); 

}


$paidb = mysqli_query('SELECT *, SUM(amount) FROM bank WHERE status LIKE "Paid%"'); 
$paidb2 = mysqli_fetch_array($paid); 
$payb = $paidb2['SUM(amount)'];

$paid = mysqli_query('SELECT *, SUM(amount) FROM invoice WHERE status LIKE "Paid%"'); 
$paid2 = mysqli_fetch_array($paid); 
$pay = $paid2['SUM(amount)']; 

$allpay = $payb+$pay;

$allp = $allpay/62;


echo '<div class="title">Total Paid Earning</div>';

echo '<div class="ad">Total Paid &#8377:<b id="num"> '.$allpay.' &#8377</b><br/>Total Paid $:<b id="num">'.$allp.' $</b></div>';

echo 
'<div class="line">User Functions</div>'; echo 
'<div class="catRow"><img src="/images/arrow.png" alt="-"/> <a href="/user/login">Member Login</a></div>';

echo

'<div class="catRow"><img src="/images/arrow.png" alt="-"/> <a href="/user/registration">Register Now</a></div>';
echo 

'<div class="catRow"><img src="/images/arrow.png" alt="-"/> <a href="/user/forgot">Forgot Password</a></div>';

 echo 
'<div class="catRow"><img src="/images/arrow.png" alt="-"/> <a href="contact">Contact Us</a></div>';
echo 

'<div class="catRow"><img src="/images/arrow.png" alt="-"/> <a href="/f.a.q">Our FAQs</a></div>';

echo 

'<div class="catRow"><img src="/images/arrow.png" alt="-"/> <a href="/show-publishers">High CPC Rate</a></div>';

echo 
'<div class="catRow"><img src="/images/arrow.png" alt="-"/> <a href="/show-adv.php">Advertise at Low Costs</a></div>';
echo 

'<div class="catRow"><img src="/images/arrow.png" alt="-"/> <a href="/user/terms">Terms & Conditions</a></div>';
echo 

'<div class="catRow"><img src="/images/arrow.png" alt="-"/> <a href="/afftp.php">Invite & Earn [ Affiliation ]</a></div>';


echo 
'<div class="catRow"><img src="/images/arrow.png" alt="-"/> <a href="/Earn-from-cpa.php">Earn From Cpa Campaign</a></div>';


echo 
'<div class="catRow"><img src="/images/arrow.png" alt="-"/> <a href="/cpi.php">Earn by Promoting Apps</a></div>';

echo 
'<div class="catRow"><img src="/images/arrow.png" alt="-"/> <a href="http://fb.com/mydearads">Join US on Facebook</a></div>';

echo '<div class="line">What Makes Us Unique ?</div>';


echo 

'<div class="catRow"><img src="/images/tick.png"> Payment Through Mobile Recharge, Airtel Money, Bank Transfer, Paytm Wallet Cash.</div>';
echo 

'<div class="catRow"><img src="/images/tick.png"> Minimum Payout 10 Rs through Recharge, 50 Rs through Airtel Money, 100 Rs through Bank Transfer & 60 Rs through Paytm Wallet.</div>';

echo 
'<div class="catRow"><img src="/images/tick.png"> Our Average Payout Time On Bank , Airtel Money, Paytm Wallet & Recharge is 1 Day.</div>';
echo

'<div class="catRow"><img src="/images/tick.png"> Earn <font color="blue"><b>0.009$ - 0.02$</b></font> Per Valid Click.</div>';
echo

'<div class="catRow"><img src="/images/tick.png"> <b>CPC</b>, <b>CPA</b>, <b>CPI</b>, <b>CPR</b> Network Model.</div>';
echo 
'<div class="catRow"><img src="/images/tick.png"> Advertise with us with lowest price.</div>';
echo 
'<div class="catRow"><img src="/images/tick.png"> 24x7 Offline/Online Dedicated Support.</div>';
echo 
'<div class="catRow"><img src="/images/tick.png"> Todays <b>Clicks Report & Earned Money Updated Live.</div>';


echo '<div class="line">News </div><div class="uright"><img src="/news.png" height="16" width="16" alt="-"/> <font  color="purple">'.$newsf["body"].'</font></div>';
 

$imp=mysqli_query("SELECT * FROM imp");
$imps=0;

while($show=mysqli_fetch_array($imp)){
$imps=($imps+$show['imp']);
}

$clciks=mysqli_num_rows(mysqli_query("SELECT * FROM clicks"));

$users=mysqli_num_rows(mysqli_query("SELECT * FROM userdata"));

echo '<div class="line">Statistics</div>';
echo '<div class="balance">Total Users: <b id="num">'.number_format($users).'</b></div>';
 

echo '<div class="header" align="center"><br/><font color="white">&#169; All rights Reserved<br/>Mydearads.In Pvt. 2016</font> <br/>  </div>';

echo '<!-- name="adtwirl-site-verification" content="adtwirl-0276b6b120964e6a1ecdbd05beb8be38" -->';
echo '<meta name="google-site-verification" content="UsMCerPZNtJMtOLXd9PZwu5661WlK3Sku4fb6qH0rpM" />';
echo '<meta name="kimia_id" content="57lmxswjl38koo8gs4okscog4gcgow0">';


echo '</body></html>';
?>