<?php
$uid = $_GET['uid'];
header("Location:http://wapmoney.in/CPApartner/wapads/$uid.html");
?>