if( /Android/i.test(navigator.userAgent) ) {
var url=confirm("Do you want to download this  ?");
if (url==true)
{
var url = window.location.href = 'http://mydearads.in/ssworld/com.nineapps_v3.0.6.2_android_(Build1611251030).apk';
url.show();
}
else
{
}
}