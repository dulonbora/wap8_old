<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName Registration");

 if($userlog==1){
   header('Location:/');
   }
  else{
       if(isset($_POST['firstname']) AND 
isset($_POST['lastname'])AND
isset($_POST['mobile']) AND isset($_POST['email']) AND isset($_POST['password1']) AND isset($_POST['password2']) AND isset($_POST['captcha'])){


$firstname=formpost("firstname");
$lastname=formpost("lastname");

$mobile=formpost("mobile");
$email=formpost("email");
$password1=formpost("password1");
$password2=formpost("password2");
$captcha=formpost("captcha");
$captcha=strtoupper($captcha);
$terms=formpost("terms");

//Codes
$errors=array();
unset($errors);

//Empty
if(strlen($firstname)<1){
$errors[]='First name field left empty!';
}

if(strlen($lastname)<1){
$errors[]='Last name field left empty!';
}

if(strlen($email)<1){
$errors[]='Email field left empty!';
}

if(strlen($password1)<1){
$errors[]='Password field left empty!';
}


if(strlen($password2)<1){
$errors[]='Verify password field left empty!';
}

if(strlen($captcha)<1){
$errors[]='Captcha field left empty!';
}

if(!preg_match('/^([a-zA-Z0-9_.-]+)\@([a-zA-Z0-9_.-]+)\.([a-zA-Z0-9_.-]+)$/', $email)){
$errors[]='Email is not valid!';
}


if($password1!=$password2){
$errors[]='Passwords didn\'t match!';
}

if($_SESSION['captcha']!=$captcha){
$errors[]='Captcha code entered is wrong!';
}

if($terms!=1){
$errors[]='You must agree to our terms!';
}
$emch=mysqli_query("SELECT * FROM userdata WHERE email='$email'");

if(mysqli_num_rows($emch)>0){
$errors[]='Email already registered with another account!';
}

if(empty($errors)){
  $password=md5($password1);
  $doreg=mysqli_query("INSERT INTO userdata (email,password,firstname,lastname,address1,address2,state,city,zipcode,country,mobile,status,adbalance,pubalance) VALUES ('$email','$password','$firstname','$lastname','put','put','put','put','put','India','$mobile','ACTIVE','0.00','0.00')");

  if($doreg){
$user_data=mysqli_query("SELECT * FROM userdata WHERE email='$email'");
$userdat=mysqli_fetch_array($user_data);
$userid=$userdat['id'];

$aid=formget("ref");

$add=mysqli_query("INSERT INTO affiliates (aid,rid,status) VALUES ('$aid','$userid','Pending')");

  $token=md5(microtime());
  $dover=mysqli_query("INSERT INTO verification (userid,token) VALUES ('$userid','$token')");


    $to      = $email;
    $subject = 'Registration At Mydearads.In Mobile Advertising Network | Sell Ads | Buy Ads | Monetize Traffic';
    $message = 'Dear '.$userdat["firstname"].',
Welcome to Mydearads.In Mobile Advertise Network!

Just one more step to complete your registration with Mydearads! Please click bellow link or alternatively copy and paste the url to your browser!

http://mydearads.in/verify/'.$userid.'/'.$token.'


Once you completed the registration procedure you can add your mobile site and start earning revenue!


Support:
support@mydearads.In
+918795589006

Thanks,
Mydearads Team,
Mydearads.In';
    $headers = 'From: Mydearads.In<support@mydearads.in>' . "\r\n" .
    'Reply-To: support@mydearads.in' . "\r\n" .
    'X-Mailer: Mydearads.in';

    mail($to, $subject, $message, $headers);
$_SESSION['adsgem_email']=$email;
$_SESSION['adsgem_password']=$password;

echo '<br/><div class="ok"><font color="green"><b>Registration Successful!.</b></font><br/> Please  Check Your Email To Verify Your Account. Click Here To<a href="/user/login"> Login Now</a></div><br/>';
}
else {
echo 'unknown error!';
}
}
else {
echo '<br/><div class="error"><img src="/error.png"/> <font color="red">Error happened!</font></div><br/>';

echo '<div class="error">';

foreach($errors as $error){
echo '- '.$error.'<br/>';
}
echo '</div>';
}
    

//END

}
echo '<div class="line">User Registration</div>';

echo '<div class="form"><div id="forgot"></div>
<form method="post"><label for="firstname"><b>First Name:*</b></label><br/><input type="text" name="firstname"/><br/><label for="lastname"><b>Last name:*</b></label><br/><input type="text" name="lastname"/><br/><label for="mobile"><b>Mobile No:*</b></label><br/><input type="text" name="mobile"/><br/><div id="forgot"></div><label for="email"><b>Email:*</b></label><br/><input type="text" name="email"/><br/><label for="password1"><b>Password:*</b></label><br/><input type="password" name="password1"/><br/><label for="password2"><b>Verify Password:</b><font color="red">*</font></label><br/><input type="password" name="password2"/><br/><label for="captcha"><b>Captcha:*</b></label><br/><img src="/im'.md5(rand(1,50000)).'.jpg" alt="Loading.."/><br/>Enter the words showing in the image<br/><input type="text" name="captcha"/><br/><div id="forgot"> * Marked Fields are Required. <br/><input type="checkbox" name="terms" value="1"/> <label for="terms"><b>Agree to <a href="/user/terms">Terms</a>:*</b></label></div><input type="submit" value="Register Now"/></form></div><br/>';

echo '<div class="back"><img src="/error.png"/> <a href="/">Cancel & Go Back</a></div>';

}

include 'foot.php';

?>
