<?php

include 'db.php';
include 'functions.php';

headtag("$SiteName CPM Sites");


if($userlog==1){

include 'head.php';

$uid=dump_udata("id");

$d=date("d");

echo '<div class="title">Showing CPM Stats of '.date("F, Y").'</div>';

echo '<div><table style="border-collapse:collapse;text-align:center;" align="center" height="60" border="1" bordercolor="#5b8ebb" cellpadding="5" width="90%">
<tr style="background-color:#5b8ebb">
<th>Date</th>
<th>Popunder</th>
<th>CPM</th>
<th>Earned</th>
</tr>';

for($i=$d;$i>0;$i--){

if(strlen($i)==1){
 $i="0$i";
}

$datee=date("".$i."-m-Y");

$clicks=mysqli_num_rows(mysqli_query("SELECT * FROM cpm WHERE userid='$uid' AND date='$datee' AND status='VALID'"));
$earn=($clicks*0.0003);

echo '<tr bgcolor="#e8e8e8">
<td>'.$datee.'</td>
<td>'.$clicks.'</td>
<td>0.0003$</td>
<td>'.$earn.' $</td>
</tr>';

}
$timp=mysqli_num_rows(mysqli_query("SELECT * FROM cpm WHERE userid='$uid'"));

$tclicks=mysqli_num_rows(mysqli_query("SELECT * FROM cpm WHERE userid='$uid' AND status='VALID'"));
$tctr=($tclicks/$timp)*100;
$tearn=($tclicks*0.0003);

echo '<tr style="background-color:#5b8ebb">
<td>Total</td>
<td>'.$tclicks.'</b></td>
<td>0.0003$</b></td>
<td>'.$tearn.' $</b></td>
</tr>';

echo '</table></div>';

echo '<div class="back"><a href="/">Go Back To Home</a></div>';

include 'foot.php';

}
else {header('Location:/');
}
?>
