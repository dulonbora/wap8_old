<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - Transfer funds from publisher balance");

if($userlog==1){

if(dump_udata("pubalance")<1){
 
 echo '<div class="error">Minimum transfer amount is 1$</div>';
}
else {

if(isset($_POST["amount"]) AND isset($_POST["captcha"])){

echo '<div class="title">Transfer balance</div>';

$amount=formpost("amount");
$captcha=formpost("captcha");

$uid=dump_udata("id");

$errors=array();


if($amount>dump_udata("pubalance")){
  $errors[]='Amount is greater than balance!';
}

if(strlen($amount)<1){
 $errors[]='Amount cannot be empty!';
}

if(!is_numeric($amount)){
 $errors[]='Amount must be a numeric value';
}

if($_SESSION["captcha"]!=$captcha){
 $errors[]='Captcha code was wrong!';
}


if(empty($errors)){

 $newad=(dump_udata("adbalance")+$amount);
 $newpu=(dump_udata("pubalance")-$amount);

 $doit=mysqli_query("UPDATE userdata SET pubalance='$newpu', adbalance='$newad' WHERE id='$uid'");
 
 if($doit){
   echo '<div class="success">Balance successfully transferred!</div>';
}
else {

 echo '<div class="error">Error transferring!</div>';

}
}
else {

dump_error($errors);

}
}

echo '<div class="form"><form method="post">Amount: (max '.dump_udata("pubalance").'$)<br/><input type="text" name="amount"/><br/>Captcha:<br/><img src="/im'.md5(microtime()).'.jpg"/><br/>Input the characters showing in image.<br/><input type="text" name="captcha"/><br/><input type="submit" value="Transfer"/></form></div>';
}
echo '<div class="ad"><img src="/home.png"/> <a href="/">Home</a> | <a href="/user/dashboard">Dashboard</a></div>';

include 'foot.php';

}

else {

header('Location:/');

}

?>



