<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - My Account");

if($userlog==1){

include 'head.php';

 $uid=dump_udata("id");

echo '<div class="title">My Account</div>';

echo '<div class="uright"><b>Personal Info:</b> </div>
<div class="uright">
 Firstname: '.ucfirst(dump_udata("firstname")).'</div> <div class="uright"> 
 Lastname: '.ucfirst(dump_udata("lastname")).'</div>
 <div class="uright"> 
 Address1: '.dump_udata("address1").'</div>
 <div class="uright"> 
 Address2: '.dump_udata("address2").'</div>
 <div class="uright"> 
 State: '.ucfirst(dump_udata("state")).'</div>
<div class="uright">
 City: '.ucfirst(dump_udata("city")).'</div>
 <div class="uright"> 
 Zipcode: '.dump_udata("zipcode").'</div>
 <div class="uright"> 
 Country: '.ucfirst(dump_udata("country")).'</div>
 <div class="uright"> 
 Mobile: '.dump_udata("mobile").'</div>
<div class="uright">
<a href="/edit_account">Edit Account</a>
</div>
<div class="line">Account Info:</div>
 <div class="uright"> Email: '.dump_udata("email").'</div> <div class="uright"> 
 Password: ******** <a href="/change_password">Change Password</a></div><div class="uright"> 
 Secure Pin: ***** <a href="/upin.php">Forget Secure Pin</a></div><br/>';

echo '<div class="back"><img src="/home.png"/> <a href="/">Home</a> | <a href="/user/dashboard">Dashboard</a></div>';

include 'foot.php';


}

else {

header('Location:/');
}
?>
