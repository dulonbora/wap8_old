<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include 'db.php';
include 'functions.php';

headtag("$SiteName - Secure Pin");

if($userlog==1){

include 'head.php';

echo '<div class="line">Forget Secure pin</div>';

   $get_use=mysqli_query("SELECT * FROM pin WHERE userid='$uid'");
   $get_us=mysqli_fetch_array($get_use);
   $uid=$get_us["userid"];
   $get_u=mysqli_query("SELECT * FROM userdata WHERE id='$uid'");
  $get_user=mysqli_fetch_array($get_u);
   $emailz=$get_user["email"];
   echo '<br/><div class="success">We Have Successfully sent the secure pin to your e-mail!</div><br/>';
       $to      = $emailz;
    $subject = 'Your Secure Pin - Mobile Advertising Network | Sell Ads | Buy Ads | Monetize Traffic';
    $message = 'Dear '.$get_user["firstname"].',


Your Secure Pin is: '.$get_us["other"].'

Thank You!


Support:
support@adzincome.in

+919782583610

Thanks,
AdzIncome Team,
AdzIncome.In';
    $headers = 'From: Adzincome.in<support@adzincome.in>' . "\r\n" .
    'Reply-To: support@adzincome.in' . "\r\n" .
    'X-Mailer: AdzIncome';

    mail($to, $subject, $message, $headers);
 

echo '<a href="#"><div class="back">HOME</div></a>'; 

 include 'foot.php';

 }
 else {
 header('Location:/');
 }
?>