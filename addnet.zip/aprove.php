<?php
include 'db.php';
include 'functions.php';

headtag("$SiteName - Aprove Balance");

if($userlog==1){

include 'head.php';
echo '<div class="title">Aprove Balance</div><div class="notice"><font color="red">Note : </font>Balance Will Be Approved Within 3 Days Of Requested Date.</div>';
if(dump_udata("pubalance")<0.20){
 echo '<br/><div class="error">Your account balance is '.dump_udata("pubalance").'$! Which is lower than our minimum amount (0.20$). Please earn more and then request !</div><br/>';
 }
else {
$uid=dump_udata("id");
if(isset($_POST["amount"])){

$amount=formpost("amount");
$captcha=formpost("captcha");
 $other=formpost("other");

$errors=array();

if(!is_numeric($amount)){
  $errors[]='Amount must be a numeric value !';
 }


if(strlen($amount)<1){
  $errors[]='Amount cannot be empty !';
 }




if(dump_udata("pubalance")<$amount){ $errors[]='You cannot request lower than our minimum amount!';
}
if($amount>dump_udata("pubalance")){
  $errors[]='Amount is bigger than account balance!';
}

 $login_check=mysqli_query("SELECT * FROM pin WHERE userid='$uid' AND other='$other'");      if(mysqli_num_rows($login_check)<1){         $errors[]='Wrong Pin!';      }

if(empty($errors)){
  $date=date("l , F d , Y"); 
  $doit=mysqli_query("INSERT INTO invoice (userid,amount,method,via,status,time,name) VALUES ('$uid','$amount','Aprove Balance','1234567890','PENDING','$date','Approved')");
  $newbal=(dump_udata("pubalance")-$amount);
  $minusb=mysqli_query("UPDATE userdata SET pubalance='$newbal' WHERE id='$uid'");
  if($doit AND $minusb){
   echo '<br/><div class="success"><b> Approved Balance Requested Successfully!</b><br/>We Will Paid it in Working 3 days!</div><br/>';
  }
  else {
   echo '<div class="error">Error creating !</div>';
}

}
else {

dump_error($errors);

}
}
echo '<div class="form"><form method="post">Amount (Min. $0.20 Max. '.dump_udata("pubalance").'$)<br/><input type="text" name="amount"/><br/>
Secure Pin: <input type="text" name="other"/><br/>
<input type="submit" value="Request Now"/></form></div>';

}
}
else {
header('Location:/');
}
echo '<br/><div class="back"><a href="/">Go Back To Home</a></div>';
include 'foot.php';

?>