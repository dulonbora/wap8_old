<?php
header('Location:/');
?>