<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - Advertisement management");

if($userlog==1){
include 'head.php';

echo '<div class="title">Advertises</div>';
$uid=dump_udata("id");

$adver=mysqli_query("SELECT * FROM advertises WHERE userid='$uid'");

if(mysqli_num_rows($adver)>0){
 while($show=mysqli_fetch_array($adver)){
  echo '<div class="uright"><b>Name:</b> <a href="/adv/'.$show["id"].'">'.$show["name"].'</a></b><br/>
    <b>UrL: </b><font color="blue">'.$show["url"].'</font><br/>
    <b>Device: </b>'.$show["device"].'<br/>
    <b>Country: </b>'.$show["country"].'<br/>
    <b>Status:</b>'.$show["status"].'<br/>
</div>';
}
}
else {

echo '<br/><div class="error">There is no Ad created by you!</div><br/>';

}

echo '<div class="uright"><a href="/newad">Create new Advertise</a></div>';

echo '<br/><div class="back"><img src="/home.png"/> <a href="/">Home</a> | <a href="/user/dashboard">Dashboard</a></div>';

include 'foot.php';

}

else {


header('Location:/');

}

?>

