<?php

/************************************

Updated By MobFreshAD As per Shahid Request On 16-12-16 4.05 PM By Rasid

**************************************/
include 'db.php';
include 'functions.php';

headtag("$SiteName Dashboard");


if($userlog==1){
$uid=dump_udata("id");

if(dump_udata("status")=='INACTIVE'){
echo '<div class="line">In Active Account</div><br/><div class="error">Your account is inactive. Please click on the link sent to your email to activate your account!<br/>If Not Yet Received Any Mail Then Call us at 8795589006 Nd Mail Us at support@mydearads.in</div><br/>';
echo '<div class="back"><img src="/home.png"> <a href="/">Home</a></div>';
include 'foot.php';
exit;
}
$pub=dump_udata("pubalance");
$ad=dump_udata("adbalance");

$newpub=($pub*61);
$newad=($ad*60);

echo '<div align="center"><div id="tabbar" class="tabbar"><a href="/"> Home </a> <a href="#"> Online (1) </a> <a href="/wall.php"> Wall </a></div></div>'; 

 $chnoti=mysqli_query("SELECT * FROM msgs WHERE rid='$uid' AND status='New'");
if(mysqli_num_rows($chnoti)>0){ $noti=mysqli_num_rows($chnoti); echo '<div class="notice" align="center"><a href="/notifications.php"><b style="color:red;">You Have  '.$noti.' Notification!</b></a></div>'; }
echo '<div class="notifications" align="center">Today Dollar Rate is - <b> 62 </b> Rs.</div>';

echo '<div class="line">Welcome, <font color="white"><b>'.ucfirst(dump_udata("firstname")).' '.ucfirst(dump_udata("lastname")).'</b></font></div>';

echo '<div class="balance"><b>Your User Id: '.$uid.'</b></div>';
echo '<div class="balance"><b> Your Account Balance : </b> <b id="num">'.dump_udata("pubalance").' $</b> <b> (   <b id="num_rs">Rs. '.$newpub.' </b> )</b> </div><div class="balance"><b> Your Approved Balance : </b> <b id="num">'.dump_udata("adbalance").' $</b>  <b>(  <b id="num_rs">Rs. '.$newad.'</b>  ) </b></div>'; 


echo '<div class="notifications"><font color="red"><b> Warning : </b></font> Dont Post any Site Link on wall otherwise your account will be blocked and you will not get any payout. </div>'; 

 
 $walls=mysqli_query("SELECT * FROM wall ORDER BY id DESC");

 $wall=mysqli_fetch_array($walls);
 
 
 $uidd=$wall['firstname'];
 

 if($uidd==none)

{ $uidd='<font color="blue">Admin</font>'; } 

 else
  { $uidd="$uidd"; } 
 
echo '<div class="shout"><font color="black"><b>'.$uidd.'</b></font><br/><img src="/images/qua.gif"> <font color="#006100"><b> '.$wall["body"].'</b></font><center><a href="/comments.php?id='.$wall["id"].'"><font color="black"><b>Reply!</b></font></a></center></div>'; 

$tips=mysqli_fetch_array(mysqli_query("SELECT * FROM sites WHERE userid='$uid'")); $tip=$tips["userid"];

 if(empty($tip)){ 

echo
 '<div class="shout"><img src="/images/tips.png" height="21" width="21"> <b> Tips : </b> You are one step away to start Earning from Your Website. Just Click on <b><font color="blue"> "Sites &amp; Ad Codes" </font></b> , Enter Your Site Details and then Click On <b><font color="blue"> "Ad Codes" </font></b> . Now Copy any Code from the box and Paste it on your Website. For better Earning use JavaScript AdCode. </div>';
}

$pin=mysqli_fetch_array(mysqli_query("SELECT * FROM pin WHERE userid='$uid'")); $pins=$pin["userid"];

 if(empty($pins)){ 
echo '<div align="center" class="error"> You Have not Create Your Secure pin <a href="/pin.php">Click here </a> To Create.</div>'; }

$ac=mysqli_fetch_array(mysqli_query("SELECT * FROM userdata WHERE id='$uid'")); 
$acc=$ac["city"];

 if($acc==put){ 
echo '<div align="center" class="error"> You Have not Complete Your Account Information <a href="/editaccount.php">Click here </a> To Complete.</div>'; }
echo 
 '<div class="line"> Account Panel </div>';
echo 
'<div class="catRow"><table><tbody><tr><td><img src="/images/arrow.png" alt="-"></td><td><b><a href="/myaccount"> Account Management </a></b><br><small> Change your Account Settings </small></td></tr></tbody></table></div>';
 
echo 
'<div class="catRow"><table><tbody><tr><td><img src="/images/arrow.png" alt="-"></td><td><b><a href="/reffer.php"> Invite &amp; Earn ( Affiliation ) </a></b><br><small> Get your referral link &amp; Earn </small></td></tr></tbody></table></div>';
echo 
'<div class="catRow"><table><tbody><tr><td><img src="/images/arrow.png" alt="-"></td><td><b><a href="/notifications.php"> Notifications</a></b><br><small> Check your notifications message from here </small></td></tr></tbody></table></div>';

echo'<div class="line"> Payments Panel </div>';
 echo 
'<div class="catRow"><table><tbody><tr><td><img src="/images/arrow.png" alt="-"></td><td><b><a href="/aprove.php"> Approved Balance </a></b><br><small> Transfer your earn money To Approved. </small></td></tr></tbody></table></div>';
 
echo 
'<div class="catRow"><table><tbody><tr><td><img src="/images/arrow.png" alt="-"></td><td><b><a href="/payout.php"> Request Payment </a></b><br><small> Request for payout your money </small></td></tr></tbody></table></div>';

 echo 
'<div class="catRow"><table><tbody><tr><td><img src="/images/arrow.png" alt="-"></td><td><b><a href="/aprovhistory.php"> Approved Balance History </a></b><br><small> Approved balance History.</small></td></tr></tbody></table></div>';
 
echo 
'<div class="catRow"><table><tbody><tr><td><img src="/images/arrow.png" alt="-"></td><td><b><a href="/invoices.php"> Payments History </a></b><br><small> Check your payments history </small></td></tr></tbody></table></div>';

 echo 
'<div class="catRow"><table><tbody><tr><td><img src="/images/arrow.png" alt="-"></td><td><b><a href="/convert.php?act=method">Currency Converter </a></b><br><small>Convert Your Currency.</small></td></tr></tbody></table></div>';
 

echo 
 '<div class="line"> CPC Panel(better for sites,blog) </div>';

echo 
'<div class="catRow"><table><tbody><tr><td><img src="/images/arrow.png" alt="-"></td><td><b><a href="/sites"> Publisher Sites &amp; Ad Codes </a></b><br><small> Manage Your Sites and Get Adcodes </small></td></tr></tbody></table></div>';

echo
'<div class="catRow"><table><tbody><tr><td><img src="/images/arrow.png" alt="-"></td><td><b><a href="/stats"> Earning &amp; Clicks Statics </a></b><br><small> Check your sites Click &amp; Earning Statics </small></td></tr></tbody></table></div>';
 
echo 


'<div class="line"> CPA Panel </div>';
echo
'<div class="catRow"><table><tbody><tr><td><img src="/images/arrow.png" alt="-"></td><td><b><a href="/cpa-rule.php"> Cpa rules </a></b><br><small> Rules and informations </small></td></tr></tbody></table></div>';
 echo 
'<div class="catRow"><table><tbody><tr><td><img src="/images/arrow.png" alt="-"></td><td><b><a href="/getcpa.php"> CPA Link </a></b><br><small> Earn By CPA. </small></td></tr></tbody></table></div>';
 
echo 
'<div class="catRow"><table><tbody><tr><td><img src="/images/arrow.png" alt="-"></td><td><b><a href="/cpareport.php"> CPA Report </a></b><br><small> See Your Conversion Report </small></td></tr></tbody></table></div>';

 echo '<div class="line"> CPI Panel </div>';
echo 
'<div class="catRow"><table><tbody><tr><td><img src="/images/arrow.png" alt="-"></td><td><b><a href="/apps/rule.php"> Apps Promotion Rules </a></b><br><small> Read Apps Rules Before Use. </small></td></tr></tbody></table></div>'; 

 echo 
'<div class="catRow"><table><tbody><tr><td><img src="/images/arrow.png" alt="-"></td><td><b><a href="/apps/promote.php">Promote 9Apps </a></b><br><small>Promote 9Apps Request For 9Apps.</small></td></tr></tbody></table></div>'; 
 
echo 
'<div class="catRow"><table><tbody><tr><td><img src="/images/arrow.png" alt="-"></td><td><b><a href="/apps/appslist.php"> Apps List Promotion Links </a></b><br><small>Appslist Get Promotion Links.</small></td></tr></tbody></table></div>'; 
 echo 
'<div class="catRow"><table><tbody><tr><td><img src="/images/arrow.png" alt="-"></td><td><b><a href="/apps/report.php"> Apps Installation Report </a></b><br><small>Get Apps Installation Promotion Reports.</small></td></tr></tbody></table></div>'; 
 

 
echo '<div class="line"> Advertiser Panel </div>';
echo 
'<div class="catRow"><table><tbody><tr><td><img src="/images/arrow.png" alt="-"></td><td><b><a href="/advertise"> Manage Advertises </a></b><br><small> Pause, Run, Delete  Your Advertisements </small></td></tr></tbody></table></div>';

echo
'<div class="catRow"><table><tbody><tr><td><img src="/images/arrow.png" alt="-"></td><td><b><a href="/gainadbalance.php"> Add Advertise fund </a></b><br><small> Add Balance in your Advertiser Balance</small></td></tr></tbody></table></div>';
echo
'<div class="catRow"><table><tbody><tr><td><img src="/images/arrow.png" alt="-"></td><td><b><a href="/cpcrate.php"> Advertising CPC Rates </a></b><br><small> Our advertise PPC Rates </small></td></tr></tbody></table></div>';
echo
'<div class="line"> Help &amp; Support Panel </div>';
echo
'<div class="catRow"><table><tbody><tr><td><img src="/images/arrow.png" alt="-"></td><td><b><a href="/support-ticket"> Suport Tickets </a></b><br><small> Create a Ticket to get help from Admin </small></td></tr></tbody></table></div>';
echo
'<div class="catRow"><table><tbody><tr><td><img src="/images/arrow.png" alt="-"></td><td><b><a href="/contact"> Contact US </a></b><br><small> Contact with US and Get Help </small></td></tr></tbody></table></div>'; 

echo '<div class="logout" align="center"><a href="/user/logout">Logout ('.ucfirst(dump_udata("firstname")).')</a></div>';
}
else {
header('Location:/');
}

include 'foot.php';

?>
