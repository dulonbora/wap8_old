<?php

	$users = "CREATE TABLE users (
				id INT NOT NULL AUTO_INCREMENT,
				username VARCHAR(120) NOT NULL,
				password VARCHAR(32) NOT NULL,
				email VARCHAR(200) NOT NULL,
				country VARCHAR(120) NOT NULL,
				status INT,
				pbal VARCHAR(255) NOT NULL,
				abal VARCHAR(255) NOT NULL,
				afbal VARCHAR(255) NOT NULL,
				regdate DATE,
				token VARCHAR(32) NOT NULL,
				pin VARCHAR(32) NOT NULL,
				mobile VARCHAR(22) NOT NULL,
				PRIMARY KEY(id)
			)";
	$admins = "CREATE TABLE admins (
				id INT NOT NULL AUTO_INCREMENT,
				admin VARCHAR(120) NOT NULL,
				password VARCHAR(32) NOT NULL,
				email VARCHAR(200) NOT NULL,
				role INT,			
				PRIMARY KEY(id)
			)";
	$ads = "CREATE TABLE ads (
				id INT NOT NULL AUTO_INCREMENT,
				name VARCHAR(120) NOT NULL,
				url VARCHAR(255) NOT NULL,
				type INT,
				adult INT,
				status INT,
				banners VARCHAR(2000) NOT NULL,
				titles VARCHAR(2000) NOT NULL,
				countrys VARCHAR(2000) NOT NULL,
				devices VARCHAR(2000) NOT NULL,
				date DATE,
				amount VARCHAR(255) NOT NULL,
				camount VARCHAR(255) NOT NULL,
				userid INT,
				PRIMARY KEY(id)
			)";
	$clicks = "CREATE TABLE clicks (
				id INT NOT NULL AUTO_INCREMENT,
				userid INT,
				siteid INT,
				amount VARCHAR(255) NOT NULL,
				campaign INT,
				ip VARCHAR(20) NOT NULL,
				ua VARCHAR(400) NOT NULL,
				country VARCHAR(120) NOT NULL,
				status INT,
				date DATE,
				ref VARCHAR(1000) NOT NULL,
				PRIMARY KEY(id)
			)";		
	$impressions = "CREATE TABLE impressions (
				id INT NOT NULL AUTO_INCREMENT,
				userid INT,
				siteid INT,
				date DATE,
				country VARCHAR(120) NOT NULL,
				adid INT,
				ip VARCHAR(20) NOT NULL,
				PRIMARY KEY(id)
			)";
	$invoices = "CREATE TABLE invoices (
				id INT NOT NULL AUTO_INCREMENT,
				invoice VARCHAR(20) NOT NULL,
				amount VARCHAR(255) NOT NULL,
				status INT,
				date DATE,
				userid INT,
				pdate DATE,
				method VARCHAR(200) NOT NULL,
				via VARCHAR(400) NOT NULL,
				payee_name VARCHAR(200) NOT NULL,
				PRIMARY KEY(id)
			)";
	$mail = "CREATE TABLE mail (
				noreply VARCHAR(200) NOT NULL,
				register VARCHAR(2000) NOT NULL,
				siteadd VARCHAR(2000) NOT NULL,
				adsadd VARCHAR(2000) NOT NULL,
				siteactive VARCHAR(2000) NOT NULL,
				adsactive VARCHAR(2000) NOT NULL,
				sitereject VARCHAR(2000) NOT NULL,
				adreject VARCHAR(2000) NOT NULL,
				userblock VARCHAR(2000) NOT NULL,
				invoicec VARCHAR(2000) NOT NULL,
				invoicep VARCHAR(2000) NOT NULL,
				pwreset VARCHAR(2000) NOT NULL,
				pin VARCHAR(2000) NOT NULL,
				name VARCHAR(200) NOT NULL
				
			)";
	$news = "CREATE TABLE news (
				id INT NOT NULL AUTO_INCREMENT,
				adminid INT,
				title VARCHAR(200) NOT NULL,
				message VARCHAR(5000) NOT NULL,
				date DATE,
				views INT,
				PRIMARY KEY(id)
			)";
	$notifications = "CREATE TABLE notifications (
				id INT NOT NULL AUTO_INCREMENT,
				userid INT,
				subject VARCHAR(200) NOT NULL,
				message VARCHAR(5000) NOT NULL,
				date DATE,
				status INT,
				PRIMARY KEY(id)
			)";
	$nreply = "CREATE TABLE nreply (
				id INT NOT NULL AUTO_INCREMENT,
				nid INT,
				userid INT,
				reply VARCHAR(5000) NOT NULL,
				date DATE,
				PRIMARY KEY(id)
			)";
	$payout = "CREATE TABLE payout (
				id INT NOT NULL AUTO_INCREMENT,
				name VARCHAR(200) NOT NULL,
				payee_name VARCHAR(200) NOT NULL,
				via VARCHAR(255) NOT NULL,
				amount VARCHAR(255) NOT NULL,
				status INT,
				PRIMARY KEY(id)
			)";
	$refer = "CREATE TABLE refer (
				id INT NOT NULL AUTO_INCREMENT,
				ref INT,
				userid INT,
				date DATE,
				status INT,
				amount VARCHAR(255) NOT NULL,
				PRIMARY KEY(id)
			)";
	$settings = "CREATE TABLE settings (
				sitename VARCHAR(500) NOT NULL,
				siteurl VARCHAR(255) NOT NULL,
				template VARCHAR(255) NOT NULL,
				minimumcpc VARCHAR(255) NOT NULL,
				adbanners INT,
				sitetitle VARCHAR(500) NOT NULL,
				impressions INT,
				sitecats VARCHAR(1000) NOT NULL,
				invalid_clicks INT,
				redirurl VARCHAR(500) NOT NULL,
				refamount VARCHAR(255) NOT NULL,
				refer INT,
				htmlads INT,
				reftrack INT,
				news INT,
				mweb INT,
				webtemp VARCHAR(255) NOT NULL,
				spamdomains VARCHAR(1000) NOT NULL
			)";
	$sites = "CREATE TABLE sites (
				id INT NOT NULL AUTO_INCREMENT,
				userid INT,
				name VARCHAR(500) NOT NULL,
				url VARCHAR(255) NOT NULL,
				description VARCHAR(500) NOT NULL,
				adult INT,
				status INT,
				regdate DATE,
				category VARCHAR(200) NOT NULL,
				PRIMARY KEY(id)
			)";	
	$country = "CREATE TABLE country (
				id int(10) unsigned auto_increment, 
				begin_ip varchar(20),end_ip varchar(20),
				begin_ip_num int(11) unsigned,
				end_ip_num int(11) unsigned,
				country_code varchar(3),
				country_name varchar(150), 
				PRIMARY KEY(id),
				INDEX(begin_ip_num,end_ip_num)
				)";
?>			
				