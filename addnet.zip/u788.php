<script>
window.location.href="http://down3.ucweb.com//down1/dineshkumar1/user788/com.nineapps_v3.0.1_android_(Build16061749).apk";
</script>
