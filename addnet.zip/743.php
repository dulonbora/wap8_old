
Run »
<!DOCTYPE html>
<html>
<body>
​
<p>Click the button to display an alert box:</p>
​
<button onclick="myFunction()">Try it</button>
​
<script>
function myFunction() {
    alert("I am an alert box!");
}
</script>
​
</body>
</html>
​
 

