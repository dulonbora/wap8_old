<?php


include 'db.php';
include 'functions.php';

headtag("Bank Payment Proofs - $SiteName");

echo '<div class="title">Bank Proofs</div>';

$page=formget("page");

if(empty($page)){
$page=0;
}
$start=$page*1;
$end=($start+10);


$bk=mysqli_query("SELECT * FROM bank WHERE status LIKE 'Paid%' ORDER BY id DESC LIMIT $start,$end");
 while($shows=mysqli_fetch_array($bk)){

$amt=$shows["amount"];
$umt=($amt/60);

echo '<div class="proof"><b>Invoice ID:</b> <span style="background: green;padding: 1px 6px;font-size: 14px;font-weight: bold;color: #FF0000;margin: 0px 0px;border-radius: 40px;"><font color="white"> #BANKINV'.$shows["id"].'</font></span><br/><b>Amount : </b><b id="num">'.$amt.' Rs</b><br/><b>Method : </b> '.$shows["method"].'<br/> <b>Holder Name : </b> '.$shows["holder"].'<br/> <b>Bank Name : </b> '.$shows["bname"].'<br/> <b>Ifsc Code : </b> '.$shows["ifscode"].'<br/> <b>Account No. : </b> '.substr($shows["via"],0,4).'******<br/><b>Status : <font color="green">'.$shows["status"].'</font></b></div>';

 
}

echo '<br/><center><spam class="error"><a href="/bank-proof?page='.($start-1).'">Prev</a></spam><spam class="success"><a href="/bank-proof?page='.($start+1).'">Next</a></spam></center><br/>';

echo '<div class="back"><a href="/">Go Back To Home</a></div>';

include 'foot.php';
