<?php


include 'db.php';
include 'functions.php';

headtag("Payment Proofs - $SiteName");

echo '<div class="title">Payments by User</div>';

$page=formget("page");

if(empty($page)){
$page=0;
}
$start=$page*1;
$end=($start+10);

$getData=mysqli_query("SELECT * FROM bank WHERE status LIKE '%Paid (%' ORDER BY id DESC LIMIT $start,$end");

while($fetchData=mysqli_fetch_array($getData)){
echo '<div class="proof"><b>Invoice ID: </b> INV'.$fetchData["id"].'<br/><b>Amount : </b><b id="num">'.$fetchData["amount"].'$</b><br/><b>Method : </b> '.$fetchData["method"].'<br/><b>Via : </b> '.substr($fetchData["via"],0,4).'******<br/><b>Requested On : </b> '.$fetchData["time"].'<br/><b>Status : </b> <font color="green">'.$fetchData["status"].'</font></div>';
}

echo '<br/><center><spam class="error"><a href="/payments-proof/'.($start-1).'">Prev</a></spam><spam class="success"><a href="/payments-proof/'.($start+1).'">Next</a></spam></center><br/>';

echo '<div class="back"><a href="/">Go Back To Home</a></div>';

include 'foot.php';
?>