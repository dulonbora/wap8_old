<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - Apps Promoting");

echo '<div class="line"> Apps Promotion Rule </div>'; echo 
'<div class="right"><b><font color="red"> Apps Promotion Rule : </font></b></div>'; echo 
'<div class="pleft"> 1. <b> If you have A Own Web/Wap Site then you can use this service, we allow Non Adult and Adult both sites. </b></div>
<div class="pleft"> 2.  Non adult site without
<b> Real Contents </b> are not allowed. </div>'; echo 
'<div class="pleft"> 3.  Adult site without
<b> Real Contents </b> are allowed. </div>'; echo 
'<div class="pleft"> 4.  We will give you daily installation report on your dashboard. </div>'; echo 
'<div class="pleft"> 5.  Earned money will be autometically added on your Account Balance on the next day. </div>'; echo 
'<div class="pleft"> 6.  Minimum payout amount is 10 Rs via Recharge. </div>'; echo 
'<div class="pleft"> 7.  Payment through our site same as Our Payment methods. </div>'; echo 
'<div class="pleft"> 8. <b> Note : </b> You can change our <b> Banners and Text </b> of our Apps Promotion Adcode. </div>'; echo 
'<div class="line"> Available Apps List </div>';
echo '<div class="proof"><img src="http://adzstar.in/banners/apps/9apps/logo.jpg" width="60px" height="60px"><br><b> App Name: </b> <font color="blue"> 9apps - APK </font> ( <font color="green"> Running </font> )
<br><b> Link Type: </b> <small> Direct Link </small><br><b> Platform: </b>
<small> Android</small><br><b> GEO: </b>
<small> India </small><br><b> Size: </b>
<small> 1.09 MB </small><br><b> CPI Rate: </b> <b class="fig"> 0.18$ </b><br></div>'; echo '<div class="proof"><img src="http://adzstar.in/banners/apps/uc/logo.jpg" width="60px" height="60px"><br><b> App Name: </b>
<font color="blue"> UC Browser - APK </font> (<font color="green"> Running</font> )
<br><b> Link Type: </b> <small> Direct Link </small><br><b> Platform: </b>
<small> Android</small><br><b> GEO: </b>
<small> India </small><br><b> Size: </b>
<small> 1.3 MB </small><br><b> CPI Rate: </b> <b class="fig"> 0.15$ </b><br></div>';
echo '<div class="proof"><img src="http://adzstar.in/banners/apps/moboplay/logo.jpg" width="60px" height="60px"><br><b> App Name: </b> <font color="blue"> Moboplay - APK</font> ( <font color="green"> Running </font> ) <br><b> Link Type: </b> <small> Google Playstore</small><br><b> Platform:</b>
<small> Android</small><br><b> GEO: </b>
<small> India </small><br><b> Size: </b>
<small> 2 MB </small><br><b> CPI Rate: </b>
<b class="fig"> 0.12$ </b><br></div><div class="proof"><img src="http://adzstar.in/banners/apps/paytm/logo.png" width="60px" height="60px"><br><b> App Name: </b>
<font color="blue"> Paytm - GP </font> ( <font color="green"> Running</font> )<br><b> Link Type: </b> <small> Google Playstore </small><br><b> Platform: </b>
<small> Android</small><br><b> GEO: </b>
<small> India </small><br><b> Size: </b>
<small> 7.9 MB </small><br><b> CPI Rate: </b> <b class="fig"> 0.5$ </b><br></div><div class="proof"><img src="http://adzstar.in/banners/apps/hotvideo/logo.png" width="60px" height="60px"><br><b> App Name: </b> <font color="blue"> Hot video - APK</font> ( <font color="green"> Running </font> ) <br><b> Link Type: </b> <small> Direct Link</small><br><b> Platform:</b>
<small> Android</small><br><b> GEO: </b>
<small> India </small><br><b> Size: </b>
<small> 4.1 MB </small><br><b> CPI Rate: </b> <b class="fig"> 0.08$ </b><br></div>'; echo '<div class="proof"><img src="http://adzstar.in/banners/apps/apus/logo.png" width="60px" height="60px"><br><b> App Name: </b>
<font color="blue"> APUS Launcher-APK-Global </font> ( <font color="green"> Running </font> ) <br><b> Link Type: </b> <small> Direct Link</small><br><b> Platform:</b>
<small> Android</small><br><b> GEO: </b>
<small> India </small><br><b> Size: </b>
<small> 3.9 MB </small><br><b> CPI Rate: </b> <b class="fig"> 0.14$ </b><br></div>'; echo '<div class="proof"><img src="http://adzstar.in/banners/apps/loopgame/logo.png" width="60px" height="60px"><br><b> App Name: </b> <font color="blue"> Loop Game-APK-Tier 3 </font> (<font color="green"> Running</font> )<br><b> Link Type: </b> <small> Direct Link </small><br><b> Platform: </b>
<small> Android</small><br><b> GEO: </b>
<small> India </small><br><b> Size: </b>
<small> 4.8 MB </small><br><b> CPI Rate: </b> <b class="fig"> 0.2$ </b><br></div>';

echo '<div class="back"><img src="/home.png"> <a href="/">Home</a></div>';

include 'foot.php';
?>