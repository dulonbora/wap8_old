<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - Password retrieval");
  

if($userlog==1){
   header('Location:/user/dashboard');
}

else {

 if(isset($_GET['email']) AND isset($_GET['token'])){
    $user_email=formget("email");
    $token=formget("token");
    
    $errors=array();
    
    $check_im=mysqli_query("SELECT * FROM passret WHERE email='$user_email'");

    if(mysqli_num_rows($check_im)<1){
      $errors[]='Email not found!';
    }

    if(mysqli_num_rows($check_im)>0){
      $chkdata=mysqli_fetch_array($check_im);
      if($chkdata['token']!=$token){
         $errors[]='Link Expired!';
       }


    if(empty($errors)){


    if(isset($_POST['newpwd1']) AND isset($_POST['newpwd2'])){
       $newpwd1=formpost("newpwd1");
       $newpwd2=formpost("newpwd2");
       $captcha=formpost("captcha");
       $errs=array();

     if(strlen($newpwd1)<1){
        $errs[]='Password left empty!';
       }
 
     if(strlen($newpwd2)<1){
        $errs[]='Verify password left empty!';
        }
      
     if($newpwd1!=$newpwd2){
       $errs[]='Passwords didn\'t match!';
        }
     if($captcha!=$_SESSION['captcha']){
       $errs[]='Image code was wrong!';
        }

     if(empty($errs)){
     
      $newpwd=md5($newpwd1);
      
       $doit=mysqli_query("UPDATE userdata SET password='$newpwd' WHERE email='$user_email'");
       
       if($doit){
          echo '<div class="success"><img src="/success.png"/> Password successfully changed! Please <a href="/">login</a>.</div>';
       }
       else {
          echo '<div class="error"><img src="/error.png"/> Something was wrong!</div>';
       }

      }
      else {
       dump_error($errs);
       }
      }
    echo '<div class="title">Reset Password</div>';
    echo '<div class="form"><form method="post">New Password:<br/><input type="text" name="newpwd1"/><br/>Confirm new password:<br/><input type="text" name="newpwd2"/><br/>Captcha:<br/><img src="/im'.md5(microtime()).'.jpg" alt="Loading.."/><br/>Input the characters showing in image!<br/><input type="text" name="captcha"/><br/><input type="submit" value="Change Password"/></form></div>';
    echo '<div class="ad"><img src="/home.png"/><a href="/">Home</a></div>';
  }
  else {
   dump_error($errors);
   }
  }
}
}
include 'foot.php';

?>
    
      
       
