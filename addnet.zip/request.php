<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - Payout Request");


if($userlog==1){

$uid=dump_udata("id");

echo '<div class="title">Payout Request</div>';

$method=formget("method");

if($method=='recharge'){
 
 if(dump_udata("pubalance")<0.20){
 echo '<div class="error">Your account balance is '.dump_udata("pubalance").'$! Which is lower than our minimum payment amount (1$). Please earn more and then request payout!</div>';
 }
else 
if(isset($_POST["amount"]) AND isset($_POST["via"]) AND isset($_POST["captcha"]) AND isset($_POST["name"])){

$amount=formpost("amount");
$via=formpost("via");
$captcha=formpost("captcha");
$name=formpost("name");
$errors=array();

if(!is_numeric($amount)){
  $errors[]='Amount must be a numeric value!';
 }


if(strlen($amount)<1){
  $errors[]='Amount cannot be empty!';
 }


if($_SESSION["captcha"]!=$captcha){
$errors[]='Captcha Code was wrong!';
}
if(strlen($via)<1){
  $errors[]='Mobile Number cannot be empty!';
 }

if($amount>dump_udata("pubalance")){
  $errors[]='Amount is bigger than account balance!';
}

if(empty($errors)){
  $date=date("l , F d , Y"); 
  $doit=mysqli_query("INSERT INTO invoice (userid,amount,method,via,status,time,name) VALUES ('$uid','$amount','Recharge','$via','PENDING','$date','$name')");
  $newbal=(dump_udata("pubalance")-$amount);
  $minusb=mysqli_query("UPDATE userdata SET pubalance='$newbal' WHERE id='$uid'");
  if($doit AND $minusb){
   echo '<div class="success">Your Payment Invoice successfully Created and will be paid soon!</div>';
  }
  else {
   echo '<div class="error">Error creating invoice!</div>';
}

}
else {

dump_error($errors);

}
}
echo '<div class="form"><form method="post">Amount (Min. $1. Max. '.dump_udata("pubalance").'$)<br/><input type="text" name="amount"/><br/>Name:<br/><input type="text" name="name"/><br/>Mobile Number:<br/><input type="text" name="via"/><br/> Operator: <br/><select name="operator" style="width:170px"><option value="Airtel"> Airtel</option><option value="Aircel"> Aircel</option><option value="BSNL"> BSNL</option><option value="BSNL Special"> BSNL Special </option><option value="Idea"> Idea</option><option value="Vodafone"> Vodafone </option><option value="Docomo Topup"> Docomo Topup </option><option value="Docomo Special"> Docomo Special </option><option value="Tata Indicom"> Tata Indicom </option><option value="Reliance GSM"> Reliance GSM </option><option value="Reliance CDMA"> Reliance CDMA </option><option value="MTS"> MTS </option><option value="Telenor"> Telenor </option><option value="Telenor Special"> Telenor Special </option><option value="Loop Mobile"> Loop Mobile </option><option value="Videocon"> Videocon</option><option value="Videocon Special"> Videocon Special </option><option value="MTNL Delhi"> MTNL Delhi </option><option value="MTNL Delhi Special"> MTNL Delhi Special </option><option value="MTNL Mumbai"> MTNL Mumbai </option><option value="MTNL Mumbai Special"> MTNL Mumbai Special </option><option value="Tata Walky"> Tata Walky</option></select> <br/>Captcha:<br/><img src="/im'.md5(microtime()).'.jpg"/><br/>Input the characters showing in image!<br/><input type="text" name="captcha"/><br/><input type="submit" value="Request Now"/></form></div>'; 

}
//end recharge

 if($method=='amoney'){
 
 if(dump_udata("pubalance")<1.00){
 echo '<div class="error">Your account balance is '.dump_udata("pubalance").'$! Which is lower than our minimum payment amount (1$). Please earn more and then request payout!</div>';
 }
else 
if(isset($_POST["amount"]) AND isset($_POST["via"]) AND isset($_POST["captcha"]) AND isset($_POST["name"])){

$amount=formpost("amount");
$via=formpost("via");
$captcha=formpost("captcha");
$name=formpost("name");
$errors=array();

if(!is_numeric($amount)){
  $errors[]='Amount must be a numeric value!';
 }


if(strlen($amount)<1){
  $errors[]='Amount cannot be empty!';
 }


if($_SESSION["captcha"]!=$captcha){
$errors[]='Captcha Code was wrong!';
}
if(strlen($via)<1){
  $errors[]='Number cannot be empty!';
 }

if($amount>dump_udata("pubalance")){
  $errors[]='Amount is bigger than account balance!';
}

if(empty($errors)){
  $date=date("l , F d , Y"); 
  $doit=mysqli_query("INSERT INTO invoice (userid,amount,method,via,status,time,name) VALUES ('$uid','$amount','Airtel Money','$via','PENDING','$date','$name')");
  $newbal=(dump_udata("pubalance")-$amount);
  $minusb=mysqli_query("UPDATE userdata SET pubalance='$newbal' WHERE id='$uid'");
  if($doit AND $minusb){
   echo '<div class="success">Your Airtel Money Request successfully Created and will be paid soon!</div>';
  }
  else {
   echo '<div class="error">Error creating invoice!</div>';
}

}
else {

dump_error($errors);

}
}
echo '<div class="form"><form method="post">Amount (Min. $1. Max. '.dump_udata("pubalance").'$)<br/><input type="text" name="amount"/><br/>Name:<br/><input type="text" name="name"/><br/>Airtel Number:<br/><input type="text" name="via"/><br/>Captcha:<br/><img src="/im'.md5(microtime()).'.jpg"/><br/>Input the characters showing in image!<br/><input type="text" name="captcha"/><br/><input type="submit" value="Request Now"/></form></div>'; 

}
//end amoney 
 if($method=='paytm'){
 
 if(dump_udata("pubalance")<1.00){
 echo '<div class="error">Your account balance is '.dump_udata("pubalance").'$! Which is lower than our minimum payment amount (1$). Please earn more and then request payout!</div>';
 }
else 
if(isset($_POST["amount"]) AND isset($_POST["via"]) AND isset($_POST["captcha"]) AND isset($_POST["name"])){

$amount=formpost("amount");
$via=formpost("via");
$captcha=formpost("captcha");
$name=formpost("name");
$errors=array();

if(!is_numeric($amount)){
  $errors[]='Amount must be a numeric value!';
 }


if(strlen($amount)<1){
  $errors[]='Amount cannot be empty!';
 }


if($_SESSION["captcha"]!=$captcha){
$errors[]='Captcha Code was wrong!';
}
if(strlen($via)<1){
  $errors[]='Number cannot be empty!';
 }

if($amount>dump_udata("pubalance")){
  $errors[]='Amount is bigger than account balance!';
}

if(empty($errors)){
  $date=date("l , F d , Y"); 
  $doit=mysqli_query("INSERT INTO invoice (userid,amount,method,via,status,time,name) VALUES ('$uid','$amount','Paytm Transfer','$via','PENDING','$date','$name')");
  $newbal=(dump_udata("pubalance")-$amount);
  $minusb=mysqli_query("UPDATE userdata SET pubalance='$newbal' WHERE id='$uid'");
  if($doit AND $minusb){
   echo '<div class="success">Your Paytm Transfer Request successfully Created and will be paid soon!</div>';
  }
  else {
   echo '<div class="error">Error creating request!</div>';
}

}
else {

dump_error($errors);

}
}
echo '<div class="form"><form method="post">Amount (Min. $1. Max. '.dump_udata("pubalance").'$)<br/><input type="text" name="amount"/><br/>Name:<br/><input type="text" name="name"/><br/>Paytm Mobile Number:<br/><input type="text" name="via"/><br/>Captcha:<br/><img src="/im'.md5(microtime()).'.jpg"/><br/>Input the characters showing in image!<br/><input type="text" name="captcha"/><br/><input type="submit" value="Request Now"/></form></div>'; 

}
//end paytm 

//end userlog

echo '<div class="back"><img src="/home.png"/> <a href="/">Home</a> | <a href="/user/dashboard">Dashboard</a></div>';

include 'foot.php';


}
else {

header('Location:/');

}

?>
