<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName News details");



$nid=formget("id");


$news=mysqli_fetch_array(mysqli_query("SELECT * FROM news WHERE id='$nid'"));
$newsr=mysqli_query("SELECT * FROM newsreplys WHERE newsid='$nid'");


echo '<div class="title">News #'.$nid.' ('.$news["time"].')</div>';
echo '<div class="form"><b>'.$news["title"].'</b><br/>'.$news["body"].'</div>';
echo '<div class="title">Replys</div>';

while($snews=mysqli_fetch_array($newsr)){
$uidd=$snews["userid"];
if($uidd==0){
$uidd='ADMINISTRATOR';
}
else {
$uidd="USER#$uidd";
}
echo '<div class="ad"><b>Reply #'.$snews["id"].'</b><br/>'.$snews["msg"].'<br/><br/>By: '.$uidd.'</div>';
}
if($userlog==1){
$uid=dump_udata("id");
if(isset($_POST['reply']) AND isset($_POST['captcha'])){
$reply=formpost("reply");
if(strlen($reply)<1){
echo 'empty field!';
exit;
}
if($_SESSION['captcha']!=$_POST['captcha']){
echo 'captcha err!';
exit;
}

$addreply=mysqli_query("INSERT INTO newsreplys (userid,msg,newsid) VALUES ('$uid','$reply','$nid')");
if($addreply){
echo '<div class="success">Reply has added!</div>';
}
else {
echo 'unk';
}
}

echo '<div class="form"><b>Add reply:</b><br/><form method="post"><textarea name="reply"></textarea><br/>Captcha:<br/><img src="/im'.md5(microtime()).'.jpg"/><br/>Input words from image!<br/><input type="text" name="captcha"/><br/><input type="submit" value="Reply"/></form></div>';
}
else {
echo '<div class="error">You have to login to reply!</div>';
}

echo '<div class="ad"><a href="/">HOME</a></div>';
include 'foot.php';

?>
