<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - Publisher");

echo '<div class="title">Publishers:</div>';

echo '<div class="form"><b>Discover our world class mobile advertising platform</b><br/>



    * Register for FREE.
    <br/>* Support Brand, Device and Platform Targeting.
    <br/>* Support Country and Telco Targeting.
    <br/>* Tweak and monitor your ad campaign from your mobile.
    <br/>* Comprehensive reporting.
    <br/>* Email alert.
    <br/>* Control daily budget.
    <br/>* 24/7 Online support.


<br/><a href="/user/registration">Start Advertising Now!</a></div>';


echo '<div class="ad"><img src="/home.png"/> <a href="/">HOME</a></div>';
include 'foot.php';

?>
