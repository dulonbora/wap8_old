<?php


include 'db.php';
include 'functions.php';

headtag("Paytm Payment Proofs - $SiteName");

echo '<div class="title">Paytm  Proofs</div>';

$page=formget("page");

if(empty($page)){
$page=0;
}
$start=$page*1;
$end=($start+10);


$getData=mysqli_query("SELECT * FROM invoice WHERE status LIKE 'Paid%' AND name='Paytm' ORDER BY id DESC LIMIT $start,$end");


while($fetchData=mysqli_fetch_array($getData)){
$name=$fetchData["name"];
if($name=='Paytm') {
$amt=$fetchData["amount"];
$umt=($amt/60);
echo '<div class="proof"><b>Invoice ID:</b> <span style="background: green;padding: 1px 6px;font-size: 14px;font-weight: bold;color: #FF0000;margin: 0px 0px;border-radius: 40px;"><font color="white"> #INV'.$fetchData["id"].'</font></span><br/><b>Amount : </b><b id="num">'.$amt.' Rs</b><br/><b>Method : </b> '.$fetchData["method"].'<br/><b>Number:</b> '.substr($fetchData["via"],0,4).'******<br/><b>Status : <font color="green">'.$fetchData["status"].'</font></b></div>';
}
}

echo '<br/><center><spam class="error"><a href="/paytm-proof.php?page='.($start-1).'">Prev</a></spam><spam class="success"><a href="/paytm-proof.php?page='.($start+1).'">Next</a></spam></center><br/>';

echo '<div class="back"><a href="/">Go Back To Home</a></div>';

include 'foot.php';
