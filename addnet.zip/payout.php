<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include 'db.php';
include 'functions.php';

headtag("$SiteName - Request Payout");

if($userlog==1){

include 'head.php';

echo '<div class="title">Request Payout</div>';
echo '<div class="catRow"><table><tbody><tr><td><img src="/images/arrow.png" alt="-"></td><td><b><a href="/Recharge.php"> Mobile Recharge </a> ( India )
</b><br><small> Payout your balance via recharge system Within Few Mints. </small></td></tr></tbody></table></div>'; 
echo '<div class="catRow"><table><tbody><tr><td><img src="/images/arrow.png" alt="-"></td><td><b><a href="/airtel-money.php"> AirTel Money </a> ( India ) </b><br><small> Payout your balance via Airtel money payment system Within 48 Hour. </small></td></tr></tbody></table></div>'; 

 
echo '<div class="catRow"><table><tbody><tr><td><img src="/images/arrow.png" alt="-"></td><td><b><a href="/bank-request.php"> Bank Transfer </a> ( India ) </b><br><small> Payout your balance via Bank Transfer payment system Within 72 Hour. </small></td></tr></tbody></table></div>'; 

 
echo '<div class="catRow"><table><tbody><tr><td><img src="/images/arrow.png" alt="-"></td><td><b><a href="/paytm.php"> Paytm Transfer </a> ( India ) </b><br><small> Payout your balance via Paytm Wallet Transfer payment system Within 72 Hour. </small></td></tr></tbody></table></div>'; 

 echo '<br/><div class="back"><img src="/home.png"/> <a href="/">Home</a> | <a href="/user/dashboard">Dashboard</a></div>';
 
 include 'foot.php';

}

?>
