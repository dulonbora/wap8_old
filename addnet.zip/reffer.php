<?php
/************************************
Script : Adnetwork Website : http://facebook.com/pranto007
Script is created and provided by Pranto (http://facebook.com/pranto007) **************************************/
include 'db.php'; 

include 'functions.php';

headtag("$SiteName - Reffer System");
if($userlog==1){
include 'head.php';




echo
 '<div class="line"> Refferral System </div>';
echo '<div class="uright"> - <b> Share Below Link With Your Friends &amp; Earn 0.10$ Per Affiliate if They make first payout from Us. </b><br>
- Dont Register More Than 1 id by yourself (You Do not Get Money And You Get Blocked). <br/>
- We Will Automaticaly Add Referal Balance When Referred User will get his/her first Payment from Us. <br/>
- All refereed friends will be shown Here after validation by Admin. </div><br/>'; 

echo 
'<div class="line"> Your Affiliate Link</div><br/>';

 echo 
'<div class="line"> Direct Link </div>'; 

echo 
'<div class="catRow">
<textarea cols="40" rows="2"> http://mydearads.in/register.php?ref='.$uid.' </textarea></div>
<div class="borderline"></div>';

 echo 
'<div class="line"> Direct Text Link </div>'; 

echo 
'<div class="catRow">
<textarea cols="40" rows="3"> <a href="http://mydearads.in/register.php?ref='.$uid.'">Join Mydearads.in and Earn 100$ Per Day. </a></textarea></div>'; 

echo 
'<div class="borderline"></div>';

 echo 
'<div class="line"> HTML Banner Link </div>';


 echo '<div class="catRow">
<textarea cols="40" rows="4"> <a href="http://mydearads.in/register.php?ref='.$uid.'"><img src="http://mydearads.in/web/logo.png" alt="Join Now"/></a></textarea></div>'; echo 
'<div class="borderline"></div>';

 echo 
'<div class="line"> Your Validated Affiliate Summary</div>';

$refs=mysqli_num_rows(mysqli_query("SELECT * FROM affiliates WHERE aid='$uid' AND status='VALID'"));

$refs=$refs["VALID"]; if(empty($refs)){ $refs=0; }

echo '<br/><div class="ref"> Your Refered Valided Users! <b id="num"> '.$refs.'</b><br/></div><br/>'; 



 echo '<div class="back"><img src="/home.png"/> <a href="user/dashboard">Back To Dashboard</a></div>';


include 'foot.php'; } 

else {
header('Location:/'); 

} 

?>