<?php
/************************************
Script : Adnetwork Website : http://facebook.com/pranto007
Script is created and provided by Pranto (http://facebook.com/pranto007) **************************************/
include 'db.php'; 

include 'functions.php';

headtag("$SiteName - Cpa campaign Adcode");
if($userlog==1){
include 'head.php';




echo
 '<div class="line"> Cpa Campaign Adcode </div>';


 echo 
'<div class="line"> JavaScript Popounder Code Better Earnings </div>'; 

echo 
'<div class="catRow">
<textarea><script type="text/javascript" src="http://adzincome.in/cpa-js.php?uid='.$uid.'"></script></textarea></div>'; 


 echo 
'<div class="line"> Direct Link </div>'; 

echo 
'<div class="catRow">
<textarea> http://adzincome.in/cpa-campaign.php?uid='.$uid.' </textarea></div>
<div class="borderline"></div>';

 echo 
'<div class="line"> Direct Text Link </div>'; 

echo 
'<div class="catRow">
<textarea> <a href="http://adzincome.in/cpa-campaign.php?uid='.$uid.'">Click Here To Download</a></textarea></div>'; 



 echo '<div class="back"><img src="/home.png"/> <a href="user/dashboard">Back To Dashboard</a></div>';


include 'foot.php'; 
} 

else {
header('Location:/'); 

} 

?>