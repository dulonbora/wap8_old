<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName Dashboard");


if($userlog==1){

include 'head.php';
 
$uid=dump_udata("id");

$d=date("d");

echo '<div class="title">Showing Stats of '.date("F, Y").'</div><br/>';


echo '<table style="border-collapse:collapse;text-align:center;" align="center" height="60" border="1" bordercolor="#5b8ebb" cellpadding="5" width="90%">
<tbody><tr style="background-color:#5b8ebb">
<th height="28"> Date </th>
<th> Cpc </th>
<th> Clicks</th>
<th> Earning</th>
</tr><tr bgcolor="#e8e8e8">';

for($i=$d;$i>0;$i--){

if(strlen($i)==1){
 $i="0$i";
}

$datee=date("".$i."-m-Y");

$imps=mysql_fetch_array(mysql_query("SELECT * FROM imp WHERE uid='$uid' AND date='$datee'"));
$imp=$imps["imp"];
if(empty($imp)){
$imp=0;
}


$cp=mysql_fetch_array(mysql_query("SELECT * FROM advertises WHERE userid='604' AND status='RUNNING'"));

$cpcc=$cp["ucpc"];


$clicks=mysql_num_rows(mysql_query("SELECT * FROM clicks WHERE userid='$uid' AND time='$datee' AND status='VALID'"));
$ctr=($clicks/$imp)*100;
$earn=($clicks*$cpcc);

echo '<tr bgcolor="#e8e8e8"> 
<td>'.$datee.'</td>
<td><b id="num">'.$cpcc.' $</b></td>
<td><b id="num">'.$clicks.'</b></td>
<td><b id="num">'.$earn.' $</b></td>
</tr>';

}
$timps=mysql_query("SELECT * FROM imp WHERE uid='$uid'");
$timp=0;

while($tshow=mysql_fetch_array($timps)){
$timp=($timp+$tshow['imp']);
}
$tclicks=mysql_num_rows(mysql_query("SELECT * FROM clicks WHERE userid='$uid' AND status='VALID'"));
$tctr=($tclicks/$timp)*100;
$tearn=($tclicks*0.009);

echo '<tr bgcolor="#bfc2c5"> 
<td height="28">Total</td>
<td><b id="num">0.009$</b></td>
<td><b id="num">'.$tclicks.'</b></td>
<td><b id="num">'.$tearn.' $</b></td>
</tr>';

echo '



</table>';

echo '<br/><div class="back"><img src="/home.png"/> <a href="/">Home</a> | <a href="/user/dashboard">Dashboard</a></div>';

include 'foot.php';

}
else {
header('Location:/');
}
?>
