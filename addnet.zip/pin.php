<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - create new pin");

if($userlog==1){


include 'head.php';

 $uid=dump_udata("id");

 echo '<div class="title">Create new pin</div>';

$get=mysqli_query("SELECT * FROM pin WHERE userid='$uid'");
$number=mysqli_num_rows($get);

if(empty($number)){

 if(isset($_POST["other"])){

    $other=formpost("other");
   
    if(empty($errors)){
       $addnote=mysqli_query("INSERT INTO msgs (rid,body,status) VALUES ('$uid','You Have successfully created New pin.','New')");
 $add=mysqli_query("INSERT INTO pin (userid,other) VALUES ('$uid','$other')");
       if($add){
        echo '<br/><div class="success"><b>New Pin successfully created!</b></div><br/>';
       }
       else {
         echo '<div class="error">Unknown error creationg pin!</div>';
       }
    }
    else {
     dump_error($errors);
    }
   }
  echo '<div class="notice"> You have to memorized your pin forever. </div><div class="notice"> Without pin you can not request for payment. </div><div class="notice"> Create Your Pin For Secure Your Account. </div><div class="notice"> Remember you can recover your pin only by your email. </div>'; echo '<div class="form"><form method="post">Create New 5 Digit Pin:<br/><input type="text" name="other" maxlength="5"/><br/><input type="submit" value="Create Pin"/></form></div>';
 

}

else { echo '<br/><div class="error"> You Have Already Created Secure Pin.</div>'; }

 echo '<br/><div class="back"><img src="/home.png"/> <a href="/">Home</a> | <a href="/myaccount">My Account</a></div>';
  
 include 'foot.php';

}

else {

header('Location:/');
}

?>
