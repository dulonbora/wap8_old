<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - Convert Currency");

echo '<div class="title">Convert Currency</div>';

 
$act=formget("act"); 

if($act=='convert') 
{ 
echo '<div class="catRow"><img src="/images/arrow.png"/> <a href="?act=rs2dollar">Rupees to dollar</a></div>';

echo '<div class="catRow"><img src="images/arrow.png"/> <a href="?act=dollar2rs">Dollar to Rupees</a></div>';
}
//end convert 
 
echo '<br/><div class="back"><img src="/home.png"> <a href="/">Back To Home</a></div>';

include 'foot.php';
?>