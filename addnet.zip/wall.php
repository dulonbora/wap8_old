<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include 'db.php';
include 'functions.php';

headtag("$SiteName - Wall Service");

if($userlog==1){

include 'head.php';

echo '<div class="title">Wall Service</div> <div class="ok"><font color="red"> Warning: </font> Dont Post any site link on wall otherwise you will be blocked from wall. </div>';

$wallb=mysqli_query("SELECT * FROM wall WHERE userid='$uid' AND status='blocked'");
 
 while($wallb=mysqli_fetch_array($wallb)){
$bwall=$wallb["status"];
}

if($bwall=='blocked'){ echo '<br/><div class="error">Your are blocked From wall.</div><br/>'; echo '<div class="back"><img src="/home.png"> <a href="/">Back to dashboard</a></div>'; 
include 'foot.php';
 exit; 
}

if(isset($_POST['body'])){


$ufrt=dump_udata("firstname");

$body=formpost("body");
$body=str_replace('[enter]','<br/>',$body);
$body=str_replace('[b]','<b>',$body);
$body=str_replace('[/b]','</b>',$body);
$date=date("l , F d , Y");
$addpost=mysqli_query("INSERT INTO wall (userid,firstname,body,time) VALUES ('$uid','$ufrt','$body','$date')");
if($addpost){
echo '<br/><div class="success"><font color="green">Post Added successfully!</font></div><br/>';
}
else {
echo 'unl';
}

}

echo '<div class="form"><form method="post">Post On Wall:<br/><textarea name="body"></textarea><br/><input type="submit" value="Post Now"/></form></div>';


$page=formget("page");

if(empty($page)){
$page=0;
}
$start=$page*10;
$end=($start+10);

$wallss=mysqli_query("SELECT * FROM wall ORDER BY id DESC LIMIT $start,$end");
 
 while($wall=mysqli_fetch_array($wallss)){
  $nid=$wall["id"];
  $comments=mysqli_num_rows(mysqli_query("SELECT * FROM comments WHERE commentid='$nid'"));

 $uidd=$wall['firstname'];
 

$img='<img src="http://earnbuzz.in/web/offline.gif"/>'; 



 if($uidd==none){ $uidd='<font color="blue">Admin</font>'; }
 else
 { $uidd="$uidd"; } 

  echo '<div class="saytop" align="left"><table width="100%"><tbody><tr><td align="left" width="32px"><img src="http://earnbuzz.in/web/profile.png" width="32px" class="ta"></td><td><b>'.$uidd.'</b><br/>'.$img.' </td><td align="right">'.$wall["time"].'</td></tr></tbody></table><div class="text"><b style="color:green;">'.$wall["body"].'</b><br> <br><div class="pages"><img src="http://earnbuzz.in/web/thumbup.png"> 1 <a href="/"><font color="blue"> Like</font></a> | <a href="/comments.php?id='.$wall["id"].'"><font color="blue">Comments ('.$comments.')</font></a> </div></div> </div>'; 
 }
 echo '<br/><div class="uright"><a href="?page='.($start+1).'">Next</a></div>';

 echo '<br/><a href="index.php"><div class="back">Back To Home</div></a>';

 include 'foot.php';

}
else {
header('Location:/');
}
?>