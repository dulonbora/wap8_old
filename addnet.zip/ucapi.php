<?php 

$params = array(
	"acc=anuj",
	"end-date=2015-10-01",
	"start-date=2013-10-01",
	"directions=I,O",
	"metrics=credits",
	"types=1,2,4",
	"pubs=chauhan.anuj006@gmail.com",
	"time=".time()
);
sort($params);//sort the parameters by letter
$url_params = implode("&",$params);//Use & mark to connect parameters
$token = "1f1a2d74";
$password="deepuankit259";
$url_temp = $url_params."&password=$password&".$token;
$md5code = md5($url_temp);
$md5key = substr($md5code,13,8);
$url_param = $url_params."&key=".$md5key;

echo ''.$url_param.'';



?>
