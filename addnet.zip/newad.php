<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include 'db.php';
include 'functions.php';

headtag("$SiteName - Create new Ad");

if($userlog==1){

 echo '<div class="title">Create new Ad</div>';

if(dump_udata("adbalance")<1){

echo '<div class="error">You must add at least 1$ to your advertiser account to advertise. For adding balance please visit <a href="http://adsgem.com/gainadbalance">http://adzincome.cf/gainadbalance</a></div>';
}
else {
 
 $uid=dump_udata("id");

 if(isset($_POST['title']) AND isset($_POST['url']) AND isset($_POST['type']) AND isset($_POST['captcha']) AND isset($_POST['device']) AND isset($_POST['country'])){

    $title=formpost("title");
    $url=formpost("url");
    $type=formpost("type");
    $captcha=formpost("captcha");
    $device=formpost("device");
    $country=formpost("country");


 $errors=array();

 if(strlen($title)<1){
    $errors[]='Title/Banner URL cannot be empty!';
  }

   if(strlen($url)<1){
    $errors[]='Ad URL cannot be empty!';
  }

   if(strlen($type)<1){
    $errors[]='Please select a type!';
  }

 if($_SESSION['captcha']!=$captcha){
    $errors[]='Captcha was wrong!';
  }

  if(empty($errors)){
    
   $date=date("l , F d , Y");

   if(empty($device)){
     $device="ALL";
   }
   if(empty($country)){
     $device="ALL";
   }
   $cad=mysqli_query("INSERT INTO advertises (userid,name,url,type,device,country,time,status,cset,dset) VALUES ('$uid','$title','$url','$type','$device','$country','$date','PENDING','no','no')");

   if($cad){
     echo '<div class="success">Advertise created successfully! One of our Admin will validate it and will run it. Thanks!</div>';
    }

    else {
      echo 'oh lala';
    }
    }
    else {
     dump_error($errors);
    }
   }
 
  echo '<div class="form"><form method="post">Ad Name / Banner URL: (300x40 image)<br/><input type="text" name="title"/><br/>Ad URL:<br/><input type="text" name="url" value="http://"/><br/>Type:<br/><select name="type"><option value="text">Text</option><option value="banner">Banner</option></select><br/>Device:<br/>Device names with commas or spaces or dots. like Android, Java. 
[NB: Do nothing  to select all device]<br/><textarea name="device"></textarea><br/>Country:<br/>Country names with commas or spaces or dots. like BD, IN, US. 
[NB: Do nothing to select all country]<br/><textarea name="country"></textarea><br/>Captcha:<br/><img src="/im'.md5(microtime()).'.jpg"/><br/>Input the characters showing in image!<br/><input type="text" name="captcha"/><br/><input type="submit" value="Create AD"/></form></div>';

}
echo '<div class="ad"><img src="/home.png"/> <a href="/">Home</a> | <a href="/advertise">My Ads</a></div>';
include 'foot.php';

}

else {

 header('location:/');

}

?>
  
    