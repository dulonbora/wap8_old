<?php
include 'db.php';
include 'functions.php';

headtag("$SiteName - Earn Money Via Affiliate");


echo '<div class="title"><b>Earn Money Via Affiliate:</b></div>
<div class="form"><b>Rules Of Affialative:-</b><br/>
     <ol>
            <li><b>Share Your Afflite link(Collect From Dashboard) with your friends And Earn <font color=red>0.10$</font> Per Affiliate. If They Finish Their Balance <font color=green>1$</font></b> When Refferal User Reach His Balance 1$</li>
            <li>Dont Register More Than 1 id by yourself(You Donot Get Money And You Get Blocked)</li>
            <li>We Will Automaticaly Add Referal Balance When Ref User Reach 1$.</li>
            <li>ALL Referrers Show On Your Cpanel After Validation By Admin</li>
</div>
<div class="uright"><a href="/user/registration"><input type="submit" value="Register Now"></a></div>
<div class="back"><a href="/">Go Back To Home</a></div>';

include 'foot.php';

?>