

 <script type="text/javascript" src="http://mydearads.in/ad/ad_pop.php?uid=604&sid=633"></script> 