<?

$secureuser=check($_SERVER['HTTP_USER_AGENT']);

 $sid=$_SESSION["sid"]; 

$req=mysqli_query("SELECT * FROM clicks WHERE siteid='$sid'");
$arr=mysqli_fetch_array($req);

$fraud=$arr['status']+INVALID;
$lastips=$ip=$_SERVER['REMOTE_ADDR'];

if($arr['ua']==$secureuser)
{
$result=mysqli_query("UPDATE clicks SET status='$fraud' WHERE siteid='$sid'");
if($result){

    header('Location:http://mydearads.in/3g.php'); 
}

}
if($arr['ip']==$lastips)
{
$result=mysqli_query("UPDATE clicks SET status='$fraud' WHERE siteid='$sid'");
if($result){

    header('Location:http://mydearads.in/3g.php');
}
}
else 
{
$result=mysqli_query("UPDATE clicks SET ip='$lastips' AND ua='$secureuser' WHERE siteid='$sid'");
}

?>