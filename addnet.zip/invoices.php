<?php


include 'db.php';
include 'functions.php';

headtag("Payment History - $SiteName");

if($userlog==1){


include 'head.php';

$uid=dump_udata("id"); 

echo '<div class="title">Payments History</div>';

$page=formget("page");

if(empty($page)){
$page=0;
}
$start=$page*1;
$end=($start+10);
 
$bankinv=mysqli_query("SELECT * FROM bank WHERE userid='$uid (' ORDER BY id DESC LIMIT $start,$end");
 
if(mysqli_num_rows($bankinv)>0){
while($show2=mysqli_fetch_array($bankinv)){ 
 

 $uidd1=$show2["status"]; 


 if($uidd1==Rejected){ $uidd1='<font color="red">Rejected</font>'; }

if($uidd1==Canceled){ $uidd1='<font color="red">Canceled</font>'; }
 
 if($uidd1==PENDING){ $uidd1='<font color="red">Pending</font>'; }
 else
 { $uidd1="$uidd1"; } 

$amt=$show2["amount"];
$umt=($amt/60);
echo '<div class="proof"><b>Invoice ID: </b> #INV'.$show2["id"].'<br/><b>Amount : </b><b id="num"> '.$amt.' Rs</b><br/><b>Method : </b> '.$show2["method"].' <br/><b>Holder : </b> '.$show2["holder"].' <br/><b>Bank Name : </b> '.$show2["bname"].' <br/><b>Ifsc Code : </b> '.$show2["ifscode"].' <br/><b>Account No. : </b> '.$show2["via"].'<br/>
 
 <b>Status :  <font color="green">'.$uidd1.'
</font>
</b>

</div>';
}

}

$invo=mysqli_query("SELECT * FROM invoice WHERE userid='$uid (' ORDER BY id DESC LIMIT $start,$end");
 
if(mysqli_num_rows($invo)>0){
while($show=mysqli_fetch_array($invo)){ 
 

 $uidd=$show["status"]; 


 if($uidd==Rejected){ $uidd='<font color="red">Rejected</font>'; }
 
 if($uidd==PENDING){ $uidd='<font color="red">Pending</font>'; }
 else
 { $uidd="$uidd"; } 

 
$name=$show["name"];
if($name=='Recharge') {
$amt=$show["amount"];
$umt=($amt/60);
echo '<div class="proof"><b>Invoice ID: </b> #RECH'.$show["id"].'<br/><b>Amount : </b><b id="num"> '.$amt.' Rs</b><br/><b>Method : </b> '.$show["method"].'<br/><b>Via : </b> '.$show["via"].'<br/>
 <b>Status :  <font color="green">'.$uidd.'
</font>
</b>

</div>';
}
else {
 $amtt=$show["amount"];
$umtt=($amt/60);
 
echo '<div class="proof"><b>Invoice ID: </b> INV'.$show["id"].'<br/><b>Amount : </b><b id="num">'.$amtt.' Rs </b><br/><b>Method : </b> '.$show["method"].'<br/><b>Via : </b> '.$show["via"].'<br/> 
 <b>Status : <font color="green">'.$uidd.'
</font>
</b>
</div>';
}
}
echo '<br/><center><spam class="error"><a href="/invoices/'.($start-1).'">Prev</a></spam><spam class="success"><a href="/invoices/'.($start+1).'">Next</a></spam></center><br/>';

}


else {

echo '<br/><div class="error">There is no payment history!</div><br/>';
}

echo '<div class="back"><a href="/user/dashboard">Go Back To Dashboard</a></div>';


include 'foot.php';


}

else {
header('Location:/');
}
?>