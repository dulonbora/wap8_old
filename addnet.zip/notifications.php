<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include 'db.php';
include 'functions.php';

headtag("$SiteName - My Sites");

if($userlog==1){
include 'head.php';


echo '<div class="title">Notifications</div>';


$act=formget("act");





 if($act=='del') 
{


$id=formget("id");


$sql=mysqli_query("DELETE FROM msgs WHERE id='$id'");


echo '<div class="success"> Deleted Successfully</div>';

}

//end del


$msg=mysqli_query("SELECT * FROM msgs WHERE rid='$uid' AND status='New'");

if(mysqli_num_rows($msg)>0){
 while($show=mysqli_fetch_array($msg)){

  echo '<div class="balance"><b style"color:blue;">'.$show["body"].'</b>
[<a href="notifications.php?act=del&id='.$show["id"].'"> <font color="red">X </font></a>]

  </div>';
 

}
}
else {
  echo '<br/><div class="error">You have not any notifications!</div><br/>';
  }



 echo '<br/><div class="back"><img src="/home.png"/> <a href="/">Home</a> | <a href="/user/dashboard">Dashboard</a></div>';
 
 include 'foot.php';

}

else {

header('Location:/');

}

?>
