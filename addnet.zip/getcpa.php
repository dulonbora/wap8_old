<?php

/************************************

This CPA Updates Are Done By MobFreshAd and Done By Rasid

**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - CPA Adcode");

if($userlog==1){
include 'head.php';

echo '<div class="title">CPA Promotion Link</div>';

$uid=dump_udata("id");





echo '<div class="notice">
<font color="red"> Note :</font> Sent Conversion the link and place the Link Correct place like Your Download Page..etc. </div><div class="notice"><font color="red"> Note : </font> There Is Different CPA AdCode. Adult And NonAdult Link. </div><br>
<div class="borderline"></div><br><div class="line"> Non Adult AdCode</div><div class="catRow"><textarea>http://mydearads.in/cpanoadult.php?uid='.$uid.'</textarea></div
<div class="borderline"></div><br><div class="line"> Adult AdCode</div><div class="catRow"><textarea>http://mydearads.in/cpaadult.php?uid='.$uid.'</textarea></div

';


echo '<br/><div class="back"><img src="/home.png"/> <a href="/">Home</a> | <a href="/sites">My Sites</a></div>';

include 'foot.php';
}
else {

header('Location:/');
}
?>