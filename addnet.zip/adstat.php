<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("Advertise - Statistics");


if($userlog==1){

$aid=formget("id");
$uid=dump_udata("id");


$chad=mysqli_query("SELECT * FROM advertises WHERRE id='$aid' AND userid='$uid'");



$tclicks=mysqli_num_rows(mysqli_query("SELECT * FROM clicks WHERE adid='$aid'"));
$vclicks=mysqli_num_rows(mysqli_query("SELECT * FROM clicks WHERE adid='$aid' AND status='VALID'"));
$bclicks=mysqli_num_rows(mysqli_query("SELECT * FROM clicks WHERE adid='$aid' AND status='INVALID'"));
$spent=($vclicks*0.005);
$date=date("l , F d , Y");
$tdclicks=mysqli_num_rows(mysqli_query("SELECT * FROM clicks WHERE adid='$aid' AND time='$date'"));
$tvclicks=mysqli_num_rows(mysqli_query("SELECT * FROM clicks WHERE adid='$aid' AND status='VALID' AND time='$date'"));
$tbclicks=mysqli_num_rows(mysqli_query("SELECT * FROM clicks WHERE adid='$aid' AND status='INVALID' AND time='$date'"));
$tspent=($tvclicks*0.005);

echo '<div class="title">Ad stats for ID#'.$aid.'</div>';
echo '<div class="form"><b>Total Clicks:</b> '.$tclicks.'<br/><b>Total Valid Clicks:</b> '.$vclicks.'<br/><b>Total Bonus Clicks:</b> '.$bclicks.'<br/><b>Total Spent:</b> '.$spent.'$<br/><b>Today Clicks:</b> '.$tdclicks.'<br/><b>Today Valid Clicks:</b> '.$tvclicks.'<br/><b>Today Bonus Clicks:</b> '.$tbclicks.'<br/><b>Today Spent:</b> '.$tspent.'$</div>';


$page=formget("page");

if(empty($page)){
$page=0;
}
$start=$page*10;
$end=($start+10);

$stat=mysqli_query("SELECT * FROM clicks WHERE adid='$aid' ORDER BY id DESC LIMIT $start,$end");

include_once('country/ip2country.php');
$ip2c=new ip2country();
$ip2c->mysqli_host='localhost';
$ip2c->db_user='anilwapc_anil';
$ip2c->db_pass='lolbaba@9087#ak)';
$ip2c->db_name='anilwapc_data';
$ip2c->table_name='ip2c';
if(mysqli_num_rows($stat)>0){
while($show=mysqli_fetch_array($stat)){
echo '<div class="ad">Date: '.$show["time"].'<br/>IP: '.$show["ip"].'<br/>User Agent: '.$show["ua"].'<br/>Country: '. $ip2c->get_country_name($show["ip"]) . ' <br/>Spent: $0.005<br/>Type: '.$show["status"].'</div>';
}

echo '<div class="ad"><a href="-'.($start+1).'">Next</a></div>';
}
else {
echo '<div class="error">There is no clicks!</div>';
}
echo '<div class="uright"><img src="/home.png"/> <a href="/">Home</a> | <a href="/advertise">Advertises</a></div>';

include 'foot.php';


}

else {

header('Location:/');
}
?>
