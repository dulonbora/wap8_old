<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - Forgot password");

if($userlog==1){
header('Location:/user/dashboard');
}
else {
  if(isset($_POST['user_email']) AND isset($_POST['captcha'])){
     
     $user_email=formpost("user_email");
     $captcha=formpost("captcha");
     $captcha=strtoupper($captcha);

     $errors=array();


     $check_email=mysqli_query("SELECT * FROM userdata WHERE email='$user_email'");
     if(mysqli_num_rows($check_email)<1){
        $errors[]='No such user with this email!';
      }
     if(strlen($user_email)<1){
        $errors[]='Email field left empty!';
      }
     
     if($_SESSION['captcha']!=$captcha){
         $errors[]='Captcha code was wrong!';
       }



     if(empty($errors)){
        $token=md5(microtime()*2);
        $check_if=mysqli_query("SELECT * FROM passret WHERE email='$user_email'");
        if(mysqli_num_rows($check_if)<1){
        $do_input=mysqli_query("INSERT INTO passret (email,token) VALUES ('$user_email','$token')");
         }
        else {
        $do_input=mysqli_query("UPDATE passret SET token='$token' WHERE email='$user_email'");
         }

        if($do_input){
           
           
        
   
    $to      = $user_email;
    $subject = 'Password Reset Of Mydearads.In Account';
    $message = 'Dear user,

Please click bellow link to rest your password and choose a new one!

http://mydearads.in/reset.php?email='.$user_email.'&token='.$token.'


Support:
support@mydearads.in
+918795589006

Thanks,
Mydearads Team,
Mydearads.in';
    $headers = 'From: Mydearads.In<support@mydearads.in>' . "\r\n" .
    'Reply-To: support@mydearads.in' . "\r\n" .
    'X-Mailer: Mydearads';

    mail($to, $subject, $message, $headers);
echo '<div class="line"><img src="/success.png"/> Successfull!</div>';
echo '<div class="success">Your Password reset link has successfully sent to your email!</div>';


}
}
else {
echo '<div class="title"><img src="/error.png"/> Error happened!</div>';
echo '<div class="error">';
foreach($errors as $error){
echo ''.$error.'<br/>';
}

echo '</div>';
}


}
echo '<div class="line">Password reset</div>';
echo '<div class="form"><form method="post"><label for="user_email">Email:</label><br/><input type="text" name="user_email"/><br/><label for="captcha">Captcha:</label><br/><img src="/im'.md5(microtime()).'.jpg" alt="loading"/><br/>Input the characters showing in the image.<br/><input type="text" name="captcha"/><br/><input type="submit" value="Reset"/></form></div>';

}

echo '<div class="back"><img src="/home.png"/> <a href="/">Home</a> &#171; Password reset</div>';

include 'foot.php';

?>