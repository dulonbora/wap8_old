<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
session_start();
error_reporting(0);
date_default_timezone_set('Etc/GMT-6');
//Modify these lines and go to hell!

$SiteName=file_get_contents('http://'.$_SERVER["HTTP_HOST"].'/sitename.txt');

function headtag($headtitle) {
if(empty($headtitle)){
$headtitle='Mydearads.In - Mobile Advertising Network | Sell Ads | Buy Ads | Monetize Traffic';
}
echo '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="shortcut icon" href="http://mydearads.in/favicon.ico" />
 
<meta name="robots" content="index, follow" />
<meta name="description" content="Mydearads.In Mobile Advertising Solutions - A leading Mobile Ad Network helps to promote your products/services on mobile websites and also you start earning money with your Websites." />
<meta name="keywords" content="mobile marketing, mobile advertising, mobile ad network, mobile advertising companies, mobile advertising companies in india, mobile app advertising, make money with websites, earn from mobile websites, mobile websites marketing solutions" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Pragma" content="no-cache" /> 
<title>'.$headtitle.' Mobile Advertising Network | Sell Ads | Buy Ads | Monetize Traffic </title>
<link rel="stylesheet" type="text/css" href="/style.css" />
 <meta name="google-site-verification" content="UsMCerPZNtJMtOLXd9PZwu5661WlK3Sku4fb6qH0rpM" /> 
</head><body><div class="logo" align="center"><a href="/"><img src="/web/logo.png" alt="logo"/></a></div>';


}

function formget($val){
$val2=$_GET["$val"];
$get=mysqli_real_escape_string(addslashes(htmlspecialchars($val2)));
return $get;
}

function formpost($val1){
$val3=$_POST["$val1"];
$post=mysqli_real_escape_string(addslashes(htmlspecialchars($val3)));
return $post;
}
function dump_error($erro){
echo '<div class="error">';
foreach($erro as $errr){
echo ''.$errr.'<br/>';
}
echo '</div>';
}
function dump_udata($udataname){
$uemail=mysqli_real_escape_string($_SESSION['adsgem_email']);

$udata=mysqli_query("SELECT * FROM userdata WHERE email='$uemail'");
$ufdata=mysqli_fetch_array($udata);
return $ufdata["$udataname"];
}


$chssuser=mysqli_real_escape_string($_SESSION['adsgem_email']);
$chsspass=mysqli_real_escape_string($_SESSION['adsgem_password']);
$chsslog=mysqli_query("SELECT * FROM userdata WHERE email='$chssuser'");
$admu=mysqli_real_escape_string($_SESSION['adsgem_rony']);
$admp=mysqli_real_escape_string($_SESSION['adsgem_rpw']);

if(file_exists("admins/$admu-data.pra")){
$rpC=explode("|-pr-|",file_get_contents("admins/$admu-data.pra"));
if($admp==md5($rpC[2])){
$main_adm=file_get_contents("admins/main-admin.pran");
if($admu==$main_adm){
$admin_id='pranto';
}
$adminlog=1;
}
}
else {
$adminlog=0;
}

if(mysqli_num_rows($chsslog)>0){
$dumlog=mysqli_fetch_array($chsslog);
if($dumlog["password"]==$chsspass){
$userlog=1;
if(preg_match('/block/',strtolower($dumlog["status"]))){



echo '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="shortcut icon" href="/favicon.ico" />
<title>Mydearads - Account Blocked!</title>
<link rel="stylesheet" type="text/css" href="/style.css" />
 <meta name="google-site-verification" content="UsMCerPZNtJMtOLXd9PZwu5661WlK3Sku4fb6qH0rpM" /> 
</head><body><div class"logo"><a href="/"><img src="/web/logo.png" alt="Mydearads"/></a></div>';

echo '<div class="error">Your Mydearads account has blocked. Reason: '.str_replace('blocked',null,$dumlog["status"]).'. Please contact Mydearads Team for unblocking your account. Email: shahidpkd4u@gmail.com <br/>Phone: 8795589006<br/>Thank you for using our services.</div>';
include 'foot.php';
exit;
}
}
else {
$userlog=0;
}
}


?>
