<?php


include 'db.php';
include 'functions.php';

headtag("Payment Proofs - $SiteName");

echo '<div class="title">Payments by AdzIncome</div>';

$paid = mysqli_query('SELECT *, SUM(amount) FROM invoice WHERE status LIKE "Paid%"'); 
$paid2 = mysqli_fetch_array($paid); 
$pay = $paid2['SUM(amount)']; 
$paid = $pay/60;
 echo 
'<p>For the users who love to see some proof before they can trust. Here a list of payments.</p><div class="back"><b>Total Paid '.$paid.' $<br>Total Paid In Rs. '.$pay.' </b></div>';
$total_bank=mysqli_num_rows(mysqli_query("SELECT * FROM bank WHERE status LIKE 'Paid%'"));

$total_rc=mysqli_num_rows(mysqli_query("SELECT * FROM invoice WHERE name='Recharge'"));

$total_amoney=mysqli_num_rows(mysqli_query("SELECT * FROM invoice WHERE status LIKE 'Paid%' AND name='Amoney'"));

$total_paytm=mysqli_num_rows(mysqli_query("SELECT * FROM invoice WHERE status LIKE 'Paid%' AND name='Paytm'"));
echo '<div class="uright"><table><tr><td><img src="/images/arrow.png" alt="-"/></td><td><b><a href="/recharge-proof.php">Recharge Payments</a> [<font color=red> '.$total_rc.' </font>]</b><br/><small>Recharge Payments made by Us.</small></td></tr></table></div>'; echo '<div class="uright"><table><tr><td><img src="/images/arrow.png" alt="-"/></td><td><b><a href="/amoney-proof.php">Airtel Money  Payments</a> [<font color=red> '.$total_amoney.' </font>]</b><br/><small>Airtel Money Payments made by Us.</small></td></tr></table></div>';
 
echo '<div class="uright"><table><tr><td><img src="/images/arrow.png" alt="-"/></td><td><b><a href="/paytm-proof.php">Paytm Wallet Payments</a> [<font color=red> '.$total_paytm.' </font>]</b><br/><small>Paytm Wallet Payments made by Us.</small></td></tr></table></div>';

echo 
'<div class="uright"><table><tr><td><img src="/images/arrow.png" alt="-"/></td><td><b><a href="/bank-proof.php">Bank Payments</a> [<font color=red>
 '.$total_bank.' </font>]</b><br/><small>Bank Payments made by Us.</small></td></tr></table></div>';



echo '<div class="back"><a href="/">Go Back To Home</a></div>';

include 'foot.php';
?>