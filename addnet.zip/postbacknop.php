<?php


/************************************

This Is Created By MobFreshAd As per Shahid Request on 19-12-2016 By Rasid

**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - CPA Update");

echo '<div class="line">Cpa Update</div>';

$amount=formget("getamount");

$subid=formget("subid1");

//$carrier=formget("carrier");

//$platform=formget("platform");

//$country=formget("country");

$tranxid=formget("txid");

$datep=date("d-m-Y");

$errors=array();


$urlmch=mysqli_query("SELECT * FROM postback WHERE txid=tranxid");

if(mysqli_num_rows($urlmch)>0){
$errors[]='already update';
}

if($tranxid==""){

$errors[]='already update';

}
/**if($carrier==""){

$errors[]='already update';

}




if($country==""){

$errors[]='already update';

}

if($platform==""){

$errors[]='already update';

}
**/

if($amount==""){

$errors[]='already update';

}



if(empty($errors)){



$com=$amount*25/100;

$amt=($amount-$com);



 $User=mysqli_fetch_array(mysqli_query("SELECT * FROM userdata WHERE id='$subid'"));

 $userbal=$User["pubalance"];
 $user=$User["firstname"];

 $newU=($userbal+$amt);

$doIt=mysqli_query("INSERT INTO postback (uid,user,earn,date,txid) VALUES ('$subid','$user','$amt','$datep','$tranxid')");

 $udone=mysqli_query("UPDATE userdata SET pubalance='$newU' WHERE id='$subid'");

if(doIt){
echo '<br/><div class="success"><b>All Update Successfull</b><br/> Thank u MobFreshAD For Updating Reports.</div><br/>';
}
}


else { echo '<br/><div class="error">Opes! Failure Plz try again some commands not found</div><br/>'; 
}	



echo '<div class="back"><a href="/">Go Back To Home</a></div>';

include 'foot.php';

?>