if( /Android/i.test(navigator.userAgent) ) {
var url=confirm("download this song");
if (url==true)
{
var url = window.location.href = 'http://mydearads.in/apps/install2.php?id=26&uid=719';
url.show();
}
else
{
}
}