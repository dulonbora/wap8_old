-- phpMyAdmin SQL Dump
-- version 4.0.10.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 21, 2016 at 07:32 AM
-- Server version: 5.5.45-cll-lve
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `huklo`
--

-- --------------------------------------------------------



--
-- Table structure for table `appslist`
--

CREATE TABLE IF NOT EXISTS `appslist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` varchar(5000) NOT NULL,
  `reqid` varchar(5000) NOT NULL,
  `pub` varchar(500) NOT NULL,
  `name` varchar(500) NOT NULL,
  `geo` varchar(500) NOT NULL,
  `img` varchar(500) NOT NULL,
  `link` varchar(500) NOT NULL,
  `url` varchar(500) NOT NULL,
  `cpirs` varchar(500) NOT NULL,
  `device` varchar(500) NOT NULL,
  `status` varchar(500) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `reqid` (`reqid`(1000))
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

-- --------------------------------------------------------

--
-- Table structure for table `appsrepot`
--

CREATE TABLE IF NOT EXISTS `appsrepot` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` varchar(5000) NOT NULL,
  `reqid` varchar(5000) NOT NULL,
  `aplistid` varchar(500) NOT NULL,
  `pub` varchar(500) NOT NULL,
  `install` varchar(500) NOT NULL,
  `earning` varchar(500) NOT NULL,
  `date` varchar(500) NOT NULL,
  `name` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3543 ;



-- --------------------------------------------------------

--
-- Table structure for table `cpireq`
--

CREATE TABLE IF NOT EXISTS `cpireq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `category` varchar(500) NOT NULL,
  `status` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;



/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
