<?php
include '../db.php';
include '../functions.php';

headtag("$SiteName - Request For 9Apps Promotion");

if($userlog==1){
include '../head.php';


$get=mysql_query("SELECT * FROM cpireq WHERE userid='$uid'");

$number=mysql_num_rows($get);


if($number=='1') {
while($row = mysql_fetch_array($get))
{
$status=$row["status"];
if($status=='Pending') {
echo '<div class="line">Request CPI 9Apps Promotion</div>';
echo '<br/><div class="error">Your Request <font color="red">Pending</font> Now it <font color="green">Approved</font> Soon</div><br/>';
}
if($status=='Approved') {
echo '<div class="line">CPI 9Apps Promotion</div>';

$aplis=mysql_query("SELECT * FROM appslist WHERE userid='$uid'");
$number=mysql_num_rows($aplis);

echo '<!--<div class="notice">Total '.$number.' Apps Available</div>-->';
while($apsl = mysql_fetch_array($aplis))
{
echo '<div class="catRow"><table><tr>
<td><img src="'.$apsl["img"].'" height="100" width="100" alt="-"/></td>
<td><b>App Name : </b><font color="blue">'.$apsl["name"].'</font><br/>
<small><b>Link Type : </b>'.$apsl["link"].'</small><br/>
<small><b>GEO : </b>'.$apsl["geo"].'</small><br/>
<small><b>Device : </b>'.$apsl["device"].'</small><br/>
<small><b>Price : </b><b class="fig">'.$apsl["cpirs"].'$</b><br/>
<small><b>Status : </b><font color="green">'.$apsl["status"].'</font></small><br/></small></td>
</tr></table>
<div class="uright"><a href="/cpi/adcodesp.php?id='.$apsl["id"].'"><font color="blue">'.$apsl["name"].' -Get Promo Link</font></a> - <a href="/cpi/9apps-report.php"><font color="green">'.$apsl["name"].' - Repot</font></a></div>
</div>';
}
}
}
}

$verify=mysql_query("SELECT * FROM clicks WHERE userid='$uid' AND status='VALID'");

$clicknm=mysql_num_rows($verify);


if($clicknm=='20') {

if(empty($number)){
echo '<div class="line">Request CPI 9Apps Promotion</div>';
echo '<div class="notice">'.$status.'<font color="blue">Enter Your Site And Request.</font></div>';
if(isset($_POST["category"])){
$category=formpost("category");
/////////////////////////////////////////////////////////////////////////////////

if(stristr($category,".tk")) {
$domn='<div class="error">.TK Not Accept US</div>';
goto sv;
}
if(stristr($category,".ml")) {
$domn='<div class="error">.ML Not Accept US</div>';
goto sv;
}
if(stristr($category,".cf")) {
$domn='<div class="error">.CF Not Accept US</div>';
goto sv;
}
if(stristr($category,".ga")) {
$domn='<div class="error">.GA Not Accept US</div>';
goto sv;
}
if(stristr($category,".gq")) {
$domn='<div class="error">.GQ Not Accept US</div>';
goto sv;
}
if(stristr($category,".wapka.mobi")) {
$domn='<div class="error">.Wapka.Mobi Not Accept US</div>';
goto sv;
}
if(stristr($category,".wap-ka.com")) {
$domn='<div class="error">.Wap-Ka.Com Not Accept US</div>';
goto sv;
}
if(stristr($category,".wapka.me")) {
$domn='<div class="error">.Wapka.Me Not Accept US</div>';
goto sv;
}

/////////////////////////////////////////////////////////////////////////////////
$errors=array();

if(strlen($category)<1){
$errors[]='Category cannot be empty !';
}

if(!preg_match('/([a-z0-9\.-])\.([a-z0-9\.-])/',$category)){
$errors[]='Site url is not valid!';
}


if(empty($errors)){
$add=mysql_query("INSERT INTO cpireq (userid,category,status) VALUES ('$uid','$category','Pending')");
if($add){
echo '<div class="success">Your 9Apps Promotion Request has successfully. <br/> We will Verify it 24 hours.</a></div>';
}
else {
echo '<div class="error">Unknown error creationg !</div>';
}
}
else {
dump_error($errors);
}

}
sv:

echo $domn;

echo '<div class="form"><form method="post">
Site(dont use http:// www ) : <br/><input type="text" name="category"/><br/>
<input type="submit" value="Request Now"/></form><br/></div>';
}
}
else { echo '<div class="line">9App Promotion Reqvest </div>'; echo '<div class="error"> Need 50 Clicks To Request for Promotion.</div>'; 
}


echo '<div class="back"><a href="/">Go Back To Home</a></div>';
  
include '../foot.php';
}
else {
header('Location:/');
}
?>