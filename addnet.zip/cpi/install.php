<?php
include '../db.php';

$uid = $_GET['uid'];
$appsid = $_GET['appsid'];

$chaps=mysql_query("SELECT * FROM appslist WHERE id='$appsid' AND userid='$uid'");
$link=mysql_fetch_array(mysql_query("SELECT * FROM appslist WHERE id='$appsid' AND userid='$uid'"));
$apilink=$link['url'];
if(empty($appsid)){
echo '<a href="http://adzincome.in">Apps id is Empty - Adzincome.in !</a>';
die();
}
if(empty($uid)){
echo '<a href="http://adzincome.in">User Id is Empty - Adzincome.in !</a>';
die();
}
if(mysql_num_rows($chaps)<1){
echo '<a href="http://adzincome.in">Apps Not Found - adzincome.in !</a>';
die();
}
header("Location:$apilink");
?>