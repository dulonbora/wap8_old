<?php

include 'db.php';
include 'functions.php';

headtag("$SiteName Sex Position Picker Install Statics");


if($userlog==1){

include 'head.php';

$uid=dump_udata("id");

$requseid=mysql_query("SELECT * FROM spcpireq WHERE userid='$uid'");
$rqid=mysql_fetch_array($requseid);

$aplsid=mysql_query("SELECT * FROM spappslist WHERE userid='$uid' AND name='Sex Position Picker' AND reqid='$rqid[id]'");
$alid=mysql_fetch_array($aplsid);

echo '<div class="line">Sex Position Picker Install Statics</div><div class="success">Repot Update Next Day under 4PM to 7PM !</div>';

echo '<div><table style="border-collapse:collapse;text-align:center;" align="center" height="60" border="1" bordercolor="#5b8ebb" cellpadding="5" width="90%">
<tbody><tr style="background-color:#5b8ebb">
<tr style="background-color:#5b8ebb">
<th>Date</th>
<th>Name</th>
<th>Installs</th>
<th>CPI</th>
<th>Earning</th>
</tr>';

$page=formget("page");

if(empty($page)){
$page=0;
}
$start=$page*1;
$end=($start+7);

$allr=mysql_query("SELECT * FROM appsrepot WHERE userid='$uid' AND reqid='$rqid[id]' AND aplistid='$alid[id]' AND pub='$alid[pub]' ORDER BY id DESC LIMIT $start,$end");
while($allsr=mysql_fetch_array($allr)) {
echo '<tr bgcolor="#e8e8e8">
<td>'.$allsr["date"].'</td>
<td>'.$allsr["name"].'</td>
<td>'.$allsr["install"].'</b></td>
<td>0.12$</b></td>
<td>'.$allsr["earning"].'$</b></td>
</tr>';
}

echo '</tbody></table></div>';

echo '<div class="back"><a href="/">Go Back To Home</a></div>';

include 'foot.php';

}
else {header('Location:/');
}
?>