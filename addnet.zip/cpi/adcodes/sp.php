<?php
include 'db.php';
include 'functions.php';

headtag("$SiteName - Request CPI Sex Position Picker Promotion");

if($userlog==1){
include 'head.php';
$uid=dump_udata("id");


$get = mysql_query("SELECT * FROM spcpireq WHERE userid='$uid'");
$number = mysql_num_rows($get);


if($number=='1') {
while($row = mysql_fetch_array($get))
{
$status=$row["status"];
if($status=='Pending') {
echo '<div class="line">Request CPI Sex Position Picker Promotion</div>';
echo '<br/><div class="error">Your Request <font color="red">Pending</font> Now it <font color="green">Approved</font> Soon</div><br/>';
}
if($status=='Approved') {
echo '<div class="line">Request CPI Sex Position Picker Browser Promotion</div>';

$aplis = mysql_query("SELECT * FROM spappslist WHERE userid='$uid'");
$number = mysql_num_rows($aplis);
echo '<!--<div class="success">Total '.$number.' Apps Available</div>-->';
while($apsl = mysql_fetch_array($aplis))
{
echo '<div class="catRow"><table><tr>
<td><img src="'.$apsl["img"].'" height="100" width="100" alt="-"/></td>
<td><b>App Name : </b><font color="blue">'.$apsl["name"].'</font><br/>
<small><b>Link Type : </b>'.$apsl["link"].'</small><br/>
<small><b>GEO : </b>'.$apsl["geo"].'</small><br/>
<small><b>Device : </b>'.$apsl["device"].'</small><br/>
<small><b>Price : </b><b class="fig">'.$apsl["cpirs"].'$</b><br/>
<small><b>Status : </b><font color="green">'.$apsl["status"].'</font></small><br/></small></td>
</tr></table>
<div class="balance"><a href="/cpi/adcode/sp/'.$apsl["id"].'"><font color="blue">'.$apsl["name"].' - Promo Link</font></a> - <a href="/cpi/repot/sp"><font color="green">'.$apsl["name"].' - Repot</font></a></div>
</div>';
}
}
}
}

if($number=='0') {
echo '<div class="line">Request CPI Sex Position Picker Browser Promotion</div>';
echo '<div class="success">'.$status.'<font color="blue">Enter Your Site And Request.</font></div>';
if(isset($_POST["category"])){
$category=formpost("category");
/////////////////////////////////////////////////////////////////////////////////

if(stristr($category,".tk")) {
$domn='<div class="error">.TK Not Accept US</div>';
goto sv;
}
if(stristr($category,".ml")) {
$domn='<div class="error">.ML Not Accept US</div>';
goto sv;
}
if(stristr($category,".cf")) {
$domn='<div class="error">.CF Not Accept US</div>';
goto sv;
}
if(stristr($category,".ga")) {
$domn='<div class="error">.GA Not Accept US</div>';
goto sv;
}
if(stristr($category,".gq")) {
$domn='<div class="error">.GQ Not Accept US</div>';
goto sv;
}
if(stristr($category,".wapka.mobi")) {
$domn='<div class="error">.Wapka.Mobi Not Accept US</div>';
goto sv;
}
if(stristr($category,".wap-ka.com")) {
$domn='<div class="error">.Wap-Ka.Com Not Accept US</div>';
goto sv;
}
if(stristr($category,".wapka.me")) {
$domn='<div class="error">.Wapka.Me Not Accept US</div>';
goto sv;
}

/////////////////////////////////////////////////////////////////////////////////
$errors=array();

if(strlen($category)<1){
$errors[]='Category cannot be empty !';
}

if(!preg_match('/([a-z0-9\.-])\.([a-z0-9\.-])/',$category)){
$errors[]='Site url is not valid!';
}


if(empty($errors)){
$add=mysql_query("INSERT INTO spcpireq (userid,category,status) VALUES ('$uid','$category','Pending')");
if($add){
echo '<div class="success">Request CPI Sex Position Picker Browser Promotion successfully. Verify 72Hrs.</a></div>';
}
else {
echo '<div class="error">Unknown error creationg !</div>';
}
}
else {
dump_error($errors);
}
}
sv:

echo $domn;

echo '<div class="form"><form method="post">
Site(don\'t use http:// www ) : <br/><input type="text" name="category"/><br/>
<input type="submit" value="Request Now"/></form><br/></div>';
}

echo '<div class="back"><a href="/">Go Back To Home</a></div>';
  
include 'foot.php';
}
else {
header('Location:/');
}
?>