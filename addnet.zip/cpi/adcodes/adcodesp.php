<?php
include 'db.php';
include 'functions.php';

headtag("$SiteName - Sex Position Picker Promotion Link");

if($userlog==1){
include 'head.php';
$id=formget("id");

$uid=dump_udata("id");
echo '<div class="line">Sex Position Picker -Promotion Adcode</div><div class="success"><b>You Use This Code Any Site.</b></div>';
$chsite=mysql_query("SELECT * FROM spappslist WHERE userid='$uid' AND id='$id'");

if(mysql_num_rows($chsite)>0){
echo '<div class="line"><b>Promotion Link : </b></div>
<div class="uright"><textarea style="width: 444px; height: 55px;">http://adcrul.com/ad/mhot.php?uid='.$uid.'&appsid='.$id.'</textarea>
</div>';

echo '<div class="line"><b>Java Code popunder (Best Earning): </b></div>
<div class="uright"><textarea style="width: 444px; height: 55px;"><script type="text/javascript" src="http://adcrul.com/ad/m-hot.php?uid='.$uid.'&appsid='.$id.'"></script></textarea>
</div>';

echo '<div class="line"><b>Java Code OK/Cancel (popup): </b></div>
<div class="uright"><textarea style="width: 444px; height: 55px;"><script type="text/javascript" src="http://adcrul.com/ad/m_hot.php?uid='.$uid.'&appsid='.$id.'"></script></textarea>
</div>';

echo '<div class="line"><b>Promotion Code (Bennar): </b></div>
<div class="uright"><textarea style="width: 444px; height: 55px;"><a href="http://adcrul.com/ad/mhot.php?uid='.$uid.'&appsid='.$id.'"><img src="http://adcrul.com/bennar"/></a></textarea>
</div>';
echo '<div class="line"><b>Promotion Code (Text): </b></div>
<div class="uright"><textarea style="width: 444px; height: 55px;"><a href="http://adcrul.com/ad/mhot.php?uid='.$uid.'&appsid='.$id.'">Click Here To Download Now</a></textarea>
</div>';
}
else {
echo '<div class="error">You do not own this site!</div>';
}

echo '<div class="back"><a href="/">Go Back To Home</a></div>';

include 'foot.php';
}
else {
header('Location:/');

}
?>