<?php
$uid=$_REQUEST['uid'];
$appsid=$_REQUEST['appsid'];
header('Content-type: application/js');
?>
if( /Android/i.test(navigator.userAgent) ) {
var r_text = new Array ();
r_text[0] = "Download File";
r_text[1] = "Update To Android 6 Marshmallow";
r_text[2] = "Rs.50 Free Mobile Recharge";
r_text[3] = "Call Sex Girl Number";
r_text[4] = "If You Want Hot Chat Girl";
r_text[5] = "DJ Remix Music";
r_text[6] = "Full HD Video";
r_text[7] = "Sunny Leone Hot Video";
r_text[8] = "Download Now";
r_text[9] = "New Action Game Android";
r_text[10] = "XXX Game For Android";
r_text[11] = "UC Browser 21.2.1 Latest Update Now";
r_text[12] = "Hindi Language Sex Video";
r_text[13] = "Mummy Sex Son";
r_text[14] = "Sister Fuck Brother";
r_text[15] = "Dhoom 4 Full Movie";
r_text[16] = "Don 3 Full HD Movie";
r_text[17] = "Unlimited Android Apps";
r_text[18] = "Bengali Sex Video";
r_text[19] = "Earning Money Your Phone";
r_text[20] = "Facebook Money Online";
r_text[21] = "WoW ! Win Iphone 6 Plus";
r_text[22] = "Samsung Galaxy Note 5 You Win";
r_text[23] = "You Win Apple Laptop";
r_text[24] = "Fast Download";
r_text[25] = "Get 2GB Free Net";
r_text[26] = "Life Time Free Net";
r_text[27] = "Click OK And Wait";
r_text[28] = "Virus in Your Phone Clean Now";
r_text[29] = "Dont Click OK 18+ Only";
var i = Math.floor(28*Math.random())
var r_link = new Array ();
r_link[0] = "http://adcrul.com/ad/sp.php?uid=<?php echo $uid; ?>&appsid=<?php echo $appsid; ?>";
r_link[1] = "http://adcrul.com/ad/sp.php?uid=<?php echo $uid; ?>&appsid=<?php echo $appsid; ?>";
r_link[2] = "http://adcrul.com/ad/sp.php?uid=<?php echo $uid; ?>&appsid=<?php echo $appsid; ?>";
r_link[3] = "http://adcrul.com/ad/sp.php?uid=<?php echo $uid; ?>&appsid=<?php echo $appsid; ?>";
r_link[4] = "http://adcrul.com/ad/sp.php?uid=<?php echo $uid; ?>&appsid=<?php echo $appsid; ?>";
var s = Math.floor(4*Math.random())
var url=confirm(r_text[i]);
if (url==true)
{
var url = window.location.href = r_link[s];
url.show();
}
else
{
}
}