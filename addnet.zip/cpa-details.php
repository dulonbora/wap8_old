<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include 'db.php';
include 'functions.php';

headtag("$SiteName - My Sites");

if($userlog==1){
include 'head.php';

$uid=dump_udata("id");

echo '<div class="title">Cpa Details</div>';

$site=mysqli_query("SELECT * FROM cparepot WHERE userid='$uid'");

if(mysqli_num_rows($site)>0){
 while($show=mysqli_fetch_array($site)){
  echo '<div class="catRow2"><b>Date:</b> '.$show["date"].' </br/>
    <b>Country:</b> '.$show["country"].'<br/>
<b>Carrier:</b> '.$show["carrier"].' </br/>
<b>Earning:</b> '.$show["amount"].' </br/>


<b>Platform:</b> '.$show["platform"].'
  </div>';
 }

 }
 else {
  echo '<br/><div class="error">You have not any conversion!</div><br/>';
  }


 echo '<div class="back"><img src="/home.png"/> <a href="/">Home</a> | <a href="/user/dashboard">Dashboard</a></div>';
 
 include 'foot.php';

}

else {

header('Location:/');

}

?>
