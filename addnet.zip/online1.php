<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - Online Usrrs");


if($userlog==1){

include 'head.php';

echo '<div class="title">Online Users</div>';

 
$time=date("D j M Y g:ia", time()+(5.5*3600));

 
$result=mysqli_query("SELECT * FROM userdata WHERE id='$time'");
 
echo '<div class="uright">Online Users</div>';
while($row=mysqli_fetch_array($result))
{
   echo '<div class="ok"><b>'.$row['id'].'</b></div>';

}
 

echo '<div class="back"><img src="/home.png"> <a href="/">Back To Dashboard</a></div>';

}
include 'foot.php';

?>