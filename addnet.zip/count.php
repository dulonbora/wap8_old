<?php
/************************************
Script : Adnetwork Website : http://facebook.com/pranto007
Script is created and provided by Pranto (http://facebook.com/pranto007) **************************************/
include 'db.php'; 

include 'functions.php'; 

$id=formget("id");

$hammad=mysqli_query("SELECT * FROM admlink WHERE id='$id'");
$khan=mysqli_fetch_array($hammad);
$hk=$khan['clicks']+1;
if ($khan['last_ip']==$_SERVER['REMOTE_ADDR'])
{
header('Location:'.$khan['linkurl'].'');
}
else 
{
mysqli_query('UPDATE admlink SET last_ip = "'.$_SERVER['REMOTE_ADDR'].'" , clicks = "'.$hk.'"
WHERE id = "'.$id.'"');
header('Location:'.$khan['linkurl'].'');
}

?>