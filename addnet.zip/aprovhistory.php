<?php


include 'db.php';
include 'functions.php';

headtag("Payment History - $SiteName");

if($userlog==1){


include 'head.php';

$uid=dump_udata("id"); 

echo '<div class="title">Payments History</div>';

$page=formget("page");

if(empty($page)){
$page=0;
}
$start=$page*1;
$end=($start+10);

$invo=mysqli_query("SELECT * FROM invoice WHERE userid='$uid (' ORDER BY id DESC LIMIT $start,$end");
 
if(mysqli_num_rows($invo)>0){
while($show=mysqli_fetch_array($invo)){ 
 

 $uidd=$show["status"]; 


 if($uidd==Rejected){ $uidd='<font color="red">Rejected</font>'; }
 
 if($uidd==PENDING){ $uidd='<font color="red">Pending</font>'; }
 else
 { $uidd="$uidd"; } 

 
$name=$show["name"];
if($name=='Approved') {
echo '<div class="proof"><b>Invoice ID: </b> #Aprv'.$show["id"].'<br/><b>Amount : </b><b id="num"> '.$show["amount"].' $</b><br/><b>Method : </b> '.$show["method"].'<br/>
 <b>Status :  <font color="green">'.$uidd.'
</font>
</b>

</div>';
}
}
 
echo '<br/><center><spam class="error"><a href="/invoices/'.($start-1).'">Prev</a></spam><spam class="success"><a href="/invoices/'.($start+1).'">Next</a></spam></center><br/>';

}


 else {
 
echo '<br/><div class="error">There is no payment history!</div><br/>';
}
 
echo '<div class="back"><a href="/user/dashboard">Go Back To Dashboard</a></div>';


include 'foot.php';


}

else {
header('Location:/');
}
?>
 