<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include 'db.php';
include 'functions.php';

headtag("$SiteName - Request Airtel Money Payout");

if($userlog==1){
include 'head.php';

 
$nwb=(dump_udata("pubalance")*60);
 
echo '<div class="title">Request Bank Payout</div>';
if($nwb<100){
 echo '<br/><div class="error">Your Account balance is ('.$nwb.' Rs) Which is lower than our minimum amount (Rs.100). Earn More and then request payout!</div>';
 }
else {
$uid=dump_udata("id");

if(isset($_POST["amount"]) AND isset($_POST["via"]) AND isset($_POST["captcha"])){

$amount=formpost("amount");
$via=formpost("via");
$ifscode=formpost("ifscode");
$holder=formpost("holder");
 
$bname=formpost("bname");
 
$captcha=formpost("captcha");
$errors=array();

if(!is_numeric($amount)){
  $errors[]='Amount must be a numeric value!';
 }


if(strlen($amount)<1){
  $errors[]='Amount cannot be empty!';
 }


if($_SESSION["captcha"]!=$captcha){
$errors[]='Captcha Code was wrong!';
}
if(strlen($via)<1){
  $errors[]='Number cannot be empty!';
 }
 
if(strlen($ifscode)<1){
  $errors[]='ifscode cannot be empty!';
 }
 
if(strlen($holder)<1){
  $errors[]='holder Name cannot be empty!';
 }
 
 
if(strlen($bname)<1){
  $errors[]='bank name cannot be empty!';
 }
 
 

if($amount>$nwb){
  $errors[]='Amount is bigger than account balance!';
}

if(empty($errors)){
  $date=date("l , F d , Y"); 
  $doit=mysqli_query("INSERT INTO bank (userid,amount,method,via,ifscode,holder,bname,status,time,name) VALUES ('$uid','$amount','Bank','$via','$ifscode','$holder','$bname','PENDING','$date','Amoney')");
$nwbl=($amount/60);
  $newbal=(dump_udata("pubalance")-$nwbl);
  $minusb=mysqli_query("UPDATE userdata SET pubalance='$newbal' WHERE id='$uid'");
  if($doit AND $minusb){
   echo '<br/><div class="success"><font color="green"><b>Your Bank Request Has successfully!</b></font><br/>Thanks For Your Request
We will be paid it In 48 Hours!</div><br/>';
  }
  else {
   echo '<div class="error">Error creating invoice!</div>';
}

}
else {

dump_error($errors);

}
}
echo '<div class="form"><form method="post">Amount (Min. Rs.100)<br/> <input type="text" name="amount"/><br/> Holder Name: <br/><input type="text" name="holder"/><br/> Bank Name: <br/><input type="text" name="bname"/><br/>Account Number:<br/><input type="text" name="via"/><br/> Ifsc Code: <br/><input type="text" name="ifscode"/><br/>Captcha:<br/><img src="/im'.md5(microtime()).'.jpg"/><br/>Input the characters showing in image!<br/><input type="text" name="captcha"/><br/><input type="submit" value="Request Now"/></form></div>';

 

}
}
else {

header('Location:/');
}

echo '<br/><div class="back"><img src="/home.png"/> <a href="/">Home</a> | <a href="/user/dashboard">Dashboard</a></div>';
include 'foot.php';

?>