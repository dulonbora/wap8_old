<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include '../db.php';
include '../functions.php';

headtag("$SiteName Apps Installation Stats");


if($userlog==1){

include '../head.php';
 
$uid=dump_udata("id");

$d=date("u");

echo '<div class="title">9Apps Apk  Installation Stats</div>';

 echo '<div class="notice"><font color="red"> Note: </font> Todays Installation Report will be Updated on Next Day.</div><div class="notice"> If some of days installation is not showing it means that days installation is 0. </div><div class="notice"> Earned Money will be added in your account on the 20th day of next month. </div><br/>';
 

echo '<table style="border-collapse:collapse;text-align:center;" align="center" height="60" border="1" bordercolor="#5b8ebb" cellpadding="5" width="90%">
<tbody><tr style="background-color:#5b8ebb">
<th height="28"> Date </th>

<th> Installation</th>
<th> Earning</th>
</tr><tr bgcolor="#e8e8e8">';


$datee=date("d-m-y"); 
 
$time=mysql_query("SELECT * FROM ucweb WHERE uid='$uid' status='VALID'");
 

$imps=mysql_fetch_array(mysql_query("SELECT * FROM imp WHERE uid='$uid' AND date='$datee'"));
$imp=$imps["imp"];
if(empty($imp)){
$imp=0;
}
$clicks=mysql_num_rows(mysql_query("SELECT * FROM ucweb WHERE userid='$uid' AND status='VALID'"));
$ctr=($clicks/$imp)*100;
$earn=($clicks*0.18);
 
$dates=mysql_query("SELECT * FROM ucweb WHERE userid='$uid' AND status='VALID'"); 
 while($time=mysql_fetch_array($dates)){ 



echo '<tr bgcolor="#e8e8e8"> 
<td> '.$time["time"].' </td>
<td><b id="num">'.$clicks.'</b></td>
<td><b id="num">'.$earn.' $</b></td>
</tr>';
}

$timps=mysql_query("SELECT * FROM imp WHERE uid='$uid'");
$timp=0;

while($tshow=mysql_fetch_array($timps)){
$timp=($timp+$tshow['imp']);
}
$tclicks=mysql_num_rows(mysql_query("SELECT * FROM ucweb WHERE userid='$uid' AND status='VALID'"));
$tctr=($tclicks/$timp)*100;
$tearn=($tclicks*0.18);

echo '<tr bgcolor="#bfc2c5"> 
<td height="28">Total</td>
<td><b id="num">'.$tclicks.'</b></td>
<td><b id="num">'.$tearn.' $</b></td>
</tr>';

echo '



</table>';


echo '<br/><div class="back"><img src="/home.png"/> <a href="/">Home</a> | <a href="/user/dashboard">Dashboard</a></div>';

include '../foot.php';

}
else {
header('Location:/');
}
?>
