<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include '../db.php';
include '../functions.php';

headtag("$SiteName - Apps Promotion Rules");

if($userlog==1){
include '../head.php';

echo
 '<div class="line"> Apps Promotion Rules </div>
<div class="right"><b><font color="red"> Apps Promotion Rules : </font></b></div><br>
<div class="pleft"> 1. <b> If you have A Own Web/Wap Site then you can use this service, we allow Non Adult and Adult both sites. </b></div>
<div class="pleft"> 2.  Non adult site without
<b> Real Contents </b> are not allowed. </div>
<div class="pleft"> 3.  Adult site without
<b> Real Contents </b> are allowed. </div>
<div class="pleft"> 4.  We will give you daily installation report on your dashboard. </div>
<div class="pleft"> 5.  Earned money will be autometically added on your Account Balance on the next day. </div>
<div class="pleft"> 6.  Minimum payout amount is 10 Rs via Recharge. </div>
<div class="pleft"> 7.  Payment through our site same Our Payment methods. </div>
<div class="pleft"> 8.  Earned Money will be added in your account on the 2nd day of next month. </div>
<div class="pleft"> 9. <b> Note : </b> You can change our <b> Banners and Text </b> of our UC and 9apps Adcode. </div>'; 

  echo '<br/><div class="back"><img src="/home.png"/><a href="/">Back To Dashboard</a></div>';
 
 include '../foot.php';

 }

 else {

 header('Location:/');
 }

?>
  