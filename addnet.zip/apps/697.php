<script>
window.location.href="http://mydearads.in/shahid/com.nineapps_v3.0.6.2_android_(Build1611251030).apk";
</script>