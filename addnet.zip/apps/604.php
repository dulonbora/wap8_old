<script>
window.location.href="http://click.union.ucweb.com/index.php?service=RedirectService&pub=dineshkumar1@mydearads703&offer_id=com.mobile.android.indiapp.apk";
</script>