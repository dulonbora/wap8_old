<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include '../db.php';
include '../functions.php';

$id=formget("id");
 
$uid=formget("uid"); 
$ip=$_SERVER['REMOTE_ADDR']; 
$ua=$_SERVER['HTTP_USER_AGENT']; 

$errors=array();

if($ip!=$_SERVER['REMOTE_ADDR']){
 $errors[]='a';
}
if($ua!=$_SERVER['HTTP_USER_AGENT']){
 $errors[]='a';
}

$date=date("d-m-Y");

$chIp=mysql_query("SELECT * FROM ucweb WHERE ip='$ip' AND time='$date'");

if(mysql_num_rows($chIp)>0){
 $errors[]='a';
}


if($_COOKIE['agmc_check']=='done'){  $errors[]='a'; } 

 
 if(empty($errors)){ 
 $Ads=mysql_fetch_array(mysql_query("SELECT * FROM admlink WHERE id='$id'"));

 $adurl=$Ads["linkurl"];
 $User=mysql_fetch_array(mysql_query("SELECT * FROM userdata WHERE id='$uid'"));

 $doIt1=mysql_query("INSERT INTO ucweb (ip,ua,userid,time,adtype,status) VALUES ('$ip','$ua','$uid','$date','User Ads','PENDING')");

 if($doIt1){
 
setcookie('agmc_check','done',time()+3600*24); 
   header('Location:'.$adurl.'');
 }

}

else {
 $Ads=mysql_fetch_array(mysql_query("SELECT * FROM admlink WHERE id='$id'"));

 $adurl=$Ads["linkurl"];
 
 
   $doIt2=mysql_query("INSERT INTO ucweb (ip,ua,userid,time,adtype,status) VALUES ('$ip','$ua','$uid','$date','Mobplaza','INVALID')");
   if($doIt2){
     header('Location:'.$adurl.'');
  }
 }
?>
