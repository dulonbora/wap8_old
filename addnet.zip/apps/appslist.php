<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include '../db.php';
include '../functions.php';

headtag("$SiteName - Apps Promotion List");

if($userlog==1){
include '../head.php';


 echo '<div class="title">Apps Promotion List</div>';

echo
  
 '<div class="line"> Apps List</div>';
echo 
'<div class="notice"><font color="red"> Note: </font> Todays Installation Report Earned Money will be Updated on Next Day.</div><div class="notice"> If some of days installation is not showing it means that days installation is 0. </div><div class="notice"> Earned Money will be added in your account on the 20th day of next month. </div><div class="proof"><img src="logo.jpg" width="60px" height="60px"><br><b> App Name: </b>
<font color="blue"> 9apps - APK </font> (<font color="green"> Running</font> )
<br><b> Link Type: </b> Direct Link<br><b> Platform:</b> Android <br><b> GEO: </b> India <br><b> Size: </b> 1.09 MB <br><b> CPI Rate: </b> <b class="fig"> 0.18$ </b><br><div class="ad"><a href="/apps/promote.php?id=1"> 9apps - APK Promo Link </a> | <a href="/apps/report.php"> 9apps - APK Install Report </a></div></div>';
echo

'<div class="proof"><img src="http://adzstar.in/banners/apps/uc/logo.jpg" width="60px" height="60px"><br><b> App Name: </b>
<font color="blue"> UC Browser - APK </font> (<font color="red"> Waiting</font> )
<br><b> Link Type: </b> Direct Link<br><b> Platform:</b> Android <br><b> GEO: </b> India <br><b> Size: </b> 1.3 MB <br><b> CPI Rate: </b> <b class="fig"> 0.15$ </b><br><div class="ad">Link Coming Soon</div></div>'; 


  echo '<br/><div class="back"><img src="/home.png"/><a href="/">Back To Dashboard</a></div>';
 
 include '../foot.php';

 }

 else {

 header('Location:/');
 }

?>
  