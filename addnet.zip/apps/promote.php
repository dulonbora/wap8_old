<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include '../db.php';
include '../functions.php';

headtag("$SiteName - Apps Promotion Links");

if($userlog==1){
include '../head.php';

echo
  
 '<div class="line"> Promotion Link </div>';
echo
'<div algin="center" class="uright"><font color="red">Hello Dear User To Get Apps Promotion Link You Have Just Send Us Email.</font>
<font color="blue"> <b>Just Write Your Site Url Nd Userid.</b></font><br/>
<font color="green">
We Will Give You The promotion link in few hours Via Email.</font><br/> You Can WhatsApp At 8795589006</div>'; 


 echo '<div class="title">Request For CPI</div>';
if(isset($_POST['email']) AND isset($_POST['msg']) AND isset($_POST['captcha'])){
 $eemail=formpost("email"); $emsg=formpost("msg");  $captcha=formpost("captcha");  $errors=array();
 if(!preg_match('/^([a-zA-Z0-9_.-]+)\@([a-zA-Z0-9_.-]+)\.([a-zA-Z0-9_.-]+)$/', $eemail)){   $errors[]='Email is not valid!';  }
 if(strlen($eemail)<1){   $errors[]='Email left empty!';  }  if(strlen($emsg)<1){   $errors[]='Msg left empty!';  }  if($_SESSION['captcha']!=$captcha){   $errors[]='Cakk';  }
 if(empty($errors)){
      $to = "shahidpkd4u@gmail.com";     $subject = 'Request For CPI';     $message = 'Hello Dear, You have a message from '.$eemail.' . Bellow is the message: [ '.$emsg.' ]';     $headers = 'From:Mydearads.IN System<'.$eemail.'>' . "\r\n" .     'Reply-To: '.$eemail.'' . "\r\n" .     'X-Mailer: Mydearads.In';
    mail($to, $subject, $message, $headers);  echo '<div class="success">Email successfully sent. You will be replied within 24 hours. Thank you for contacting!</div>'; } else {
 dump_error($errors); } } echo '<div class="form"><form method="post">Your Email: <br/><input type="text" name="email"/><br/>Type Message:<br/><textarea name="msg"></textarea><br/>Captcha:<br/><img src="/im'.md5(microtime()).'.jpg"/><br/>Input the words from image.<br/><input type="text" name="captcha"/><br/><input type="submit" value="Send Request"/></form></div>';
 
  echo '<br/><div class="back"><img src="/home.png"/><a href="/">Back To Dashboard</a></div>';
 
 include '../foot.php';

 }

 else {

 header('Location:/');
 }

?>
