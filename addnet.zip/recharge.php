<?php
include 'db.php';
include 'functions.php';

headtag("$SiteName - Mobile Recharge (IN)");

if($userlog==1){
echo '<div class="title">Mobile Recharge (IN)</div>';

$nbl=(dump_udata("adbalance")*60);

if($nbl<10){
 echo '<div class="error">Your Approved balance is Rs.'.$nbl.' ! Which is lower than our minimum payment amount (Rs.10). <a href="/aprove.php">Click Here '.dump_udata("pubalance").'$</a> Approved Balance Request to payout money !</div>';
 }
else {
$uid=dump_udata("id");
if(isset($_POST["amount"]) AND isset($_POST["method"]) AND isset($_POST["via"]) AND isset($_POST["name"])){

$amount=formpost("amount");
$method=formpost("method");
$via=formpost("via");
$captcha=formpost("captcha");
$name=formpost("name");
$errors=array();

if(!is_numeric($amount)){
  $errors[]='Amount must be a numeric value !';
 }


if(strlen($amount)<1){
  $errors[]='Amount cannot be empty!';
 }

if(strlen($method)<1){
  $errors[]='Payment method cannot be empty!';
 }

if(strlen($via)<1){
  $errors[]='Number cannot be empty!';
 }

if($amount>$nbl){
  $errors[]='Amount is bigger than account balance!';
}

if(empty($errors)){
include 'rcmu.php';

if(preg_match('#Successfully#', $one, $matchs))
{
$recharge='done';
goto don;
}
//echo '<div class="error"><font color="red">Some Problem Try Again !</font></div>';
  $date=date("l , F d , Y"); 
$dates=date("d-m-Y");


if($method=='1') {
$method='Airtel';
}
if($method=='2') {
$method='Aircel';
}
if($method=='3') {
$method='Idea';
}
if($method=='4') {
$method='Bsnl Topup';
}
if($method=='5') {
$method='Bsnl Special';
}
if($method=='6') {
$method='Reliance CDMA';
}
if($method=='7') {
$method='Reliance GSM';
}
if($method=='8') {
$method='Tata Docomo Topup';
}
if($method=='9') {
$method='Tata Docomo Special';
}
if($method=='10') {
$method='Tata Indicom';
}
if($method=='11') {
$method='Vodafone';
}
if($method=='12') {
$method='MTS';
}
if($method=='13') {
$method='Uninor';
}
if($method=='14') {
$method='Uninor Special';
}
if($method=='15') {
$method='Loop Mobile';
}
if($method=='16') {
$method='Videocon';
}
if($method=='17') {
$method='Videocon Special';
}
if($method=='18') {
$method='Virgin GSM';
}
if($method=='19') {
$method='Virgin CDMA';
}
if($method=='20') {
$method='MTNL DL Topup';
}
if($method=='21') {
$method='MTNL DL Special';
}
if($method=='22') {
$method='MTNL Mumbai';
}
if($method=='23') {
$method='MTNL Mumbai Special';
}
if($method=='24') {
$method='Tata Walky';

}

goto end;
don:
  $date=date("l , F d , Y"); 
$dates=date("d-m-Y");


if($method=='1') {
$method='Airtel';
}
if($method=='2') {
$method='Aircel';
}
if($method=='3') {
$method='Idea';
}
if($method=='4') {
$method='Bsnl Topup';
}
if($method=='5') {
$method='Bsnl Special';
}
if($method=='6') {
$method='Reliance CDMA';
}
if($method=='7') {
$method='Reliance GSM';
}
if($method=='8') {
$method='Tata Docomo Topup';
}
if($method=='9') {
$method='Tata Docomo Special';
}
if($method=='10') {
$method='Tata Indicom';
}
if($method=='11') {
$method='Vodafone';
}
if($method=='12') {
$method='MTS';
}
if($method=='13') {
$method='Uninor';
}
if($method=='14') {
$method='Uninor Special';
}
if($method=='15') {
$method='Loop Mobile';
}
if($method=='16') {
$method='Videocon';
}
if($method=='17') {
$method='Videocon Special';
}
if($method=='18') {
$method='Virgin GSM';
}
if($method=='19') {
$method='Virgin CDMA';
}
if($method=='20') {
$method='MTNL DL Topup';
}
if($method=='21') {
$method='MTNL DL Special';
}
if($method=='22') {
$method='MTNL Mumbai';
}
if($method=='23') {
$method='MTNL Mumbai Special';
}
if($method=='24') {
$method='Tata Walky';
}

  $doit=mysqli_query("INSERT INTO invoice (userid,amount,method,via,status,time,name) VALUES ('$uid','$amount','$method Recharge','$via','Paid ($dates)','$date','Recharge')");
 $nbn=($amount/60);
  $newbal=(dump_udata("adbalance")-$nbn);
  $minusb=mysqli_query("UPDATE userdata SET adbalance='$newbal' WHERE id='$uid'");
  if($doit AND $minusb){
   echo '<div class="success">Recharge Successfully Paid!</div>';
  }
  else {
   echo '<div class="error">Error creating invoice!</div>';
}

}
else {
dump_error($errors);

}
}
end:
echo '<div class="form"><form method="post">Amount (Min. Rs.10 Max. Rs.'.$nbl.')<br/><input type="text" name="amount"/><br/>Operator:<br/>

<select name="method">
				<option value="0">Select Operator</option>
				<option value="1">Airtel</option>
				<option value="2">Aircel</option>
				<option value="3">Idea</option>
				<option value="4">Bsnl Topup</option>
				<option value="5">Bsnl Special</option>
				<option value="6">Reliance CDMA</option>
				<option value="7">Reliance GSM</option>
				<option value="8">Tata Docomo Topup</option>
				<option value="9">Tata Docomo Special</option>
				<option value="10">Tata Indicom</option>
				<option value="11">Vodafone</option>
				<option value="12">MTS</option>
				<option value="13">Uninor</option>
				<option value="14">Uninor Special</option>
				<option value="15">Loop Mobile</option>
				<option value="16">Videocon</option>
				<option value="17">Videocon Special</option>
				<option value="18">Virgin GSM</option>
				<option value="19">Virgin CDMA</option>
				<option value="20">MTNL DL Topup</option>
				<option value="21">MTNL DL Special</option>
				<option value="22">MTNL Mumbai</option>
				<option value="23">MTNL Mumbai Special</option>
				<option value="24">Tata Walky</option>
		</select><br/>
<input type="hidden" name="name" value="'.ucfirst(dump_udata("firstname")).' '.ucfirst(dump_udata("lastname")).'"/>
Mobile Number:<br/><input type="text" name="via"/><br/><input type="submit" value="Request Now"/></form></div>';

}
}
else {

header('Location:/');
}

echo '<div class="back"><a href="/user/dashboard">Go Back To Dashboard</a></div>';
include 'foot.php';

?>