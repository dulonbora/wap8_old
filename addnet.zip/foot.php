<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

echo '<div class="footer" align="center"><b>All rights reserved<br/><a href="/">Mydearads.In</a> Pvt. 2016</b></div>';

echo '</body></html>';

?>
