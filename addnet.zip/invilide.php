<script>
window.location.href="http://mydearads.in/ad/html.php?uid=604&sid=694";
</script>