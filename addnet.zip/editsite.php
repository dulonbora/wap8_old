<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - Edit site");

if($userlog==1){

echo '<div class="title">Edit site</div>';
$site=formget("id");

$uid=dump_udata("id");

$chsite=mysqli_query("SELECT * FROM sites WHERE userid='$uid' AND id='$site'");

if(mysqli_num_rows($chsite)>0){

  if(isset($_POST['name']) AND isset($_POST['url']) AND isset($_POST['descr'])){
     
     
    $name=formpost("name");
    $url=formpost("url");
    $url=strtolower($url);
    $url=str_replace('http://',null,$url);
    $desc=formpost("descr");

    
    $errors=array();

    if(!preg_match('/([a-z0-9\.-])\.([a-z0-9\.-])/',$url)){
       $errors[]='Site url is not valid!';
     }

    if(strlen($name)<1){
      $errors[]='Site name cannot be empty!';
     }

   if(empty($errors)){
      $url='http://'.$url.'';
      $edsite=mysqli_query("UPDATE sites SET name='$name',url='$url',descr='$desc' WHERE userid='$uid' AND id='$site'");

      if($edsite){
         echo '<div class="success">Site edited successfully! <a href="/sites">Continue</a></div>';
       }
       else {
          echo 'unknoen err';
        }

     }
     else {
       dump_error($errors);
     }
 
     }
   $ssite=mysqli_fetch_array($chsite);
  echo '<div class="form"><form method="post">Site name:<br/><input type="text" name="name" value="'.$ssite["name"].'"/><br/>Site url:<br/><input type="text" name="url" value="'.$ssite["url"].'"/><br/>Description:<br/><textarea name="descr">'.$ssite["descr"].'</textarea><br/><input type="submit" value="Edit"/></form></div>';

 }
 else {
   echo '<div class="error">You do not own this site!</div>';
  }

 echo '<div class="ad"><img src="/home.png"/> <a href="/">Home</a> | <a href="/sites">My Sites</a></div>';
  
 include 'foot.php';
}

else {

header('Location:/');
}
?>