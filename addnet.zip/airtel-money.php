<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include 'db.php';
include 'functions.php';

headtag("$SiteName - Request Airtel Money Payout");

if($userlog==1){
include 'head.php';

 
$nwb=(dump_udata("pubalance")*61);
 
echo '<div class="title">Request Airtel Money Payout</div>';
if($nwb<50){
 echo '<br/><div class="error">Your Account balance is Rs.'.$nwb.' Which is lower than our minimum amount (Rs.50). Please Earn and then request payout!</div>';
 }
else {
$uid=dump_udata("id");

if(isset($_POST["amount"]) AND isset($_POST["via"]) AND isset($_POST["other"])){

$amount=formpost("amount");
$via=formpost("via");
$other=formpost("other");
$errors=array();

if(!is_numeric($amount)){
  $errors[]='Amount must be a numeric value!';
 }


if(strlen($amount)<1){
  $errors[]='Amount cannot be empty!';
 }

$login_check=mysqli_query("SELECT * FROM WHERE other='$other'");
   if(mysqli_num_rows($login_check)>0){
        $login_checked=mysqli_fetch_array($login_check);
        
        if($login_checked['other']!=$other){
           $errors[]='Secure pin entered was wrong!';
        }
      }

if(strlen($other)<1){
$errors[]='Plz enter your Secure pin!';
}
if(strlen($via)<1){
  $errors[]='Number cannot be empty!';
 }

$nb=($amount/61);

if($nb<$amount){ $errors[]='You cannot request lower than our minimum amount!';
}

if($amount>$nwb){
  $errors[]='Amount is bigger than account balance!';
}

if(empty($errors)){
  $date=date("l , F d , Y"); 
  $doit=mysqli_query("INSERT INTO invoice (userid,amount,method,via,status,time,name) VALUES ('$uid','$amount','Airtel Money','$via','PENDING','$date','Amoney')");
$nwbl=($amount/61);
  $newbal=(dump_udata("pubalance")-$nwbl);
  $minusb=mysqli_query("UPDATE userdata SET pubalance='$newbal' WHERE id='$uid'");
  if($doit AND $minusb){
   echo '<br/><div class="success"><font color="green"><b>Your Airtel Money Request Has been successfully!</b></font><br/>Thanks For Request
We will be paid it In 48 Hours!</div><br/>';
  }
  else {
   echo '<div class="error">Error creating invoice!</div>';
}

}
else {

dump_error($errors);

}
}
echo '<div class="form"><form method="post">Amount (Min. Rs.50)<br/><input type="text" name="amount"/><br/>Airtel Money Number:<br/><input type="text" name="via"/><br/>Secure Pin:<br/> <input type="text" name="other"/><br/><input type="submit" value="Request Now"/></form></div>';

 

}
}
else {

header('Location:/');
}

echo '<br/><div class="back"><img src="/home.png"/> <a href="/">Home</a> | <a href="/user/dashboard">Dashboard</a></div>';
include 'foot.php';

?>