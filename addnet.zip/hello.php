Js

<script src="https://mobfreshad.com/Jsads?siteid=5438&size=320x50" type="text/javascript"></script>


Smart Link

http://mobfreshadtrk.com/mainstream.php?site_id=5438


PHP

<?php
  
  function advertisement($site_id) 
  {    
     $requestURL="https://mobfreshad.com/Ads/advertisement";
     $postfield=array();
     $postfield["site_id"]= $site_id;
     if(function_exists("json_encode"))
        $postfield["servervars"]= json_encode($_SERVER);
     $postfield["ip"]=$_SERVER["REMOTE_ADDR"];
     $postfield["ua"]=$_SERVER["HTTP_USER_AGENT"];
     $postfield["number_of_ads"]= 1;
     $postfield["type"]= "html";
     $postfield["date_time"] = time();
     $postfield["size"] = "320x50";
     $ch=  curl_init($requestURL);
     curl_setopt($ch, CURLOPT_POST, true);
     curl_setopt($ch, CURLOPT_POSTFIELDS, $postfield);
     curl_setopt($ch, CURLOPT_FORBID_REUSE, true);
     curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 4);
     curl_setopt($ch, CURLOPT_TIMEOUT, 4);
     curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
     $exec=  curl_exec($ch);
     return $exec;
}	
echo advertisement("5438");
?>