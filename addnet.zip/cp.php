<?php

	include "init.php";
	
	if(!$user->is_user()){
		redir($setting["siteurl"]."/login");
		exit;
	}
	
	if($user->data("status")==2){
			$smarty->assign("title","Account Unverified ".$setting["sitename"]);
			template("user_unverified.tpl");
			exit;
		}
	if($user->data("status")==0){
		$smarty->assign("title","Account Blocked ".$setting["sitename"]);
		template("user_blocked.tpl");
		exit;
	}
	
	$smarty->assign("title","Change Password - ".$setting["sitename"]);
	
	if(isset($_GET["sendPin"]) && $_GET["sendPin"]=="new"){
	
		if($user->pin()){
			$_SESSION["message"]="New PIN has sent to your Email";
			redir($setting["siteurl"]."/cp");
		}
		else {
			echo "CRITICAL_DB_ERROR!";
		}
	}
	else {
	
		if(isset($_POST["old_password"]) && isset($_POST["new_password1"]) && isset($_POST["new_password2"]) && isset($_POST["pin"])){
		
			$oldPassword = post("old_password");
			$newPassword1 = post("new_password1");
			$newPassword2 = post("new_password2");
			$pin = post("pin");
			
			$errors = array();
			
			if($user->data("password")!=md5($oldPassword)) 	$errors[] = $_LANG["old_pw_mismatch"];
			if(empty($newPassword1) OR strlen($newPassword1)<1) 	$errors[] = $_LANG["password_empty"];
			if($newPassword1!=$newPassword2) 	$errors[] = $_LANG["password_not_match"];
			if(empty($pin) OR strlen($pin)<1) 	$errors[] = $_LANG["pin_empty"];
			if($pin!=$user->data("pin")) 	$errors[] = $_LANG["pin_invalid"];
			if(empty($errors)){
			
				$code = $db->update("users",array("password"=>md5($newPassword1)),array("id"=>$user->id));
				if($code){
					$_SESSION["message"]=$_LANG["pw_change_success"];
					unset($_SESSION["id"]);
					redir($setting["siteurl"]."/login");
				}
				else {
					echo "CRITICAL_DB_ERROR!";
					exit;
				}
			}
			else {
				$smarty->assign("change_pw_error",$errors);
			}
		}
		
		if(isset($_SESSION["message"])){
			$smarty->assign("message",$_SESSION["message"]);
			unset($_SESSION["message"]);
		}
		
		$form = '<form method="POST">'.$_LANG["old_password"].':<br/><input type="password" name="old_password"/><br/>'.$_LANG["new_password1"].':<br/><input type="password" name="new_password1"/><br/>'.$_LANG["new_password2"].':<br/><input type="password" name="new_password2"/><br/>'.$_LANG["pin"].': (<a href="?sendPin=new">Send New PIN</a>)<br/><input type="password" name="pin"/><br/><input type="submit" value="Change Password"/></form>';
		$smarty->assign("change_pw_form",$form);
		template("change_password.tpl");
	}
	
?>