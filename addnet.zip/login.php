<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include 'db.php';
include 'functions.php';

headtag("$SiteName - Login");

if($userlog==1){
header('Location:/user/dashboard');
}
else {

 
  if(isset($_POST['user_email']) AND isset($_POST['user_pwd'])){
     

 $user_email=formpost("user_email");
     $user_pwd=formpost("user_pwd");
     $user_password=md5($user_pwd);


     $errors=array();


     $login_check=mysqli_query("SELECT * FROM userdata WHERE email='$user_email'");

 
 
$login_check1=mysqli_query("SELECT * FROM userdata WHERE id='$user_email'");
  
 
     if(mysqli_num_rows($login_check)<1){
        $errors[]='No such user with this email!';
     }
 
 
     if(mysqli_num_rows($login_check)>0){
        $login_check2=mysqli_fetch_array($login_check);
        
        if($login_check2['password']!=$user_password){
           $errors[]='Password entered was wrong!';
        }
      }

     if(strlen($user_email)<1){
       $errors[]='Please enter your email!';
      }

     if(strlen($user_pwd)<1){
       $errors[]='Please enter your password!';
     }



     if(empty($errors)){
       $_SESSION['adsgem_email']=$user_email;
       $_SESSION['adsgem_password']=$user_password;
       header('Location:/user/dashboard');
     }

     else {
          echo '<div class="line"><img src="/error.png"/> <font color="red">Login Error:</font></div>';
          echo '<div class="error">';
          foreach($errors as $error){
          echo ''.$error.'<br/>';
          }
          echo '</div>';
     }
   }
   echo '<div class="line">Member Log in</div>';
   echo '<div class="form"><form method="post"><label for="user_email">Your Email:</label><br/><input type="text" name="user_email"/><br/><label for="user_password">Password:</label><br/><input type="password" name="user_pwd"/><br/>
<div id="forgot"><img src="/images/forgot.png" alt="?"> <a href="/user/forgot"><small>Forgot Password?</small></a></div> <input type="submit" value="Login Now"/></form></div>';

}

echo '<div class="back"><img src="/home.png"/> <a href="/">Home</a> &#171; Log in</div>';
include 'foot.php';
?>
