<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include 'db.php';
include 'functions.php';

headtag("$SiteName - My Sites");

if($userlog==1){
include 'head.php';

$uid=dump_udata("id");

echo '<div class="title">Sites & Ad Codes</div>';

$site=mysqli_query("SELECT * FROM sites WHERE userid='$uid'");

if(mysqli_num_rows($site)>0){
 while($show=mysqli_fetch_array($site)){

$stats=$show["status"];

if($stats=="Disabled"){

$stats='Active'; }

  echo '<div class="catRow2"><b>Site Name:</b> '.$show["name"].' </br/>
    <b>Site Url:</b> '.$show["url"].'<br/>
<b>Status: </b>
   ( <font color="green"> '.$stats.' </font>
)
    <br/><b>
Action: </b> <a href="/adcode/'.$show["id"].'">Get AdCodes</a> - 
<a href="/deletesite/'.$show["id"].'">Delete Site</a>

  </div>';
 }

 }
 else {
  echo '<br/><div class="error">You have not added any site!</div><br/>';
  }

 echo '<div class="balance"><a href="/newsite.php"><b>Add new site</b></a></div><br/>';

 echo '<div class="back"><img src="/home.png"/> <a href="/">Home</a> | <a href="/user/dashboard">Dashboard</a></div>';
 
 include 'foot.php';

}

else {

header('Location:/');

}

?>
