<?php
include 'db.php';
include 'functions.php';

headtag("$SiteName - CPM Adcodes");

if($userlog==1){
include 'head.php';

$site=formget("sid");


$chsite=mysqli_query("SELECT * FROM sites WHERE userid='$uid' AND id='$site'");

if(mysqli_num_rows($chsite)>0){


echo '<div class="title"><b>CPM Code : </b></div>'; 
echo '<div class="notice"><font color="red">Note :</font> Adcode use in your site top (head)</div>';
echo '<div class="uright"><textarea style="width: 444px; height: 55px;"><script type="text/javascript" src="http://mydearads.in/ad/cpm.php?uid='.$uid.'&sid='.$site.'"></script></textarea> </div>';

}
else {
echo '<div class="error">You do not own this site!</div>';
}

echo '<div class="back"><a href="/">Go Back To Home</a></div>';

include 'foot.php';
}
else {
header('Location:/');

}
?>
