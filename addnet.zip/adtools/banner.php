<?php

 echo file_get_contents('Ad23-2.gif');
 header('Content-type: image/gif');
 
 echo file_get_contents('play-1.gif');
header('Content-type: image/gif');

 ?>