<?php

echo file_get_contents('1.gif');
header('Content-type: image/gif');
 
echo file_get_contents('2.gif');
header('Content-type: image/gif');
 
header('Content-title: Adsgem');
?>