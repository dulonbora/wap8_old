<?php

echo file_get_contents('728 i pic.gif');
header('Content-type: image/gif');
header('Content-title: Adsgem');
?>