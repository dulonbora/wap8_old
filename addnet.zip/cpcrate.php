<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - Advertising CPC Rates");

echo '<div class="line"> Advertising CPC Rates </div>'; echo
'<div class="uright"> Please Read Below CPC rates After crearting Text or Banner Advertisement. </div><br>
<table style="border-collapse:collapse;text-align:center;" align="center" height="60" border="1" bordercolor="#5b8ebb" cellpadding="5" width="90%">
<tbody><tr style="background-color:#5b8ebb">
<th> Country Name </th>
<th> Charges</th>
</tr>
<tr bgcolor="#e8e8e8">
<td> WorldWide</td>
<td> 0.0095$ </td>
</tr>
<tr bgcolor="#e8e8e8">
<td> India </td>
<td> 0.001$ </td>
</tr>
<tr bgcolor="#e8e8e8">
<td> Bangladesh</td>
<td> 0.001$ </td>
</tr>
<tr bgcolor="#e8e8e8">
<td> Sri Lanka </td>
<td> 0.001$ </td>
</tr>
<tr bgcolor="#e8e8e8">
<td> United States</td>
<td> 0.025$ </td>
</tr>
<tr bgcolor="#e8e8e8">
<td> United Kingdom</td>
<td> 0.03$ </td>
</tr>
<tr bgcolor="#e8e8e8">
<td> South Africa </td>
<td> 0.03$ </td>
</tr>
<tr bgcolor="#e8e8e8">
<td> Germany</td>
<td> 0.035$ </td>
</tr>
<tr bgcolor="#e8e8e8">
<td> Saudi Arabia </td>
<td> 0.015$ </td>
</tr>
<tr bgcolor="#e8e8e8">
<td> United Arab Emirates</td>
<td> 0.017$ </td>
</tr>
<tr bgcolor="#e8e8e8">
<td> Other</td>
<td> 0.025$ </td>
</tr>
</tbody></table>';
echo 
'<div class="line"> Target  Device ( Additional Cost ) </div>';
echo 
'<div class="uright"><font color="red"><b> Note : </b></font> You have to pay Additional cost for Targeting Device. Our extra charges list are Below. </div>';
echo 
'<table style="border-collapse:collapse;text-align:center;" align="center" height="60" border="1" bordercolor="#5b8ebb" cellpadding="5" width="90%">
<tbody><tr style="background-color:#5b8ebb">
<th> Device Name</th>
<th> Extra Charges </th>
</tr>
<tr bgcolor="#e8e8e8">
<td> All Device </td>
<td> 0.00$ </td>
</tr>
<tr bgcolor="#e8e8e8">
<td> Symbian Device </td>
<td> 0.003$ </td>
</tr>
<tr bgcolor="#e8e8e8">
<td> Java Device </td>
<td> 0.002$ </td>
</tr>
<tr bgcolor="#e8e8e8">
<td> Android Device </td>
<td> 0.005$ </td>
</tr>
<tr bgcolor="#e8e8e8">
<td> Nokia Device </td>
<td> 0.002$ </td>
</tr>
<tr bgcolor="#e8e8e8">
<td> Samsung Device </td>
<td> 0.002$ </td>
</tr>
<tr bgcolor="#e8e8e8">
<td> Sony Ericssion</td>
<td> 0.003$ </td>
</tr>
<tr bgcolor="#e8e8e8">
<td> Black Berry</td>
<td> 0.003$ </td>
</tr>
<tr bgcolor="#e8e8e8">
<td> LG Device </td>
<td> 0.003$ </td>
</tr>
<tr bgcolor="#e8e8e8">
<td> Motorolla Device </td>
<td> 0.003$ </td>
</tr>
</tbody></table>';
echo
'<div class="uright"><font color="red"><b> Example : </b></font> Suppose if You want to make a advertise by targetting <font color="red"> India Country </font> and <font color="red"> Android Device</font> then you have to pay (0.01+0.005) = 0.015$ per Unique Click.
</div>';

echo '<div class="back"><img src="/home.png"> <a href="/">Back To Dashboard</a></div>';

include 'foot.php';
?>