<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - Support ticket");

if($userlog==1){
include 'head.php';

 $uid=dump_udata("id");
 $ticket=formget("id");

 echo '<div class="title">Support ticket #'.$ticket.'</div><br/>';

  
 $chticket=mysqli_query("SELECT * FROM tickets WHERE userid='$uid' AND id='$ticket'");

 if(mysqli_num_rows($chticket)>0){
   
   $tdtl=mysqli_fetch_array($chticket);
   
echo '<div style="background:#ececec;padding:2px;margin:2px;">Me ('.$tdtl["time"].')</div><div class="uright"><b>'.$tdtl["title"].'</b><br/>'.$tdtl["msg"].'</div>';

 $reply=mysqli_query("SELECT * FROM treplys WHERE tid='$ticket'");
 
 if(mysqli_num_rows($reply)>0){
    $replys=mysqli_fetch_array($reply);

   
   echo '<div style="background:#ececec;padding:2px;margin:2px;">Replied by Admin ('.$replys["date"].')</div><div class="ad"><b>Re1: '.$tdtl["title"].'</b><br/>'.$replys["reply"].'</div>';
    }

}
else {
 echo 'holy its not your ticket';
 }

  echo '<br/><div class="back"><img src="/home.png"/> <a href="/">Home</a> | <a href="/support-ticket">Support Tickets</a></div>';
 
 include 'foot.php';

 }

 else {

 header('Location:/');
 }

?>
  