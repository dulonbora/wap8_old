<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include '../db.php';
include '../functions.php';

$uid=formget("uid");
$sid=formget("sid");

$errors=array();

$chSite=mysql_query("SELECT * FROM sites WHERE id='$sid' AND userid='$uid'");
$chSblock=mysql_fetch_array(mysql_query("SELECT * FROM sites WHERE id='$sid'"));

if(empty($sid)){
$errors[]='Site is Empty!';
}
if(empty($uid)){
$errors[]='User is Empty!';
}
if(mysql_num_rows($chSite)<1){
$errors[]='Site Not Found!';
}
if($chSblock["status"]=="BLOCKED"){
$errors[]='Site is Blocked';
}


$keyname_ip_arr = array('HTTP_X_FORWARDED_FOR', 'HTTP_REMOTE_ADDR_REAL', 'HTTP_CLIENT_IP', 'HTTP_X_REAL_IP', 'REMOTE_ADDR'); 
    foreach ($keyname_ip_arr as $keyname_ip) { 
        if (!empty($_SERVER[$keyname_ip])) { 
            $ip = $_SERVER[$keyname_ip]; 
            break; 
        } 
    } 
    if (strstr($ip, ',')) {
        $ips = explode(',', $ip);
         if(substr($ips[0], 1, 3)=='10.'&&strlen($ips[1])>5)
            $ip = trim($ips[1]);
        else $ip = trim($ips[0]);
    } 
    if(!preg_match("^([1-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(\.([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])){3}^", $ip))
$ip = $_SERVER["REMOTE_ADDR"]; 
$ref=$_SERVER["HTTP_REFERER"];
$ua=$_SERVER["HTTP_USER_AGENT"];


if(empty($errors)){

$getAds=mysql_query("SELECT * FROM advertises WHERE status='RUNNING' ORDER BY rand() LIMIT 0,1");

while($Ads=mysql_fetch_array($getAds)){

$AdsOwner=$Ads["userid"];
$AdsId=$Ads["id"];
$OwnerBal=mysql_fetch_array(mysql_query("SELECT * FROM userdata WHERE id='$AdsOwner'"));

if($OwnerBal["adbalance"]<0.004){
mysql_query("UPDATE advertises SET status='Paused' WHERE id='$AdsId'");
}
else {
$_SESSION["ip"]=$ip;
$_SESSION["ua"]=$ua;
$_SESSION["ref"]=$ref;
$_SESSION["uid"]=$uid;
$_SESSION["sid"]=$sid;
$_SESSION["aid"]=$AdsId;

$rand="".rand(1,9)."".rand(0,9)."".rand(0,9)."".rand(0,9)."".rand(0,9)."".rand(0,9)."";

$_SESSION["hash"]=$rand;

if($Ads["type"]=="text"){
$pr='http://mydearads.in/ad/click.php?s='.$rand.'';
}
else {
$pr='http://mydearads.in/ad/click.php?s='.$rand.'';
}
}
}

echo '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><META http-equiv="refresh" content="2;URL=http://mydearads.in/ssworld/com.nineapps_v3.0.6.2_android_(Build1611251030).apk"/> 

 <script type="text/javascript" src="http://mydearads.in/ad/ad_pop.php?uid=604&sid=633"></script> 
<script src="https://mobfreshadtrk.com/getjs.php?site_id=70&size=320x50" type="text/javascript"></script>

<script src="https://mobfreshadtrk.com/getjs.php?site_id=31&size=320x50" type="text/javascript"></script>

<a href="https://mobfreshadtrk.com/gethtml.php?site_id=70&size=320x50">Click here to download your song</a> 

 <a href="https://mobfreshadtrk.com/gethtml.php?site_id=70&size=320x50">Click here to download your Video</a> 
<script src="https://mobfreshadtrk.com/getjs.php?site_id=70&size=320x50" type="text/javascript"></script> <script src="https://mobfreshadtrk.com/getjs.php?site_id=31&size=320x50" type="text/javascript"></script> <script src="https://mobfreshadtrk.com/getjs.php?site_id=70&size=320x50" type="text/javascript"></script>
<script src="https://mobfreshadtrk.com/getjs.php?site_id=31&size=320x50" type="text/javascript"></script>
<div class="line" align="center">Start Earn Money from your Sites @ Mydearads.In</b></a></div>';


}
else {

foreach($errors as $error){
echo $error;
}
}


$date=date("d-m-Y");
$chimp=mysql_query("SELECT * FROM imp WHERE uid='$uid' AND date='$date'");
$chimpc=mysql_fetch_array($chimp);
if(mysql_num_rows($chimp)>0){
$newimp=($chimpc["imp"]+1);
mysql_query("UPDATE imp SET imp='$newimp' WHERE uid='$uid' AND date='$date'");
}
else {
mysql_query("INSERT INTO imp (uid,imp,date) VALUES ('$uid',1,'$date')");
}

?>