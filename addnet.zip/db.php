<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/



ini_set('display_errors', 1); 
error_reporting(E_ALL);

$host = "localhost";
$data = "addnet";
$user = "root";
$pass = "";
$dbselect = mysqli_connect($host, $user, $pass, $data) or trigger_error(mysqli_error(),E_USER_ERROR); 
mysqli_set_charset($dbselect,"utf8");

?>
