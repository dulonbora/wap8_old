<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - Frequently asked questions");

echo '<div class="title">F.A.Q</div>';


echo '<div class="uright"> 1) <a href="#what-is-mydearads">What is Mydearads.In ? </a></div>';
echo
'<div class="uright"> 2) <a href="#how-it-works"> How does Mydearads.In Works ? </a></div>';
echo 
'<div class="uright"> 3) <a href="#how-to-earn"> How to earn from Mydearads.In ? </a></div>';
echo 
'<div class="uright"> 4) <a href="#how-to-withdraw"> How to Withdraw? </a></div>';
echo 
'<div class="uright"> 5) <a href="#how-to-advertise">How to advertise? </a></div>'; echo 
'<div class="uright"> 6) <a href="#how-to-addbalance"> How to Add Funds? </a></div>'; echo 
'<div class="uright"> 7) <a href="#payment-methods">Payment Methods? </a></div>';
echo 
'<div class="uright"> 8) <a href="#payment-time"> How Much Time Does It Takes To Process The Payment? </a></div>'; echo 
'<div class="line"> Answers: </div>'; echo 
'<div class="uright"><a name="what-is-Mydearads"></a><b> What is Mydearads.In ? </b><br> Mydealads.In is a mobile advertising platform where user can earn revenue by publishing ads and also can advertise their products. </div>'; echo 
'<div class="uright"><a name="how-it-works"></a><b> How does Mydearads.In Works ?
</b><br> On Mydearads.In, site owners can advertise their sites at low cost. You just share your users with other site owners who in return provide you their visitors.Also, you can convert the number of visitors you share into cash. </div>';
echo 
'<div class="uright"><a name="how-to-earn"></a><b> How to earn from Mydearads.In ?
</b><br> It is very simple to start benefiting from Nyearads.in The basic structure of how Mydearads.In works is: <br>
- <a href="/user/registration"> Account Signup </a><br>
- Add your Mobile site from your dashboard.<br>
- You place Mydearads.In ads on your site using Html adcode or Javascript adcode. <br>
- For each valid click you earn Upto 0.016$.<br>
- For each valid click you receive from Mydearads.In, 0.009$-0.018$(Depend on you) will be deducted from your account. Invalid click will be given free as Bonus Clicks. <br>
- Your visitors will come back to your site since they know your site. But users which we will send to your site will be new users for your site. This will help you grow traffic many times. </div>';
echo 
'<div class="uright"><a name="how-to-advertise"></a><b> How to advertise? </b><br> To advertise on Mydearads.In Go to your Dashboard &gt; Advertiser Panel &gt; Choose banner or text advertise. You can add funds using Bank,Airtel Money Payment. You can also target country and devices. </div>'; echo 
'<div class="uright"><a name="how-to-addbalance"></a><b> How to Add Funds? </b><br> To add funds, goto your dashboard and then click on Add  Advertiser balance. </div>'; echo 
'<div class="uright"><a name="payment-methods"></a><b> Payment Methods? </b><br> Currently AdzIncome.In support bellow methods:<br> -Recharge (IN)(Live) <br> - Paytm Wallet  <br> - Paypal And Payoneer (All country) <br> - Bank Transfer (IN) <br> If you want any new payment methods please <a href="/contact"> contact us </a> .</div>'; echo 
'<div class="uright"><a name="payment-time"></a><b> How Much Time Does It Takes To Process The Payment? </b><br> Currently Mydearads.In is paying within 48 Hour. </div>'; echo 
'<div class="uright"><a name="how-to-withdraw"></a><b> How To Withdraw? </b><br> To withdraw money please request money from your dashboard while your account balance is minimum 10 Rs. </div>';

echo '<div class="back"><img src="/home.png"/> <a href="/">HOME</a></div>';
include 'foot.php';

?>

