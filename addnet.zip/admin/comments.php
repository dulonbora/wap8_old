<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include '../db.php';
include '../functions.php';

headtag("$SiteName - Wall reply");

if($adminlog==1){
echo '<div class="line">Wall Comments</div>';

 $nid=formget("id");


 $wall=mysqli_fetch_array(mysqli_query("SELECT * FROM wall WHERE id='$nid'"));
 $comment=mysqli_query("SELECT * FROM comments WHERE commentid='$nid'");
$uid=$wall["userid"];
if(isset($_POST['reply'])){
  $reply=formpost("reply");
  

 $addnote=mysqli_query("INSERT INTO msgs (rid,body,status) VALUES ('$uid','You Have Comment By Admin Of Your Wall Post.','New')");
$addreply=mysqli_query("INSERT INTO comments (firstname,msg,commentid) VALUES ('none','$reply','$nid')");
  if($addreply){
    echo '<div class="success">Comment has added Successful!</div>';
   }
   else {
    echo 'unk';
   }
  }


 $uidd=$wall["firstname"];
  if($uidd==none){
    $uidd='Admin';
  }

 echo '<div class="saytop" align="left"><table width="100%"><tbody><tr><td align="left" width="32px"><img src="http://earnbuzz.in/web/profile.png" width="32px" class="ta"></td><td><b> '.$uidd.'</b><br> <img src="http://earnbuzz.in/web/offline.gif" alt="image"> </td><td align="right">'.$wall["time"].'</td></tr></tbody></table><div class="text"><b style="color:green;">'.$wall["body"].'</b><br> <br><div class="pages"><img src="http://earnbuzz.in/web/thumbup.png"> 1 <a href="/"><font color="blue"> Like</font></a> | </div></div>
</div>';
 
 while($swall=mysqli_fetch_array($comment)){
  $uidd=$swall["firstname"];
  if($uidd==none){
    $uidd='Admin';
  }
  echo '<div class="saytop" align="left"><table width="100%"><tbody><tr><td align="left" width="32px"><img src="http://earnbuzz.in/web/profile.png" width="32px" class="ta"></td><td><b> '.$uidd.'</b><br> <img src="http://earnbuzz.in/web/offline.gif" alt="image"> </td><td align="right">'.$wall["time"].'</td></tr></tbody></table><div class="text">'.$swall["msg"].'<br> <br><div class="pages"><img src="http://earnbuzz.in/web/thumbup.png"> 1 <a href="/"><font color="blue"> Like</font></a> | </div></div>
</div>';
}

echo '<div class="line">Add Comments </div><br/><div class="form"><b>Add Comment:</b><br/><form method="post"><textarea name="reply"></textarea><br/><input type="submit" value="Comment Now"/></form></div>';

echo '<a href="wall.php"><div class="uright">Wall</div></a>';
include '../foot.php';
}
else {
 header('Location:login.php');
 }
?>