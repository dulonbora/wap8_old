<?php


include '../db.php';
include '../functions.php';

headtag("$SiteName - Add User");

if($adminlog==1){
echo '<div class="line">Ad user apps</div>';

if(isset($_POST['pub'])){

$uid=formget("userid");

$pub=formpost("pub");

 
 $doit=mysqli_query("UPDATE cpi SET cpilink='$pub',status='Approved' WHERE userid='$uid'");

 $addnote=mysqli_query("INSERT INTO msgs (rid,body,status) VALUES ('$uid','Your 9apps Promotion has been approved.','New')");
if($addnote){
echo '<div class="success">Added successfully !</div>';
}
}

echo '<div class="form"><form method="post">
UC pub url : <br/><input type="text" name="pub"/><br/>
<input type="submit" value="Add 9apps"/>
</form></div>';
echo '<div class="back"><a href="sper.php">Go Back To CPI Page</a></div>';
include '../foot.php';
}
else {
header('Location:login.php');
}
?>
