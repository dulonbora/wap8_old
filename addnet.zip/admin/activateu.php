<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include '../db.php';
include '../functions.php';

headtag("$SiteName - Activate User");

if($adminlog==1){

$uid=formget("id");

 $doit=mysqli_query("UPDATE userdata SET status='Active' WHERE id='$uid'");
 if($doit){
  echo '<div class="success">User is Activated.</div>';
 }
 else {
  echo 'unk';
 }

 echo '<a href="user.php?id='.$uid.'"><div class="ua">User Details</div></a>';
 include '../foot.php';
 }
 else {
 header('Location:login.php');
 }
 ?>