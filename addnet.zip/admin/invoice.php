<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include '../db.php';
include '../functions.php';

headtag("$SiteName - Invoices");

if($adminlog==1){

echo '<div class="title">Invoices</div>';

$page=formget("page");

if(empty($page)){
$page=0;
}
$start=$page*10;
$end=($start+10);

 
$bks=mysqli_query("SELECT * FROM bank ORDER BY id DESC LIMIT $start,$end");
 
 while($bkss=mysqli_fetch_array($bks)){
$rsa=$bkss["amount"];
$dmt=($rsa/60);

  echo '<a href="invodbk.php?id='.$bkss["id"].'"><div class="uright">Invoice ID: '.$bkss["id"].'<br/>Amount: Rs. '.$rsa.' ( '.$dmt.' )<br/>Method: '.$bkss["method"].' ('.$bkss["via"].') <br/>Holder: '.$bkss["holder"].'<br/>Bank Name: '.$bkss["bname"].' <br/>Ifs Code : '.$bkss["ifscode"].' <br/> Status: '.$bkss["status"].'</div></a>';
 }
 
$ads=mysqli_query("SELECT * FROM invoice ORDER BY id DESC LIMIT $start,$end");
 
 while($sites=mysqli_fetch_array($ads)){
$rsa=$sites["amount"];
$dmt=($rsa/60);

  echo '<a href="invod.php?id='.$sites["id"].'"><div class="uright">Invoice ID: '.$sites["id"].'<br/>Amount: Rs. '.$rsa.' ( '.$dmt.' )<br/>Method: '.$sites["method"].' ('.$sites["via"].')<br/> Status: '.$sites["status"].'</div></a>';
 }
 echo '<div class="uright"><a href="?page='.($start+1).'">Next</a></div>';
 echo '<a href="index.php"><div class="back">Home</div></a>';
 include '../foot.php';
}
else {
header('Location:index.php');
}
?>