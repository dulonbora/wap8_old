<?php
include '../db.php';
include '../functions.php';

headtag("$SiteName - CPI Update");

if($adminlog==1){
echo '<div class="line">Cpa Update</div>';


if(isset($_POST['datep'])) {

$datep=formpost("datep");



$apikey = "9338-A2DA-EAC9-64AC-F09B-D464-9527-2ED2";

$url = "http://partners.adplay.in/cpa-report-api.php?apikey=$apikey&date=$datep";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_TIMEOUT, 30);
$html = curl_exec($ch);
$response_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if($response_code == 200) {
	$json = json_decode($html, true);
	$success = $json["success"];

	if($success == "true") {
		$convertions = $json["message"]["convertions"];
		$earning = $json["message"]["earning"];
		$data = $json["data"];

		echo "Total Convertions : $convertions <br/>";
		echo "Total Earning : $earning <br/>";
		echo "<hr/>";
		
		foreach($data as $value) {
			

$subid = $value["subid"];
			$carrier = $value["carrier"];
			$country = $value["country"];
			$platform = $value["platform"];
			$tranxid = $value["tranxid"];

$amount = $value["amount"];
		

echo "Sub ID - $subid <br/>";
			echo "Carrier - $carrier <br/>";
			echo "Country - $country <br/>";
			echo "Platform - $platform <br/>";
			echo "Amount - $amount <br/>";
			echo "<hr/>";

// Your Quary Here


$errors=array();


$urlmch=mysqli_query("SELECT * FROM cparepot WHERE txid LIKE '%$tranxid%'");

if(mysqli_num_rows($urlmch)>0){
$errors[]='already update';
}


if(empty($errors)){


if($carrier=="Vodafone(IN)"){


$amt=($amount-0.07);

}

if($carrier=="Wifiornotidentified(IN)"){


$amt=($amount-0.05);

}

else { 

$amt=($amount-0.10);

}


 $User=mysqli_fetch_array(mysqli_query("SELECT * FROM userdata WHERE id='$subid'"));

 $userbal=$User["cpabal"];

 $newU=($userbal+$amt);

$doIt=mysqli_query("INSERT INTO cparepot (userid,action,platform,carrier,country,earning,amount,date,txid,status) VALUES ('$subid','1','$platform','$carrier','$country','$amt','$amt','$datep','$tranxid','PENDING')");

 $udone=mysqli_query("UPDATE userdata SET cpabal='$newU' WHERE id='$subid'");

if(doIt){
echo '<div class="success">All Update Successfull</div>';
}
}


else { echo '<div class="error">Unknown error</div>'; 
}	

}
}
	else
	{
		echo $json["error"];
	}
}
else
{
	echo "Communication Problem";
}


}


$vaste=date("Y-m-d");
echo '<form method="post">
<div class="uright">
<label for="datep">Date:</label><br />
<input type="text" name="datep" value="'.$vaste.'"/></div>
<div class="uright">
<input type="submit" value="See Preview" />
</div>
</form>';


echo '<div class="back"><a href="/admin">Go Back To Admin Home</a></div>';

include '../foot.php';
}
else {
header('Location:login.php');
}

?>