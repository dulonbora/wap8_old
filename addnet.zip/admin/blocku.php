<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include '../db.php';
include '../functions.php';

headtag("$SiteName - Block User");

if($adminlog==1){

$uid=formget("id");

if(isset($_POST["res"])){
 $res=formpost("res");
 $reso="blocked $res";

 $doit=mysqli_query("UPDATE userdata SET status='$reso' WHERE id='$uid'");
 if($doit){
  echo '<div class="success">User is Blocked.</div>';
 }
 else {
  echo 'unk';
 }
}
echo '<form method="post">Reason:<br/><input type="text" name="res"/><br/><input type="submit" value="Block"/></form>';


 echo '<a href="user.php?id='.$uid.'"><div class="ua">User Details</div></a>';
 include '../foot.php';
 }
 else {
 header('Location:login.php');
 }
 ?>