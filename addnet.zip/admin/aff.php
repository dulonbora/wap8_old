<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include '../db.php';
include '../functions.php';

headtag("$SiteName - Admin Panel Beta");

if($adminlog==1){
echo '<div class="line">Pending Reffer</div>';

$page=formget("page");

if(empty($page)){
$page=0;
}
$start=$page*10;
$end=($start+10);

$act=formget("act"); 

 if($act=='del') {

 $id=formget("id");

 $sql=mysqli_query("DELETE FROM affiliates WHERE id='$id'"); echo '<div class="success"> Deleted Successfully</div>'; 
} 

//end del

$refs=mysqli_query("SELECT * FROM affiliates WHERE status='Pending' ORDER BY id DESC LIMIT $start,$end");


while($ref=mysqli_fetch_array($refs)){

echo '<div class="uright">Register user: <a href="user.php?id='.$ref["rid"].'">Joined User #'.$ref["rid"].'</a><br/>Status: '.$ref["status"].' <br/>Refer By: <a href="user.php?id='.$ref["aid"].'">USER#'.$ref["aid"].' </a>
<br/>Delete: <a href="?act=del&id='.$ref["id"].'">Delele #'.$ref["aid"].' </a><br/>
User stats
 <a href="affu.php?id='.$ref["aid"].'">ustat</a></div>';
}
echo '<div class="back"><a href="?page='.($page+1).'">Next</a></div>';
echo '<a href="index.php?redir=aff"><div class="back">Home</div></a>';

include '../foot.php';

}

?>
