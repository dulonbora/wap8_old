<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include '../db.php';
include '../functions.php';

headtag("$SiteName - Admin Login");

if($adminlog==1){
header('Location:index.php?error=session');
}
else {
echo '<div class="title">Login</div>';

if(isset($_POST['uname']) AND isset($_POST['pwd'])){

$auname=formpost("uname");
$apwd=formpost("pwd");
$apwd=md5($apwd);

$errors=array();

if(!file_exists("admins/$auname-data.pra")){
$errors[]='Username was wrong!';
}
$daTa=explode("|-pr-|",file_get_contents("admins/$auname-data.pra"));

if($apwd!=md5($daTa[2])){
$errors[]='Password was wrong!';
}

if(strlen($auname)<1){
$errors[]='Username was empty!';
}
if(strlen($apwd)<1){
$errors[]='Password was empty!';
}

if(empty($errors)){

$_SESSION['adsgem_rony']=$auname;
$_SESSION['adsgem_rpw']=$apwd;

header('Location:index.php?login=success');
}
else {
dump_error($errors);
}
}

echo '<div class="form"><form method="post">Admin Name:<br/><input type="text" name="uname"/><br/>Password:<br/><input type="password" name="pwd"/><div id="forgot"><img src="/forgot.png"/> <a href="forgot.php">Forgot Password</a></div><input type="submit" value="Log in"/></form></div>';
echo '<div class="ad"><img src="/home.png"/> <a href="/">Home</a></div>';
}
include '../foot.php';
?>
