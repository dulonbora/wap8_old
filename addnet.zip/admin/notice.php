<?php
/************************************
Script : Adnetwork Website : http://facebook.com/pranto007
Script is created and provided by Pranto (http://facebook.com/pranto007) **************************************/
include '../db.php'; include '../functions.php';
headtag("$SiteName - Links  Add");
if($adminlog==1){
echo '<div class="title">Add Link</div>';
if(isset($_POST['body'])){ 
$uid=formget("uid"); $body=formpost("body");

 $addnote=mysqli_query("INSERT INTO msgs (rid,body,status) VALUES ('$uid','$body','New')");
  if($addnote){ echo '<div class="success">Notification Added successfully!</div>'; } else { echo 'unl'; } } echo '<div class="form"><form method="post">Message:<br/><textarea name="body"></textarea><br/><input type="submit" value="Send Message"/></form></div>';
echo '<a href="user.php?id='. $uid.'"><div class="ua">user</div></a>'; include '../foot.php'; } else { header('Location:login.php'); } ?>