<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include '../db.php';
include '../functions.php';

headtag("$SiteName - Admin Panel Beta");

if($adminlog==1){
echo '<div class="line">Pending post</div>';

$page=formget("page");

if(empty($page)){
$page=0;
}
$start=$page*10;
$end=($start+10);


$act=formget("act");

 if($act=='del') {
$id=formget("id");
$sql=mysqli_query("DELETE FROM wall WHERE id='$id'");
echo '<div class="success"> Deleted Successfully</div>';
}
//end del
 
$wall=mysqli_query("SELECT * FROM wall WHERE status='PENDING' ORDER BY id DESC LIMIT $start,$end");


while($pwall=mysqli_fetch_array($wall)){


$uidd=$pwall["firstname"]; 

if($uidd==none)

{ $uidd='Admin';
} 


  echo '<div class="saytop" align="left"><table width="100%"><tbody><tr><td align="left" width="32px"><img src="http://earnbuzz.in/web/profile.png" width="32px" class="ta"></td><td><b> '.$uidd.'</b><br> <img src="http://earnbuzz.in/web/offline.gif" alt="image"> </td><td align="right">'.$pwall["time"].'</td></tr></tbody></table><div class="text"><b style="color:green;">'.$pwall["body"].'</b><br> <br><div class="pages"> <a href="?act=del&id='.$pwall["id"].'"><font color="blue">Delete</font></a> | <a href="comments.php?id='.$pwall["id"].'"><font color="blue">Comments('.$comments.')</font></a><a href="wallp.php?id='.$pwall["id"].'">Approved</a> </div></div> </div><br/>'; 
 }

echo '<div class="back"><a href="?page='.($page+1).'">Next</a></div>';
echo '<a href="wall.php"><div class="back">Home</div></a>';

include '../foot.php';

}
else {

header('Location:/login.php?error=ticket&reason=session');
}

?>