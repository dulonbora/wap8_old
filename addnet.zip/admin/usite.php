<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include '../db.php';
include '../functions.php';

headtag("$SiteName - Sites");

if($adminlog==1){

$uid=formget("id");
echo '<div class="title">Sites of U#'.$uid.'</div>';

$page=formget("page");

if(empty($page)){
$page=0;
}
$start=$page*10;
$end=($start+10);

$stat=mysqli_query("SELECT * FROM sites WHERE userid='$uid' ORDER BY id DESC LIMIT $start,$end");

while($show=mysqli_fetch_array($stat)){
 echo '<a href="site.php?id='.$show["id"].'"><div class="ua">Url: '.$show["url"].'<br/>Site ID: '.$show["id"].'</div></a>';
 }


echo '<div class="ad"><a href="?page='.($start+1).'">Next</a></div>';


echo '<a href="user.php?id='.$uid.'"><div class="back" align="center"><b>User Details</b></div></a>';

include '../foot.php';
}
else {

header('Location:login.php?error=session&out=no&valid=no&session=no');
}

?>
