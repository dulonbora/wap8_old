<?php
include '../db.php';
include '../functions.php';

headtag("$SiteName - CPI Accept");

if($adminlog==1){
$id=formget("id");
$uid=formget("uid");
$add=mysqli_query("UPDATE cpi SET status='Approved' WHERE id='$id' AND userid='$uid'");
if($add){
header('Location:add-apps.php?userid='.$uid.'');
}
else {
echo '<div class="error">Unknown error creationg !</div>';
}

echo '<div class="back"><a href="/">Go Back To Home</a></div>';
  
include '../foot.php';
}
else {
header('Location:login.php');
}
?>