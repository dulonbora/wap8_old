<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include '../db.php';
include '../functions.php';

headtag("$SiteName Dashboard");


if($adminlog==1){



$d=date("d");

echo '<div class="title">Showing Stats of '.date("F, Y").'</div><br/>';


echo '<table style="border-collapse:collapse;text-align:center;" align="center" height="60" border="1" bordercolor="#5b8ebb" cellpadding="5" width="90%">
<tbody><tr style="background-color:#5b8ebb">
<th height="28"> Date </th>
<th> Clicks</th>
<th> Earning</th>
</tr><tr bgcolor="#e8e8e8">';

for($i=$d;$i>0;$i--){

if(strlen($i)==1){
 $i="0$i";
}

$datee=date("".$i."-m-Y");


$cp=mysqli_fetch_array(mysqli_query("SELECT * FROM advertises WHERE userid='640' AND status='RUNNING'"));

$cpcc=$cp["ucpc"];


$clicks=mysqli_num_rows(mysqli_query("SELECT * FROM clicks WHERE time='$datee' AND status='VALID'"));

$earn=($clicks*$cpcc);

echo '<tr bgcolor="#e8e8e8"> 
<td>'.$datee.'</td>
<td><b id="num">'.$clicks.'</b></td>
<td><b id="num">'.$earn.' $</b></td>
</tr>';

}
$tclicks=mysqli_num_rows(mysqli_query("SELECT * FROM clicks WHERE status='VALID'"));

$tearn=($tclicks*0.009);

echo '<tr bgcolor="#bfc2c5"> 
<td height="28">Total</td>
<td><b id="num">'.$tclicks.'</b></td>
<td><b id="num">'.$tearn.' $</b></td>
</tr>';

echo '



</table>';

echo '<br/><div class="back"><img src="/home.png"/> <a href="index.php">Home</a> | <a href="index.php">Admin</a></div>';

include '../foot.php';

}
else {
header('Location:/');
}
?>
