<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include '../db.php';
include '../functions.php';

headtag("$SiteName - Ads");

if($adminlog==1){

$aid=formget("id");
if(isset($_POST['acpc']) AND isset($_POST['ucpc'])){
 $acpc=formpost("acpc");
 $ucpc=formpost("ucpc");
 $doit1=mysqli_query("UPDATE advertises SET acpc='$acpc',ucpc='$ucpc' WHERE id='$aid'");
 $doit=mysqli_query("UPDATE advertises SET status='RUNNING' WHERE id='$aid'");
 if($doit AND $doit1){
   echo '<div class="success">Advertise is running Now!</div>';
 }
 else {
  echo 'unknown err.';
 }
}
echo '<div class="form"><form method="post">Advertise CPC: (How much will cut from advertiser)<br/><input type="text" name="acpc"/><br/>User CPC: (How much user will paid)<br/><input type="text" name="ucpc"/><br/><input type="submit" value="Run"/></form></div>';
echo '<a href="advertise.php"><div class="ua">Advertises</div></a>';
include '../foot.php';
}
else {
header('Location:index.php');
}
?>