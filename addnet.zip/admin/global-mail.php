<?php
flush();
ob_flush();
include '../db.php';
include '../functions.php';
flush();
ob_flush();
flush();
ob_flush();
headtag("$SiteName - Global Email Send");
echo '<div class="line"><center>Global Email Send</center></div>';
if($adminlog==1)
{
$submit=$_REQUEST["submit"];
if(empty($submit))
{
goto end;
}

$get = mysqli_query("SELECT * FROM userdata WHERE status='Active'");

$number = mysqli_num_rows($get);

while($row = mysqli_fetch_array($get))
{
flush();
ob_flush();
$subject = $_POST['sub'];
$msg = $_POST['message'];
flush();
ob_flush();
$email = $row['email'];
$fname = $row['firstname'];
$lname = $row['lastname'];
$name = ''.$fname.' '.$lname.'';
$pubalance = $row['pubalance'];
$adbalance = $row['adbalance'];
flush();
ob_flush();
$to = $email;
$subject = $subject;
$message = 'Hi, '.$fname.'!


'.$msg.'

Call : +91-8795589006
 

Thanks For using

Mydearads.In';
$message = str_replace("[name]", $name, $message);
$message = str_replace("[pubalance]", $pubalance, $message);
$message = str_replace("[adbalance]", $adbalance, $message);
flush();
ob_flush();
$from = 'support@Mydearads.in';
$headers = "From: Mydearads.In Global Mail $from";
flush();
ob_flush();
mail($to,$subject,$message,$headers);
flush();
ob_flush();
}
echo '<div class="success">Total '.$number.' Email Sent to Active Users.</div>';
end:
echo '<div class="uright">Name: <b>[name]</b>, Publish Balance : <b>'.$pubalance.'</b> and Advence Balance : <b>'.$adbalance.'</b></div>';
echo '<div class="from"><form method="post">Subject:<br/><input type="text" name="sub"><br/>Message:<br/><textarea name="message"></textarea><br/><input type="submit" value="Send Mail" name="submit"></form></div>';
echo '<div class="back"><a href="index.php">Go Back To Home</a></div>';
include '../foot.php';
}
else
{
header('Location:index.php');
}
?>