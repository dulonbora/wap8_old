<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include '../db.php';
include '../functions.php';

headtag("$SiteName - Admin Panel Beta");

if($adminlog==1){

$tid=formget("id");
$uid=formget("uid");
if(isset($_POST['reply'])){
 
 $reply=formpost("reply");
 $date=date("h:i:s A , l , F d , Y");

 $addnote=mysqli_query("INSERT INTO msgs (rid,body,status) VALUES ('$uid','Your ticket has been Replied by Admin Plz check it.','New')");
 $doreply=mysqli_query("INSERT INTO treplys (tid,reply,date) VALUES ('$tid','$reply','$date')");
 $doch=mysqli_query("UPDATE tickets SET status='ANSWERED' WHERE id='$tid'");
 if($doreply AND $doch){
   echo '<div class="success">Ticket #'.$tid.' has replied!</div>';
 }
 else {
   echo 'Unknown error!';
 }
 }
 echo '<div class="form"><form method="post">Reply:<br/><textarea name="reply"></textarea><br/><input type="submit" value="Reply"/></form></div>';

echo '<a href="tickets.php"><div class="back">Tickets</div></a>';
include '../foot.php';
}
else {
header('Location:login.php?error=log&err=session');
}

?>