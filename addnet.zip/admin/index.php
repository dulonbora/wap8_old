<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include '../db.php';
include '../functions.php';

headtag("$SiteName - Admin Panel Beta");

if($adminlog==1){

echo '<div class="title">Welcome, <b><font color="green">Administrator ('.ucwords($admu).')</font></b></div>';

$auser=mysqli_query("SELECT * FROM userdata WHERE status='ACTIVE'");
$tuser=mysqli_num_rows(mysqli_query("SELECT * FROM userdata"));
$iuser=mysqli_query("SELECT * FROM userdata WHERE status='INACTIVE'");
$buser=mysqli_query("SELECT * FROM userdata WHERE status='BLOCKED'");
$asite=mysqli_query("SELECT * FROM sites WHERE status='<font color=\'green\'>Active</font>'");
$bsite=mysqli_query("SELECT * FROM sites WHERE status='BLOCKED'");
$rads=mysqli_query("SELECT * FROM advertises WHERE status='RUNNING'");
$pads=mysqli_query("SELECT * FROM advertises WHERE status='PENDING'");
$bads=mysqli_query("SELECT * FROM advertises WHERE status='REFUSED'");


$ausers=mysqli_num_rows($auser);
$iusers=mysqli_num_rows($iuser);
$busers=mysqli_num_rows($buser);
$asites=mysqli_num_rows($asite);
$bsites=mysqli_num_rows($bsite);
$rad=mysqli_num_rows($rads);
$pad=mysqli_num_rows($pads);
$bad=mysqli_num_rows($bads);


$ticket=mysqli_query("SELECT * FROM tickets WHERE status='Waiting for Admin\'s reply'");

if(mysqli_num_rows($ticket)>0){

$tickets=mysqli_num_rows($ticket);

echo '<a href="ticket.php"><div class="error">There are '.$tickets.' tickets waiting for reply!</div></a>';
}

if(mysqli_num_rows($pads)>0){

$padv=mysqli_num_rows($pads);


echo '<a href="advertise.php"><div class="error">There are '.$padv.' advertise waiting for activation!</div></a>';
}

$walp=mysqli_query("SELECT * FROM wall WHERE status='PENDING'");

if(mysqli_num_rows($walp)>0){

$posts=mysqli_num_rows($walp);

echo '<a href="unwall.php"><div class="error">There are '.$posts.' Wall post waiting for approval!</div></a>';
}

$chinvo=mysqli_query("SELECT * FROM invoice WHERE status='PENDING'");

if(mysqli_num_rows($chinvo)>0){
$invo=mysqli_num_rows($chinvo);
echo '<a href="unpayinvo.php"><div class="error">There are '.$invo.' Unpaid user invoices!</div></a>';
}


$chcpi=mysqli_query("SELECT * FROM cpi WHERE status='Pending'");

if(mysqli_num_rows($chcpi)>0){
$cpi=mysqli_num_rows($chcpi);
echo '<a href="sper.php"><div class="error">There are '.$cpi.' waiting for approval!</div></a>';
}

$adchinvo=mysqli_query("SELECT * FROM bank WHERE status='PENDING'");

if(mysqli_num_rows($adchinvo)>0){
$adinvo=mysqli_num_rows($adchinvo);
echo '<a href="unpayinvo.php"><div class="error">There are '.$adinvo.' Unpaid Bank invoices!</div></a>';
}

echo '<div class="form"><form method="get" action="user.php"><input type="text" name="id" value="User Id"/><input type="submit" value="Go"/></form><form method="get" action="search.php"><input type="text" name="q" value="Search User"/><input type="submit" value="Search"/></form></div>';

 $walls=mysqli_query("SELECT * FROM wall ORDER BY id DESC");
 $wall=mysqli_fetch_array($walls);  $uidd=$wall["firstname"];
 if($uidd==none)
{ $uidd='Admin'; }
 else   { $uidd="$uidd"; } echo '<div class="shout"><font color="black"><b>'.$uidd.'</b></font><br/><img src="/images/qua.gif"> <font color="#006100"><b> '.$wall["body"].'</b></font><center><a href="comments.php?id='.$wall["id"].'"><font color="black"><b>Reply!</b></font></a></center></div>'; 

$total_clicks=mysqli_num_rows(mysqli_query("SELECT * FROM clicks"));
$total_vclicks=mysqli_num_rows(mysqli_query("SELECT * FROM clicks WHERE status='VALID'"));
$date2=date("d-m-Y");
$today_clicks=mysqli_num_rows(mysqli_query("SELECT * FROM clicks WHERE time='$date2'"));
$today_vclicks=mysqli_num_rows(mysqli_query("SELECT * FROM clicks WHERE time='$date2' AND status='VALID'"));
$total_iclicks=($total_clicks-$total_vclicks);
$today_iclicks=($today_clicks-$today_vclicks);
$total_earn=($total_vclicks*0.009);
$today_earn=($today_vclicks*0.009);
 
$total_install=mysqli_num_rows(mysqli_query("SELECT * FROM ucweb"));
$total_vinstall=mysqli_num_rows(mysqli_query("SELECT * FROM ucweb WHERE status='VALID'"));
$date2=date("d-m-Y");
$today_install=mysqli_num_rows(mysqli_query("SELECT * FROM ucweb WHERE time='$date2'"));
$today_vinstall=mysqli_num_rows(mysqli_query("SELECT * FROM ucweb WHERE time='$date2' AND status='VALID'"));
$total_iinstall=($total_install-$total_vinstall);
$today_iinstall=($today_install-$today_vinstall);
$total_earns=($total_vinstall*0.18);
$today_earns=($today_vinstall*0.18);
 
$total_invo=mysqli_num_rows(mysqli_query("SELECT * FROM invoice"));
$paid_invo=mysqli_num_rows(mysqli_query("SELECT * FROM invoice WHERE status LIKE '%Paid%'"));
$pending_invo=mysqli_num_rows(mysqli_query("SELECT * FROM invoice WHERE status LIKE '%Pending%'"));
$validated_invo=mysqli_num_rows(mysqli_query("SELECT * FROM invoice WHERE status LIKE '%Validated%'"));

 $total_wall=mysqli_num_rows(mysqli_query("SELECT * FROM wall"));
$total_reply=mysqli_num_rows(mysqli_query("SELECT * FROM comments"));
 
$total_news=mysqli_num_rows(mysqli_query("SELECT * FROM news"));
$total_reply=mysqli_num_rows(mysqli_query("SELECT * FROM newsreplys"));

echo '<div class="title">Main Menu</div>';

echo '<div class="form" style="padding:0px;margin:2px;">';

echo '<div style="border-bottom:1px dotted #ccc;padding:4px;"><b><a href="users.php">Users</a></b><br/>'.$tuser.' Total, '.$ausers.' Active, '.$iusers.' Inactive, '.$busers.' Blocked.</div>';

echo '<div style="border-bottom:1px dotted #ccc;padding:4px;"><b><a href="sites.php">Sites</a></b><br/>'.($asites+$bsites).' Total, '.$asites.' Active, '.$bsites.' Blocked.</div>';

echo '<div style="border-bottom:1px dotted #ccc;padding:4px;"><b><a href="stats.php">Statistics</a></b><br/>'.$total_clicks.' Total, '.$today_clicks.' Today, '.$total_earn.'$ Total, '.$today_earn.'$ Today.</div>';

 echo '<div style="border-bottom:1px dotted #ccc;padding:4px;"><b><a href="appsstat.php">Apps Statistics</a></b><br/>'.$total_install.' Total, '.$today_install.' Today, '.$total_earns.'$ Total, '.$today_earns.'$ Today.</div>';
 

echo '<div style="border-bottom:1px dotted #ccc;padding:4px;"><b><a href="advertise.php">Advertises</a></b><br/>'.($rad+$pad+$bad).' Total, '.$rad.' Running, '.$pad.' Pending, '.$bad.' Refused.</div>';


echo '<div style="border-bottom:1px dotted #ccc;padding:4px;"><b><a href="cpa-stats.php">CPA Statistics</a></b><br/>Check All CPA Statics.</div>';
echo '<div style="border-bottom:1px dotted #ccc;padding:4px;"><b><a href="cpa-update.php">CPA Balance Update</a></b><br/>Update Users CPA Balance.</div>';


 echo '<div style="border-bottom:1px dotted #ccc;padding:4px;"><b><a href="total-report.php">Total Reports</a></b></div>';

 echo '<div style="border-bottom:1px dotted #ccc;padding:4px;"><b><a href="global-mail.php">Global Mail</a></b></div>';

 echo '<div style="border-bottom:1px dotted #ccc;padding:4px;"><b><a href="admlinks.php">Admlinks</a></b></div>';
 
 echo '<div style="border-bottom:1px dotted #ccc;padding:4px;"><b><a href="cpa-api.php">Cpa Report</a></b></div>';

 echo '<div style="border-bottom:1px dotted #ccc;padding:4px;"><b><a href="all-cpa.php">Cpa All Report</a></b></div>';


 echo '<div style="border-bottom:1px dotted #ccc;padding:4px;"><b><a href="aff.php">Affiliate</a></b></div>';

echo '<div style="border-bottom:1px dotted #ccc;padding:4px;"><b><a href="prlinkd.php">Promo links</a></b></div>';
echo '<div style="border-bottom:1px dotted #ccc;padding:4px;"><b><a href="invoice.php">Invoices</a></b><br/>'.$total_invo.' Total, '.$paid_invo.' Paid, '.$pending_invo.' Pending, '.$validated_invo.' Validated.</div>';

 echo '<div style="border-bottom:1px dotted #ccc;padding:4px;"><b><a href="wall.php">Wall Service</a></b><br/>'.$total_wall.' Wall, '.$total_reply.' Comments.</div>';
 
echo '<div style="border-bottom:1px dotted #ccc;padding:4px;"><b><a href="news.php">News</a></b><br/>'.$total_news.' News, '.$total_reply.' Replies.</div>';

if($admin_id=='pranto'){

$admin_count=count(glob("admins/*.pra"));
echo '<div style="border-bottom:1px dotted #ccc;padding:4px;"><b><a href="admins.php">Admins</a></b><br/>'.$admin_count.' Active Admins</div>';
}


echo '<div style="border-bottom:1px dotted #ccc;padding:4px;"><b><a href="account.php">Account</a></b><br/>Manage Account and Password</div>';
echo '</div>';

echo '<div class="back"><img src="/home.png"/> <a href="/">Home</a> | <a href="logout.php">Logout</a></div>';

include '../foot.php';



}
else {

header('Location:login.php?redir=index');

}


?>