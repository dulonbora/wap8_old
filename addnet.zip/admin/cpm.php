<?php


include '../db.php';
include '../functions.php';

headtag("$SiteName - CPM Stats");

if($adminlog==1){

$total_clicks=mysqli_num_rows(mysqli_query("SELECT * FROM cpm"));

$total_vclicks=mysqli_num_rows(mysqli_query("SELECT * FROM cpm WHERE status='VALID'"));

$date=date("d-m-Y");
$today_clicks=mysqli_num_rows(mysqli_query("SELECT * FROM cpm WHERE date='$date'"));

$today_vclicks=mysqli_num_rows(mysqli_query("SELECT * FROM cpm WHERE date='$date' AND status='VALID'"));


$total_iclicks=($total_clicks+$total_vclicks);
$today_iclicks=($today_clicks+$today_vclicks);
$total_earn=($total_vclicks*0.0003);
$today_earn=($today_vclicks*0.0003);

echo '<div class="line">CPM Statistics</div>';
echo '<div class="form" align="center"><table><tr><td><div class="ad" style="padding:5px;margin:5px;"><div style="background:#ececec;padding:2px;margin:2px;" align="center"><b>Total:</b></div><div class="ad" style="padding:3.5px">Total CPM: '.$total_clicks.'<br/>Total Valid CPM: '.$total_vclicks.'<br/>User earned total: '.$total_earn.'$</div></td><td><div class="ad" style="padding:5px;margin:5px;"><div style="background:#ececec;padding:2px;margin:2px;" align="center"><b>Today CPM:</b></div><div class="ad" style="padding:3.5px">Today CPM: '.$today_clicks.'<br/>Today Valid CPM: '.$today_vclicks.'<br/>User earned today: '.$today_earn.'$</div></td></tr></table></div>';

echo '<div class="line">CPM Statistic Report</div>';

$page=formget("page");

if(empty($page)){
$page=0;
}
$start=$page*1;
$end=($start+50);

$stat=mysqli_query("SELECT * FROM cpm ORDER BY id DESC LIMIT $start,$end");

include_once('../country/ip2country.php');
$ip2c=new ip2country();
$ip2c->mysqli_host='localhost';
$ip2c->db_user='piubap';
$ip2c->db_pass='piubap';
$ip2c->db_name='piubap';
$ip2c->table_name='ip2c';
if(mysqli_num_rows($stat)>0){

echo '<div class="form"><table style="border-collapse:collapse;text-align:center;" border="1" bordercolor="#5b8ebb" height="60" cellpadding="5" align="center">
<tr style="background-color:#5b8ebb">
<th>Date</th>
<th>IP</th>
<th>User-Agent</th>
<th>Country</th>
<th>From</th>
<th>User</th>
<th>Site</th>
</tr>';

while($show=mysqli_fetch_array($stat)){



echo '<tr bgcolor="#e8e8e8">
<td>'.$show["date"].'('.$show["time"].')</td>
<td>'.$show["ip"].'</td>
<td>'.strstr(urldecode($show["ua"]),'(',true).'</td>
<td>'.$show["country"].'('. $ip2c->get_country_name($show["ip"]) . ')</td>
<td><a href="'.$show["host"].'">'.strstr(str_replace('http://',null,$show["host"]),'/',true).'</a></td>
<td><a href="user.php?id='.$show["userid"].'">'.$show["userid"].'</a></td>
<td><a href="site.php?id='.$show["siteid"].'">'.$show["siteid"].'</a></td>
</tr>';


}

echo '



</table></div>';

echo '<br/><center><spam class="error"><a href="?page='.($start-1).'">Prev</a></spam><spam class="success"><a href="?page='.($start+1).'">Next</a></spam></center><br/>';
}
else {
echo '<br/><div class="error">There is no clicks!</div>';
}

echo '<div class="back"><a href="index.php">Go Back To Admin Home</a></div>';
include '../foot.php';
}
else{
 echo '<META http-equiv="refresh" content="0;URL=/admin/index.php">';
}
?>
