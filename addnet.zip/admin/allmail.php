<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include '../db.php';
include '../functions.php';

headtag("$SiteName - Validate Invoice");

if($adminlog==1){

echo '<div class="line">Mail User</div>';


 if(isset($_POST['msg'])){ 

 
 $emsg=formpost("msg");
 

 $errors=array(); 

 if(strlen($emsg)<1){   $errors[]='Msg left empty!';  } 

 
 if(empty($errors)){

 
$get=mysqli_query("SELECT * FROM userdata");
$number=mysqli_num_rows($get);

while($row=mysqli_fetch_array($get)){

$emailz=$row["email"];

 
       $to      = $emailz;
    $subject = 'Mydearads Admin Mail';
    $message = ''.$emsg.'


Support:
support@mydearads.in

+918795589006

Thanks,
Mydearads Team,
Mydearads.In';
    
$headers = 'From: Mydearads Admin <support@mydearads.in>' . "\r\n" .     'Reply-To: shahidpkd4u@gmail.com' . "\r\n" .     'X-Mailer: Mydearads.In';
    mail($to, $subject, $message, $headers);

 echo '<div class="success">Message Successfully Sent!</div>';

}

 else {
 dump_error($errors); 
}

}


echo '<div class="uright">Users Publishers Balance: '.$row["pubalance"].'$</div>';

}
 echo '<div class="form"><form method="post">Msg To User:<br/><textarea name="msg"></textarea><br/><input type="submit" value="Send Message"/></form></div>';
 
echo '<a href="../index.php"><div class="back">HOME</div></a>'; 

 include '../foot.php';

 }
 else {
 header('Location:login.php');
 }
?>