
<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include '../db.php';
include '../functions.php';
 
header("$SiteName - Block Site");

if($adminlog==1){

 $sid=formget("id");

 $doit=mysqli_query("UPDATE sites SET status='Disabled' WHERE id='$sid'");
 if($doit){
  echo '<div class="success">Site Disabled Successfully!</div>';
 }
 else {
  echo '<div class="error">Unknown Error!</div>';
 }
 
 echo '<a href="site.php?id='.$sid.'"><div class="back">SITES</div></a>';
 include '../foot.php';
 }
 else {
  header('Location:login.php');
 }
 ?>