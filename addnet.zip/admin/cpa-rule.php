<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - Cpa Campaign Promoting Rules");


if($userlog==1){

include 'head.php';


echo '<div class="line">Cpa Campaign Rule</div>';


echo '<div class="uright">1) <a href="#what-is-cpa">What is CPA Campaign ?</a></div>

<div class="uright">2) <a href="#what-to-do">What Type of Action Advertisers Required Normally ?</a></div>

<div class="uright">3) <a href="#can-i-promote">Can I Promote CPA Campaigns in my Site ?</a></div>

<div class="uright">4) <a href="#what-is-my-link">What is my CPA affilate link and Banners ?</a></div>

<div class="uright">5) <a href="#what-i-get">What I get when My Referred Visitor Complete a Conversation ?</a></div>

<div class="uright">6) <a href="#is-adult-allowed">Can I send Visitor From Adult Sites ?</a></div>

<div class="uright">7) <a href="#report-time">When I ll Get my Convertion Report ?</a></div>

<div class="uright">8) <a href="#payment-time">When I ll Get my Payment ?</a></div>

<div class="line">Answers:</div>

<div class="uright">1) <a name="what-is-cpa"></a><b>What is CPA Campaign ?</b><br/>CPA means Cost Per Action. In this Advertisement system A Conversation will be Complete when a Visitor Complete the Required Action of Advertiser.</div>

<div class="uright">2) <a name="what-to-do"></a><b>What Type of Action Advertisers Required Normally ?</b><br/>Normally Advertisers Required to Registration / Click to a Confirmation Link etc to Complete a Conversation.</div>

<div class="uright">3) <a name="can-i-promote"></a><b>Can I Promote CPA Campaigns in my Site ?</b><br/>Sure, We are Finding CPA Campaign Publishers to Publish Our CPA Campaigns. Anybody can Join with this Program.</div>

<div class="uright">4) <a name="what-is-my-link"></a><b>What is my CPA affilate link and Banners ?</b><br/>Your Unique CPA Link is Available on CPA REPORT Page. Please <a href="/cpa-adcode.php">Click Here</a> to Get Your Affilate Link Where you Need to Send your Visitors. You Can use your Own Text/Image Banner to Promot this Link.</div>

<div class="uright">5) <a name="what-i-get"></a><b>What I get when My Referred Visitor Complete a Conversation ?</b><br/>When a Visitor make a Successful Conversation we ll Pay You Commission for it. Commission will be Depend on Your Quality of Traffic. We ll pay 95% Revenue which we take From Advertisers. The Commission Amount will be Minimum 0.10$ up to 1.00$ per Conversation.</div>

<div class="uright">6) <a name="is-adult-allowed"></a><b>Can I send Visitor From Adult Sites ?</b><br/>Yes, There is No Limitation to send Visitors. We ll Accept all Visitors for this Program.</div>

<div class="uright">7) <a name="report-time"></a><b>When I ll Get my Convertion Report ?</b><br/>You will get Convertion Report within 5 Minutes of Convertion.</div>

<div class="uright">8) <a name="payment-time"></a><b>When I ll Get my Payment ?</b><br/>We will transfer CPA Earning balance to your Account Balance on the 1st Day of next Month. Then you Can payout it Anytime with Our Payment Methods.</div>';

echo '<div class="back"><img src="/home.png"/> <a href="/">HOME</a></div>';

}
include 'foot.php';

?>
