<?php

	include "init.php";
	
	if(!$admin->is_admin()){
		redir("login.php");
		exit;
	}
	
	$module = get("module");
	
	if($module == "sites"){
	
		if($admin->data("role")==3){
			$admin->head("Access Denied!");
			echo '<div class="menu">Sorry but you are not allowed to access this page!</div>';
			$admin->foot();
			exit;
		}
	
		$admin->head("Sites Settings");
		echo '<div class="title">Site Categories</div>';
		
		if(isset($_POST["sitecats"])){
		
			$siteCats = post("sitecats");
			
			if(empty($siteCats)){
				echo "Empty Categorys";
				exit;
			}
			
			if(preg_match('/,/',$siteCats)){
				if(substr($siteCats,-1)==","){
					$siteCats = substr($siteCats,0,-1);
				}
				$cats = str_replace(",","[%,%]",$siteCats);
			}
			else {
				$cats = $siteCats;
			}
			
			$update = $db->update("settings",array("sitecats"=>$cats),"");
			
			if($update){
				echo '<div class="success">Successfully Updated!</div>';
			}
			else { echo "CRITICAL_DB_ERROR~!"; }
		}
		echo '<div class="menu"><form method="post"><textarea name="sitecats">'.str_replace("[%,%]",",",$setting["sitecats"]).'</textarea><br/>Each Category Separated by comma(,) <br/><input type="submit" value="Update"/></form></div>';
	}
	elseif($module == "ads"){
		
		if($admin->data("role")==3){
			$admin->head("Access Denied!");
			echo '<div class="menu">Sorry but you are not allowed to access this page!</div>';
			$admin->foot();
			exit;
		}
	
		$admin->head("Ad Settings");
		echo '<div class="title">Ad Settings</div>';
		
		if(isset($_POST["cpc"],$_POST["banners"])){
			
			$cpc = post("cpc");
			$banners = post("banners");
			
			$errors = array();
			
			if(empty($cpc) OR strlen($cpc)<1 OR !is_numeric($cpc)) 	$errors[] = "CPC Invalid";
			if(empty($banners) OR strlen($banners)<1 OR !is_numeric($banners)) 	$errors[] = "Banners Invalid";
			
			if(empty($errors)){
				
				$update = $db->update("settings",array("minimumcpc"=>$cpc,"adbanners"=>$banners),"");
				if($update){
					echo '<div class="success">Successfully Updated!</div>';
				}
				else { 
					echo "CRITICAL_DB_ERROR~!"; 
				}
			}
			else {
				$admin->error($errors);
			}
		}
		
		echo '<div class="menu" style="padding:0">';
		echo '<form method="post">';
		echo '<div class="border">Minimum CPC: $ <input type="text" name="cpc" value="'.$setting["minimumcpc"].'" size="4"/><br/>(Minimum CPC for Creating Ad)</div>';
		echo '<div class="border">Banners in Form: <input type="text" name="banners" value="'.$setting["adbanners"].'" size="1"/><br/>(Banners for Creating Ad)</div>';
		echo '<div class="border"><input type="submit" value="Update"></div></form></div>';
		
	}
	elseif($module == "clicks"){
		
		if($admin->data("role")==3){
			$admin->head("Access Denied!");
			echo '<div class="menu">Sorry but you are not allowed to access this page!</div>';
			$admin->foot();
			exit;
		}
	
		$admin->head("Clicks & Impressions Settings");
		echo '<div class="title">Clicks & Impressions Settings</div>';
		
		if(isset($_POST["invalid_clicks"],$_POST["impressions"],$_POST["htmlads"],$_POST["reftrack"])){
		
			$redirurl = post("redirurl");
			$redirurl = str_replace('http://',null,$redirurl);
			
			if(empty($redirurl) OR strlen($redirurl)<1){
				echo "URL EMPTY!~~~!";
				exit;
			}
		
			$update = $db->update("settings",array("impressions"=>post("impressions"),"invalid_clicks"=>post("invalid_clicks"),"redirurl"=>$redirurl,"htmlads"=>post("htmlads"),"reftrack"=>post("reftrack")),"");
			if($update){
				echo '<div class="success">Successfully Updated!</div>';
			}
			else { 
				echo "CRITICAL_DB_ERROR~!"; 
			}
		}
		echo '<div class="menu" style="padding:0">';
		echo '<form method="post">';
		echo '<div class="border">Invalid Clicks Counting: <select name="invalid_clicks">';
		if($setting["invalid_clicks"]==1){
			echo '<option value="1" selected="selected">On</option>';
			echo '<option value="0">Off</option>';
		}
		else {
			echo '<option value="1">On</option>';
			echo '<option value="0" selected="selected">Off</option>';
		}
		echo '</select></div>';
		echo '<div class="border">Impressions: <select name="impressions">';
		if($setting["impressions"]==1){
			echo '<option value="1" selected="selected">On</option>';
			echo '<option value="0">Off</option>';
		}
		else {
			echo '<option value="1">On</option>';
			echo '<option value="0" selected="selected">Off</option>';
		}
		echo '</select></div>';
		
		echo '<div class="border">Referer Tracking: <select name="reftrack">';
		if($setting["reftrack"]==1){
			echo '<option value="1" selected="selected">On</option>';
			echo '<option value="0">Off</option>';
		}
		else {
			echo '<option value="1">On</option>';
			echo '<option value="0" selected="selected">Off</option>';
		}
		echo '</select></div>';
		
		echo '<div class="border">HTML Ads Type:<br/><select name="htmlads">';
		
		if($setting["htmlads"]==1){
			echo '<option value="1" selected="selected">Listing All Ads</option>';
			echo '<option value="2">1 Link Random Ads</option>';
		}
		else {
			echo '<option value="1">Listing All Ads</option>';
			echo '<option value="2"  selected="selected">1 Link Random Ads</option>';
		}
		echo '</select></div>';
			
		
		echo '<div class="border">Invalid Clicks Redirect URL:<br/><input type="text" name="redirurl" value="http://'.$setting["redirurl"].'"/><br/>(%ad_link% to redirect to active ad)</div>';
		
		echo '<div class="border"><input type="submit" value="Update"/></form></div></div>';
		
	}
	elseif($module == "payment"){
	
		if($admin->data("role")==3){
			$admin->head("Access Denied!");
			echo '<div class="menu">Sorry but you are not allowed to access this page!</div>';
			$admin->foot();
			exit;
		}
	
		$act = get("act");
		
		if($act == "add"){
			$admin->head("Add Payment Method");
			echo '<div class="title">Add Payment Method</div>';
		
			if(isset($_POST["name"],$_POST["payee_name"],$_POST["via"],$_POST["amount"])){
			
				$name = post("name");
				$payee_name = post("payee_name");
				$via = post("via");
				$amount = post("amount");
				
				$errors = array();
				
				if(empty($name) OR strlen($name)<1) 	$errors[] = "Payment Method Name is Empty!";
				if(empty($payee_name) OR strlen($payee_name)<1) 	$errors[] = "Payee Name is Empty!";
				if(empty($via) OR strlen($via)<1) 	$errors[] = "Payment Via is Empty!";
				if(empty($amount) OR strlen($amount)<1 OR !is_numeric($amount)) 	$errors[] = "Payment Amount is Invalid!";
				
				if(empty($errors)){
				
					$insert = $db->insert("payout",array("name"=>$name,"payee_name"=>$payee_name,"via"=>$via,"amount"=>$amount),"");
					
					if($insert){
						$_SESSION["message"]="Payment Method Added Successfully!";
						redir("settings.php?module=payment");
					}
					else {
						echo "UUUUUNNNNKKKKNNNOOWWWNNNNEEEERRRROOOORRR";
						exit;
					}
				}
				else {
					$admin->error($errors);
				}
			}
			
			echo '<div class="menu" style="padding:0">';
			echo '<form method="post">';
			echo '<div class="border">Payment Method Name:<br/><input type="text" name="name"/><br/>(Ex. PayPal)</div>';
			echo '<div class="border">Payee Name:<br/><input type="text" name="payee_name"/><br/>(Ex. PayPal Name)</div>';
			echo '<div class="border">Payment Via:<br/><input type="text" name="via"/><br/>(Ex. PayPal Email)</div>';
			echo '<div class="border">Minimum Amount:<br/><input type="text" name="amount"/></div>';
			echo '<div class="border"><input type="submit" value="Add"/></form></div></div>';
		}
		elseif($act == "edit" && isset($_GET["id"])){
			
			$id = get("id");
			if(!$admin->payment_exists($id)){
				echo "Payment Method Not Found!";
				exit;
			}
			$admin->head("Edit Payment Method");
			echo '<div class="title">Edit Payment Method</div>';
		
			if(isset($_POST["name"],$_POST["payee_name"],$_POST["via"],$_POST["amount"])){
			
				$name = post("name");
				$payee_name = post("payee_name");
				$via = post("via");
				$amount = post("amount");
				
				$errors = array();
				
				if(empty($name) OR strlen($name)<1) 	$errors[] = "Payment Method Name is Empty!";
				if(empty($payee_name) OR strlen($payee_name)<1) 	$errors[] = "Payee Name is Empty!";
				if(empty($via) OR strlen($via)<1) 	$errors[] = "Payment Via is Empty!";
				if(empty($amount) OR strlen($amount)<1 OR !is_numeric($amount)) 	$errors[] = "Payment Amount is Invalid!";
				
				if(empty($errors)){
				
					$update = $db->update("payout",array("name"=>$name,"payee_name"=>$payee_name,"via"=>$via,"amount"=>$amount),array("id"=>$id));
					
					if($update){
						$_SESSION["message"]="Payment Method Edited Successfully!";
						redir("settings.php?module=payment&act=details&id=$id");
					}
					else {
						echo "UUUUUNNNNKKKKNNNOOWWWNNNNEEEERRRROOOORRR";
						exit;
					}
				}
				else {
					$admin->error($errors);
				}
			}
			
			$paymentDetails = $db->select("payout","",array("id"=>$id));
			$payment = $paymentDetails->fetch_assoc();
			
			echo '<div class="menu" style="padding:0">';
			echo '<form method="post">';
			echo '<div class="border">Payment Method Name:<br/><input type="text" name="name" value="'.$payment["name"].'"/><br/>(Ex. PayPal)</div>';
			echo '<div class="border">Payee Name:<br/><input type="text" name="payee_name" value="'.$payment["payee_name"].'"/><br/>(Ex. PayPal Name)</div>';
			echo '<div class="border">Payment Via:<br/><input type="text" name="via" value="'.$payment["via"].'"/><br/>(Ex. PayPal Email)</div>';
			echo '<div class="border">Minimum Amount:<br/><input type="text" name="amount"  value="'.$payment["amount"].'"/></div>';
			echo '<div class="border"><input type="submit" value="Edit"/></form></div></div>';
		}
		elseif($act == "del" && isset($_GET["id"])){
			
			$id = get("id");
			if(!$admin->payment_exists($id)){
				echo "Payment Method Not Found!";
				exit;
			}
			$admin->head("Delete Payment Method");
			echo '<div class="title">Delete Payment Method</div>';
			
			if($_GET["confirm"]=="yes"){
				
				$delete = $db->link->query("DELETE FROM payout WHERE id='$id'");
				if($delete){
					$_SESSION["message"]="Payment Method Deleted Successfully!";
					redir("settings.php?module=payment&act=details&id=$id");
				}
				else {
					echo "UnKmn";
					exit;
				}
			}
			else {
				
				echo '<div class="menu" align="center">Are You Sure ??<br/><a href="settings.php?module=payment&act=del&id='.$id.'&confirm=yes">Yes, Delete</a> - <a href="settings.php?module=payment&act=details&id='.$id.'">No, Go Back</a></div>';
			}
		}
		elseif($act == "details" && isset($_GET["id"])){
				
			$id = get("id");
			if(!$admin->payment_exists($id)){
				echo "Payment Method Not Found!";
				exit;
			}
			$admin->head("Payment Method Details");
			echo '<div class="title">Payment Method Details</div>';
			
			echo '<div class="menu">';
			$paymentDetails = $db->select("payout","",array("id"=>$id));
			$payment = $paymentDetails->fetch_assoc();
			
			echo 'Payment Method Name: '.$payment["name"].'<br/>';
			echo 'Payee Name: '.$payment["payee_name"].'<br/>';
			echo 'Payment Via: '.$payment["via"].'<br/>';
			echo 'Payment Minimum Amount: '.$payment["amount"];
			echo '</div>';
			echo '<div class="title">Options</div>';
			echo '<div class="menu">';
			echo '<a href="settings.php?module=payment&act=edit&id='.$id.'">Edit Payment Method</a><br/>';
			echo '<a href="settings.php?module=payment&act=del&id='.$id.'">Delete Payment Method</a><br/>';
			echo '</div>';
		}
		else {
		
			$paymentMethods = $db->select("payout","name,amount,id","");
			$admin->head("Payment Methods");
			echo '<div class="title">Payment Methods</div>';
			if($paymentMethods->num_rows<1){
				echo '<div class="menu" align="center">No Payment method configured!</div>';
			}
			else {
				echo '<div class="menu" style="padding:0">';
				while($payment=$paymentMethods->fetch_assoc()){
					echo '<div class="border"><b><a href="settings.php?module=payment&act=details&id='.$payment["id"].'">'.$payment["name"].'</a></b><br/>Minimum Payout: $'.$payment["amount"].'</div>';
				}
				echo '</div>';
			}
			echo '<div class="success" style="text-align:left">+ <a href="settings.php?module=payment&act=add">Add Payment Method</a></div>';
		}
	}
	elseif($module == "global"){
	
		if($admin->data("role")==3){
			$admin->head("Access Denied!");
			echo '<div class="menu">Sorry but you are not allowed to access this page!</div>';
			$admin->foot();
			exit;
		}
		
		$admin->head("Global Settings");
		echo '<div class="title">Global Settings</div>';
		
		if(isset($_POST["sitename"],$_POST["sitetitle"],$_POST["siteurl"],$_POST["news"])){
		 
			$sitename = post("sitename");
			$siteurl = post("siteurl");
			$siteurl = str_replace("http://",null,$siteurl);
			$sitetitle = post("sitetitle");
			$news = post("news");
			
			$errors = array();
			
			if(empty($sitename) OR strlen($sitename)<1) 	$errors[] = "Site name is empty!";
			if(empty($siteurl) OR strlen($siteurl)<1) 	$errors[] = "Site URL is empty!";
			if(empty($sitetitle) OR strlen($sitetitle)<1) 	$errors[] = "Site title is empty!";
			if(empty($news) OR strlen($news)<1) 	$errors[] = "News is empty!";
			
			if(empty($errors)){
				
				$update = $db->update("settings",array("sitename"=>$sitename,"siteurl"=>"http://".$siteurl,"sitetitle"=>$sitetitle,"news"=>$news),"");
				if($update){
					echo '<div class="success">Updated Successfully!</div>';
				}
				else {
					echo "Unnn";
					exit;
				}
			}
		}
		
		echo '<div class="menu"><form method="post">';
		echo 'Site name:<br/><input type="text" name="sitename" value="'.$setting["sitename"].'"/><br/>';
		echo 'Site URL:<br/><input type="text" name="siteurl" value="'.$setting["siteurl"].'"/><br/>';	
		echo 'Site Title:<br/><input type="text" name="sitetitle" value="'.$setting["sitetitle"].'"/><br/>';
		echo 'News System: <select name="news">';
		if($setting["news"]==1){
			echo '<option value="1" selected="selected">On</option>';
			echo '<option value="0">Off</option>';
		}
		else {
			echo '<option value="1">On</option>';
			echo '<option value="0" selected="selected">Off</option>';
		}
		echo '</select><br/>';
		echo '<input type="submit" value="Update"/></form></div>';
	}
	elseif($module == "admins"){
		
		if($admin->data("role")!=1){
			$admin->head("Access Denied!");
			echo '<div class="menu">Sorry but you are not allowed to access this page!</div>';
			$admin->foot();
			exit;
		}
	
		$act = get("act");
		
		if($act == "add"){
		
			$admin->head("Add Admin");
			echo '<div class="title">Add Admin</div>';
			
			if(isset($_POST["admin"],$_POST["password"],$_POST["cpassword"],$_POST["email"],$_POST["role"])){
			
				$admin = post("admin");
				$password = post("password");
				$cpassword = post("cpassword");
				$email = post("email");
				$role = post("role");
				
				$errors = array();
				
				if(empty($admin) OR strlen($admin)<1) 			$errors[] = "Admin Username Cannot be Empty!";
				if(empty($password) OR strlen($password)<1) 	$errors[] = "Admin Password Cannot be Empty!";
				if(empty($email) OR strlen($email)<1) 			$errors[] = "Admin Email Cannot be Empty!";
				if(!$admin->valid($admin)) 						$errors[] = "Admin Username is not valid";
				if($password!=$cpassword) 						$errors[] = "Password & Confirm Password didn't macth";
				if(!$admin->email($email)) 						$errors[] = "Email is not Valid!";
				if($role>3 OR $role<2 OR !is_numeric($role)) 	$errors[] = "Admin Role is Invalid!";
				if($admin->exists(array("admin"=>$admin))) 		$errors[] = "Admin Already Exists!";
				
				if(empty($errors)){
				
					$insert = $db->insert("admins",array("admin"=>$admin,"password"=>md5($password),"email"=>$email,"role"=>$role),"");
					
					if($insert){
						echo '<div class="success">Admin Added Successfully!</div>';
					}
					else {
						echo "Unknown ERROR!@@@$###";
					}
				}
				else {
					$admin->error($errors);
				}
			}
			echo '<div class="menu"><form method="post">Admin Username:<br/><input type="text" name="admin"/><br/>Password:<br/><input type="password" name="password"><br/>Confirm Password:<br/> <input type="password" name="cpassword"/><br/>Email:<br/><input type="text" name="email"/><br/><select name="role"><option value="2">Second Admin</option><option value="3">Third Admin</option></select><br/>Second Admin: Can do everything except Admin Functions.<br/>Third Admin: Can do everything except settings.<br/><input type="submit" value="Add"/></form></div>';
		}
		elseif($act == "edit" && isset($_GET["id"])){
			
			if($admin->gdata(array("id"=>$id),"role")==1){
				echo "Head Admin Cannot be edited!";
				exit;
			}
			$admin->head("Edit Admin");
			echo '<div class="title">Edit Admin</div>';
			
			$id = get("id");
			if(!$admin->exists(array("id"=>$id))){
				echo "Admin Not Found!";
				exit;
			}
			
			if(isset($_POST["password"],$_POST["cpassword"],$_POST["email"],$_POST["role"])){
			
				$password = post("password");
				$cpassword = post("cpassword");
				$email = post("email");
				$role = post("role");
				
				$errors = array();
				
				
				if(empty($password) OR strlen($password)<1) 	$errors[] = "Admin Password Cannot be Empty!";
				if(empty($email) OR strlen($email)<1) 			$errors[] = "Admin Email Cannot be Empty!";
				if($password!=$cpassword) 						$errors[] = "Password & Confirm Password didn't macth";
				if(!$admin->email($email)) 						$errors[] = "Email is not Valid!";
				if($role>3 OR $role<2 OR !is_numeric($role)) 	$errors[] = "Admin Role is Invalid!";
				
				if(empty($errors)){
				
					$update = $db->update("admins",array("password"=>md5($password),"email"=>$email,"role"=>$role),array("id"=>$id));
					
					if($update){
						echo '<div class="success">'.$admin->gdata(array("id"=>$id),"admin").' Updated	Successfully!</div>';
					}
					else {
						echo "Unknown ERROR!@@@$###";
					}
				}
				else {
					$admin->error($errors);
				}
			}
			echo '<div class="menu"><form method="post">Admin Username:<br/><input type="text" readonly="readonly" value="'.$admin->gdata(array("id"=>$id),"admin").'"/><br/>Password:<br/><input type="password" name="password"><br/>Confirm Password:<br/> <input type="password" name="cpassword"/><br/>Email:<br/><input type="text" name="email"  value="'.$admin->gdata(array("id"=>$id),"email").'"/><br/><select name="role"><option value="2">Second Admin</option><option value="3">Third Admin</option></select><br/>Second Admin: Can do everything except Admin Functions.<br/>Third Admin: Can do everything except settings.<br/><input type="submit" value="Edit"/></form></div>';
		}
		elseif($act == "del" && isset($_GET["id"])){
		
			$admin->head("Delete Admin");
			echo '<div class="title">Delete Admin</div>';
			
			$id = get("id");
			if(!$admin->exists(array("id"=>$id))){
				echo "Admin Not Found!";
				exit;
			}
			if($admin->gdata(array("id"=>$id),"role")==1){
				echo "Head Admin Cannot be deleted!";
				exit;
			}
			
			if($_GET["confirm"]=="yes"){
		
				$delete = $db->link->query("DELETE FROM admins WHERE id='$id'");
				if($delete){
					$_SESSION["message"]="Admin ".$admin->gdata(array("id"=>$id),"admin")." deleted successfully!";
					redir("settings.php?module=admins");
				}
				else {
					echo "UnknownError~DbError";
				}
			}
			else {
			
				echo '<div class="title">Delete '.$admin->gdata(array("id"=>$id),"admin").'?</div>';
				echo '<div class="menu" align="center">Are you Sure ??<br/><a href="settings.php?module=admins&act=del&id='.$id.'&confirm=yes">Yes, Delete</a> - <a href="settings.php?module=admins&act=details&id='.$id.'">No, Go Back</a></div>';
			}
		}
		elseif($act == "details" && isset($_GET["id"])){
		
			$admin->head("Admin Details");
			echo '<div class="title">Admin Details</div>';
			
			$id = get("id");
			if(!$admin->exists(array("id"=>$id))){
				echo "Admin Not Found!";
				exit;
			}
			
			echo '<div class="menu">Admin Username: '.$admin->gdata(array("id"=>$id),"admin").'<br/>Admin Email: '.$admin->gdata(array("id"=>$id),"email").'<br/>';
			if($admin->gdata(array("id"=>$id),"role")==1){
				$role = "Head Admin";
			}
			elseif($admin->gdata(array("id"=>$id),"role")==2){
				$role = "Second Admin";
			}
			else {
				$role = "Third Admin";
			}
			echo 'Admin Role: '.$role.'</div>';
			echo '<div class="title">Options</div>';
			echo '<div class="menu">';
			
			if($admin->gdata(array("id"=>$id),"role")!=1){
				echo '<a href="settings.php?module=admins&act=edit&id='.$id.'">Edit Admin</a><br/>';
				echo '<a href="settings.php?module=admins&act=del&id='.$id.'">Delete Admin</a><br/>';
			}
			echo '</div>';
		}
		else {
		
			$admin->head("Admins");
			
			echo '<div class="title">Admins:</div>';
			
			$admins = $db->select("admins","id,admin,role,email","");
			echo '<div class="menu" style="padding:0">';
			while($result=$admins->fetch_assoc()){
				echo '<div class="border">';
				echo '<a href="settings.php?module=admins&act=details&id='.$result["id"].'"><b>'.$result["admin"].'</b></a>';
				if($result["role"]==1){
					$role = "Head Admin";
				}
				elseif($result["role"]==2){
					$role = "Second Admin";
				}
				else {
					$role = "Third Admin";
				}
				echo ' ('.$role.')<br/>'.$result["email"].'</div>';
			}
			echo '</div>';
			echo '<div class="success" style="text-align:left">+ <a href="settings.php?module=admins&act=add">Add New Admin</a></div>';
		}
	}
	elseif($module == "refer"){
		
		if($admin->data("role")==3){
			$admin->head("Access Denied!");
			echo '<div class="menu">Sorry but you are not allowed to access this page!</div>';
			$admin->foot();
			exit;
		}
		
		$act = get("act");
		
		
			$admin->head("Referral Settings");
			echo '<div class="title">Referral Settings</div>';
			
			if(isset($_POST["refer"],$_POST["refamount"])){
				
				$refer = post("refer");
				$refamount = post("refamount");
				if(empty($refamount) OR strlen($refamount)<1 OR !is_numeric($refamount)){
					echo "Invalid amount";
					exit;
				}
				$update = $db->update("settings",array("refer"=>$refer),"");
				if($update){
					echo '<div class="success">Updated Successfully!</div>';
				}
				else {
					echo "UuUUu";
					exit;
				}
			}
			
			echo '<div class="menu"><form method="post">Referral Type:<br/><select name="refer">';
			
			for($i=1;$i<=2;$i++){
				if($i==$setting["refer"]){
					echo '<option value="'.$i.'" selected="selected">'.$i.'</option>';
				}
				else {
					echo '<option value="'.$i.'">'.$i.'</option>';
				}
			}
			echo '</select><br/>';
			
			echo '
					<b>1</b> - Pay Per Valid Registration.<br/>
					<b>2</b> - Pay After Referred User Earns.<br/>
					User Benifits:<br/>$ <input type="text" name="refamount" value="'.$setting["refamount"].'"/><br/>
					<input type="submit" value="Update"/></form></div>';
		
	}
	elseif($module == "mail"){
		
		if($admin->data("role")==3){
			$admin->head("Access Denied!");
			echo '<div class="menu">Sorry but you are not allowed to access this page!</div>';
			$admin->foot();
			exit;
		}
	
		$admin->head("Mail Settings");
		echo '<div class="title">Mail Settings</div>';
		
		if(isset($_POST["noreply"],$_POST["register"],$_POST["siteadd"],$_POST["adsadd"],$_POST["siteactive"],$_POST["adsactive"],$_POST["sitereject"],$_POST["adreject"],$_POST["userblock"],$_POST["invoicec"],$_POST["invoicep"],$_POST["name"],$_POST["pin"],$_POST["pwreset"])){
		
			$noReply = post("noreply");
			$register = post("register");
			$siteAdd = post("siteadd");
			$adsAdd = post("adsadd");
			$siteActive = post("siteactive");
			$adsActive = post("adsactive");
			$siteReject = post("sitereject");
			$adReject = post("adreject");
			$userBlock = post("userblock");
			$invoiceC = post("invoicec");
			$invoiceP = post("invoicep");
			
			$update = $db->update("mail",array("noreply"=>$noReply,"register"=>$register,"siteadd"=>$siteAdd,"adsadd"=>$adsAdd,"siteactive"=>$siteActive,"adsactive"=>$adsActive,"sitereject"=>$siteReject,"adreject"=>$adReject,"userblock"=>$userBlock,"invoicec"=>$invoiceC,"invoicep"=>$invoiceP,"name"=>post("name"),"pwreset"=>post("pwreset"),"pin"=>post("pin")),"");
			
			if($update){
				echo '<div class="success">Mail Templates Updated Successfully!</div>';
			}
			else {
				echo "U";
			}
		}
		
		$mailS = $db->select("mail","","");
		$mails = $mailS->fetch_assoc();
		
		echo '<div class="menu"><form method="post">';
		echo 'Email Sender:<br/><input type="text" name="noreply" value="'.$mails["noreply"].'"/><br/>';
		echo 'Email Sender Name: (Ex. My Adnetwork)<br/><input type="text" name="name" value="'.$mails["name"].'"/><br/>';
		echo 'Register Email Template:<br/><textarea name="register" rows="10">'.$mails["register"].'</textarea><br/>%username% = Username, %date% = Date, %verify_link% = Verify Link<br/>';
		echo 'Password Reset Email Template:<br/><textarea name="pwreset" rows="10">'.$mails["pwreset"].'</textarea><br/>%username% = Username, %date% = Date, %reset_link% = Reset Password Link<br/>';
		echo 'New PIN Email Template:<br/><textarea name="pin" rows="10">'.$mails["pin"].'</textarea><br/>%username% = Username, %date% = Date, %pin% = New PIN<br/>';
		echo 'Site Added Email Template:<br/><textarea name="siteadd" rows="10">'.$mails["siteadd"].'</textarea><br/>%username% = Username, %date% = Date,%sitename% = Site Name, %siteurl% = Site URL<br/>';
		echo 'Advertise Added Email Template:<br/><textarea name="adsadd" rows="10">'.$mails["adsadd"].'</textarea><br/>%username% = Username, %date% = Date,%adname% = Advertise Name, %adurl% = Advertise URL<br/>';
		echo 'Site Active Email Template:<br/><textarea name="siteactive" rows="10">'.$mails["siteactive"].'</textarea><br/>%username% = Username, %date% = Date,%sitename% = Site Name, %siteurl% = Site URL<br/>';
		echo 'Advertise Active Email Template:<br/><textarea name="adsactive" rows="10">'.$mails["adsactive"].'</textarea><br/>%username% = Username, %date% = Date,%adname% = Ad Name, %adurl% = Ad URL<br/>';
		echo 'Site Rejected Email Template:<br/><textarea name="sitereject" rows="10">'.$mails["sitereject"].'</textarea><br/>%username% = Username, %date% = Date,%sitename% = Site Name, %siteurl% = Site URL<br/>';
		echo 'Advertise Rejected Email Template:<br/><textarea name="adreject" rows="10">'.$mails["adreject"].'</textarea><br/>%username% = Username, %date% = Date,%adname% = Ad Name, %adurl% = Ad URL<br/>';
		echo 'User Blocked Email Template:<br/><textarea name="userblock" rows="10">'.$mails["userblock"].'</textarea><br/>%username% = Username, %date% = Date<br/>';
		echo 'Invoice Created Email Template:<br/><textarea name="invoicec" rows="10">'.$mails["invoicec"].'</textarea><br/>%username% = Username, %date% = Date,%invoice% = Invoice<br/>';
		echo 'Invoice Paid Email Template:<br/><textarea name="invoicep" rows="10">'.$mails["invoicep"].'</textarea><br/>%username% = Username, %date% = Date,%invoice% = Invoice';
		
		echo '<input type="submit" value="Update"/></form></div>';
	}
	elseif($module == "changePassword"){
	
		$admin->head("Change Password");
		echo '<div class="title">Change Password</div>';
	
		if(isset($_POST["oldpassword"],$_POST["newpassword"],$_POST["newpassword2"])){
		
			$oldpassword = post("oldpassword");
			$newpassword = post("newpassword");
			$newpassword2 = post("newpassword2");
			
			$errors = array();
			
			if($admin->data("password")!=md5($oldpassword)) 	$errors[] = "Old Password is Invalid!";
			if(empty($newpassword) OR strlen($newpassword)<1) 	$errors[] = "New Password Can't be Empty!";
			if($newpassword!=$newpassword2) 	$errors[] = "Passwords didn't match!";
			
			if(empty($errors)){
			
				if($db->update("admins",array("password"=>md5($newpassword)),array("id"=>$admin->id))){
					$_SESSION["message"]="Password Changed Successfully!";
					unset($_SESSION["adminid"]);
					redir("login.php");
				}
				else {
					echo "Unnn";
				}
			}
			else {
				$admin->error($errors);
			}
		}
		
		echo '<div class="menu"><form method="post">';
		echo 'Old Password:<br/><input type="password" name="oldpassword"/><br/>New Password:<br/><input type="password" name="newpassword"/><br/>Confirm New Password:<br/><input type="password" name="newpassword2"/><br/><input type="submit" value="Change Password"/></form></div>';
	}
	elseif($module == "styles"){
	
		if($admin->data("role")==3){
			$admin->head("Access Denied!");
			echo '<div class="menu">Sorry but you are not allowed to access this page!</div>';
			$admin->foot();
			exit;
		}
		
		$admin->head("Template & Styles");
		echo '<div class="title">Template & Styles</div>';
		$admin->message();
		
		if($setting["mweb"]==1){
		
			if(isset($_POST["template"],$_POST["webtemp"],$_POST["mweb"])){
			
			$template = post("template");
			$webtemp = post("webtemp");
			$mweb = post("mweb");
			
			if(!$admin->template_exists($template)){
				echo "Template Not Found!";
				exit;
			}
			if(!$admin->template_exists($webtemp)){
				echo "Template Not Found!";
				exit;
			}
			
			if($db->update("settings",array("template"=>$template,"mweb"=>$mweb,"webtemp"=>$webtemp),"")){
				$_SESSION["message"]="Template Updated Successfully!";
				redir("settings.php?module=styles");
			}
			else {
				echo 'Wrororor';
				exit;
			}
			}
			echo '<div class="menu" style="padding:0"><form method="post">';
			echo '<div class="border">Web & Mobile Detected Template: <select name="mweb">';
			if($setting["mweb"]==1){
				echo '<option value="1" selected="selected">On</option>';
				echo '<option value="0">Off</option>';
			}
			else {
				echo '<option value="1">On</option>';
				echo '<option value="0" selected="selected">Off</option>';
			}
			echo '</select></div>';
			echo '<div class="border">Web Template: <select name="webtemp">';
			foreach(glob(ROOTDIR."/templates/*",GLOB_ONLYDIR) as $templ){
				if($setting["webtemp"]==basename($templ)){
					echo '<option value="'.basename($templ).'" selected="selected">'.basename($templ).'</option>';
				}
				else {
					echo '<option value="'.basename($templ).'">'.basename($templ).'</option>';
				}
			}
			echo '</select></div>';
			echo '<div class="border">Mobile Template: <select name="template">';
			foreach(glob(ROOTDIR."/templates/*",GLOB_ONLYDIR) as $templ){
				if($setting["template"]==basename($templ)){
					echo '<option value="'.basename($templ).'" selected="selected">'.basename($templ).'</option>';
				}
				else {
					echo '<option value="'.basename($templ).'">'.basename($templ).'</option>';
				}
			}
			echo '</select></div>';
			echo '<div class="border"><input type="submit" value="Update"/></form></div></div>';
		}
		else {
		
			if(isset($_POST["template"],$_POST["mweb"])){
			
			$template = post("template");
			$mweb = post("mweb");
			
			if(!$admin->template_exists($template)){
				echo "Template Not Found!";
				exit;
			}
			
			if($db->update("settings",array("template"=>$template,"mweb"=>$mweb),"")){
				$_SESSION["message"]="Template Updated Successfully!";
				redir("settings.php?module=styles");
			}
			else {
				echo 'Wrororor';
				exit;
			}
			}
			echo '<div class="menu" style="padding:0"><form method="post">';
			echo '<div class="border">Web & Mobile Detected Template: <select name="mweb">';
			if($setting["mweb"]==1){
				echo '<option value="1" selected="selected">On</option>';
				echo '<option value="0">Off</option>';
			}
			else {
				echo '<option value="1">On</option>';
				echo '<option value="0" selected="selected">Off</option>';
			}
			echo '</select></div>';
			echo '<div class="border">Template: <select name="template">';
			foreach(glob(ROOTDIR."/templates/*",GLOB_ONLYDIR) as $templ){
				if($setting["template"]==basename($templ)){
					echo '<option value="'.basename($templ).'" selected="selected">'.basename($templ).'</option>';
				}
				else {
					echo '<option value="'.basename($templ).'">'.basename($templ).'</option>';
				}
			}
			echo '</select></div>';
			echo '<div class="border"><input type="submit" value="Update"/></form></div></div>';
	
		}
		
	}
	else {
		
		
		
		$admin->head("Settings");
		echo '<div class="title">Settings</div>';
		
		echo '<div class="menu" style="padding:0">';
		
		if($admin->data("role")==3){
			echo '<div class="border2"><img src="images/menu.png"> <a href="?module=changePassword">Change Password</a></div></div>';
		}
		else {
		
		echo '<div class="border2"><img src="images/menu.png"> <a href="?module=global">Global Settings</a></div>';
		echo '<div class="border2"><img src="images/menu.png"> <a href="?module=sites">Sites Settings</a></div>';
		echo '<div class="border2"><img src="images/menu.png"> <a href="?module=ads">Ads Settings</a></div>';
		echo '<div class="border2"><img src="images/menu.png"> <a href="?module=clicks">Clicks Settings</a></div>';
		echo '<div class="border2"><img src="images/menu.png"> <a href="?module=payment">Payment Methods</a></div>';
		echo '<div class="border2"><img src="images/menu.png"> <a href="?module=refer">Referral Settings</a></div>';
		echo '<div class="border2"><img src="images/menu.png"> <a href="?module=mail">Email Settings</a></div>';
		echo '<div class="border2"><img src="images/menu.png"> <a href="?module=styles">Template & Styles</a></div>';
		if($admin->data("role")==1){
			echo '<div class="border2"><img src="images/menu.png"> <a href="?module=admins">Admins Settings</a></div>';
		}
		echo '<div class="border2"><img src="images/menu.png"> <a href="?module=changePassword">Change Password</a></div></div>';
		}
		
	}
	
	$admin->foot();
	
?>
		
			
		
		
			
			