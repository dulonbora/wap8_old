<?php

	ini_set('MEMORY_LIMIT',-1);
	ini_set('MAX_EXECUTION_TIME',800);

	include "init.php";
	
	if(!$admin->is_admin()){
		redir("login.php");
		exit;
	}
	
	include (ROOTDIR."/includes/phpmailer/PHPMailerAutoload.php");
	$mail = new PHPMailer();
	
	$act = get("act");
	
	if($act == "user" && isset($_GET["username"])){
	
		$admin->head("Send Email to ".get("username"));
		echo '<div class="title">Send Email</div>';
	
		$username = get("username");
		$checkUserName = $db->select("users","email",array("username"=>$username));
		if($checkUserName->num_rows<1){
			echo "User not found";
			exit;
		}
		$userMail = $checkUserName->fetch_assoc();
		
		if(isset($_POST["subject"],$_POST["message"])){
		
			$subject = post("subject");
			$message = post("message");
			
			if(empty($subject) OR empty($message)){
				echo "Must not empty";
				exit;
			}
			
			$subject = str_replace("%username%",$username,$subject);
			$message = str_replace("%username%",$username,$message);
			$subject = str_replace("%date%",$date,$subject);
			$message = str_replace("%date%",$date,$message);
			
			$subject = stripslashes($subject);
			$message = stripslashes($message);
			
		
		
			$Mail = $db->select("mail","","");
			$mails = $Mail->fetch_assoc();
			$mail->setFrom($mails["noreply"],$mails["name"]);
			$mail->addReplyTo($mails["noreply"],$mails["name"]);
			$mail->addAddress($userMail["email"]);
			$mail->Subject = $subject;
			$mail->msgHTML($message);
			$mail->AltBody = $message;
			
			if(!$mail->send()){
				echo '<div class="error">Email is not sent! '.$mail->ErrorInfo.'</div>';
			}
			else {
				echo '<div class="success">Email Successfully Sent!</div>';
			}
		}
		
		echo '<div class="menu" style="padding:0"><form method="post">';
		echo '<div class="border">To User:<br/><input type="text" value="'.$username.'" readonly="readonly"/></div>';
		echo '<div class="border">Subject:<br/><input type="text" name="subject"/></div>';
		echo '<div class="border">Message:<br/><textarea name="message" rows="10"></textarea></div>';
		echo '<div class="border"><input type="submit" value="Send"/></form></div>';
		echo '<div class="border">Available Variables:<br/> %username% = username<br/>%date% = Current Date</div></div>';
		
	}
	elseif($act == "all"){
	
		$users = $db->select("users","email",array("status"=>1));
		
		$admin->head("Send Email to All User");
		echo '<div class="menu" align="center">You are sending email to '.$users->num_rows.' users, this could take a long time depending on your server!!</div>';
		
		echo '<div class="title">Send Email</div>';
		
		if(isset($_POST["subject"],$_POST["message"])){
		
			$subject = post("subject");
			$message = post("message");
			
			if(empty($subject) OR empty($message)){
				echo "Must not empty";
				exit;
			}
			
			$subject = str_replace("%username%",$username,$subject);
			$message = str_replace("%username%",$username,$message);
			$subject = str_replace("%date%",$date,$subject);
			$message = str_replace("%date%",$date,$message);
			
			$subject = stripslashes($subject);
			$message = stripslashes($message);
			
		
		
			$Mail = $db->select("mail","","");
			$mails = $Mail->fetch_assoc();
			$mail->setFrom($mails["noreply"],$mails["name"]);
			$mail->addReplyTo($mails["noreply"],$mails["name"]);
			$mail->Subject = $subject;
			$mail->msgHTML($message);
			$mail->AltBody = $message;
			
			echo '<div class="menu">';
			while($userMail=$users->fetch_assoc()){
			
				$mail->addAddress($userMail["email"]);
			
				if(!$mail->send()){
					echo '<font color="#ff5500">Email Not Sent To '.$userMail["email"].' ('.$mail->ErrorInfo.')</font><br/>';
				}
				else {
					echo '<font color="green">Email Sent To '.$userMail["email"].'</font><br/>';
				}
				$mail->clearAddresses();
			}
			echo '</div>';
			
		}
		else {
		echo '<div class="menu" style="padding:0"><form method="post">';
		echo '<div class="border">To User:<br/><input type="text" value="all" readonly="readonly"/></div>';
		echo '<div class="border">Subject:<br/><input type="text" name="subject"/></div>';
		echo '<div class="border">Message:<br/><textarea name="message" rows="10"></textarea></div>';
		echo '<div class="border"><input type="submit" value="Send"/></form></div>';
		echo '<div class="border">Available Variables:<br/> %username% = username<br/>%date% = Current Date</div></div>';
			
		}	
	}
	else {
	
		$admin->head("Send Mail");
		echo '<div class="title">Send Email</div>';
		
		echo '<div class="menu" style="padding:0">';
		echo '<div class="border"><form method="get" action="mail.php"><input type="hidden" name="act" value="user">Send Mail To User By Username:<br/><input type="text" name="username"/><br/><input type="submit" value="Send"/></form></div>';
		echo '<div class="border"><a href="?act=all">Send Mail To All Users</a></div></div>';
		
	}
	
	$admin->foot();
	
?>
		
		
		
	
		