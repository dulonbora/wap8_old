<?php
include 'db.php';
include 'functions.php';

headtag("$SiteName - Aprove Balance");

if($userlog==1){
include 'head.php';
echo '<div class="title">Aprove Balance</div><div class="success"><font color="red">Note : </font>Balance Will Be Approved Within 3 Days Of Requested Date.</div>';
if(dump_udata("pubalance")<0.20){
 echo '<div class="error">Your account balance is '.dump_udata("pubalance").'$! Which is lower than our minimum amount (0.20$). Please earn more and then request !</div>';
 }
else {
$uid=dump_udata("id");
if(isset($_POST["amount"]) AND isset($_POST["via"])){

$amount=formpost("amount");
$via=formpost("via");
$captcha=formpost("captcha");
$errors=array();

if(!is_numeric($amount)){
  $errors[]='Amount must be a numeric value !';
 }


if(strlen($amount)<1){
  $errors[]='Amount cannot be empty !';
 }

if(strlen($via)<1){
  $errors[]='Number cannot be empty!';
 }

if($amount>dump_udata("pubalance")){
  $errors[]='Amount is bigger than account balance!';
}

if(empty($errors)){
  $date=date("l , F d , Y"); 
  $doit=mysqli_query("INSERT INTO invoice (userid,amount,method,via,status,time,name) VALUES ('$uid','$amount','Aprove Balance','$via','APENDING','$date','EarnStar.In User')");
  $newbal=(dump_udata("pubalance")-$amount);
  $minusb=mysqli_query("UPDATE userdata SET pubalance='$newbal' WHERE id='$uid'");
  if($doit AND $minusb){
   echo '<div class="success">Requested Successfully ! Wait 3day verify us !</div>';
  }
  else {
   echo '<div class="error">Error creating !</div>';
}

}
else {

dump_error($errors);

}
}
echo '<div class="form"><form method="post">Amount (Min. $0.2 Max. '.dump_udata("pubalance").'$)<br/><input type="text" name="amount"/><br />
Your Call Number:<br/><input type="text" name="via"/><br/><input type="submit" value="Request"/></form></div>';

}
}
else {
header('Location:/');
}
echo '<div class="page"><a href="/">Go Back To Home</a></div>';
include 'foot.php';

?>