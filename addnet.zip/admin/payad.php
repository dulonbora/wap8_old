<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include '../db.php';
include '../functions.php';

headtag("$SiteName - Validate Invoice");

if($adminlog==1){

 $vid=formget("id");

$doit=mysqli_query("UPDATE adinvoice SET status='VALIDATED' WHERE id='$vid'");
 if($doit){
   $get_use=mysqli_query("SELECT * FROM adinvoice WHERE id='$vid'");
   $get_us=mysqli_fetch_array($get_use);
   $uid=$get_us["userid"];
   $get_u=mysqli_query("SELECT * FROM userdata WHERE id='$uid'");
   $get_user=mysqli_fetch_array($get_u);
   $emailz=$get_user["email"];
   $newbal=$get_user["adbalance"];
   $adbal=($newbal+$get_us["amount"]);
   mysqli_query("UPDATE userdata SET adbalance='$adbal' WHERE id='$uid'");
   
   echo '<div class="success">Successfully validated!</div>';
       $to      = $emailz;
    $subject = 'Your Approved Balance Has Been Validated';
    $message = 'Dear '.$get_user["firstname"].',
We are happy to tell you that your Approved Balance #APRV'.$vid.' has been successfully validated and the balance has added in your Approved  balance!

Thank You!


Support:
support@mydearads.in
+91-8795589006

Thanks,
Mydearads Team,
Mydearads.in';
    $headers = 'From: Mydearads.in<support@mydearads.in>' . "\r\n" .
    'Reply-To: support@mydearads.in' . "\r\n" .
    'X-Mailer: Mydearads.in';

    mail($to, $subject, $message, $headers);
 }
 else {
  echo 'Unknown error';
 }
echo '<a href="unadinvo.php"><div class="back">HOME</div></a>'; 

 include '../foot.php';

 }
 else {
 header('Location:login.php');
 }
?>
