<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include '../db.php';
include '../functions.php';

headtag("$SiteName - Block Invoice");

if($adminlog==1){

 $vid=formget("id");

$doit=mysqli_query("UPDATE bank SET status='Rejected' WHERE id='$vid'");
   echo '<div class="success">Successfully Rejected!</div>';
echo '<a href="unadinvo.php"><div class="back">HOME</div></a>'; 

 include '../foot.php';

 }
 else {
 header('Location:login.php');
 }
?>