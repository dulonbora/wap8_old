<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include '../db.php';
include '../functions.php';

headtag("$SiteName - Validate Invoice");

if($adminlog==1){

 $vid=formget("id");
 $date=date("d-m-Y");

 $doit=mysqli_query("UPDATE bank SET status='Paid On $date' WHERE id='$vid'");
 if($doit){
   $get_use=mysqli_query("SELECT * FROM bank WHERE id='$vid'");
   $get_us=mysqli_fetch_array($get_use);
   $uid=$get_us["userid"];
   $get_u=mysqli_query("SELECT * FROM userdata WHERE id='$uid'");
 $addnote=mysqli_query("INSERT INTO msgs (rid,body,status) VALUES ('$uid','Your Bank Payment Has been Successfully Paid.','New')");
 $get_user=mysqli_fetch_array($get_u);
   $emailz=$get_user["email"];

   $mobile=$get_user["mobile"];

   echo '<div class="success">Successfully Paid!<br/>
<a href="../anil/index.php?mo='.$mobile.'&m='.$get_us["method"].'">Send Sms '.$mobile.'</a></div>';
       $to      = $emailz;
    $subject = 'Your Bank Payment Request  Has Been Paid - Mobile Advertising Network | Sell Ads | Buy Ads | Monetize Traffic';
    $message = 'Dear '.$get_user["firstname"].',


We are happy to tell you that your invoice #BANKINV'.$vid.' has been successfully Paid!

Your Summary Details below.

Amount: '.$get_us["amount"].'

Method: '.$get_us["method"].'


Thank You!


Support:
support@mydearads.in

+918795589006

Thanks,
Mydearads Team,
Mydearads.In';
    $headers = 'From: Mydearads.In<support@mydearads.in>' . "\r\n" .
    'Reply-To: support@mydearads.in' . "\r\n" .
    'X-Mailer: Mydearads';

    mail($to, $subject, $message, $headers);
 }
 else {
  echo 'Unknown error';
 }
echo '<a href="unpayinvo.php"><div class="back">HOME</div></a>'; 

 include '../foot.php';

 }
 else {
 header('Location:login.php');
 }
?>