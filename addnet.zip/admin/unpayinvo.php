<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include '../db.php';
include '../functions.php';

headtag("$SiteName - Admin Panel Beta");

if($adminlog==1){
echo '<div class="line">Pending Invoices</div>';

$page=formget("page");

if(empty($page)){
$page=0;
}
$start=$page*10;
$end=($start+10);


 
$bbinvoice=mysqli_query("SELECT * FROM bank WHERE status='PENDING' ORDER BY id DESC LIMIT $start,$end");


while($binvoices=mysqli_fetch_array($bbinvoice)){

 $amt=$binvoices["amount"];
$umt=($amt/60);

 
echo '<div class="uright">INVOICE: #'.$binvoices["id"].'<br/>Amount: Rs. '.$amt.'  ( '.$umt.'$ )<br/>Method: '.$binvoices["method"].' '.$binvoices["via"].'<br/> holder: '.$binvoices["holder"].'<br/> Bank Name: '.$binvoices["bname"].'<br/> Ifsc Code: '.$binvoices["ifscode"].'<br/> Created: '.$binvoices["time"].'<br/>Created By: <a href="user.php?id='.$binvoices["userid"].'">USER#'.$binvoices["id"].'</a><br/> <a href="pay-bank.php?id='.$binvoices["id"].'">Pay Now</a> - <a href="breject.php?id='.$binvoices["id"].'">Reject</a> </div>';
}
$invoice=mysqli_query("SELECT * FROM invoice WHERE status='PENDING' ORDER BY id DESC LIMIT $start,$end");


while($invoices=mysqli_fetch_array($invoice)){

$name=$invoices["name"];

if($name=='Recharge') {
 $amt=$invoices["amount"];
$umt=($amt/60);

 
echo '<div class="uright">INVOICE: #'.$invoices["id"].'<br/>Amount: Rs. '.$amt.'  ( '.$umt.'$ )<br/>Method: '.$invoices["method"].' '.$invoices["via"].' <br/>Created: '.$invoices["time"].'<br/>Created By: <a href="user.php?id='.$invoices["userid"].'">USER#'.$invoices["id"].'</a><br/> <a href="payrc.php?id='.$invoices["id"].'">Pay Now</a> - <a href="reject.php?id='.$invoices["id"].'">Reject</a> - <a href="cancel.php?id='.$invoices["id"].'">Cencel </a></div>';
}
else {

$amtt=$invoices["amount"];
$umtt=($amtt/60);

 
echo '<div class="uright">INVOICE: #'.$invoices["id"].'<br/>Amount: Rs. '.$amtt.'  ( '.$umtt.'$ )<br/>Method: '.$invoices["method"].'  '.$invoices["via"].' <br/>Created: '.$invoices["time"].'<br/>Created By: <a href="user.php?id='.$invoices["userid"].'">USER#'.$invoices["id"].'</a><br/> 
 <a href="addbal.php?id='.$invoices["id"].'">Approved</a>   - <a href="pay.php?id='.$invoices["id"].'">Pay Now</a> - <a href="reject.php?id='.$invoices["id"].'">Reject</a> - <a href="cancel.php?id='.$invoices["id"].'">Cencel </a> </div>';
}

}
echo '<div class="back"><a href="?page='.($page+1).'">Next</a></div>';
echo '<a href="index.php?redir=unpay"><div class="back">Home</div></a>';

include '../foot.php';

}
else {

header('Location:/login.php?error=ticket&reason=session');
}

?>