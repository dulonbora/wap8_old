<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include '../db.php';
include '../functions.php';

headtag("$SiteName - Admin Management");

if($adminlog==1){
if($admin_id=='pranto'){

$Pr=formget("pr");
if($Pr=='add'){
echo '<div class="title">Add Admin</div>';
if(isset($_POST["name"]) AND isset($_POST["email"]) AND isset($_POST["pwd"])){
$nname=formpost("name");
$nemail=formpost("email");
$npwd=formpost("pwd");
if($nname=="admins/$main_adm-data.pra"){
echo 'main admin cannot be deleted';
exit;
}
$dataFile="admins/$nname-data.pra";

$doIT=file_put_contents($dataFile,"$nname|-pr-|$nemail|-pr-|$npwd|-pr-|");

if($doIT){
echo '<div class="success">Admin added successfully</div>';
}
else {
echo 'cannot ';
}
}

echo '<div class="form"><form method="post">Admin Name:<br/><input type="text" name="name"/><br/>Admin Email:<br/><input type="text" name="email"/><br/>Admin Password:<br/><input type="password" name="pwd"/><br/><input type="submit" value="Add"/></form></div>';

echo '<div class="back"><a href="admins.php">Back</a></div>';
}
elseif($Pr=='del'){
$dname=formget("name");
if($dname=="admins/$main_adm-data.pra"){
echo 'main admin cannot be deleted';
exit;
}
$doiT=unlink($dname);
If($doiT){
echo '<div class="success">Admin successfully deleted!</div>';
}
else {
echo 'cannnotoo';
}

echo '<div class="back"><a href="admins.php">Back</a></div>';
}
else{
$admFile=glob("admins/*.pra");
echo '<div class="title">Admins</div>';
foreach($admFile as $Admin){
$admData=file_get_contents($Admin);
$arrzData=explode("|-pr-|","$admData");
$gname=$arrzData[0];
$gemail=$arrzData[1];
echo '<div class="ad">Name: '.$gname.'<br/>Email: '.$gemail.'<br/><a href="?pr=del&name='.$Admin.'">Delete Admin</a> </div>';
}
echo '<div class="uright"><a href="?pr=add">Add new Admin</a></div>';

echo '<div class="back"><a href="index.php">Home</a></div>';
}
}
else {
echo '<div calss="errors">You do not have permission to access this page!</div>';
}
include '../foot.php';
}
else {
header('Location:login.php');
}
?>
