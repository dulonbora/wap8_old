<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include '../db.php';
include '../functions.php';

headtag("$SiteName - SET Email");

if($adminlog==1){
 
 $uid=formget("id");


 $userd=mysqli_fetch_array(mysqli_query("SELECT * FROM userdata WHERE id='$uid'"));

$umail=$userd["email"];

if(isset($_POST['mail'])){

 $urmail=formpost("mail");
 
 $doit=mysqli_query("UPDATE userdata SET email='$urmail' WHERE id='$uid'");
 if($doit){
   echo '<div class="success">email SET successfully!</div>';
 }
 else {
  echo 'unk';
 }
 }
 echo '<div class="form"><form method="post">email:<br/><input type="text" name="mail" value="'.$umail.'"/><br/><input type="submit" value="Update"/></form></div>';
 
 echo '<div class="ad"><a href="user.php?id='.$uid.'">usrrs</a></div>';
 include '../foot.php';
 }
 else {
 header('Location:login.php');
 }
 ?>