<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include '../db.php';
include '../functions.php';

headtag("$SiteName - News");

if($adminlog==1){

echo '<div class="title">News</div>';

echo '<div class="form"><a href="newnews.php">Add new news</a></div>';

$page=formget("page");

if(empty($page)){
$page=0;
}
$start=$page*10;
$end=($start+10);

$newss=mysqli_query("SELECT * FROM news ORDER BY id DESC LIMIT $start,$end");
 
 while($news=mysqli_fetch_array($newss)){
  $nid=$news["id"];
  $newsr=mysqli_num_rows(mysqli_query("SELECT * FROM newsreplys WHERE newsid='$nid'"));
  echo '<a href="newsr.php?id='.$news["id"].'"><div class="ua"><b>'.$news["title"].'</b><br/>'.strip_tags(substr($news["body"],0,40)).'..<br/>Replies: '.$newsr.'</div></a>';

 }
 echo '<div class="ad"><a href="?page='.($start+1).'">Next</a></div>';
 echo '<a href="index.php"><div class="ua">Home</div></a>';
 include '../foot.php';
}
else {
header('Location:index.php');
}
?>