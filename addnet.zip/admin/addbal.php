<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include '../db.php';
include '../functions.php';

headtag("$SiteName - Validate Invoice");

if($adminlog==1){

 $vid=formget("id");

 $date=date("d-m-Y");
 $doit=mysqli_query("UPDATE invoice SET status='Approved on $date' WHERE id='$vid'");
 if($doit){
   $get_use=mysqli_query("SELECT * FROM invoice WHERE id='$vid'");
   $get_us=mysqli_fetch_array($get_use);
   $uid=$get_us["userid"];
   $get_u=mysqli_query("SELECT * FROM userdata WHERE id='$uid'");
   $get_user=mysqli_fetch_array($get_u);
 $userd=mysqli_fetch_array(mysqli_query("SELECT * FROM userdata WHERE id='$uid'")); 

$balance=$userd["adbalance"];   $adm=$get_us["amount"];
$newbal=($balance+$adm);
   $doit=mysqli_query("UPDATE userdata SET adbalance='$newbal' WHERE id='$uid'");


 $addnote=mysqli_query("INSERT INTO msgs (rid,body,status) VALUES ('$uid','Your balance has been Approved.','New')");

$mobile=$get_user["mobile"];
   $emailz=$get_user["email"];
   echo '<div class="success">Successfully validated!<br/>
<a href="../anil/index.php?mo='.$mobile.'&m='.$get_us["method"].'">Send Sms '.$mobile.'</a></div>';
       $to      = $emailz;
    $subject = 'Your Approve Balance Invoice Has Approved';
    $message = 'Dear '.$get_user["firstname"].',
We are happy to tell you that your Approved Balance #Aprv'.$vid.' has been successfully Approved.

Your Approved Amount: '.$get_us["amount"].'

Thank You!


Support:
support@mydearads.in
+918795589006

Thanks,
Mydearads Team,
Mydearads.In';
    $headers = 'From: Mydearads.In<support@mydearads.in>' . "\r\n" .
    'Reply-To: support@mydearads.in' . "\r\n" .
    'X-Mailer: Mydearads';

    mail($to, $subject, $message, $headers);
 }
 else {
  echo 'Unknown error';
 }
echo '<a href="unpayinvo.php"><div class="ua">HOME</div></a>'; 

 include '../foot.php';

 }
 else {
 header('Location:login.php');
 }
?>