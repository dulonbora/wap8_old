<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include '../db.php';
include '../functions.php';

headtag("$SiteName - Validate Invoice");

if($adminlog==1){

echo '<div class="line">Mail User</div>';

 $uid=formget("id");

 if(isset($_POST['msg'])){ 

 
 $emsg=formpost("msg");
 

 $errors=array(); 

 if(strlen($emsg)<1){   $errors[]='Msg left empty!';  } 

 
 if(empty($errors)){
 
   $get_u=mysqli_query("SELECT * FROM userdata WHERE id='$uid'");
  $get_user=mysqli_fetch_array($get_u);
   $emailz=$get_user["email"];

 
       $to      = $emailz;
    $subject = 'Mydearads Admin Mail';
    $message = 'Dear '.$get_user["firstname"].',


'.$emsg.'


Support:
support@mydearads.in

+918795589006

Thanks,
Mydearads Team,
Mydearads.In';
    
$headers = 'From: Mydearads Admin <support@mydearads.in>' . "\r\n" .     'Reply-To: shahidpkd4u@gmail.com' . "\r\n" .     'X-Mailer: Mydearads.In';
    mail($to, $subject, $message, $headers);

 echo '<div class="success">Message Successfully Sent!</div>';

}
 else {
 dump_error($errors); }
 } 

 echo '<div class="form"><form method="post">Msg To User:<br/><textarea name="msg"></textarea><br/><input type="submit" value="Send Message"/></form></div>';
 
echo '<a href="unpayinvo.php"><div class="back">HOME</div></a>'; 

 include '../foot.php';

 }
 else {
 header('Location:login.php');
 }
?>