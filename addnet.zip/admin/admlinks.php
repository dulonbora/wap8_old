<?php 

include '../db.php'; 

include '../functions.php';

headtag("$SiteName - Admlink");

if($adminlog==1){
 
$act=formget('act');


if($act=="add")
{

echo '<div class="line"><b>Adding Links</b></div>';
echo '<form action="?act=added" method="post">
News Title: <input type="text" name="url" /><br>
News: <input type="text" name="text" /><br>
<input type="submit" value="add Link" />
</form>';
}

if($act=="added")
{
if ($_POST['url']=="")
{
echo '<div class="line"><b>Problem</b></div>';
echo '<div class="alarm">All Fields are required</div>';
}
else
{
echo '<div class="line"><b>Link Added</b></div>';
mysqli_query('INSERT INTO admlink (linkurl, link_text)
VALUES ("'.$_POST['url'].'", "'.$_POST['text'].'")');
echo '<div class="fmenu">News added successfully</div>';
}
}


if($act=="del")
{
echo '<div class="line"><b>Confirmation</b></div>';
echo '<div class="error">Do you really want to delete This link ? <a href="?act=yes&id='.$id.'"><b>Yes</b></a> | <a href="news.php">No</a></div>';

}

if($act=="yes")
{
echo '<div class="line"><b>Deleted</b></div>';
echo '<div class="menu">Deleted Successfully</div>';
mysqli_query('DELETE FROM admlink WHERE id="'.$id.'"');

}

echo
'<div class="line"><b>LinKS</b></div>
<div class="fmenu">
<a href="?act=add"><font color=red>Add LinKs</font></a></div>
';

if(mysqli_num_rows(mysqli_query("SELECT * FROM admlink"))){

$result=mysqli_query('SELECT * FROM admlink');
while($row=mysqli_fetch_array($result, MYSQL_ASSOC)) {
   echo '<div class="uright">link : <b>'.$row['linkurl'].' ( '.$row['clicks'].' ) </b> <a href="?act=del&id='.$row['id'].'"><font color=red>x</font></a><br></div>
<div class="uright"> LinK Text : '.$row['link_text'].'
<br/>Id: '.$row['id'].' </div>';
}
}
else
{
echo "no news";
}

echo '<div class="back"><a href="index.php">Back to Home</a></div>';

include '../foot.php';
}
?>