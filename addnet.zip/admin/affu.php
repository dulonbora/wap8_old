<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include '../db.php';
include '../functions.php';

headtag("$SiteName - Admin Panel Beta");

if($adminlog==1){
echo '<div class="line">Pending Reffer</div>';

$id=formget("id");

$page=formget("page");

if(empty($page)){
$page=0;
}
$start=$page*10;
$end=($start+10);


$refs=mysqli_query("SELECT * FROM affiliates WHERE aid='$id' AND status='Pending' ORDER BY id DESC LIMIT $start,$end");


while($ref=mysqli_fetch_array($refs)){

echo '<div class="uright">Register user:  '.$ref["rid"].'<br/>Status: '.$ref["status"].'<br/>Refer By: <a href="user.php?id='.$ref["aid"].'">USER#'.$ref["aid"].'</a><br/>
User VALID
 <a href="affv.php?vid='.$ref["id"].'">VALID #'.$ref["id"].'</a></div>';
}

echo '<div class="back"><a href="?page='.($page+1).'">Next</a></div>';
echo '<a href="index.php?redir=aff"><div class="back">Home</div></a>';

include '../foot.php';

}
else {

header('Location:/login.php?error=aff&reason=session');
}

?>