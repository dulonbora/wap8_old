<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - Clicks details");

if($userlog==1){
$uid=dump_udata("id");

echo '<div class="title">Statistic Report</div>';

$page=formget("page");

if(empty($page)){
$page=0;
}
$start=$page*10;
$end=($start+10);

$stat=mysqli_query("SELECT * FROM clicks WHERE userid='$uid' ORDER BY id DESC LIMIT $start,$end");

include_once('country/ip2country.php');
$ip2c=new ip2country();
$ip2c->mysqli_host='localhost';
$ip2c->db_user='anilwapc_anil';
$ip2c->db_pass='@lolbaba9087)';
$ip2c->db_name='anilwapc_data';
$ip2c->table_name='ip2c';
if(mysqli_num_rows($stat)>0){
while($show=mysqli_fetch_array($stat)){
echo '<div class="uright">Date: '.$show["time"].'<br/>IP: '.$show["ip"].'<br/>User Agent: '.$show["ua"].'<br/>Country: '. $ip2c->get_country_name($show["ip"]) . ' <br/>Earned: $0.009<br/>Type: '.$show["status"].'</div>';
}

echo '<div class="uright"><a href="/clicks_details/'.($start+1).'">Next</a></div>';
}
else {
echo '<div class="error">There is no clicks!</div>';
}

echo '<div class="back"><img src="/home.png"/> <a href="/">Home</a> | <a href="/user/dashboard">Dashboard</a></div>';

include 'foot.php';


}

else {

header('Location:/');
}
?>
