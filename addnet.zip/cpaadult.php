<?php

/************************************

This CPA Updates Are Done By MobFreshAd and Done By Rasid


**************************************/

include 'db.php';
include 'functions.php';

$subid=formget("uid");

header("Location:https://mobfreshadtrk.com/adult.php?site_id=5438&subid1=$subid");
  
?>