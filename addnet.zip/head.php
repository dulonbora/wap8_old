<?php

$uid=dump_udata("id");
 
 $pub=dump_udata("pubalance"); $ad=dump_udata("adbalance");

$newpub=($pub*61);
 $newad=($ad*60); 

 echo '<div class="line">Welcome, <font color="white"><b>'.ucfirst(dump_udata("firstname")).' '.ucfirst(dump_udata("lastname")).'</b></font></div>';
echo '<div class="balance">WhatsApp Help: 8795589006 </div>';
echo '<div class="balance"><b> Your Account Balance : </b> <b id="num">'.dump_udata("pubalance").' $</b> <b> (   <b id="num_rs">Rs. '.$newpub.' </b> )</b> </div><div class="balance"><b> Your Approved Balance : </b> <b id="num">'.dump_udata("adbalance").' $</b>  <b>(  <b id="num_rs">Rs. '.$newad.'</b>  ) </b></div>'; 
?>