<?php

/************************************

This is Created By Rasid The Request of Shahid and Updated For MobFreshAd at 16-12-16 04.11 PM

**************************************/

include 'db.php';
include 'functions.php';

headtag("CPA Conversation Stats");


if($userlog==1){

include '../head.php';
 
$uid=dump_udata("id");

$d=date("u");

echo '<div class="title">CPA Conversation Stats</div>';

 echo '<div class="notice"><font color="red"> Note: </font> All Report Are Live </div><br/>';
 

echo '<table style="border-collapse:collapse;text-align:center;" align="center" height="60" border="1" bordercolor="#5b8ebb" cellpadding="5" width="90%">
<tbody><tr style="background-color:#5b8ebb">
<th height="28"> Date </th>

<th> Conversation</th>
<th> Earning</th>
</tr><tr bgcolor="#e8e8e8">';


$d=date("d");

for($i=$d;$i>0;$i--){

if(strlen($i)==1){
 $i="0$i";
}
$date=date("".$i."-m-Y");
 

$cpaqrry=mysqli_query("SELECT SUM(earn) FROM postback WHERE uid='$uid' AND date='$date'");
  $cpaern = mysqli_fetch_row($cpaqrry);
  $cpaearn =$cpaern[0]*1;
 

$getinstall = mysqli_query("SELECT * FROM postback WHERE uid='$uid' AND date='$date'");

  $showinstall = mysqli_num_rows($getinstall);

$cpareport=mysqli_query("SELECT * FROM postback WHERE uid='$uid' AND date='$date'");
while($getcpareport=mysqli_fetch_array($cpareport)){
 



echo '  
<tr class="even">
<td>'.$date.'</td>
 <td>'.$showinstall.'</td>
 <td>'.$cpaearn.'</td>
</tr>';
}}


$tcpaqrry=mysqli_query("SELECT SUM(earn) FROM postback WHERE uid='$uid'");
  $tcpaern = mysqli_fetch_row($tcpaqrry);
  $tcpaearn =$tcpaern[0]*1;
 

$tgetinstall = mysqli_query("SELECT * FROM postback WHERE uid='$uid'");

  $tshowinstall = mysqli_num_rows($tgetinstall);

echo '<tr bgcolor="#bfc2c5"> 
<td height="28">Total</td>
<td><b id="num">'.$tshowinstall.'</b></td>
<td><b id="num">'.$tcpaearn.' $</b></td>
</tr>';

echo '



</table>';


echo '<br/><div class="back"><img src="/home.png"/> <a href="/">Home</a> | <a href="/user/dashboard">Dashboard</a></div>';

include '../foot.php';

}
else {
header('Location:/');
}
?>
