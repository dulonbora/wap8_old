<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - Add funds");

if($userlog==1){

echo '<div class="title">Add funds</div>';

echo '<div class="uright">There are several ways to add funds to your account. Present ways at AdzIncome to add funds is given bellow:<br/>
- <a href="/transfer-from-publisher">Transfer from publisher balance ('.dump_udata("pubalance").'$)</a></div>';
echo '<div class="uright"><font color="red"><b> Note : </b></font> At first send balance to our below Paytm Wallet Transfer Number. <br></div>
<div class="uright"> After sending Money Create a Support Ticket or Mail Us : <a href="mailto:support@adzincome.in"> support@mydearads.in </a> . We will Update your Balance within 12 Hour. <br>
<b> Dont forget to Mention Reference/Transaction ID, Amount and  Date. </b><br>
<font color="blue"> Our minimum funding amount is <b> Rs. 60 </b> . </font><br></div>
<div class="uright">
<b> Paytm Wallet Transfer No. : </b> 8795589006</div>'; 

echo '<div class="back"><img src="/home.png"> <a href="/">Home</a> | <a href="/user/dashboard">Dashboard</a></div>';

include 'foot.php';

}
else {
header('Location:/');
}
?>
