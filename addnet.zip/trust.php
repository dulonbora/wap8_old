<?php include "inc/def.php"; ?>
<?php include "inc/usrchk.php";
if($guest==0) {
    header("location:Cpanel.php");
} ?> 
<?php


include "inc/header.php";
 include "inc/siteinfo.php";
echo '<title>Payment Proofs</title>';
$get=mysqli_query("SELECT * FROM moneybooker WHERE status=1");
$anuj2 = mysqli_num_rows($get);
$get=mysqli_query("SELECT * FROM dth WHERE status=1");
$anuj1 = mysqli_num_rows($get);
$get=mysqli_query("SELECT * FROM airtelmoney WHERE status=1");
$anuj = mysqli_num_rows($get);
$get=mysqli_query("SELECT * FROM recharge WHERE status=1");
$ban = mysqli_num_rows($get);
 $bank=mysqli_query("SELECT * FROM banks WHERE point=1");
$ketla = mysqli_num_rows($bank);

  echo '<div class="news_header"><p><b>Payment Proofs</b></p></div>';


   echo '<div class="ok"><a href="rcwins.htm"><b>Recharge Payments</b></a> <b><font color=red>['.$ban.']</font></b></div>
<div class="ok"><a href="bankwins.htm"><b>Bank Payments</b></a> <b><font color=red>['.$ketla.']</font></b></div>
<div class="ok"><a href="airtelwins.htm"><b>Airtel Money Payments</b></a> <b><font color=red>['.$anuj.']</font></b></div>
<div class="ok"><a href="dthwins.htm"><b>DTH Payments</b></a> <b><font color=red>['.$anuj1.']</font></b></div>
<div class="ok"><a href="mbwins.htm"><b>Moneybooker Payments</b></a> <b><font color=red>['.$anuj1.']</font></b></div>';

echo '</div>';
include "inc/footer.php";


?>
</html>