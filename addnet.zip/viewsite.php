<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - View site");

if($userlog==1){

echo '<div class="title">Site details</div>';
$site=formget("id");

$uid=dump_udata("id");

$chsite=mysqli_query("SELECT * FROM sites WHERE userid='$uid' AND id='$site'");

if(mysqli_num_rows($chsite)>0){

  $sites=mysqli_fetch_array($chsite);

  echo '<div class="form"><b>Name:</b> '.$sites["name"].'<br/><b>Url:</b> '.$sites["url"].'<br/><b>Description:</b> '.$sites["descr"].'</div>';

  echo '<div class="title">Statistics</div>';
  
  $sclick=mysqli_query("SELECT * FROM clicks WHERE siteid='$site'");
  $siclick=mysqli_query("SELECT * FROM clicks WHERE siteid='$site' AND status='INVALID'");
  
  $sclicks=mysqli_num_rows($sclick);
  $siclicks=mysqli_num_rows($siclick);
  $svclicks=($sclicks-$siclicks);
  $earned=($svclicks*0.004);
  $vcr=($svclicks/$sclicks)*100;
  
 
  echo '<div class="ad">Total clicks: '.$sclicks.'<br/>Valid clicks: '.$svclicks.'<br/>Invalid clicks: '.$siclicks.'<br/>Valid click rate: '.$vcr.'%<br/>Earned: '.$earned.'$</div>';

  echo '<div class="title">Site options</div>';

  echo '<div class="form">- <a href="/editsite/'.$site.'">Edit site</a><br/>- <a href="/deletesite/'.$site.'">Delete site</a><br/>- <a href="/adcode/'.$site.'">Adcode</a></div>';

 }

 else {
  
  echo '<div class="error">Unauthorized access!</div>';
 }
  
echo '<div class="ad"><img src="/home.png"/> <a href="/">Home</a> | <a href="/sites">My sites</a></div>';

include 'foot.php';

}

else {
 header('Location:/');
 }

?>

 
  