<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include '../db.php';
include '../functions.php';

$uid=formget("uid");
$sid=formget("sid");

$errors=array();

$chSite=mysqli_query("SELECT * FROM sites WHERE id='$sid' AND userid='$uid'");
$chSblock=mysqli_fetch_array(mysqli_query("SELECT * FROM sites WHERE id='$sid'"));

if(empty($sid)){
 $errors[]='Site is Empty!';
}
if(empty($uid)){
 $errors[]='User is Empty!';
}
if(mysqli_num_rows($chSite)<1){
 $errors[]='Site Not Found!';
}
if($chSblock["status"]=="BLOCKED"){
 $errors[]='Site is Blocked';
}


      $pr='<a href="https://mobfreshadtrk.com/adult.php?site_id=5438&subid1=$uid"><img src="http://adplay.in/banners/image.php?siteid=18" alt="Click Here"/><b>Click Here To Download</b></a>';

      
   
   
   echo 'document.write(\''.$pr.'\');';

}
else {

foreach($errors as $error){
echo 'document.write(\''.$error.'\');';
}
}
 
include'../pop.js';

$date=date("d-m-Y");
$chimp=mysqli_query("SELECT * FROM imp WHERE uid='$uid' AND date='$date'");
$chimpc=mysqli_fetch_array($chimp);
if(mysqli_num_rows($chimp)>0){
$newimp=($chimpc["imp"]+1);
mysqli_query("UPDATE imp SET imp='$newimp' WHERE uid='$uid' AND date='$date'");
}
else {
mysqli_query("INSERT INTO imp (uid,imp,date) VALUES ('$uid',1,'$date')");
}

header('Content-type: application/js');
?>