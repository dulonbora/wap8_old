<footer id="searchbarrrrr" class="footer bg-success dker animated fadeInUp">
<form action="/s.php" class="navbar-form m-t m-l-n-xs" role="search"> 
         <div class="input-group"> <span class="input-group-btn"> 
                    <button type="submit" class="btn btn-sm bg-white btn-icon rounded">
                        <i class="fa fa-search"></i></button> </span>
                <input type="text" name="q" class="form-control input-sm no-border rounded" placeholder="Search songs, albums...">
            </div> </form>
</footer>