
<div class="wrapper"> <h4 class="m-t-none">Add New Artist</h4>
                <form  method="post" id="fmenu" role="form">
                <div class="form-group"> <label>Name</label>
                    <input type="text" name="ARTIST_NAME" id="ARTIST_NAME" placeholder="Artist Name" class="input-sm form-control"> </div>
                
                <div class="form-group"> <label>Born</label>
                    <input type="text" name="BORN_ON" id="BORN_ON" placeholder="BORN_ON" class="input-sm form-control"> </div>
              
                <div class="form-group"> <label>Description</label>
                    <input type="text" name="DESCRIPTION" id="DESCRIPTION" placeholder="DESCRIPTION" class="input-sm form-control"> </div>
              
                    
                    <div class="m-t-lg"><input type="submit" id="addmenu" value="Add Album" class="btn btn-primary btn-rounded btn-block"></div> 
                </form> </div>


