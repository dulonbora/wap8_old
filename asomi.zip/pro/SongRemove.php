<?php include '../classes/songs.php';

$id = "-1";
if(isset($_GET['i'])==true){

$id = $_GET['i'];
}


$v = new songs();

$v->Remove($id);

?>