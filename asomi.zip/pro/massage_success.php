<div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <i class="fa fa-ok-sign"></i><strong>Well done!</strong> You successfully Added 
                <a href="index.php" class="alert-link">check your posts</a>. </div>