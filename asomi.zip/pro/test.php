<section class="scrollable hover">
    <ul class="list-group list-group-lg auto m-b-none m-t-n-xxs">
        <li class="list-group-item clearfix bg bg-succss">
    <a href="" class="pull-left thumb-sm m-r"> <img src="image/" alt="..."> </a>
    <a class="clear" href=""> <span class="block text-ellipsis">Comming Soon</span> <small class="text-muted">by Comming Soon</small> </a>
        </li></ul>
</section>