<?php

$path = "-1";
if (isset($_GET['l'])) {
    $path = $_GET['l'];
    //$path = str_replace('../', '', $path1);
}
$fileName = "-1";
if (isset($_GET['f'])) {
    $fileName = $_GET['f'];
}

if (isset($_GET['i']) == true) {
    $id = $_GET['i'];
}

if (unlink($path."/".$fileName)) {
    echo "Removed";
}

function pageRedirect($page) {
    echo "<script type=\"text/javascript\">	";
    echo "document.location = '" . $page . "' ";
    echo "</script>";
}

?>