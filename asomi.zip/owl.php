<div class="row">
            <div class="span12">

              <div id="owl-example" class="owl-carousel owl-theme" style="opacity: 1; display: block;">

                <div class="owl-wrapper-outer"><div class="owl-wrapper" style="width: 4820px; left: 0px; display: block; transform: translate3d(0px, 0px, 0px); transition: all 0ms ease;"><div class="owl-item" style="width: 241px;"><div class="item darkCyan">
                  <img src="assets/img/demo-slides/touch.png" alt="Touch">
                    <h3>Touch</h3>
                    <h4>Can touch this</h4>
                </div></div><div class="owl-item" style="width: 241px;"><div class="item forestGreen">
                  <img src="assets/img/demo-slides/grab.png" alt="Grab">
                    <h3>Grab</h3>
                    <h4>Can grab this</h4>
                </div></div><div class="owl-item" style="width: 241px;"><div class="item orange">
                  <img src="assets/img/demo-slides/responsive.png" alt="Responsive">
                    <h3>Responsive</h3>
                    <h4>Fully responsive!</h4>
                </div></div><div class="owl-item" style="width: 241px;"><div class="item yellow">
                  <img src="assets/img/demo-slides/css3.png" alt="CSS3">
                    <h3>CSS3</h3>
                    <h4>3D Acceleration.</h4>
                </div></div><div class="owl-item" style="width: 241px;"><div class="item dodgerBlue">
                  <img src="assets/img/demo-slides/multi.png" alt="Multi">
                    <h3>Multiply</h3>
                    <h4>Owls on page.</h4>
                </div></div><div class="owl-item" style="width: 241px;"><div class="item skyBlue">
                  <img src="assets/img/demo-slides/modern.png" alt="Modern Browsers">
                    <h3>Modern</h3>
                    <h4>Browsers Compatibility</h4>
                </div></div><div class="owl-item" style="width: 241px;"><div class="item zombieGreen">
                  <img src="assets/img/demo-slides/zombie.png" alt="Zombie Browsers - old ones">
                    <h3>Zombie</h3>
                    <h4>Browsers Compatibility</h4>
                </div></div><div class="owl-item" style="width: 241px;"><div class="item violet">
                  <img src="assets/img/demo-slides/controls.png" alt="Take Control">
                    <h3>Take Control</h3>
                    <h4>The way you like</h4>
                </div></div><div class="owl-item" style="width: 241px;"><div class="item yellowLight">
                  <img src="assets/img/demo-slides/feather.png" alt="Light">
                    <h3>Light</h3>
                    <h4>As a feather</h4>
                </div></div><div class="owl-item" style="width: 241px;"><div class="item steelGray">
                  <img src="assets/img/demo-slides/tons.png" alt="Tons of Opotions">
                    <h3>Tons</h3>
                    <h4>of options</h4>
                </div></div></div></div>
                
                

                

                

                

                

                

                

                

              </div>


            </div>
          </div>