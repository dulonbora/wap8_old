                                    <div class="hidden-lg hidden-md text-center">
<?php
// AdzMedia Publisher Install Code
// Language: PHP (curl)
// Version: 2.0
// Copyright AdzMedia.com, All rights reserved

		$adzone = 9347;
	 
	 	$adzmedia_url  = 'http://rtb.adzmedia.com/api?';
	 	
		 $adzmsite = array('adzone'=>$adzone);
	 
	 	if(isset($_SERVER['HTTP_HOST']) && isset($_SERVER['REQUEST_URI']))
	 	{
	 		$adzmsite['rqpage']  = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	 	}
	 	if(isset($_SERVER['HTTP_REFERER']))
	 	{
	 		$adzmsite['ref'] =  $_SERVER['HTTP_REFERER'];
	 	}
	 	
	 	$adzmdevice = array('ip' => $_SERVER['REMOTE_ADDR'],'ua'=>$_SERVER['HTTP_USER_AGENT']);
	 	
	 	$adzmedia_headers = array();
	 	$adzmheaderprefix = 'ADZ-';
		foreach ($_SERVER as $adz_name => $adz_value)
		{
    		$adzmedia_headers[$adzmheaderprefix.$adz_name] = $adz_value;
   		}	
   		$adzmcontent_type=array("Content-Type: application/json");
   	    
   	    $adzmsite['headers'] = $adzmedia_headers;

   		$adzmobj = json_encode(array('site' => $adzmsite,'device'=>$adzmdevice)); 	

	 	$adzmrequest = curl_init();
		$adzmrequest_timeout = 5; 
		curl_setopt($adzmrequest, CURLOPT_URL, $adzmedia_url);
		curl_setopt($adzmrequest, CURLOPT_USERAGENT, $adzmdevice['ua']);
		curl_setopt($adzmrequest, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($adzmrequest, CURLOPT_HTTPHEADER, $adzmcontent_type);
		curl_setopt($adzmrequest, CURLOPT_POST, 1);
		curl_setopt($adzmrequest, CURLOPT_TIMEOUT, $adzmrequest_timeout);
		curl_setopt($adzmrequest, CURLOPT_CONNECTTIMEOUT, $adzmrequest_timeout);
		curl_setopt($adzmrequest, CURLOPT_POSTFIELDS,$adzmobj);

		$adzmcontents = curl_exec($adzmrequest);
		if (curl_getinfo($adzmrequest,CURLINFO_HTTP_CODE) == 200)
		{
			echo $adzmcontents;
		}
		
		curl_close($adzmrequest);
?>
                                    </div>
