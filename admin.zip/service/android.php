<?php
define('IN_SS', true);
include_once('../inc/init.php');
$title = 'Check here your phone is android or not';
include_once('../header.php');
echo '<div class="ad2 tCenter"></div> <div id="cateogry"><h4 class="ad1" align="center">Bellow Result</h4><br/><div class="bt"></div>';
$Android = stripos($_SERVER['HTTP_USER_AGENT'], "Android");
if($Android){
echo '<div style="padding: 4px;"><b>Congratulations! Your Mobile Phone Is Android</b></div>';
}
else
{
echo '<div style="padding: 4px;"><b>Sorry Your Mobile Phone Is Not Android</b></div>';
}
echo '<div class="bt"></div></div><div class="ftrLink"><a href="/" class="siteLink">'.$ss->settings['title'].'</a></div></body></html>';
?>