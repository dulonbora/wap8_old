<?php
include_once('./header.php');
$lng = $_SERVER['HTTP_ACCEPT_LANGUAGE'];
echo'<div class="info">Phone Info</div><div class="main"><b>Your Browser Language:</b> '.$lng.'</div><div class="main"><a href="/service/info/">Phone Info</a></div>';
include_once('./footer.php');
?>