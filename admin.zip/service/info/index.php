<?php
include_once('./header.php');
echo'<div class="info">Phone Info</div><div class="main"><a href="browser.php">Browser</a><br/><a href="ip.php">IP Address</a><br/><a href="acc.php">Browser Accepts</a><br/><a href="lng.php">Browser Language</a><br/><a href="time.php">Time Date</a><br/>';
include_once('./footer.php');
echo'<p align="center"><a href="http://kingbuzz.in">Powered by KingBuzz</a></p>';
?>