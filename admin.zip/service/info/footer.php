<?php
echo'<div class="footer"><a href="/">Home</a></div><div class="center"></div></body></html>';
?>