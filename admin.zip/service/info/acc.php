<?php
include_once('./header.php');
$acc = $_SERVER['HTTP_ACCEPT'];
echo'<div class="info">Phone Info</div><div class="main"><b>Your Browser Accepts:</b><br/>'.$acc.'</div><div class="main"><a href="/service/info/">Phone Info</a></div>';
include_once('./footer.php');
?>