<?php
include_once('./header.php');
date_default_timezone_set('Asia/Calcutta'); 
$time = date('d/m/Y - h:i:s A', time());
$t= time();
$t2 = strtotime("+1 week", time());
echo $t;
echo $t2;
echo'<div class="info">Phone Info</div><div class="main"><b>Date Time:</b><br/> '.$time.'</div><div class="main"><a href="/service/info/">Phone Info</a></div>';
include_once('./footer.php');
?>