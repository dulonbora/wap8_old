<?php
define('IN_SS', true);
include_once('../inc/init.php');

$title = 'MyMp3King Custom Search';
include_once('../header.php');
include_once('../assets/includes/gcustom.php');
echo '</body></html>';
?>