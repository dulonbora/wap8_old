<?php
define('IN_SS', true);

$title = "Weather Information";
include_once('../inc/init.php');

include_once("../header.php");
include_once('../assets/ads/header.php');
echo'<h2>Weather Information</h2><div class="toptitle"><form action="'.$_SERVER['PHP SELF'].'" method="get"><div>Enter City Name:<br/>
<input type="text" name="city" value=""/></div><div>
<input type="submit" value="View" />
</div>
</form></div>';
$city= $_GET['city'];
if($city ==! '')
{
$city = $_GET['city'];
}
else
{
$city = 'Kolkata';
}
echo "<h2>Result For $city</h2>";
$country="IN";
//Two digit country code
$apikey="4600dbc40f30b9aa38adc0b762360299";
//Your openweathermap api key
$url="http://api.openweathermap.org/data/2.5/weather?q=".$city.",".$country."&units=metric&cnt=7&lang=en&APPID=".$apikey."";
$json=file_get_contents($url);
$data=json_decode($json,true);
//Get current Temperature in Celsius
echo '<div class="toptitle"><div>Temperature: ';
echo$data['main']['temp']."&deg; C</div></div>";
//Get current air pressure in hg
echo '<div class="toptitle"><div>Pressure: ';
echo$data['main']['pressure']." Hg</div></div>";
//Get current humidity in percentage
echo '<div class="toptitle"><div>Humidity: ';
echo$data['main']['humidity']."%</div></div>";
//Get max Temperature in Celsius
echo '<div class="toptitle"><div>Min Temperature: ';
echo$data['main']['temp_min']."&deg; C</div></div>";
//Get max Temperature in Celsius
echo '<div class="toptitle"><div>Max Temperature: ';
echo$data['main']['temp_max']."&deg; C</div></div>";
//Get weather condition
echo '<div class="toptitle"><div>Condition: ';
echo$data['weather'][0]['main']."</div></div>";
//Get cloud percentage
echo '<div class="toptitle"><div>Cloud: ';
echo$data['clouds']['all']."%</div></div>";
//Get wind speed
echo '<div class="toptitle"><div>Wind Speed: ';
echo$data['wind']['speed']." Km/h</div></div>";
date_default_timezone_set('Asia/Calcutta'); 
//Get current sunrise time
echo '<div class="toptitle"><div>Sunrise: ';
$sunrise = date('h:i:s A',$data['sys']['sunrise']);
echo "$sunrise</div></div>";
//Get current sunset time
echo '<div class="toptitle"><div>Sunset: ';
$sunset = date('h:i:s A',$data['sys']['sunset']);
echo "$sunset</div></div>";
include_once('./assets/ads/footer.php');
echo '<div class="path"><a href="/">Home</a> &raquo;</div>';
include_once('../footer.php');
?>