<?php
include'lib/functions.php';
$u=strip_tags($_GET['u']);
$html = file_get_html('http://m.thatscricket.com/'.$u.'');
// Live matches
preg_match('|<title>(.*?)</title>|is',$html,$out);
$ttl=$out[1];
$ttl=str_replace(' - thatscricket Mobile','',$ttl);
mac_header(''.$ttl.'');
$mac = 0;
foreach($html->find('div.livescorecardBlock') as $e){
echo'<div class="box"><div class="title">'.$ttl.'</div>';

$mac = $mac + 1;     
$_mac = $e->innertext . '';
$results = $_mac;
$results=preg_replace('|<div class="refresh">(.*?)</div>|is','<div class="refresh"><input type="button" value="Refresh" onClick="window.location.reload()"></div>',$results);
$results=preg_replace('|Share This: <div class="pw-widget pw-size-medium">(.*?)</div>|is','',$results);
$results=preg_replace('|<div class="headingLists">(.*?)</div>|is','',$results);
$results=preg_replace('|<script(.*?)</script>|is','',$results);
$results=preg_replace("|<a href = '/(.*?)/players/(.*?)'>(.*?)</a>|is",'<b>$3</b>',$results);
$results=str_replace('/scores/',''.$config[url].'/expand/scores/',$results);
echo $results;	

}

echo'</div>';

mac_footer();
?>