<?php
include'lib/functions.php';
mac_header('Live Cricket Score');
all();
mac_footer();
?>