<?php
include'lib/functions.php';
$html = file_get_html('http://m.thatscricket.com/schedules/');

mac_header('Fixtures');
$mac = 0;
echo'<div class="box"><div class="title">Fixtures</div>';
foreach($html->find('div.mainBlock1') as $e){


$mac = $mac + 1;     
$_mac = $e->innertext . '';
$results = $_mac;
echo $results;	

}

echo'</div>';

mac_footer();
?>