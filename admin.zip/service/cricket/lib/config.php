<?php

// The main Config File //
$config['sitename']="KingBuzz.In"; // The name of your site
$config['url']="/service/cricket"; // the url of your site
$config['desc']="Online live cricket score service by kingbuzz.in"; //meta description 
$config['keyword']="kingbuzz, kingbuzz.in, nextwave solutions, live crickets"; // Your Meta keywords
$config['api']="HYG576FGD37DGXXC67zAs21"; // Secret key - if you touch this your site will no longer work :/
;?>