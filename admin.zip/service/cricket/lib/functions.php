<?php
// The Functions //
include'config.php';
include "html_dom.php";
// The Header
function mac_header($title){
global $config;
echo'<!DOCTYPE HTML>
<html>
<head>
<title>'.$title.' :: '.$config[sitename].'</title>
<meta charset="utf-8"/>
<link rel="stylesheet" type="text/css" href="'.$config[url].'/css/style.css"/>
<link href="data:image/x-icon;base64,AAABAAEAEBAAAAAAAABoBQAAFgAAACgAAAAQAAAAIAAAAAEACAAAAAAAAAEAAAAAAAAAAAAAAAEAAAAAAAAAAAAAdWz1ABwTxgAOCaAATUXlACMZ2ABqYfAAKSTMAAEAoQCGffsARj7jAMG+9gCRi+8Ae3fhAGNc4gAdFc0ANCreAGJa7gALBLYAY1ruAJeR+ACEgdsAamHxAFNL5gC1s/EAEQnFAIeE5ABVTOkAdnHQAHRr9ACmofIAeXnWAF9W7AB6cvcAUlHDADUs3AB7cvcACwXDACIY1wA7MtwAEQm9ACkjwgA8M98AbmfpAGxk8gBcV8wAhn73AFhP6gBDOuIALyjRAAcCsgBKQeUAq6fzACAZyQBNROUAIx3DAAoGvgBras8AgHj4AG9tzwCzsPMAhHz7ANDN+AApINUAQTraAG9n8wCHf/sABQCtADAqzwBGPeMAwb/zAH543gBiWe4AeXH2AGhh2QB9duoAIhrNACMa1gC0s+sAoqDgAJ6a8gC5t+4AurnrAC0l0wCNh/AAGA/RABkP0QBeVewAwb7xAH9/0AA0Kd8ANSvcAFNQzABQR+cAUkrnACYhyAA/ONYAV07qAG9m8gCHgPcAW1LtAE9LtQBKQOUAYVjtAB8ZwwAdE9UAxsP4AGlh5AB/d/gAPjXgAEA52gBXTusApKPiAAIApwBGPdQARDzjAF5X4gAvJd4ADwyVAAoDuQAhGscADge8AFFJ5gAmIsQAa2LxAD422wBzctAALiy+AEE44QAsI9kAHBmzABwTxQBfV+wADwyWAMTB9AB8c/cAZl7vADky2QBoYOwAmZL5AG9r1wBuZfIAiYTrADArzgBNTLsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB2hQAAAAAAAAAAAAAAZTlZkAhxQwMAAAAAAAAALR9+giJPOzJ3EgAAAAAAeSU4KRVwf1xSNxkoAAAAAFUPNXhoe06MX1FMVgAAAINNP1MxRI8HGg1gRmkCAAAFgSMnfW5AQIkYdI5rJgAAEFttCgR6Fxd6Mz5ahnUAADAqRV0vIBEThGFQKzxzAABygDYvSBZiQXwTih4MSgAAAGZeVwYdJIcBfG8LVAAAAAAOG2eNIQlCh0FkajQAAAAAAEuILEk9CSGNE1gAAAAAAAAARxQubDpji0cAAAAAAAAAAAAAABwcAAAAAAAAAP//AAD+fwAA8A8AAOAHAADAAwAAwAMAAIABAACAAQAAgAEAAIABAACAAQAAwAMAAMADAADgBwAA8A8AAP5/AAA=" rel="icon" type="image/x-icon" />
<meta name="description" content="'.$config[desc].'"/>
<meta name="keywords" content="'.$config[keywords].'"/>
</head>
<body>
<div class="wrap"><div class="logo"><a href="'.$config[url].'"><img src="'.$config[url].'/static/logo.png" alt="'.$config[sitename].'"/></a></div><div class="nav"><a href="'.$config[url].'">Home</a> <a href="'.$config[url].'/fixtures.html">Fixtures</a></div><!-- Adblock 1 -->';
include'ad1.php';
echo'<!-- Adblock 1 Ends --> ';

}
// The Footer
function mac_footer(){
global $config;
echo'<!-- Adblock 2 -->';
include'ad2.php';
echo'<!-- Adblock 2 Ends --> ';
echo'
<div class="footer">&#169; '.$config[sitename].' '.date(Y).'<br/>Development by : <a href="http://nextwavesolutions.cu.cc">Nextwave Solutions</a></div></div>
</body>
</html>';}

// Main
function all(){
global $config;
$html = file_get_html('http://m.thatscricket.com');
// Live matches
$mac = 0;
foreach($html->find('div#tab1') as $e){
echo'<div class="box"><div class="title">Live Matches</div>';
if($e){
$mac = $mac + 1;     
$_mac = $e->innertext . '';
$results = $_mac;
$results=preg_replace('|<div class="normalText"><a(.*?)\'>(.*?)</a>|is','<div class="normalText">$2',$results);
$results=str_replace('</a></a>','</a>',$results);
$results=str_replace('/scores/',''.$config[url].'/expand/scores/',$results);
//$results=str_replace('Ball by Ball','View Ball by Ball Update',$results);
echo $results;	
}
else{
echo'<div class="error">No Live Match Running!</div>';}

}
echo'</div>';

// Fixtures
echo'<div class="box"><div class="title">Fixtures</div>';
foreach($html->find('div#fixtures') as $i){
if($i){
$mac = $mac + 1;     
$_iac = $i->innertext . '';
$fix = $_iac;
$fix = str_replace('<ul>','<ul id="fixtures">',$fix);
$fix = preg_replace('|<a href="/schedules/">More</a>|is','<a href="'.$config[url].'/fixtures.html">Show More</a>',$fix);
echo $fix;	
}
else{
echo'<div class="error">failed to load fixtures!</div>';}

}
echo'</div>';

//Results
echo'<div class="box"><div class="title">Results</div>';
foreach($html->find('div#results') as $x){
if($x){
$mac = $mac + 1;     
$_xac = $x->innertext . '';
$re = $_xac;
$re = str_replace('<ul>','<ul id="results">',$re);
$re = str_replace('/scores/',''.$config[url].'/expand/scores/',$re);
echo $re;	
}
else{
echo'<div class="error">failed to load results!</div>';}

}
echo'</div>';
// ICC Ranking

echo'<div class="box"><div class="title">ICC Ranking</div>';
foreach($html->find('div.rankingBlock') as $rank){
if($rank){
$mac = $mac + 1;     
$_rac = $rank->innertext . '';
$rnk = $_rac;
$rnk = preg_replace('|<div class="moreLink">(.*?)</div>|is','',$rnk);
$rnk = preg_replace('|/ranking/flags|is','http://m.thatscricket.com/ranking/flags',$rnk);
echo $rnk;	
}
else{
echo'<div class="error">failed to load rankings!</div>';}

}
echo'</div>';
}
