<?php
header('Location: http://mirazmac.info/'); ?>