<?php
define('IN_SS', true);
include_once('./inc/init.php');

$title = 'Development By Nextwave Solutions';
include_once('./header.php');
include_once('./assets/ads/header.php');
include_once('./searchbox.php');
echo '<h2>404 Not Found</h2><div class="ad tCenter">The Page you requested is not found or not available.<br/><a href="/">Go to Homepage</a></div>';
include_once('./footer.php');
?>