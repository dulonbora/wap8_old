<?php
define('IN_SS', true);
include_once('./inc/init.php');

$fid = $ss->get_input('id');

$query = $db->simple_select("files", "*", "fid={$fid}");
$file = $db->fetch_array($query);

if(!$file)
{
header('Location: '.$ss->settings['url'].'');
exit;
}

$db->query("UPDATE ".TABLE_PREFIX."files SET dcount=dcount+1 WHERE fid=".$file['fid']."");

$date = date("dmY", TIME_NOW);

$query = $db->simple_select("download_history", "did", "fid=".$file['fid']." AND date='{$date}'");
$count = $db->num_rows($query);

if($count != 0)
{
$db->query("UPDATE ".TABLE_PREFIX."download_history SET hits=hits+1 WHERE fid=".$file['fid']." AND date='{$date}'");
}
else
{
$db->insert_query("download_history", ['hits' => 1, 'fid'=>$fid, 'date'=>$date]);
}
$id = $_GET['id'];
$query = $db->simple_select("files", "fid, name, use_icon, path, description, isdir", "fid='{$id}'");
$file = $db->fetch_array($query);
$path = $file['path'];
if($path ==! '')
{
$type = $_GET['type'];
switch($type) 
{ 
case '3GP': 
$order = '.3gp'; 
break; 
case 'MP4': 
$order = '.mp4'; 
break;
case 'HD': 
$order = '_480p.mp4'; 
break;
case 'FHD': 
$order = '_720p.mp4'; 
break;
}
$path2 = str_replace(".mp4", "$order", $path);
$path2 = str_replace("/files", "files", $path2);
header('Location: '.$ss->settings['dlserver'].''.$path2.'');
}
else
{
header('Location: /');
}
?>