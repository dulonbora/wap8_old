<?php
$dbhost = "localhost";
$dbtype = "mysqli";
$dbname = "mympking_data";
$dbuser = "mympking_data";
$dbpass = "@mymp3king";
$dbprefix = "sm_";
$admin_dir ="admin";
$api_key = "WWxoc2RHTkVUbkpoVnpWdVRHMXNkVnB0T0QwPQ==";
$dbencoding = "utf8";
?>