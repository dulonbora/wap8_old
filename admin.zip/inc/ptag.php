<?php
define('IN_SS', true);
include_once('./init.php');
$id = $_GET['id'];
$query = $db->simple_select("files", "fid, name, use_icon, path, description, ptag", "fid='{$id}'");
$folder = $db->fetch_array($query);
$ftag = $folder['ptag'];
if(escape($folder['ptag']) == '')
{
echo ''; 
}
else
{ 
echo '<center><div class="filedescription"><small><b>Tags:</b> '.$folder['ptag'].'</small></div></center>';
}
?>