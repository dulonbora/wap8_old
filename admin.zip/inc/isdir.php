<?php
define('IN_SS', true);
include_once('./init.php');
$id = $_GET['id'];
$query = $db->simple_select("files", "fid, name, use_icon, path, description, isdir", "pid='{$id}'");
$file = $db->fetch_array($query);
$isdir = $file['isdir'];
echo ''.$isdir.'';
?>