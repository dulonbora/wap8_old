<?php
define('IN_SS', true);
include_once('./init.php');
$id = $_GET['id'];
$query = $db->simple_select("files", "fid, name, use_icon, path, description", "fid='{$id}'");
$folder = $db->fetch_array($query);
$fname = $folder['name'];
echo '<br/><span class="al">Album: '.$fname.'</span>';
?>