<?php
define('IN_SS', true);
include_once('./init.php');
$id = $_GET['id'];
$query = $db->simple_select("files", "fid, name, use_icon, path, description, isdir", "fid='{$id}'");
$file = $db->fetch_array($query);
$path = $file['path'];
$path = str_replace('/files/', '/' , $path);
echo $path;
?>