/********************
*                   *
*     ionutvmi      *
*  wap phpmyadmin   *
*     v 2.1         *
*                   *
********************/

/*** REQUIREMENTS **/
PHP5
MYSQL5
A WEB BROWSER

/****** INSTALL ****/
1. unzip wap_phpmyadmin_2_1.zip file
2. if needed chmod `data` folder 777
2.1 if you want to use the Translate option you have to chmod `lang/index.php` to 666 (also if needed)
3. ENJOY AND USE IT

NOTE: i would be very happy to see new teplates for this (iPhone :x)

/******* bugs ******/
I'M STILL TESTING THIS SCRIPT SO IF YOU FIND ANY BUGS PLEASE REPORT IT AT ionutvmi@gmail.com  also you can get help on master-land.net

/**** DONATIONS ****/
If you want to support the development of this app you can donate via PayPal: ionutvmi@gmail.com

Thank you,
ionutvmi