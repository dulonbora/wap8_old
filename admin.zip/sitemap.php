<?php
define('IN_SS', true);
include_once('./inc/init.php');

$url="http://mazaming.in/";
$contents = file_get_contents($url); //Simple file_get_contents for free hosting users :p 
header('Content-type: text/xml'); // Tell the robot that I'm a XML file :p
$contents2 = str_replace('<a href="/','<a href="'.$url.'', $contents);
echo "<?xml version='1.0' encoding='UTF-8'?>\n";
echo "<!-- Generated via MAI SEO 2.0 Plugin-->\n";
echo "<urlset xmlns='http://www.google.com/schemas/sitemap/0.84'>\n";
//Get the urls out of the page
preg_match_all("/<a href=\"http(.*?)\"/", $contents2, $matches);
foreach($matches[1] as $value)
{  
        echo'<url>
		<loc>http'.$value.'</loc>
		<priority>1.0</priority>
		<changefreq>daily</changefreq>
		</url>';        
          
}  
echo'</urlset>';
?> 