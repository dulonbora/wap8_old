<?php
echo'
<!-- Nextwave Solutions :: Display Dropdown Menu --><section class="topmenu"><div class="has-dropdown">
<ul class="swtrow"></ul>
<a href="#" class="dropdownmenu"></a>
</div>
<div class="submenu">
<ul class="swtrow">';
$query = $db->simple_select("files", "fid", "pid='0'");
$total = $db->num_rows($query);

$options = ['order_by' => 'disporder ASC, fid DESC', 'limit_start' => $start, 'limit' => 30];
$query = $db->simple_select("files", "fid, name, isdir, tag, path, size, views, dcount, description, ptag, link, flagtime, status, pageurl, time", "pid='0'", $options);
while($dropcat = $db->fetch_array($query))
{
if($dropcat['link'])
{
echo '<li class="swtcol12"><a href="'.$dropcat['link'].'">'.$dropcat['name'].'</a></li>';
}
else
{
$strname = $ss->settings['title'];
$dropcatname = str_replace("($strname)", "", escape($dropcat['name']));
echo '<li class="swtcol12"><a href="/categorylist/'.$dropcat['fid'].'/new2old/1.html">'.$dropcatname.'</a></li>';
}
}
echo '</ul></div></section>';

?>