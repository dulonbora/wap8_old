<?php
define('IN_SS', true);
include_once('./inc/init.php');

$title = 'Latest Updates';
include_once('./header.php');
include_once('./searchbox.php'); 
echo'<div class="topadvt advertisment">'; 
include_once('./assets/ads/header.php');
echo'</div>';
$page = isset($ss->input['page']) ? (int)$ss->input['page'] : 1;

$start = ($page-1)*$ss->settings['updates_per_page']; 

$sort = isset($ss->input['sort']) ? $ss->input['sort'] : $ss->settings['sort'];

$query = $db->simple_select("updates", "uid");
$total = $db->num_rows($query);

echo '<section class="section_header aligncenter bgcolor_main">Latest Updates</section>'; 
if($_GET['sort'] == 'default') 
{ 
echo '<section class="sorting_section aligncenter">Sort by : <a href="/latest_updates/new2old/1.html" class="main-bg active">New 2 Old</a>&nbsp;|&nbsp;<a href="/latest_updates/popular/1.html" class="main-bg">Popular</a>&nbsp;|&nbsp;<a href="/latest_updates/a2z/1.html" class="main-bg">A to Z</a>&nbsp;|&nbsp;<a href="/latest_updates/z2a/1.html" class="main-bg">Z to A</a></section>'; 
} 
if($_GET['sort'] == 'new2old') 
{ 
echo '<section class="sorting_section aligncenter"> Sort by : <a href="/latest_updates/new2old/1.html" class="main-bg active">New 2 Old</a>&nbsp;|&nbsp;<a href="/latest_updates/popular/1.html" class="main-bg">Popular</a>&nbsp;|&nbsp;<a href="/latest_updates/a2z/1.html" class="main-bg">A to Z</a>&nbsp;|&nbsp;<a href="/latest_updates/z2a/1.html" class="main-bg">Z to A</a></section>'; 
} 
if($_GET['sort'] == 'popular') 
{ 
echo '<section class="sorting_section aligncenter">Sort by : <a href="/latest_updates/new2old/1.html" class="main-bg" 
>New 2 Old</a>&nbsp;|&nbsp;<a href="/latest_updates/popular/1.html" class="main-bg active">Popular</a> 
&nbsp;|&nbsp;<a href="/latest_updates/a2z/1.html" class="main-bg">A to Z</a>&nbsp;|&nbsp;<a href="/latest_updates/z2a/1.html" class="main-bg">Z to A</a></section>'; 
} 
if($_GET['sort'] == 'a2z') 
{echo '<section class="sorting_section aligncenter">Sort by : <a href="/latest_updates/new2old/1.html" class="main-bg">New 2 Old</a>&nbsp;|&nbsp;<a href="/latest_updates/popular/1.html" class="main-bg">Popular</a>&nbsp;|&nbsp;<a href="/latest_updates/a2z/1.html" class="main-bg active">A to Z</a>&nbsp;|&nbsp;<a href="/latest_updates/z2a/1.html" class="main-bg">Z to A</a></section>'; 
} 
if($_GET['sort'] == 'z2a') 
{ 
echo '<section class="sorting_section aligncenter">Sort by : <a href="/latest_updates/new2old/1.html" class="main-bg" 
>New 2 Old</a>&nbsp;|&nbsp;<a href="/latest_updates/popular/1.html" class="main-bg" 
>Popular</a>&nbsp;|&nbsp;<a href="/latest_updates/a2z/1.html" class="main-bg">A to Z</a>&nbsp;|&nbsp;<a href="/latest_updates/z2a/1.html" class="main-bg active">Z to A</a></section>'; 
} 

echo'<!-- Nextwave Solutions :: Display Latest Updates --><section class="item_list latest_list">'; 

 echo'<div class="download-middle-advt advertisment">'; 
include_once('./assets/ads/bfilelist.php'); 
echo'</div>';
switch($sort) 
{ 
case 'new2old': 
$order = 'uid';
$type = 'desc';
break; 
case 'a2z': 
$order = 'text'; 
$type = 'asc';
break; 

case 'z2a': 
$order = 'text'; 
$type = 'desc';
break; 
case 'popular': 
$order = 'url'; 
$type = 'desc';
break; 
default: 
$order = 'created_at'; 
$type = 'desc';
break; 
} 

if($total != 0)
{
$options = ['order_by' => ''.$order.'', 'order_dir' => ''.$type.'', 'limit_start' => $start, 'limit' => $ss->settings['updates_per_page']];

$query = $db->simple_select("updates", "iconid, text, url, update_time, created_at", "status='A'", $options);
while($update = $db->fetch_array($query))
{ 
$time = time(); 
$showtime = $update['update_time']; 
if($showtime <= $time) 
{ 
if(file_exists(SS_ROOT.'/thumbs/'.$update['iconid'].'.png')) 
{ 
$uicon = '<div class="listimg leftside"><img src="/siteuploads/thumb/'.$update['iconid'].'_1.jpg" /></div>'; 
} 
else 
{ 
$uicon = '<div class="listimg leftside"><img src="/assets/images/65-feed.jpg" /></div>'; 
} 
echo '<a href="'.$update['url'].'" class="listitem boxshadow"><div class="listdetail">'.$uicon.'<div class="list_title">'.$update['text'].'</div> 
<div class="list_desc"> <br> </div> 
</div> 
<div class="clear"></div> 
</a>'; 
}
}
echo'</section><div class="download-middle-advt">'; 
include_once('./assets/ads/afilelist.php'); 
echo'</div>';
echo '<!-- Nextwave Solutions :: End Latest Updates -->';
$url = "{$ss->settings['url']}/latest_updates/{$sort}";

$paging = pagination($page, $ss->settings['updates_per_page'], $total, $url); 
echo $paging; 
if($paging != '') 
{ 
echo '</div> 
<div class="jumptopage aligncenter"> 
<form method="get" action="/latest_updates"><input type="hidden" name="action" id="action" value="5" /><input type="hidden" name="sort" id="sort" value="'.$_GET['sort'].'" /><span class="jumpfrmlbl">Jump to Page</span> <input type="text" name="page" id="page" value="" class="jumpfrmtxt"/> <input type="submit" value="GO" class="jumpfrmbut bgcolor_main"/></form></div></section>';
}
}
echo'<div class="bottomadvt advertisment">'; 
include_once('./assets/ads/footer.php'); 
echo'</div>';
echo '<section class="breadcrumb"><a href="/">Home</a> &raquo;</section>';

include_once('./footer.php');
?>