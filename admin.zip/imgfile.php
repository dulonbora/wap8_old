<?php
define('IN_SS', true);
include_once('./inc/init.php');

$fid = $ss->get_input('id');

$query = $db->simple_select("files", "*", "fid={$fid}");
$file = $db->fetch_array($query);

if(!$file)
{
header('Location: '.$ss->settings['url'].'');
exit;
}

$db->query("UPDATE ".TABLE_PREFIX."files SET dcount=dcount+1 WHERE fid=".$file['fid']."");

$date = date("dmY", TIME_NOW);

$query = $db->simple_select("download_history", "did", "fid=".$file['fid']." AND date='{$date}'");
$count = $db->num_rows($query);

if($count != 0)
{
$db->query("UPDATE ".TABLE_PREFIX."download_history SET hits=hits+1 WHERE fid=".$file['fid']." AND date='{$date}'");
}
else
{
$db->insert_query("download_history", ['hits' => 1, 'fid'=>$fid, 'date'=>$date]);
}
$id = $_GET['id'];
$w = $_GET['w'];
$h = $_GET['h'];
$query = $db->simple_select("files", "fid, name, use_icon, path, description, isdir", "fid='{$id}'");
$file = $db->fetch_array($query);
$fname = $file['name'];
$fext = pathinfo($fname, PATHINFO_EXTENSION);
$fname = str_replace(' ', '_', $fname);
$fname = str_replace('.'.$fext.'', '', $fname);
header('Location: '.$ss->settings['dlserver'].'ifiles/'.$w.'x'.$h.'/'.$id.'/'.$fname.'('.$ss->settings['title'].').'.$fext.'');
?>