<?php
define('IN_SS', true);
include_once('./inc/init.php');


$folder['name'] = 'Home';
$folder['use_icon'] = 0;
$key = $ss->get_input('find');
$key = str_replace("_", " ", $key);
$key = ucwords($key);
$pid = $ss->get_input('pid', 1);
$page = isset($ss->input['page']) ? (int)$ss->input['page'] : 1;
$title = 'Your Search Result';
$total = 0;

if($pid == 0)
{
$where = '';
}
else
{
$where = 'pid='.$pid.' AND ';
}

include_once('./header.php');
include_once('./assets/ads/header.php');
include_once('./searchbox.php');
include_once('./assets/ads/bcategory.php');
echo '<h2>Your Search Result</h2>';
include_once('./assets/ads/acategory.php');
if($_GET['sort'] == 'default')
{
echo '<div class="list">
<div class="dtype">
<a href="/search/'.$_GET['find'].'/new2old/1.html">New 2 Old</a>&nbsp;|&nbsp;<a href="/search/'.$_GET['find'].'/download/1.html">Popular</a>&nbsp;|&nbsp;<a href="/search/'.$_GET['find'].'/a2z/1.html">A to Z</a>&nbsp;|&nbsp;<a href="/search/'.$_GET['find'].'/z2a/1.html">Z to A</a></div></div>';
}
if($_GET['sort'] == 'new2old')
{
echo '<div class="list">
<div class="dtype"><span>New 2 Old</span>&nbsp;|&nbsp;<a href="/search/'.$_GET['find'].'/download/1.html">Popular</a>&nbsp;|&nbsp;<a href="/search/'.$_GET['find'].'/a2z/1.html">A to Z</a>&nbsp;|&nbsp;<a href="/search/'.$_GET['find'].'/z2a/1.html">Z to A</a></div></div>';
}
if($_GET['sort'] == 'download')
{
echo '<div class="list">
<div class="dtype">
<a href="/search/'.$_GET['find'].'/new2old/1.html">New 2 Old</a>&nbsp;|&nbsp;<span>Popular</span>&nbsp;|&nbsp;<a href="/search/'.$_GET['find'].'/a2z/1.html">A to Z</a>&nbsp;|&nbsp;<a href="/search/'.$_GET['find'].'/z2a/1.html">Z to A</a></div></div>';
}
if($_GET['sort'] == 'a2z')
{
echo '<div class="list">
<div class="dtype">
<a href="/search/'.$_GET['find'].'/new2old/1.html">New 2 Old</a>&nbsp;|&nbsp;<a href="/search/'.$_GET['find'].'/download/1.html">Popular</a>&nbsp;|&nbsp;<span>A to Z</span>&nbsp;|&nbsp;<a href="/search/'.$_GET['find'].'/z2a/1.html">Z to A</a></div></div>';
}
if($_GET['sort'] == 'z2a')
{
echo '<div class="list">
<div class="dtype">
<a href="/search/'.$_GET['find'].'/new2old/1.html">New 2 Old</a>&nbsp;|&nbsp;<a href="/search/'.$_GET['find'].'/download/1.html">Popular</a>&nbsp;|&nbsp;<a href="/search/'.$_GET['find'].'/a2z/1.html">A to Z</a>&nbsp;|&nbsp;<span>Z to A</span></div></div>';
}
include_once('./assets/ads/bfilelist.php');
if(isset($ss->input['action']) && $ss->input['action'] == 'do_search')
{
echo'';
}
else
{
if(strlen($key) <= 1)
{
$errors[] = '';
}

if(empty($errors))
{
$search_words = explode(" ", $key);

foreach($search_words as $search_word)
{
$where1[] = "`name` LIKE '%$search_word%'";
$where2[] = "`description` LIKE '%$search_word%'";
}
$where_text = "(".implode("AND", $where1).") OR (".implode("AND", $where2).")";

$query = $db->simple_select("files", "fid", "{$where}{$where_text}");
$total = $db->num_rows($query);
}
else
{
show_errors($errors);
}
}
if($_GET['sort'] == 'new2old')
{
$order ='time DESC';
}
if($_GET['sort'] == 'default')
{
$order ='time ASC';
}
if($_GET['sort'] == 'download')
{
$order ='dcount DESC';
}
if($_GET['sort'] == 'a2z')
{
$order ='name ASC';
}
if($_GET['sort'] == 'z2a')
{
$order ='name DESC';
}
if($total > 0)
{
$start = ($page-1)*$ss->settings['files_per_page'];

$query = $db->simple_select("files", "fid, name, size, isdir, path, tag, dcount, description, time", "{$where}{$where_text}", ['order_by' => ''.$order.'', 'limit_start' => $start, 'limit' => $ss->settings['files_per_page']]);
echo'<!-- Nextwave Solutions :: Display File List -->';
while($file = $db->fetch_array($query))
{
if($file['isdir'] == 1)
{
$totalfolder ='0';
}
else
{
$strname = $ss->settings['title'];
$filename = str_replace("($strname)", "", escape($file['name']));
echo '<div class="fl odd"><a href="/download/'.$file['fid'].'/'.convert_name($file['name']).'.html" class="fileName"><div><div>';

if(file_exists(SS_ROOT.'/thumbs/'.$file['fid'].'.png'))
{
$ftitle = preg_replace('/\.[^.]+$/','', $filename);
echo '<img src="/siteuploads/thumb/'.$file['fid'].'_2.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_2"/>';
}
else if($folder['use_icon'] == 1 && file_exists(SS_ROOT.'/thumbs/'.$folder['fid'].'.png'))
{
echo '';
}
else 
{
echo '';
}

echo '</div><div>'.$filename.'';
$time = time();
$extime = strtotime("+15 days", $file['time']);
if($time <= $extime)
{
if($file['tag'] == 1)
{
echo ' '.ss_img('new.png', "New").'';
}
else if($file['tag'] == 2)
{
echo ' '.ss_img('updated.png', "Updated").'';
}
}
if(escape($file['description']) == '')
{
$singer = ''; 
}
else
{ 
$singer = '<br/><span class="ar">'.$file['description'].'</span>';
}
echo ''.$singer.'</span><br /><span>'.convert_filesize($file['size']).'</span> | <span>'.$file['dcount'].' Hits</span></div></div></a></div>';
}
echo '<!-- Nextwave Solutions :: End File List -->';
}
include_once('./assets/ads/afilelist.php');

$url = "/search/".$_GET['find']."/".$_GET['sort']."";
echo pagination($page, $ss->settings['files_per_page'], $total, $url);
echo '<form method="get" action="/search"><input type="hidden" name="action" id="action" value="3" /><input type="hidden" name="find" id="find" value="'.$_GET['find'].'" /><input type="hidden" name="sort" id="sort" value="'.$_GET['sort'].'" />Jump to Page <input type="text" name="page" id="page" value="" size="3" /><input type="submit" value="Go&raquo;" /></form></div>';
}
include_once('./assets/ads/footer.php');
echo '<div class="path"><a href="/">Home</a> &raquo;</div>';

include_once('./footer.php');