<?php
define('IN_SS', true);
include_once('./inc/init.php');
$fid = $ss->get_input('fid');

$query = $db->simple_select("files", "*", "fid={$fid}");
$file = $db->fetch_array($query);
$sname = $ss->settings['title'];
$filename = str_replace("($sname)", "", $file['name']);

if(!$file)
{
header('Location: '.$ss->settings['url'].'');
exit;
}

$input = SS_ROOT.$file['path'];
$info = pathinfo($input);

$db->query("UPDATE ".TABLE_PREFIX."files SET views=views +1 WHERE fid='".$file['fid']."'");
$album = file_get_contents('http://'.$_SERVER['HTTP_HOST'].'/inc/fname.php?id='.$file['pid'].'');

$title = ''.$filename.' - '.$album.' - Free Download';
include_once('./header.php');
include_once('./searchbox.php');
echo'<div class="topadvt advertisment">'; 
include_once('./assets/ads/header.php'); 
echo'</div>'; 
$query = $db->simple_select("files", "*", "fid='{$file['pid']}'");
$folder = $db->fetch_array($query);
echo '<section class="section_header aligncenter bgcolor_main remove_bottom_margin">Free Download '.$filename.'</section><section class="detailpage aligncenter">
<!-- Nextwave Solutions :: Display Download Link -->';

$dlstrname = $ss->settings['title']; 
$dlname = str_replace("($dlstrname)", "", escape($file['name'])); 
$dlext = pathinfo($dlname, PATHINFO_EXTENSION); 

if(file_exists(SS_ROOT.'/thumbs/'.$file['fid'].'.png'))
{
$ftitle = preg_replace('/\.[^.]+$/','', $dlname);
echo '<div class="detailimg "><img src="/siteuploads/thumb/'.$file['fid'].'_3.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_3"/></div><br/>';
}
else if($dlext == 'mp3') 
{ 
echo '<div class="detailimg "><img src="/assets/images/160-mp3.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_3"/></div><br/>'; 
} 

else if($dlext == 'mp4') 
{ 
echo '<div class="detailimg "> <img src="/assets/images/160-vid.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_3"/></div><br/>'; 
} 

else if($dlext == '3gp') 
{ 
echo '<div class="detailimg "><img src="/assets/images/160-vid.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_3"/></div><br/>'; 
} 
else if($dlext == 'avi') 
{ 
echo '<div class="detailimg "><img src="/assets/images/160-vid.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_3"/></div><br/>'; 
} 

else if($dlext == 'apk') 
{ 
echo '<div class="detailimg "><img src="/assets/images/160-apk.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_3"/></div><br/>'; 
} 
else if($dlext == 'zip') 
{ 
echo '<div class="detailimg "><img src="/assets/images/160-arch.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_3"/></div><br/>'; 
} 
else if($dlext == 'rar') 
{ 
echo '<div class="detailimg "><img src="/assets/images/160-arch.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_3"/></div><br/>'; 
} 
else if($dlext == '7z') 
{ 
echo '<div class="detailimg "><img src="/assets/images/160-arch.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_3"/></div><br/>'; 
} 
else if($dlext == 'jpg') 
{ 
echo'<div class="detailimg "><img src="/assets/images/160-img.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_3"/></div><br/>'; 
} 
else if($dlext == 'jpeg') 
{ 
echo '<div class="detailimg "><img src="/assets/images/160-img.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_3"/></div><br/>'; 
} 
else if($dlext == 'png') 
{ 
echo '<div class="detailimg "><img src="/assets/images/160-img.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_3"/></div><br/>'; 
} 

else if($dlext == 'gif') 
{ 
echo '<div class="detailimg "><img src="/assets/images/160-img.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_3"/></div><br/>'; 
} 
else if($dlext == 'jar') 
{ 
echo '<div class="detailimg "><img src="/assets/images/160-java.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_3"/></div><br/>'; 
} 

else if($dlext == 'jad') 
{ 
echo '<div class="detailimg "><img src="/assets/images/160-java.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_3"/></div><br/>'; 
} 
else 
{ 
echo '<div class="detailimg "><img src="/assets/images/160-doc.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_3"/></div><br/>'; 
}
echo'<div class="downloadtop advertisment">'; 
include_once('./assets/ads/bdown.php'); 
echo'</div>';
$query = $db->simple_select("files", "fid, name", "fid='{$file['pid']}'"); 
$folder = $db->fetch_array($query);

$sharebut = '<script type="text/javascript">var switchTo5x=true;</script>
<script type="text/javascript" id="st_insights_js" src="http://w.sharethis.com/button/buttons.js?publisher=6c6b3ee8-cb8f-46f8-af69-142f88d968e4"></script>
<script type="text/javascript">stLight.options({publisher: "6c6b3ee8-cb8f-46f8-af69-142f88d968e4", doNotHash: true, doNotCopy: true, hashAddressBar: true});</script><span class="st_sharethis_large" displayText="ShareThis"></span>
<span class="st_facebook_large" displayText="Facebook"></span>
<span class="st_twitter_large" displayText="Tweet"></span>
<span class="st_linkedin_large"  displayText="LinkedIn"></span>
<span class="st_pinterest_large" displayText="Pinterest"></span>
<span class="st_email_large" displayText="Email"></span> <div class="detailresolution">
<ul class="swtrow">
</ul></div>';
$fcat = '<span>Category: <a href="/fileList/'.escape($file['pid']).'/new2old/1.html">'.escape($folder['name']).'</a></span>';
$dwnlink = '<a class="downloadfile_but butpage bgcolor_main" href="/files/download/id/'.escape($file['fid']).'">Download File</a>';
$fsize ='<span>Size: ('.convert_filesize($file['size']).')</span>';
If($info['extension'] == 'jpeg')
{ 
echo'<div class="detaildesc">'; 
echo $fsize; 
echo '<br/>'; 
echo $fcat; 
echo '<br/><br/>'; 
echo'<div class="downloadtop advertisment">'; 
include_once('./assets/ads/adown.php'); 
echo'</div>'; 
echo $sharebut; 
echo'</div>'; 
echo'<div class="detailresolution"><ul class="swtrow">'; 
$wallString = $ss->settings['wallpaper_size'];
$wallArray = explode(',', $wallString); 
foreach($wallArray as $wall_Array) 
{ 
echo '<li class="swtcol6"><a href="/files/download/id/'.$file['fid'].'/size/'.$wall_Array.'">'.$wall_Array.'</a></li>'; 
} 
echo'</ul></div></div></section>'; 
} 
elseIf($info['extension'] == 'jpg')
{
echo'<div class="detaildesc">'; 
echo $fsize; 
echo '<br/>'; 
echo $fcat; 
echo '<br/><br/>';
echo'<div class="downloadtop advertisment">'; 
include_once('./assets/ads/adown.php'); 
echo'</div>'; 
echo $sharebut;
echo'</div>';
echo'<div class="detailresolution"><ul class="swtrow">';
$wallString = $ss->settings['wallpaper_size'];
$wallArray = explode(',', $wallString); 
foreach($wallArray as $wall_Array) 
{ 
echo '<li class="swtcol6"><a href="/files/download/id/'.$file['fid'].'/size/'.$wall_Array.'">'.$wall_Array.'</a></li>'; 
}
echo'</ul></div></div></section>';
}
else If($info['extension'] == 'png')
{
echo'<div class="detaildesc">'; 
echo $fsize; 
echo '<br/>'; 
echo $fcat; 
echo '<br/><br/>';
echo'<div class="downloadtop advertisment">'; 
include_once('./assets/ads/adown.php'); 
echo'</div>';
echo $sharebut;
echo'</div>';
echo'<div class="detailresolution"><ul class="swtrow">'; 
$wallString = $ss->settings['wallpaper_size'];
$wallArray = explode(',', $wallString); 
foreach($wallArray as $wall_Array) 
{ 
echo '<li class="swtcol6"><a href="/files/download/id/'.$file['fid'].'/size/'.$wall_Array.'">'.$wall_Array.'</a></li>'; 
} 
echo'</ul></div></div></section>'; 
}
else If($info['extension'] == 'mp4') 
{ 
echo '<br/>'; 
$output = "{$info['dirname']}/{$info['filename']}.3gp"; 
$output2 = "{$info['dirname']}/{$info['filename']}.{$info['extension']}"; 
$output3 = "{$info['dirname']}/{$info['filename']}_480p.{$info['extension']}"; 
$output4 = "{$info['dirname']}/{$info['filename']}_720p.{$info['extension']}"; 
$size1 = convert_filesize(filesize($output)); 
$size2 = convert_filesize(filesize($output2));
$size3 = convert_filesize(filesize($output3));
$size4 = convert_filesize(filesize($output4));
if(file_exists($output) || file_exists($output3) || file_exists($output4)) 
{ 

if(file_exists($output)) 
{ 
$output = str_replace(SS_ROOT, '', $output); 
echo '<a href="/files/download/id/'.escape($file['fid']).'/type/3GP" class="gp3button downloadfile_but butpage bgcolor_main">3GP - '.$size1.'</a>'; 
} 

if(file_exists($output2)) 
{ 
$output2 = str_replace(SS_ROOT, '', $output2); 

echo '<a href="/files/download/id/'.escape($file['fid']).'" class="mp4button downloadfile_but butpage bgcolor_main">MP4 - '.$size2.'</a>'; 
} 

if(file_exists($output3)) 
{ 
$output3 = str_replace(SS_ROOT, '', $output3); 

echo '<a href="/files/download/id/'.escape($file['fid']).'/type/HD" class="hdbutton downloadfile_but butpage bgcolor_main">HD - '.$size3.'</a>'; 
} 
if(file_exists($output4)) 
{ 
$output4 = str_replace(SS_ROOT, '', $output4); 
echo '<a href="/files/download/id/'.escape($file['fid']).'/type/FHD" class="fullhdbutton downloadfile_but butpage bgcolor_main">Full HD - '.$size4.'</a>'; 
} 
echo'<div class="detaildesc">';
echo $fcat; 
echo '<br/><br/>'; 
echo'<div class="downloadtop advertisment">'; 
include_once('./assets/ads/adown.php'); 
echo'</div>';
echo $sharebut; 
echo'</div></div></section>';
} else 
{ 
echo $dwnlink; 
echo'<div class="detaildesc">'; 
echo $fsize; 
echo '<br/>'; 
echo $fcat; 
echo '<br/><br/>';
echo'<div class="downloadtop advertisment">'; 
include_once('./assets/ads/adown.php'); 
echo'</div>';
echo $sharebut; 
echo'</div></div></section>';
}
} 
else If($info['extension'] == 'mp3')
{
echo '<br/><audio src="'.$ss->settings['url'].'/files/download/id/'.$file[fid].'" controls></audio><br/>';
$output = "{$info['dirname']}/{$info['filename']}_64.{$info['extension']}";
$output2 = "{$info['dirname']}/{$info['filename']}.{$info['extension']}";
$output3 = "{$info['dirname']}/{$info['filename']}_192.{$info['extension']}"; 
$output4 = "{$info['dirname']}/{$info['filename']}_320.{$info['extension']}";
$size1 = convert_filesize(filesize($output));
$size2 = convert_filesize(filesize($output2));
$size3 = convert_filesize(filesize($output3));
$size4 = convert_filesize(filesize($output4));
if(file_exists($output) || file_exists($output3) || file_exists($output4))
{

if(file_exists($output))
{
$output = str_replace(SS_ROOT, '', $output);
echo '<a href="/files/download/type/64/id/'.escape($file['fid']).'" class="gp3button downloadfile_but butpage bgcolor_main">64 KBPS - '.$size1.'</a>';
}

if(file_exists($output2))
{
$output2 = str_replace(SS_ROOT, '', $output2);

echo '<a href="/files/download/id/'.escape($file['fid']).'" class="mp4button downloadfile_but butpage bgcolor_main">128 KBPS - '.$size2.'</a>';
}

if(file_exists($output3))
{
$output3 = str_replace(SS_ROOT, '', $output3);

echo '<a href="/files/download/type/192/id/'.escape($file['fid']).'" class="hdbutton downloadfile_but butpage bgcolor_main">192 KBPS - '.$size3.'</a>';
}
if(file_exists($output4)) 
{ 
$output4 = str_replace(SS_ROOT, '', $output4); 

echo '<a href="/files/download/type/320/id/'.escape($file['fid']).'" class="fullhdbutton downloadfile_but butpage bgcolor_main">320 KBPS - '.$size4.'</a>'; 
}
echo'<div class="detaildesc">';
echo $fcat;
echo '<br/><br/>';
echo'<div class="downloadtop advertisment">'; 
include_once('./assets/ads/adown.php'); 
echo'</div>';
echo $sharebut;
echo'</div></div></section>';
if(escape($file['description'])) 
{ 
echo '<section class="section_header aligncenter bgcolor_main remove_bottom_margin">Artist</section><section class="item_list categories_list">'; 
$myString = escape($file['description']); $myString = str_replace(", ", ",", $myString); 
$myArray = explode(',', $myString); 
foreach($myArray as $my_Array) 
{ 
$singer = str_replace(" ", "_", $my_Array); 
$singer = strtolower($singer); 
echo '<a class="listitem boxshadow" href="/singer/'.$singer.'/new2old/1.html"><div class="clear"></div><div class="listdetail"><div class="listimg leftside"><img src="/assets/images/65-artist.jpg" /></div> <div class="list_title"> 
'.$my_Array.'</div><div class="list_desc"><br/>Play All Songs</div></div><div class="clear"></div></a>'; 
} 
echo '</section>';
} 
} 
else 
{ 
echo $dwnlink; 
echo'<div class="detaildesc">'; 
echo $fsize;
echo '<br/>';
echo $fcat; 
echo '<br/><br/>';
echo'<div class="downloadtop advertisment">'; 
include_once('./assets/ads/adown.php'); 
echo'</div>';
echo $sharebut; 
echo'</div></div></section>'; 
if(escape($file['description'])) 
{ 
echo '<section class="section_header aligncenter bgcolor_main remove_bottom_margin">Artist</section><section class="item_list categories_list">'; 
$myString = escape($file['description']); $myString = str_replace(", ", ",", $myString); 
$myArray = explode(',', $myString); 
foreach($myArray as $my_Array) 
{ 
$singer = str_replace(" ", "_", $my_Array); 
$singer = strtolower($singer); 
echo '<a class="listitem boxshadow" href="/singer/'.$singer.'/new2old/1.html"><div class="clear"></div><div class="listdetail"><div class="listimg leftside"><img src="/assets/images/65-artist.jpg" /></div> <div class="list_title"> 
'.$my_Array.'</div><div class="list_desc"><br/>Play All Songs</div></div><div class="clear"></div></a>'; 
} 
echo '</section>'; 
} 
} 
}
else
{ 
echo '<br/>';
echo $dwnlink;
echo'<div class="detaildesc">'; 
echo $fsize;
echo '<br/>';
echo $fcat;
echo '<br/><br/>';
echo'<div class="downloadtop advertisment">'; 
include_once('./assets/ads/adown.php'); 
echo'</div>';
echo $sharebut;
echo'</div></div></section>';
}
echo'<!-- Nextwave Solutions :: End Download Link -->'; 
if($ss->settings['related_files']){echo '<section class="section_header aligncenter bgcolor_main remove_bottom_margin">Related Files</section>';$rsort = array('dcount DESC', 'dcount ASC', 'fid DESC', 'fid ASC', 'name DESC', 'name ASC', 'time DESC', 'time ASC');$srsort = $rsort[rand(0, count($rsort)-1)];$options = ['order_by' => ''.$srsort.'', 'limit' => $ss->settings['related_files_per_page']];echo '<!-- Nextwave Solutions :: Display Related List -->';$query = $db->simple_select("files", "fid, name, tag, size, path, dcount, description, time", "pid='{$file['pid']}' AND isdir='0'", $options);while($rfile = $db->fetch_array($query)){ $strname = $ss->settings['title']; $filename = str_replace("($strname)", "", escape($rfile['name'])); $fext = pathinfo($filename, PATHINFO_EXTENSION); 
$ftitle = preg_replace('/\.[^.]+$/','', $filename); if(file_exists(SS_ROOT.'/thumbs/'.$rfile['fid'].'.png')) { $filethumb = '<div class="listimg leftside"><img src="/siteuploads/thumb/'.$rfile['fid'].'_1.jpg" title="'.$ftitle.'" alt="'.$rfile['fid'].'_1"/></div>'; 
} 
else if($fext == 'mp3') { $filethumb = '<div class="listimg leftside"><img src="/assets/images/65-mp3.jpg" title="'.$ftitle.'" alt="'.$rfile['fid'].'_1"/></div>'; } 
else if($fext == 'mp4') { 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-vid.jpg" title="'.$ftitle.'" alt="'.$rfile['fid'].'_1"/></div>'; 
} 

else if($fext == '3gp') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-vid.jpg" title="'.$ftitle.'" alt="'.$rfile['fid'].'_1"/></div>'; 
} 
else if($fext == 'avi') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-vid.jpg" title="'.$ftitle.'" alt="'.$rfile['fid'].'_1"/></div>'; 
} 

else if($fext == 'apk') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-apk.jpg" title="'.$ftitle.'" alt="'.$rfile['fid'].'_1"/></div>'; 
} 
else if($fext == 'zip') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-arch.jpg" title="'.$ftitle.'" alt="'.$rfile['fid'].'_1"/></div>'; 
} 
else if($fext == 'rar') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-arch.jpg" title="'.$ftitle.'" alt="'.$rfile['fid'].'_1"/></div>'; 
} 
else if($fext == '7z') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-arch.jpg" title="'.$ftitle.'" alt="'.$rfile['fid'].'_1"/></div>'; 
} 
else if($fext == 'jpg') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-img.jpg" title="'.$ftitle.'" alt="'.$rfile['fid'].'_1"/></div>'; 
} 
else if($fext == 'jpeg') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-img.jpg" title="'.$ftitle.'" alt="'.$rfile['fid'].'_1"/></div>'; 
} 
else if($fext == 'png') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-img.jpg" title="'.$ftitle.'" alt="'.$rfile['fid'].'_1"/></div>'; }
else if($fext == 'gif') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-img.jpg" title="'.$ftitle.'" alt="'.$rfile['fid'].'_1"/></div>'; 
} 
else if($fext == 'jar') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-java.jpg" title="'.$ftitle.'" alt="'.$rfile['fid'].'_1"/></div>'; 
} 

else if($fext == 'jad') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-java.jpg" title="'.$ftitle.'" alt="'.$rfile['fid'].'_1"/></div>'; 
} 
else 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-doc.jpg" title="'.$ftitle.'" alt="'.$rfile['fid'].'_1"/></div>'; 
} 
if(escape($rfile['description']) == ''){ 
$rsinger = ''; }else 
{ 
$rsinger = ''.$rfile['description'].''; 
} 

echo '<section class="item_list"><a href="/download/'.$rfile['fid'].'/'.convert_name($rfile['name']).'.html" class="listitem boxshadow"><div class="listdetail">'.$filethumb.'<div class="list_title">'.$filename.'</div><div class="list_desc">'.$rsinger.'<br/>'.convert_filesize($rfile['size']).'&nbsp;&nbsp;&nbsp;<span class="download-icon"> '.$rfile['dcount'].'</span></div>'; 
echo '</div> <div class="clear"></div> </a></section>'; 
} 
echo'<!-- Nextwave Solutions :: End Related List -->'; 
} 

$_dr = ''; 
$blink = $_SERVER['HTTP_REFERER']; 
echo '</div>'; 
echo'<div class="bottomadvt advertisment">'; 
include_once('./assets/ads/footer.php'); 
echo'</div>'; 
echo '<section class="breadcrumb"><a href="/">Home</a>'; 

foreach(explode('/', substr($file['path'], 7)) as $dr) 
{ 
$_dr .= "/".$dr;$path = "/files{$_dr}";$query = $db->simple_select("files", "fid, name, pageurl", "path='".$db->escape_string($path)."'");$id = $db->fetch_array($query);$iname = str_replace("('.$ss->settings['title'].')", "", escape($id['name']));if($fid == $id['fid']) 
{ 
echo ''; 
} 
else 
{ 
echo ' &raquo; <a href="/'.$id['pageurl'].'/'.$id['fid'].'/'.$ss->settings['sort'].'/1.html">'.escape($id['name']).'</a>'; 
} 
} echo '</section>'; include_once('./footer.php'); ?>