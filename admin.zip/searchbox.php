<?php
if($ss->settings['show_searchbox'])
{
echo '<section class="search_section aligncenter bgcolor_main"> 
<form method="get" action="/jump.php" id="searchfrm"><input type="text" name="find" id="find"  class="searchfrmtxt" placeholder="Search Here" value=""/>

<select name="commit" class="searchfrmext"> 
<option value="Search">Files</option> 
<option value="Album">Album</option> 
<option value="Singer">Singer</option> 
</select>
<input type="submit" class="searchfrmbut bgcolor_main" value="Submit" /></form></section>';
}
include_once('./dropdown.php');
if($pid != 0) 
{ 
echo'<div class="topadvt advertisment">';
include_once('./assets/ads/header.php');
echo'</div>';
} 
?>