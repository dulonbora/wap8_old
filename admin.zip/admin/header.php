<?php
error_reporting(0);
if(empty($title))
{
$title = $ss->settings['title'];
}
else
{
$title .= " - {$ss->settings['title']}";
}

$title = escape($title);

echo '<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="title" content="'.$ss->settings['title'].' :: '.$title.'" />
<meta name="robots" content="index, follow" />
<meta name="language" content="en" />
<meta content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;" name="viewport" />
<meta name="viewport" content="width=device-width" />
<title>'.$title.'</title>
<link href="/assets/images/favicon.png" rel="shortcut icon"/>
<link href="/assets/css/apanel.css" type="text/css" rel="stylesheet"/>
</head>
<body>
<div class="logo"><a href="/"><img alt="'.$site.'" src="'.$ss->settings['logo'].'" /></a></div>';
?>