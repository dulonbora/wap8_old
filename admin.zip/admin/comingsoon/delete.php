<?php
define('IN_SS', true);
include("../inc/init.php");
if($ss->settings['show_ipblocker'])
{
include_once('../iplist.php');
if(!in_array($_SERVER['REMOTE_ADDR'], $safelist)) 
{
header('Location: '.$ss->settings['url'].'');
exit;
}
}
if(!is_admin())
{
header('Location: '.$ss->settings['url'].'');
exit;
}

$cid = $ss->get_input('cid', 1);

if(isset($ss->input['action']) && $ss->input['action'] == 'do_delete' && $ss->request_method == 'post')
{
$query = $db->delete_query("comingsoon", "cid='{$cid}'");

header('Location: '.$ss->settings['adminurl'].'/comingsoon/index.php');
exit;
}

$query = $db->simple_select("comingsoon", "cid", "cid='{$cid}'");
$total = $db->num_rows($query);

if($total == 0)
{
header('Location: '.$ss->settings['adminurl'].'');
exit;
}

$title = 'Delete Upcoming Item';
include_once('../header.php');

echo '<div class="top">Wrong item found? Dont worry, just delete them!</div>';
include_once('../time.php');
echo'<h2>Delete Upoming Item</h2>
<div class="toptitle">
<form method="post" action="#">
<div>Do you want to delete this upcoming item?</div>
<div><input type="hidden" name="action" value="do_delete" />
<input type="submit" value="Delete" /> <a href="'.$ss->settings['adminurl'].'/comingsoon/index.php">No</a></div>
</form>
</div>';

echo '<div class="path"><a href="'.$ss->settings['url'].'">Home</a> &raquo; <a href="'.$ss->settings['adminurl'].'">Admin Panel</a> &raquo; <a href="'.$ss->settings['adminurl'].'/comingsoon">Upcoming Manager</a></div>';

include_once('../footer.php');