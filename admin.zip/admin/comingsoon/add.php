<?php
define('IN_SS', true);
include_once("../inc/init.php");
if($ss->settings['show_ipblocker'])
{
include_once('../iplist.php');
if(!in_array($_SERVER['REMOTE_ADDR'], $safelist)) 
{
header('Location: '.$ss->settings['url'].'');
exit;
}
}
if(!is_admin())
{
header('Location: '.$ss->settings['url'].'');
exit;
}

$message = '';
$title = 'Add Upcoming Item';

if(isset($ss->input['action']) && $ss->input['action'] == 'do_add' && $ss->request_method == 'post')
{
$description = $ss->get_input('description');
$status = $ss->get_input('status');

if($status != 'A')
{
$status = 'D';
}

if(!empty($description))
{
$data = ['description' => $db->escape_string($description), 'created_at' => TIME_NOW, 'status' => $status];

$db->insert_query("comingsoon", $data);

$message = 'Upoming Item added successfully!';

header('Location: '.$ss->settings['adminurl'].'/comingsoon/index.php');
}
else
{
$message = 'Please enter html code!';
}
}

include_once('../header.php');

echo '<div class="top">Here you can add a new upcoming item for your site!</div>';
include_once('../time.php');
echo'<h2>Add Upcoming Item</h2>';

if(!empty($message))
{
echo '<div class="toptitle">'.$message.'</div>';
}

echo '<div class="toptitle">
<form method="post" action="#">
<div>HTML Code:</div>
<div><textarea name="description"></textarea></div>
<div><input type="checkbox" name="status" value="A" checked /> Active (Show on Index)?</div>
<div><input type="hidden" name="action" value="do_add" />
<input type="submit" value="Add" /></div>
</form>
</div>';

echo '<div class="path"><a href="'.$ss->settings['url'].'">Home</a> &raquo; <a href="'.$ss->settings['adminurl'].'">Admin Panel</a> &raquo; <a href="'.$ss->settings['adminurl'].'/comingsoon">Upcoming Manager</a></div>';

include_once('../footer.php');