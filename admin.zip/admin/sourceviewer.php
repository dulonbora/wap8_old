<?php
define('IN_SS', true);
include('./inc/init.php');

if(!is_admin())
{
header('Location: '.$ss->settings['url'].'');
exit;
}

$title = 'HTML Source Viewer';
include('./header.php');
echo '<div class="top">Here you can check html source codes from any site!</div>';
include_once('./time.php');
echo'<h2>HTML Source Viewer</h2><div class="toptitle"><form action="'.$_SERVER['PHP SELF'].'" method="get"><div>Source Url:</div><div>
<input type="text" name="url" value="http://"/></div><div>
<input type="submit" value="View" />
</div>
</form></div>';
if(isset($_GET['url']) && substr($_GET['url'],0,7) == 'http://')
{
$source = file_get_contents($_GET['url']);
echo '<h2>Source Code</h2><div class="toptitle">'.htmlspecialchars($source).'</div><h2>Copy From Below</h2><div class="toptitle"><textarea>'.htmlspecialchars($source).'</textarea></div>';
}
echo '<div class="path"><a href="/">Home</a> &raquo; <a href="/admin">Admin Panel</a></div>';
include_once("footer.php");
?>