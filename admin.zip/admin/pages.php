<?php
define('IN_SS', true);
include_once("./inc/init.php");
if($ss->settings['show_ipblocker'])
{
include_once('./iplist.php');
if(!in_array($_SERVER['REMOTE_ADDR'], $safelist)) 
{
header('Location: '.$ss->settings['url'].'');
exit;
}
}
if(!is_admin())
{
header('Location: '.$ss->settings['url'].'');
exit;
}

$title = 'Pages Manager';
$message = '';

include_once('./header.php');

echo '<div class="top">Here you can manage your page codes easily!</div>';
include_once('./time.php');
echo'<h2>Pages Manager</h2>';

$file = $ss->get_input('file');

if(!empty($file))
{
$ad = SS_ROOT.'assets/includes/'.$file.'.php';

if(isset($ss->input['action']) && $ss->input['action'] == 'do_save' && $ss->request_method == 'post')
{
$fp = fopen($ad, 'w');
fwrite($fp, $ss->input['description']);
$message = 'Page updated successfully!';
}

// Read Code
$fp = fopen($ad, 'r');
$filesize = filesize($ad);

if($filesize > 0)
{
$content = fread($fp, $filesize);
}
else
{
$content = '';
}
fclose($fp);

if(!empty($message))
{
echo '<div class="toptitle">'.$message.'</div>';
}
echo '<div class="toptitle">
<form method="post" action="#">
<div><textarea name="description">'.htmlentities($content).'</textarea></div>
<div><input type="hidden" name="action" value="do_save" />
<input type="submit" value="Update" /></div>
</form>
</div>';
}
else
{
$links = [['value' => 'header', 'title' => 'Header'], ['value' => 'footer', 'title' => 'Footer'], ['value' => 'headtag', 'title' => 'Head Tag'], ['value' => 'disclaimer', 'title' => 'Disclaimer'], ['value' => 'online', 'title' => 'Online Counter'], ['value' => 'gcustom', 'title' => 'Google Custom Search']];

foreach($links as $link)
{
echo '<div class="catRowHome"><a href="?file='.$link['value'].'">'.$link['title'].'</a></div>';
}

}

echo '<div class="path"><a href="/">Home</a> &raquo; <a href="'.$settings['adminurl'].'">Admin Panel</a></div>';

include_once('./footer.php');