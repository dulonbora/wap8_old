<?php
date_default_timezone_set('Asia/Calcutta'); 
$hour = date('H', time()); 
if($hour > 5 && $hour <= 11) 
{
echo "<div class='top'>Good morning admin, have a great day ahead!</div>"; 
} 
else if($hour > 11 && $hour <= 16) 
{
echo "<div class='top'>Good afternoon admin, i'm happy to see you again!</div>"; } 
else if($hour > 16 && $hour <= 20) 
{
echo "<div class='top'>Good evening admin, let's keep up the good work!</div>"; 
} 
else 
{
echo "<div class='top'>Good night admin, have a sweet dream!</div></div>"; 
}
include_once('./time.php');
echo '<h2>Admin Menu</h2>
<div class="catRow"><a href="settings">Settings Manager</a></div>
<div class="catRow"><a href="updates">Updates Manager</a></div>
<div class="catRow"><a href="comingsoon">Upcoming Manager</a></div>
<div class="catRow"><a href="ads.php">Ads Manager</a></div><div class="catRow"><a href="codes">Codes Manager</a></div><div class="catRow"><a href="pages.php">Pages Manager</a></div>
<div class="catRow"><a href="files">File Manager</a></div><h2>Useful Tools</h2><div class="catRow"><a href="scan.php">Scan Folder</a></div><div class="catRow"><a href="ping.php">Ping Your Sitemap</a></div><div class="catRow"><a href="sourceviewer.php">HTML Source Viewer</a></div><div class="catRow"><a href="watermark">Online Image Editor</a></div>
<h2>Navigation</h2>
<div class="catRow"><a href="settings/change.php">Change Password</a></div>
<div class="catRow"><a href="logout.php">Logout ('.$_SERVER['REMOTE_ADDR'].')</a></div><div class="pgn">';
include_once('../assets/includes/online.php');
echo'</div>';
?>