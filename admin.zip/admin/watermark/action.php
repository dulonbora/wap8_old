<?php
ob_start();
error_reporting(0);
$folder ="temp_datas";
$rec_file = $_POST['file'];
$fname2 = @end(@explode("/",$rec_file));
$rand = rand(1000, 10000);
$fname = $rand."_".$fname2;
if($_POST['ch']=="watermark")
{
$r = @$_POST['act'];
if($r=='wimage')
{
$wimage = $fname;
$ext = strtolower(@array_pop(@explode(".",$wimage)));
if(in_array($ext,array("jpeg","jpg","gif","png")))
{
$string = (rand(1000,10000));
$img = $folder."/".$fname;
copy($rec_file,$img);
//image file path

//watermark position
$p = @$_POST['align']; if(!$p) $p = 'br';
/*
p can be anything from the following list:
tl = top left
tc = top center
tr = top right
cl = center left
c = center of the image
cr = center right
bl = bottom left
bc = bottom center
br = bottom right
*/
//watermarked image quality
$q = @$_GET['q'];
//if the quality field is missing or is not on the 0 to 100 scale then we set the quality to 93
if(!$q || $q<0 || $q>100) $q = '100';
$filetype = substr($img,strlen($img)-4,4);
$filetype = strtolower($filetype);
if($filetype == ".gif") $image = @imagecreatefromgif($img);
if($filetype == ".jpg") $image = @imagecreatefromjpeg($img);
if($filetype == ".png") $image = @imagecreatefrompng($img);
if (!$image) die();
//getting the image size for the original image
$img_w = imagesx($image);
$img_h = imagesy($image);
//if the filename has 150x150 in it's name then we don't apply the watermark
if (preg_match("/150x150/", $img)) {
    imagejpeg($image, null, $q); die();
} else {
if(strtolower(@end(@explode(".",$_FILES['wimg']['name'])))=="png")

{
move_uploaded_file($_FILES['wimg']['tmp_name'],"wimg/".$_FILES['wimg']['name']);
    $watermark = @imagecreatefrompng("wimg/".$_FILES['wimg']['name']);
    }
    else die('Only png watermark files are allowed');
}
/*
//if you want to use the watermark only on bigger images then use this instead of the condition above
if ($img_w < "150") {//if image width is less then 150 pixels
    imagejpeg($image, null, $q); die();
} else {
    $watermark = @imagecreatefrompng('watermark.png');
}
*/
//getting the image size for the watermark
$w_w = imagesx($watermark);
$w_h = imagesy($watermark);

if($p == "tl") {
    $dest_x = 0;
    $dest_y = 0;
} elseif ($p == "tc") {
    $dest_x = ($img_w - $w_w)/2;
    $dest_y = 0;
} elseif ($p == "tr") {
    $dest_x = $img_w - $w_w;
    $dest_y = 0;
} elseif ($p == "cl") {
    $dest_x = 0;
    $dest_y = ($img_h - $w_h)/2;
} elseif ($p == "c") {
    $dest_x = ($img_w - $w_w)/2;
    $dest_y = ($img_h - $w_h)/2;
} elseif ($p == "cr") {
    $dest_x = $img_w - $w_w;
    $dest_y = ($img_h - $w_h)/2;
} elseif ($p == "bl") {
    $dest_x = 0;
    $dest_y = $img_h - $w_h;
} elseif ($p == "bc") {
    $dest_x = ($img_w - $w_w)/2;
    $dest_y = $img_h - $w_h;
} elseif ($p == "br") {
    $dest_x = $img_w - $w_w;
    $dest_y = $img_h - $w_h;
}

imagecopy($image, $watermark, $dest_x, $dest_y, 1, 1, $w_w, $w_h);

imagejpeg($image, $img, $q);
header('location:'.$img.'');
}
}
if($r=='text')
{
error_reporting(E_ALL);
function getPos ($text,$file,$sourcefile_width, $sourcefile_height, $pos, $wm_image = "") { 
include 'config.php';
$src_image_name = $file; // input image file name (must contain the path name) 

$ext = strtolower(@array_pop(@explode('.',$file)));

switch($ext)
{
case 'jpeg':
$src_image = imagecreatefromjpeg($src_image_name);
break;
case 'jpg':
$src_image = imagecreatefromjpeg($src_image_name);
break;
case 'gif':
$src_image = imagecreatefromgif($src_image_name);
break;
case 'png':
$src_image = imagecreatefrompng($src_image_name);
default:
$src_image = imagecreatefromjpeg($src_image_name);
}

$jpeg_quality = 100; // jpeg picture quality 
$save_image_file =''; // output file name 
$wm_image_pos = $pos; // watermark image placed 
// 0 = middle 
// 1 = top left 
// 2 = top right 
// 3 = bottom right 
// 4 = bottom left 
// 5 = top middle 
// 6 = middle right 
// 7 = bottom middle 
// 8 = middle left 
// Other = 3 
$wm_image_transition = 20; // the degree of integration of the watermark image with the original pictures (1 = 100) 

$wm_text = $text; // watermark text (in English as well as with the / r / n interbank text) 
$wm_text_size = $size; // watermark text size 
$wm_angle = 0; // angle of the watermark text, this value is try not to change 
$wm_text_pos = $pos; // watermark text placement 
$wm_text_font = $font; // watermark text font 
$wm_text_color = "#f2f2f2"; // watermark font color values 


$lineCount = explode ("/r/n", $wm_text); 

$fontSize = imagettfbbox ($wm_text_size, $wm_angle, $wm_text_font, $wm_text); 
$insertfile_width = $fontSize [2] - $fontSize [0]; 
$insertfile_height = count ($lineCount) * ($fontSize [1] - $fontSize [3]); 


switch ($pos) { 
case 'c': 
$Dest_x = ($sourcefile_width / 2) - ($insertfile_width / 2); 
$Dest_y = ($sourcefile_height / 2) - ($insertfile_height / 2); 
break; 

case 'tl': 
$Dest_x = 0; 
$Dest_y = $wm_text_size*2; 
 
break; 

case 'tr': 
$Dest_x = $sourcefile_width - $insertfile_width; 
$Dest_y = $wm_text_size*2; 
break; 

case 'br': 
$Dest_x = $sourcefile_width - $insertfile_width; 
$Dest_y = $sourcefile_height - $insertfile_height; 
break; 

case 'bl': 
$Dest_x = 0; 
$Dest_y = $sourcefile_height - $insertfile_height; 
break; 

case 5: 
$Dest_x = (($sourcefile_width- $insertfile_width) / 2); 
$Dest_y = $insertfile_height; 
break; 

case 6: 
$Dest_x = $sourcefile_width - $insertfile_width; 
$Dest_y = ($sourcefile_height / 2) - ($insertfile_height / 2); 
break; 
case 7: 
$dest_x = (($sourcefile_width- $insertfile_width) / 2); 
$Dest_y = $sourcefile_height - $insertfile_height; 
break; 

case 8: 
$Dest_x = 0; 
$Dest_y = ($sourcefile_height / 2) - ($insertfile_height / 2); 
break; 

default: 
$Dest_x = $sourcefile_width - $insertfile_width; 
$Dest_y = $sourcefile_height - $insertfile_height; 
break; 
} 


$wm_text_x = $Dest_x; 
$wm_text_y = $Dest_y; 

$wm_text_color = imagecolorallocate ($src_image, $color[0],$color[1],$color[2]); 
function imagettfstroketext(&$image,$size,$angle,$x,$y, &$textcolor, &$strokecolor,$fontfile,$text,$px) {
for ($c1= ($x-abs($px));$c1<= ($x+abs($px));$c1++)
for ($c2= ($y-abs($px));$c2<= ($y+abs($px));$c2++)
$bg = imagettftext($image,$size,$angle,$c1,$c2,$strokecolor,$fontfile,$text);
return imagettftext($image,$size,$angle,$x,$y,$textcolor,$fontfile,$text);
}
$black = imagecolorallocate($src_image,0,0,0);
imagettfstroketext($src_image,$wm_text_size,$wm_angle,$wm_text_x,$wm_text_y,$wm_text_color,$black,$wm_text_font,$wm_text,1);

imagepng($src_image,$file);
header('location:'.$file.'');
} 
copy($rec_file,$folder."/".$fname);
$file = $folder."/".$fname;
$h = imagecreatefromjpeg($file);
$w = imagesx($h);
$h = imagesy($h);

getPos($_POST['text'],$file,$w,$h,$_POST['align']);

}
}
else
{
$rand = (rand(1000,10000));
$filename = $folder."/".$fname;

$ext = strtolower(@end(@explode('.',$filename)));
if(in_array($ext,array('jpeg','jpg','png','gif')))
{
copy($rec_file,$filename);
// Get new sizes
list($width, $height) = getimagesize($filename);
$newwidth = empty($_POST['w'])?50:intval($_POST['w']);
$newheight = empty($_POST['h'])?50:intval($_POST['h']);

// Load
$thumb = imagecreatetruecolor($newwidth, $newheight);

switch($ext)
{
case 'jpeg':
$source = imagecreatefromjpeg($filename);
break;
case 'jpg':
$source = imagecreatefromjpeg($filename);
break;
case 'gif':
$source = imagecreatefromgif($filename);
break;
case 'png':
$source = imagecreatefrompng($filename);
default:
$source = imagecreatefromjpeg($filename);
}

// Resize
imagecopyresampled($thumb, $source, 0, 0, 0, 0, $newwidth, $newheight, $width, $height);

// Output
imagepng($thumb,$filename);
header('location:'.$filename.'');
}

}
ob_flush();
?>