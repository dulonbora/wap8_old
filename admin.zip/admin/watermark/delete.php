<?php
$dir = "temp_datas";
array_map('unlink', glob($dir."/*"));
mkdir($dir,0755);
$dir2 = "wimg";
array_map('unlink', glob($dir2."/*"));
mkdir($dir2,0755);
{
echo 'Previous files has been deleted!';
}
?>