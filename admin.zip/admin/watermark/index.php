<?php
define('IN_SS', true);
include('../inc/init.php');
if($ss->settings['show_ipblocker'])
{
include_once('../iplist.php');
if(!in_array($_SERVER['REMOTE_ADDR'], $safelist)) 
{
header('Location: '.$ss->settings['url'].'');
exit;
}
}
if(!is_admin())
{
header('Location: '.$ss->settings['url'].'');
exit;
}

$title = 'Online Image Editor';
include('../header.php');

echo '<div class="top">Online image editor tool to watermark or resize your images easily!</div>';
include_once('../time.php');
echo'<h2>Watermark Image</h2><form method="post" id="form" action="action.php" enctype="multipart/form-data"><div class="toptitle"><div>Image Url:</div><div>
<input type="text" name="file" id="uploadForm" value="http://"/></div></div><div class="toptitle"><div>
Choose Action:</div><div><input id="ch1" type="radio" name="ch" value="watermark" checked/> Watermark <input type="radio" id="ch2" name="ch" value="resize"/> Resize</div></div><div class="toptitle"><div>Watermark Text:</div><div>
<input type="text" value="" name="text"/></div></div><div class="toptitle"><div>Watermark Logo:</div><div><input type="file" name="wimg"/></div></div>
<div class="toptitle"><div>Watermark Type:</div> <div><input type="radio" id="act1" value="wimage" name="act" checked/> Image
<input type="radio" id="act" value="text" name="act" /> Text</div></div><div class="toptitle"><div>Watermark Position:</div> <div><select name="align">
<option value="c">Centre</option>
<option value="tl">Top-Left</option>
<option value="tr">Top-Right</option>
<option value="bl">Bottom-Left</option>
<option value="br">Bottom-Right</option>
</select></div></div><div class="toptitle"><div>Watermark Size:</div><div><input type="text" name="size" value="15"/></div></div><div class="toptitle"><div>Watermark Color:</div><div>R <input name="r" type="text" size="3" value="204"/> G <input name="g" type="text" size="3" value="204"/> B <input name="b" type="text" size="3" value="204"/></div></div><h2>Resize Image</h2><div class="toptitle"><div>Image Size:</div><div>Width <input name="w" type="text" size="3" /> Height <input name="h" type="text" size="3" /></div></div>
<div class="toptitle"><input type="submit" value="Upload" /></div></form>';
echo '<div class="pgn"><a href="delete.php">Delete Previous Files</a></div><div class="path"><a href="'.$ss->settings['url'].'">Home</a> &raquo; <a href="'.$ss->settings['adminurl'].'">Admin Panel</a></div>';
include_once('../footer.php');
?>