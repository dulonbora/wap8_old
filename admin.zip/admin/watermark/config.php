<?php
define('IN_SS', true);

$color = array();
$font = 'audiowide.ttf'; // in TTF file
$color[0] = $_POST['r']; // RED in RGB
$color[1] = $_POST['g']; // GREEN in RGB
$color[2] = $_POST['b']; // BLUE in RGB
$size = $_POST['size']; // in pixels

?>