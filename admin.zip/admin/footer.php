<?php
echo '<div class="f1"><a href="'.$ss->settings['url'].'">'.escape($ss->settings['title']).'</a></div>
</body>
</html>';
