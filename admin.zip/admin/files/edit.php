<?php
define('IN_SS', true);
include_once("../inc/init.php");

include_once(SS_ROOT."inc/class_watermark.php");
if($ss->settings['show_ipblocker'])
{
include_once('../iplist.php');
if(!in_array($_SERVER['REMOTE_ADDR'], $safelist)) 
{
header('Location: '.$ss->settings['url'].'');
exit;
}
}
if(!is_admin())
{
header('Location: '.$ss->settings['url'].'');
exit;
}

$fid = $ss->get_input('fid', 1);
$message = '';

$query = $db->simple_select("files", "*", "fid='{$fid}'");
$file = $db->fetch_array($query);

if(!$file)
{
header("Location: {$ss->settings['url']}");
exit;
}

if($file['isdir'] == 1)
{
$verb = 'Category';
$name = $ss->get_input('name');
$fname = convert_name($name);
}
else
{
$verb = 'File';
$name = $ss->get_input('name');
$fname = convert_filename($name);
}

$title = 'Edit '.$verb.'';
include_once("../header.php");

echo '<div class="top">Edit your previous '.$verb.' from here!</div>';
include_once('../time.php');
echo'<h2>Edit '.$verb.'</h2>';

if(isset($ss->input['action']) && $ss->input['action'] == 'do_edit' && $ss->request_method == 'post')
{
$name = $ss->get_input('name');

if($name != $file['name'])
{
$path = $file['path'];

$query = $db->simple_select("files", "fid", "path='".$db->escape_string($path)."'");
$count = $db->num_rows($query);
}
else
{
$path = $file['path'];
}

$description = $ss->get_input('description');
$dcount = $ss->get_input('dcount', 1);
$flagtime = $ss->get_input('flagtime');
$pageurl = $ss->get_input('pageurl');
$link = $ss->get_input('link');
$ptag = $ss->get_input('ptag');
$tag = $ss->get_input('tag', 1);
$disporder = $ss->get_input('disporder', 1);
$use_icon = $ss->get_input('use_icon', 1);
$status = $ss->get_input('status', 1);
$title = $ss->get_input('title');
$data = ['name' => $db->escape_string($name), 'title' => $ss->get_input('title'), 'pageurl' => $ss->get_input('pageurl'), 'ptag' => $ss->get_input('ptag'), 'link' => $ss->get_input('link'), 'flagtime' => $ss->get_input('flagtime'), 'description' => $db->escape_string($description), 'disporder' => $disporder, 'tag' => $tag, 'dcount' => $dcount, 'path' => $db->escape_string($path), 'use_icon' => $use_icon,
'status' => $status];
if(empty($message))
{
$query = $db->update_query("files", $data, "fid='".$fid."'");

if($path != $file['path'])
{
rename(SS_ROOT.$file['path'], SS_ROOT.$path);

if($file['isdir'] == 1)
{
$db->query("UPDATE `".TABLE_PREFIX."files` SET `path`=replace(`path`,'".$db->escape_string($file['path'])."','".$db->escape_string($path)."') WHERE `path` LIKE '".$db->escape_string_like($file['path'])."%'");
}
}

if(isset($_FILES['icon']) && $_FILES['icon']['name'] != '')
{
upload_icon('icon', $fid);
}
elseif(isset($ss->input ['url_icon']) && !empty($ss->input ['url_icon']) && $ss->input ['url_icon'] != 'http://')
{
import_icon($ss->get_input('url_icon'), $fid);
}
$message = ''.$verb.' detail updated sucessfully.';

$file['name'] = $name;
$file['title'] = $title;
$file['pageurl'] = $pageurl;
$file['ptag'] = $ptag;
$file['link'] = $link;
$file['flagtime'] = $flagtime;
$file['status'] = $status;
$file['description'] = $description;
$file['disporder'] = $disporder;
$file['tag'] = $tag;
}
}
if(isset($ss->input['action']) && $ss->input['action'] == 'remove' && $ss->request_method == 'get')
{
if(unlink(SS_ROOT.'/thumbs/'.$fid.'.png'))
{
$message = 'Thumb has been deleted.';
}
else
{
$message = 'Unable to delete Thumb.';
}
}

if(!empty($message))
{
echo '<div class="toptitle">'.$message.'</div>';
}

echo '<div>
<form method="post" action="#" enctype="multipart/form-data">
<div class="toptitle">
<div>'.$verb.' Name:</div>
<div><input type="text" name="name" value="'.escape($file['name']).'" maxlength="100" /></div>
</div>';
if($file['isdir'] == 1)
{
echo'<div class="toptitle">
<div>Title:</div>
<div><textarea name="title" />'.escape($file['title']).'</textarea></div>
</div><div class="toptitle">
<div>Tag:</div>
<div><textarea name="ptag" />'.escape($file['ptag']).'</textarea></div>
</div><div class="toptitle">
<div>Type:</div>
<div><select name="pageurl"><option value="categorylist" '.($file['pageurl'] == categorylist ? 'selected ' : '').'>Categorylist</option><option value="fileList" '.($file['pageurl'] == fileList ? 'selected ' : '').'>Filelist</option></select></div></div>';
}
echo'<div class="toptitle">
<div>Description:</div>
<div><textarea name="description" />'.escape($file['description']).'</textarea></div></div></div>';
if($file['isdir'] == 0)
{
echo '<div class="toptitle">
<div>Download Count:</div>
<div><input name="dcount" value="'.escape($file['dcount']).'"/></div>';
}
if($file['isdir'] == 1)
{
echo '<div class="toptitle">
<div>Target Url:</div>
<div><input name="link" value="'.escape($file['link']).'"/></div>
</div><div class="toptitle">
<div>Status:</div>
<div><input type="radio" name="status" value="1" '.($file['status'] == 1 ? 'checked ' : '').'/> Active <input type="radio" name="status" value="0" '.($file['status'] == 0 ? 'checked ' : '').'/> Block</div></div><div class="toptitle">
<div>Display Order:</div>
<div><input type="text" name="disporder" value="'.escape($file['disporder']).'" /></div>
</div>
<div class="toptitle">
<div>Display Header Thumb: </div>
<div><input type="radio" name="use_icon" value="1" '.($file['use_icon'] == 1 ? 'checked ' : '').'/> Yes <input type="radio" name="use_icon" value="0" '.($file['use_icon'] == 0 ? 'checked ' : '').'/> No</div>
</div> ';
}

echo '<div class="toptitle">
<div>Upload Thumb From PC: (500x500 recommended)</div>
<div><input type="file" name="icon" /></div></div><div class="toptitle">
<div>Import Thumb From URL: (500x500 recommended)</div>
<div><input type="text" name="url_icon" value="http://" /></div>
</div>';

if(file_exists(''.SS_ROOT.'/thumbs/'.$file['fid'].'.png'))
{
echo '<div class="toptitle"><div><img src="'.$ss->settings['url'].'/thumbs/'.$file['fid'].'.png" alt="" width="90px" height="90px" /><br />
<a href="'.$ss->settings['adminurl'].'/files/edit.php?fid='.$file['fid'].'&action=remove">Remove Thumb</a></div></div>';
}
if($file['isdir'] == 1)
{
echo '<div class="toptitle">
<div>Flag:</div>
<div><input type="radio" name="tag" value="1" '.($file['tag'] == 1 ? 'checked ' : '').'/> New <input type="radio" name="tag" value="2" '.($file['tag'] == 2 ? 'checked ' : '').'/> Update <input type="radio" name="tag" value="3" '.($file['tag'] == 3 ? 'checked ' : '').'/> Hot <input type="radio" name="tag" value="0" '.($file['tag'] == 0 ? 'checked ' : '').'/> No Flag</div>
</div><div class="toptitle">
<div>Display Flag For:</div>
<div><select name="flagtime"><option value="+7 days" '.($file['flagtime'] == '+7 days' ? 'selected ' : '').'>One Week</option><option value="+15 days" '.($file['flagtime'] == '+15 days' ? 'selected ' : '').'>Two Week</option><option value="+21 days" '.($file['flagtime'] == '+21 days' ? 'selected ' : '').'>Three Week</option><option value="+30 days" '.($file['flagtime'] == '+30 days' ? 'selected ' : '').'>One Month</option><option value="+60 days" '.($file['flagtime'] == '+60 days' ? 'selected ' : '').'>Two Month</option><option value="+90 days" '.($file['flagtime'] == '+90 days' ? 'selected ' : '').'>Three Month</option></select></div></div>';
}
echo'<div class="toptitle">
<div><input type="hidden" name="action" value="do_edit" />
<input type="submit"  value="Edit" /></div>
</div>
</form>
</div>';

if($file['isdir'] == 0)
{
$ext = pathinfo($file['path'], PATHINFO_EXTENSION); 
if($ext == 'mp4') 
{ 
echo'<h2>Multiple Format</h2>'; 
$del_vpath2 = str_replace('.mp4', '.3gp', SS_ROOT.$file['path']); 
$del_vpath3 = str_replace('.mp4', '_480p.mp4', SS_ROOT.$file['path']); 
$del_vpath4 = str_replace('.mp4', '_720p.mp4', SS_ROOT.$file['path']); 

if(isset($ss->input['action']) && $ss->input['action'] == 'del_vid' && $ss->request_method == 'get') 
{ 
$vid_type = $ss->get_input('vid_type'); 
$del_vpath = str_replace('.mp4', ''.$vid_type.'', SS_ROOT.$file['path']); 

if(file_exists($del_vpath)) 
{ 
if(unlink($del_vpath)) 
{ 
$message2 = 'File has been deleted.'; 
} 
else 
{ 
$message2 = 'Unable to delete file.'; 
} 
} 
} 
if(!empty($message2)) 
{ 
echo '<div class="toptitle">'.$message.'</div>'; 
} 
if(isset($ss->input['action']) && $ss->input['action'] == 'upload_vid') 
{ 
$vid_url = $ss->get_input('vid_url'); 
$vid_type = $ss->get_input('vid_type'); 

$vid_path = SS_ROOT.$file['path']; 
$vid_path2 = str_replace('.mp4', ''.$vid_type.'', SS_ROOT.$file['path']); 
if($fid > 0 && isset($_FILES['vidfile']) && $_FILES['vidfile']['name'] != '') 
{ 
if(!move_uploaded_file($_FILES['vidfile']['tmp_name'], $vid_path2)) 
{ 
echo '<div class="toptitle">Unable to upload file.</div>'; 
} 
else 
{ 
echo '<div class="toptitle">File has been uploaded.</div>'; 
} 
} 
elseif(isset($ss->input ['vid_url']) && !empty($ss->input ['vid_url']) && $ss->input ['vid_url'] != 'http://') 
{ 
if(!copy($vid_url, $vid_path2)) 
{ 
echo '<div class="toptitle">Unable to upload file.</div>'; 
} 
else 
{ 
echo '<div class="toptitle">File has been uploaded.</div>'; 
} 
} 
if(file_exists($vid_path2)) { 
if($ss->settings['watermark_videos']) 
{ 
watermark_video($vid_path2); 
} 
} 
} 
echo'<form method="post" action="#" enctype="multipart/form-data"><div class="toptitle"><div><input type="radio" name="vid_type" value=".3gp" checked/> 3GP (144p)'; 

if(file_exists($del_vpath2)) 
{ 
echo ' - <a href="'.$ss->settings['adminurl'].'/files/edit.php?fid='.$file['fid'].'&vid_type=.3gp&action=del_vid">[Remove]</a>'; 
} 
echo'<br/><input type="radio" name="vid_type" value="_480p.mp4"/> HD MP4 (480p)'; 

if(file_exists($del_vpath3)) 
{ 
echo ' - <a href="'.$ss->settings['adminurl'].'/files/edit.php?fid='.$file['fid'].'&vid_type=_480p.mp4&action=del_vid">[Remove]</a>'; 
} 
echo'<br/><input type="radio" name="vid_type" value="_720p.mp4"/> Full HD MP4 (720p)'; 
if(file_exists($del_vpath4)) 
{ 
echo ' - <a href="'.$ss->settings['adminurl'].'/files/edit.php?fid='.$file['fid'].'&vid_type=_720p.mp4&action=del_vid">[Remove]</a>'; 
} 
echo'</div> 
</div><div class="toptitle"> 
<div>Upload From PC:</div> 
<div><input type="file" name="vidfile" /></div> 
</div> <div class="toptitle"> 
<div>Import From URL:</div> 
<div><input type="text" name="vid_url" value="http://" /></div> 
</div><div class="toptitle"> 
<div><input type="hidden" name="action" value="upload_vid" /> 
<input type="submit" value="Submit" /></div> 
</div> 
</form> 
</div>'; 
}

if($ext == 'mp3')
{
echo'<h2>Multiple Format</h2>'; 
$del_path2 = str_replace('.mp3', '_64.mp3', SS_ROOT.$file['path']); 
$del_path3 = str_replace('.mp3', '_192.mp3', SS_ROOT.$file['path']); 
$del_path4 = str_replace('.mp3', '_320.mp3', SS_ROOT.$file['path']);  

if(isset($ss->input['action']) && $ss->input['action'] == 'del_mp3' && $ss->request_method == 'get') 
{
$mp3_type = $ss->get_input('mp3_type');
$del_path = str_replace('.mp3', '_'.$mp3_type.'.mp3', SS_ROOT.$file['path']);

if(file_exists($del_path)) 
{
if(unlink($del_path)) 
{ 
$message3 = 'File has been deleted.'; 
} 
else 
{ 
$message3 = 'Unable to delete file.'; 
} 
} 
}
if(!empty($message3)) 
{ 
echo '<div class="toptitle">'.$message.'</div>'; 
} 
if(isset($ss->input['action']) && $ss->input['action'] == 'upload_mp3') 
{
$mp3_url = $ss->get_input('mp3_url'); 
$mp3_type = $ss->get_input('mp3_type'); 

$mp3_path = SS_ROOT.$file['path']; 
$mp3_path2 = str_replace('.mp3', '_'.$mp3_type.'.mp3', SS_ROOT.$file['path']); 
if($fid > 0 && isset($_FILES['mp3file']) && $_FILES['mp3file']['name'] != '') 
{ 
if(!move_uploaded_file($_FILES['mp3file']['tmp_name'], $mp3_path2)) 
{ 
echo '<div class="toptitle">Unable to upload file.</div>'; 
}
else
{ 
echo '<div class="toptitle">File has been uploaded.</div>'; 
} 
} 
elseif(isset($ss->input ['mp3_url']) && !empty($ss->input ['mp3_url']) && $ss->input ['mp3_url'] != 'http://') 
{
if(!copy($mp3_url, $mp3_path2)) 
{ 
echo '<div class="toptitle">Unable to upload file.</div>'; 
} 
else
{ 
echo '<div class="toptitle">File has been uploaded.</div>'; 
} 
}
if(file_exists($mp3_path2)) { 
auto_tag($mp3_path2); 
} 
}
echo'<form method="post" action="#" enctype="multipart/form-data"><div class="toptitle"><div><input type="radio" name="mp3_type" value="64" checked/> 64 KBPS (Low)'; 

if(file_exists($del_path2)) 
{ 
echo ' - <a href="'.$ss->settings['adminurl'].'/files/edit.php?fid='.$file['fid'].'&mp3_type=64&action=del_mp3">[Remove]</a>'; 
} 
echo'<br/><input type="radio" name="mp3_type" value="192"/> 192 KBPS (Medium)';

if(file_exists($del_path3)) 
{ 
echo ' - <a href="'.$ss->settings['adminurl'].'/files/edit.php?fid='.$file['fid'].'&mp3_type=192&action=del_mp3">[Remove]</a>'; 
} 
echo'<br/><input type="radio" name="mp3_type" value="320"/> 320 KBPS (High)';
if(file_exists($del_path4)) 
{ 
echo ' - <a href="'.$ss->settings['adminurl'].'/files/edit.php?fid='.$file['fid'].'&mp3_type=320&action=del_mp3">[Remove]</a>'; 
} 
echo'</div> 
</div><div class="toptitle"> 
<div>Upload From PC:</div> 
<div><input type="file" name="mp3file" /></div> 
</div> <div class="toptitle"> 
<div>Import From URL:</div> 
<div><input type="text" name="mp3_url" value="http://" /></div> 
</div><div class="toptitle"> 
<div><input type="hidden" name="action" value="upload_mp3" /> 
<input type="submit" value="Submit" /></div> 
</div> 
</form> 
</div>';

echo '<h2>Mp3 Tag Editor</h2>';

if(isset($ss->input['action']) && $ss->input['action'] == 'do_change')
{
$path = SS_ROOT.$file['path'];
$path2 = str_replace('.mp3', '_64.mp3', SS_ROOT.$file['path']);
$path3 = str_replace('.mp3', '_192.mp3', SS_ROOT.$file['path']);
$path4 = str_replace('.mp3', '_320.mp3', SS_ROOT.$file['path']);

if(file_exists($path))
{
mp3tags_writter($path);
}
if(file_exists($path2))
{
mp3tags_writter($path2);
}
if(file_exists($path3))
{
mp3tags_writter($path3);
}
if(file_exists($path4)) 
{ 
mp3tags_writter($path4); 
} 
}
$tags = get_tags(SS_ROOT.$file['path']);
echo '<div>
<form action="#" method="post" enctype="multipart/form-data">
<div class="toptitle">
<div>Title:</div>
<div><input type="text" name="title" value="'.escape($tags['title']).'" /></div>
</div>
<div class="toptitle">
<div>Artist:</div>
<div><input type="text" name="artist" value="'.escape($tags['artist']).'" /></div>
</div>
<div class="toptitle">
<div>Album:</div>
<div><input type="text" name="album" value="'.escape($tags['album']).'" /></div>
</div>
<div class="toptitle">
<div>Genre:</div>
<div><input type="text" name="genre" value="'.escape($tags['genre']).'" /></div>
</div>
<div class="toptitle">
<div>Year:</div>
<div><input type="text" name="year" value="'.escape($tags['year']).'" /></div>
</div>
<div class="toptitle">
<div>Track:</div>
<div><input type="text" name="track" value="'.escape($tags['track']).'" /></div>
</div>
<div class="toptitle">
<div>Band:</div>
<div><input type="text" name="band" value="'.escape($tags['band']).'" /></div>
</div>
<div class="toptitle">
<div>Publisher:</div>
<div><input type="text" name="publisher" value="'.escape($tags['publisher']).'" /></div>
</div>
<div class="toptitle">
<div>Composer:</div>
<div><input type="text" name="composer" value="'.escape($tags['composer']).'" /></div>
</div>
<div class="toptitle">
<div>Comment:</div>
<div><input type="text" name="comment" value="'.escape($tags['comment']).'" /></div>
</div>';

if(file_exists(SS_ROOT.$ss->settings['mp3_albumart']))
{
echo '<div class="toptitle">
<div>Default Cover album:</div>
<div><img src="'.$ss->settings['url'].'/'.$ss->settings['mp3_albumart'].'" width="90px" height="90px" /></div>
<div><input type="checkbox" name="image_default" value="1"> Use this image ?</div>
</div>';
}

echo '<div class="toptitle">
<div>Upload Image (jpg, png, or gif only):</div>
<div><input type="file" name="image_file" /></div>
</div>
<div class="toptitle">
<div>Import Image from URL (jpg, png, or gif only):</div>
<div><input type="text" name="image_url" value="" /></div>
</div>
<div class="toptitle">
<div><input type="checkbox" name="image_remove" value="1"> Remove Image Album ?</div>
<div><input type="hidden" name="action" value="do_change" />
<input type="submit" value="Submit" /></div>
</div>
</form>
</div>';
}
}

echo '<h2>Select Option</h2><div class="catRow"><a href="'.$settings['adminurl'].'/files/move.php?fid='.$fid.'">Move '.$verb.'</a></div>';echo '<div class="catRow"><a href="'.$settings['adminurl'].'/files/delete.php?fid='.$fid.'">Delete '.$verb.'</a></div>';

echo '<div class="pgn"><a href="'.$ss->settings['adminurl'].'/files/index.php?pid='.$_GET['pid'].'">Go back to the Category</a></div><div class="path"><a href="/">Home</a> &raquo; <a href="'.$ss->settings['adminurl'].'">Admin Panel</a> &raquo;</div>';

include_once("../footer.php");