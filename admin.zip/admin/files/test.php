<div id='rate_yont0xd' class='ffbs_rate'>
<!--{[['<img src="http://img.graddit.com/img/ice_star.png"/>', '<img src="http://img.graddit.com/img/red_star.png"/>']]}--></div>
<div id='feedback_yont0xd' class='ffbs_feedback'>
<!--{["Useless", "Boring", "Need more details", "Perfect"]}--></div>
<div id='stats_yont0xd' class='ffbs_stats'></div>
<script type='text/javascript' src='http://www.graddit.com/rate/eng/5/yont0xd?id=rate_yont0xd&stats=stats_yont0xd&feedback=feedback_yont0xd&info=info&info_delay=2&class_star=ffbs_star_fimg&class_star_set=ffbs_star_fimg&class_star_vote=ffbs_star_fimg&average=yes&views=yes&votes=yes'></script>