<?php
define('IN_SS', true);
include_once("../inc/init.php");

include_once(SS_ROOT."/inc/class_watermark.php");
if($ss->settings['show_ipblocker'])
{
include_once('../iplist.php');
if(!in_array($_SERVER['REMOTE_ADDR'], $safelist)) 
{
header('Location: '.$ss->settings['url'].'');
exit;
}
}
 if(!is_admin())
{
header('Location: '.$ss->settings['url'].'');
exit;
}

$pid = $ss->get_input('pid', 1);

$title = 'Add Category';
$errors = [];

include_once('../header.php');

echo '<div class="top">Here you can add a new folder under this directory!</div>';
include_once('../time.php');
echo'<h2>Add Category</h2>';

if(isset($ss->input['action']) && $ss->input['action'] == 'do_add' && $ss->request_method == 'post')
{
$name = $ss->get_input('name');

if(empty($name))
{
$errors[] = 'Category name can not be empty!</div>';
}
$query = $db->simple_select("files", "path", "fid='{$pid}'");
$folder = $db->fetch_array($query);

if(!$folder)
{
$folder['path'] = '/files';
}
$query = $db->simple_select("files");
$count = $db->num_rows($query);
$cid = $count+1;
$path = "{$folder['path']}/{$cid}";
$query = $db->simple_select("files", "fid", "path='".$db->escape_string($path)."'");
$count = $db->num_rows($query);
if($count != 0)
{
$errors[] = 'Category already exists!';
}

if(empty($errors))
{
$data = ['name' => $db->escape_string($ss->get_input('name')), 'title' => $db->escape_string($ss->get_input('title')), 'ptag' => $db->escape_string($ss->get_input('ptag')), 'description' => $db->escape_string($ss->get_input('description')), 'link' => $db->escape_string($ss->get_input('link')), 'pageurl' => $db->escape_string($ss->get_input('pageurl')), 'flagtime' => $ss->get_input('flagtime'), 'status' => $ss->get_input('status', 1), 'path' => $db->escape_string($path), 'pid' => $pid, 'time' => TIME_NOW, 'isdir' => 1, 'tag' => $ss->get_input('tag', 1), 'disporder' => $ss->get_input('disporder', 1), 'use_icon' => $ss->get_input('use_icon', 1)];
$fid = $db->insert_query("files", $data);
if($fid)
{
if(!is_dir(SS_ROOT.$path))
{
mkdir(SS_ROOT.$path, 0777, true);
}

if(isset($_FILES['icon']) && $_FILES['icon']['name'] != '')
{
upload_icon('icon', $fid);
}
elseif(isset($ss->input ['url_icon']) && !empty($ss->input ['url_icon']) && $ss->input ['url_icon'] != 'http://')
{
import_icon($ss->get_input('url_icon'), $fid);
}

echo '<div class="toptitle">Category added successfully!<br/><a href="/'.$_POST['pageurl'].'/'.$fid.'/new2old/1.html">'.$_POST['name'].'</a></div>';
}

}
else
{
show_errors($errors);
}

}
echo '<div>
<form method="post" action="#" enctype="multipart/form-data">
<div class="toptitle">
<div>Category Name:</div>
<div><input type="text" name="name" value="" maxlength="100" /></div>
</div>
<div class="toptitle">
<div>Title:</div>
<div><textarea name="title" /></textarea></div>
</div><div class="toptitle">
<div>Tag:</div>
<div><textarea name="ptag" /></textarea></div>
</div><div class="toptitle">
<div>Type:</div>
<div><select name="pageurl"><option value="categorylist">Categorylist</option><option value="fileList">Filelist</option></select></div>
</div><div class="toptitle">
<div>Description:</div>
<div><textarea name="description" /></textarea></div>
</div><div class="toptitle">
<div>Target Url:</div>
<div><input name="link" value=""/></div>
</div>
<div class="toptitle">
<div>Display Order:</div>
<div><input type="text" name="disporder" value="" /></div>
</div>
<div class="toptitle">
<div>Upload Thumb From PC: (500x500 recommended)</div>
<div><input type="file" name="icon" /></div>
</div><div class="toptitle">
<div>Import Thumb From URL: (500x500 recommended)</div>
<div><input type="text" name="url_icon" value="http://" /></div>
</div>
<div class="toptitle">
<div>Flag:</div>
<div><input type="radio" name="tag" value="1" /> New <input type="radio" name="tag" value="2" /> Updated <input type="radio" name="tag" value="3"/> Hot <input type="radio" name="tag" value="0" checked/> No Flag</div>
</div><div class="toptitle"><div>Display Flag For:</div>
<div><select name="flagtime"><option value="+7 days">One Week</option><option value="+15 days">Two Week</option><option value="+21 days">Three Week</option><option value="+30 days">One Month</option><option value="+60 days">Two Week</option><option value="+90 days">Three Week</option></select></div>
</div><div class="toptitle">
<div>Display Header Thumb:</div>
<div><input type="radio" name="use_icon" value="1"/> Yes <input type="radio" name="use_icon" value="0" checked/> No</div>
</div><div class="toptitle">
<div>Status:</div>
<div><input type="radio" name="status" value="1" checked/> Active <input type="radio" name="status" value="0"/> Block</div>
</div>
<div class="toptitle">
<div><input type="hidden" name="action" value="do_add" />
<input type="submit" value="Add" /></div>
</div>
</form>
</div>';

echo '<div class="pgn"><a href="'.$ss->settings['adminurl'].'/files/index.php?pid='.$_GET['pid'].'">Go back to the Category</a></div><div class="path"><a href="'.$ss->settings['url'].'">Home</a> &raquo; <a href="'.$ss->settings['adminurl'].'">Admin Panel</a></div>';

include_once('../footer.php');