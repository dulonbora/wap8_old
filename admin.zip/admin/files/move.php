<?php
define('IN_SS', true);
include_once("../inc/init.php");
if($ss->settings['show_ipblocker'])
{
include_once('../iplist.php');
if(!in_array($_SERVER['REMOTE_ADDR'], $safelist)) 
{
header('Location: '.$ss->settings['url'].'');
exit;
}
}
if(!is_admin())
{
header('Location: '.$ss->settings['url'].'');
exit;
}

$title = 'Move Item';
$fid = $ss->get_input('fid', 1);
$message = '';

$query = $db->simple_select("files", "*", "fid={$fid}");
$file = $db->fetch_array($query);

if(!$file)
{
header("Location: {$ss->settings['url']}");
exit;
}

include_once("../header.php");

if(isset($ss->input['action']) && $ss->input['action'] == 'do_move')
{
$path = "/files".$ss->get_input('path');

$query = $db->simple_select("files", "fid", "path='".$db->escape_string($path)."'");
$dirid = $db->fetch_field($query, 'fid');

$real_path = $path."/".basename($file['path']);

$db->update_query("files", ['pid' => $dirid, 'path' => $db->escape_string($real_path)], "fid='".$file['fid']."'");

if($file['path'] != $real_path)
{
if(is_file(SS_ROOT.$file['path']))
{
rename(SS_ROOT.$file['path'], SS_ROOT.$real_path);
}
else
{
dirmv(SS_ROOT.$file['path'], SS_ROOT.$real_path);
$db->query("UPDATE`".TABLE_PREFIX."files` SET `path`=replace(`path`,'".$db->escape_string($file['path'])."','".$db->escape_string($real_path)."') WHERE `path` LIKE '".$db->escape_string_like($file['path'])."%'");
}
$message = 'File/Folder moved sucessfully!';
}
}
echo '<div class="top">Do you want to move any item? Its too much easy from here!</div>';
include_once('../time.php');
echo'<h2>Move Item</h2>';

if(!empty($message))
{
echo '<div class="toptitle">'.$message.'</div>';
}
$query = $db->simple_select("files", "path", "isdir=1");
while($folder = $db->fetch_array($query))
{
$folder2 = substr($folder['path'], 6);
if(dirname($file['path']) === $folder['path'])
$selected="selected='sahil'";
else
$selected='';
}
$fpath = file_get_contents('http://'.$_SERVER['HTTP_HOST'].'/inc/fpath.php?id='.$_GET['pid'].'');
if($_GET['pid'] == '')
{
echo '<form method="get" action="'.$ss->settings['adminurl'].'/files/move.php"><div class="toptitle">
<div>Enter Category ID:</div>
<div><input type="text" name="pid" value=""/><input type="hidden" name="fid" value="'.$_GET['fid'].'"/></div><div><input type="submit" value="Move"/></div></div></form>'; 
}
else
{ 
echo '<form method="post" action="#"><div class="toptitle"><div>Move to:</div><div><select name="path"><option value="">Root Directory</option><option value="'.$fpath.'" selected>'.$fpath.'</option></select>/'.basename($file['path']).'<input type="hidden" name="action" value="do_move"/></div><div><input type="submit" value="Confirm"/></div></div></form>';
}

echo '<div class="path"><a href="'.$ss->settings['url'].'">Home</a> &raquo; <a href="'.$ss->settings['adminurl'].'">Admin Panel</a></div>';

include_once('../footer.php');