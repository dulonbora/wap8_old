<?php
define('IN_SS', true);
include_once('../inc/init.php');
if($ss->settings['show_ipblocker'])
{
include_once('../iplist.php');
if(!in_array($_SERVER['REMOTE_ADDR'], $safelist)) 
{
header('Location: '.$ss->settings['url'].'');
exit;
}
}
if(!is_admin())
{
header('Location: '.$ss->settings['url'].'');
exit;
}

$title = 'File Manager';
$folder = [];
$pid = $ss->get_input('pid', 1);
$page = isset($ss->input['page']) ? (int)$ss->input['page'] : 1;

if($pid != 0)
{
$query = $db->simple_select("files", "fid, name, use_icon, path, description, time, flagtime", "fid='{$pid}'");
$folder = $db->fetch_array($query);

if(!is_array($folder))
{
header('Location: '.$ss->settings['url']);
exit;
}

$title = $folder['name'];
$folder['name'] = escape($folder['name']);
}
else
{
$folder['name'] = 'Root Directory';
$folder['use_icon'] = 0;
}

include_once('../header.php');


if($pid == 0)
{
echo '<div class="top">Its your file manager, so here you can upload, edit, move or delete any file or folder easily!</div>';
include_once('../time.php');
echo'<div id="category"><h2>File Manager</h2></div>';
}
else
{
echo '<div class="top">Its your file manager, so here you can upload, edit, move or delete any file or folder easily!</div>';
include_once('../time.php');
echo'<div id="category"><h2>Select Option</h2></div>
<div class="catRow"><a href="'.$ss->settings['adminurl'].'/files/edit.php?fid='.$folder['fid'].'&pid='.$_GET['pid'].'">Edit Category</a></div>';
if(file_exists(SS_ROOT.'/thumbs/'.$folder['fid'].'.png'))
{
echo '';
}
}

echo '<div class="catRow"><a href="'.$ss->settings['adminurl'].'/files/add.php?pid='.$pid.'">Add Category</a></div>
<div class="catRow"><a href="'.$ss->settings['adminurl'].'/upload.php?pid='.$pid.'">Upload File</a></div>';
echo '<h2>'.$folder['name'].'</h2>';
$query = $db->simple_select("files", "fid", "pid='{$pid}'");
$total = $db->num_rows($query);
$dirid = file_get_contents('http://'.$_SERVER['HTTP_HOST'].'/inc/isdir.php?id='.$_GET['pid'].'');
if($dirid != 1)
{
$fileshow = $ss->settings['files_per_page'];
}
else
{
$fileshow = $ss->settings['cats_per_page'];
}
if($total != 0)
{
$start = ($page-1)*$fileshow;

$options = ['order_by' => 'disporder ASC, fid DESC', 'limit_start' => $start, 'limit' => $fileshow];

$query = $db->simple_select("files", "fid, name, isdir, tag, path, size, dcount, description, time, flagtime", "pid='{$pid}'", $options);
while($file = $db->fetch_array($query))
{
if($file['isdir'] == 1)
{
echo '<div class="catRow"><a href="'.$ss->settings['adminurl'].'/files/index.php?pid='.$file['fid'].'"><div>'.escape($file['name']).'';

if($total != 0)
{
$counter = $db->simple_select("files", "fid", "path LIKE '".$db->escape_string_like($file['path'])."%' AND `isdir` = '0'");
echo ' ['.$db->num_rows($counter).'] ';
}
$time = time();
$extime = strtotime("{$file['flagtime']}", $file['time']);
if($time <= $extime)
{
if($file['tag'] == 1)
{
echo ' '.ss_img('new.png', "New").'';
}
else if($file['tag'] == 2)
{
echo ' '.ss_img('updated.png', "Updated").'';
}
else if($file['tag'] == 3)
{
echo ' '.ss_img('hot.gif', "Hot").'';
}
}
echo '</div></a></div>';
}
else
{
echo '<div class="fl odd"><b><a href="'.$ss->settings['adminurl'].'/files/edit.php?fid='.$file['fid'].'&pid='.$_GET['pid'].'"><div><div>';

if(file_exists(SS_ROOT.'/thumbs/'.$file['fid'].'.png'))
{
echo '<img src="/siteuploads/thumb/'.$file['fid'].'_2.jpg" alt="'.$file['fid'].'_2"/>';
}
else if($folder['use_icon'] == 1 && file_exists(SS_ROOT.'/thumbs/'.$folder['fid'].'.png'))
{
echo '';
}
else 
{
echo '';
}
$srname = $ss->settings['title'];
$filename = str_replace("($srname)", "", escape($file['name']));
if(escape($file['description']) == '')
{
$singer = ''; 
}
else
{ 
$singer = '<br/><span style="color: green;">'.escape($file['description']).'</span>';
}
echo '</div><div>'.$filename.''.$singer.'<br/><span>'.convert_filesize($file['size']).'</span> | <span>'.$file['dcount'].' Hits</span></div></div></a></b></div>';
}}

$url = "{$ss->settings['adminurl']}/files/index.php?pid={$pid}&page={page}";
echo pagination($page, $ss->settings['files_per_page'], $total, $url);
echo '<form method="get" action="'.$ss->settings['adminurl'].'/files/index.php"><input type="hidden" name="pid" id="pid" value="'.$_GET['pid'].'" />Jump to Page <input type="text" name="page" id="page" value="" size="3" /><input type="submit" value="Go&raquo;" /></form></div></div>';
}
else
{
echo '<div class="fl odd" align="center"><span class="error"><b>Folder is empty!</b></span></div><div class="pgn"><span class="cur">1</span><div>Page(1/1)</div><form method="get" action=""><input type="hidden" name="pid" id="pid" value="'.$_GET['pid'].'" />Jump to Page <input type="text" name="page" id="page" value="" size="3" /><input type="submit" value="Go&raquo;" /></form></div>';
}


if($pid != 0)
{

$_dr = '';

echo '<div class="path"><a href="/">Home</a> &raquo; <a href="'.$ss->settings['adminurl'].'">Admin Panel</a> &raquo; <a href="'.$ss->settings['adminurl'].'/files">File Manager</a>';

foreach(explode('/', substr($folder['path'], 7)) as $dr)
{
$_dr .= "/".$dr;
$path = "/files{$_dr}";

$query = $db->simple_select("files", "fid, name", "path='".$db->escape_string($path)."'");
$id = $db->fetch_array($query);

if($pid == $id['fid'])
{
echo '';
}
else
{
echo ' &raquo; <a href="'.$ss->settings['adminurl'].'/files/index.php?pid='.$id['fid'].'">'.escape($id['name']).'</a>';
}
}
echo '</div>';
}
else
{
echo'<div class="path"><a href="/">Home</a> &raquo; <a href="'.$ss->settings['adminurl'].'">Admin Panel</a></div>';
}

include_once('../footer.php');
