<?php
define('IN_SS', true);
include_once("../inc/init.php");
if($ss->settings['show_ipblocker'])
{
include_once('../iplist.php');
if(!in_array($_SERVER['REMOTE_ADDR'], $safelist)) 
{
header('Location: '.$ss->settings['url'].'');
exit;
}
}
if(!is_admin())
{
header('Location: '.$ss->settings['url'].'');
exit;
}

$fid = $ss->get_input('fid', 1);

$query = $db->simple_select("files", "fid, path", "fid={$fid}");
$file = $db->fetch_array($query);

if(!$file)
{
header("Location: {$ss->settings['url']}");
exit;
}

if(isset($ss->input['action']) && $ss->input['action'] == 'do_delete' && $ss->request_method == 'post')
{
if(is_dir(SS_ROOT.$file['path']))
{
deleteAll(SS_ROOT.$file['path']);

$query = $db->simple_select("files", "fid", "path LIKE '".$db->escape_string_like($file['path'])."%'");
while($fi = $db->fetch_array($query))
{
if(file_exists(SS_ROOT.'thumbs/'.$fi['fid'].'.png'))
{
unlink(SS_ROOT.'thumbs/'.$fi['fid'].'.png');
}
}

$db->delete_query("files", "path LIKE '".$db->escape_string_like($file['path'])."%'");
}
else
{
@unlink(SS_ROOT.$file['path']);

if(file_exists(SS_ROOT.'thumbs/'.$fid.'.png'))
{
unlink(SS_ROOT.'thumbs/'.$fid.'.png');
}

$db->delete_query("files", "fid='".$file['fid']."'");
}

header('Location: '.$ss->settings['adminurl'].'/files');
exit;
}

$title = 'Delete Item';
include_once("../header.php");

echo '<div class="top">Wrong or copyrighted item found? Dont worry, just kick them out!</div>';
include_once('../time.php');
echo'<h2>Delete Item</h2>
<div class="toptitle">
<form method="post" action="#">
<div>Do you want to delete this item?</div>
<div><input type="hidden" name="action" value="do_delete" />
<input type="submit" value="Delete" /> <a href="'.$ss->settings['adminurl'].'/files">No</a></div>
</form>
</div>';

echo '<div class="path"><a href="'.$ss->settings['url'].'">Home</a> &raquo; <a href="'.$ss->settings['adminurl'].'">Admin Panel</a> &raquo; <a href="'.$ss->settings['adminurl'].'/files">File Manager</a></div>';

include_once("../footer.php");