<?php 
$date = date('h:i A - d/m/y (D)', time());
echo'<div class="error">'.$date.'</div>';
?>