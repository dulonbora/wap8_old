<?php
define('IN_SS', true);
include_once("./inc/init.php");

// Login
if(isset($ss->input['action']) && $ss->input['action'] == 'do_login')
{
$pass = sha1($ss->input['password']);

if($pass == $ss->settings['adminpass'])
{
if($ss->get_input('remember', 1) == 1)
{
ss_setcookie("pass", $pass);
}
$_SESSION['adminpass'] = $pass;
}
}
$title = 'Admin Panel';
include_once("./header.php");
if(!is_admin())
{
$ip = $_SERVER['REMOTE_ADDR'];
if($pass == '')
{
$message = 'Please login first!';
}
else
{
$message = 'Incorrect password!';
}
echo '<div class="error">'.$message.'</div><h2>Admin Login</h2>
<div>
<form method="post" action="#"><div class="toptitle"><div>IP Address:</div><div><input type="text" name="ip" value="'.$ip.'" disabled ="disabled"/></div></div>
<div class="toptitle">
<div>Password:</div>
<div><input type="password" name="password" /></div>
</div>
<div class="toptitle">
<div><input type="checkbox" name="remember" value="1" /> Enable automatic login</div>
<br/><div><input type="hidden" name="action" value="do_login" />
<input type="submit" value="Login" /></div>
</div>
</form>
</div><div class="toptitle"><div><font color="red"><b>Note:</b></font> Your IP address will be logged for potential security violations.</div></div>';
}
else
{
if($ss->settings['show_ipblocker'])
{
include_once('./iplist.php');
if(in_array($_SERVER['REMOTE_ADDR'], $safelist)) 
{
include_once('./content.php');
}
else
{
$ip = $_SERVER['REMOTE_ADDR'];
echo '<div class="error">Your IP was blocked!</div><h2>Admin Login</h2>
<div>
<form method="post" action="#"><div class="toptitle"><div>IP Address:</div><div><input type="text" name="ip" value="'.$ip.'" disabled ="disabled"/></div></div>
<div class="toptitle">
<div>Password:</div>
<div><input type="password" name="password" /></div>
</div>
<div class="toptitle">
<div><input type="checkbox" name="remember" value="1" /> Enable automatic login</div><br/><div><input type="hidden" name="action" value="do_login" />
<input type="submit" value="Login" /></div>
</div>
</form>
</div><div class="toptitle"><div><font color="red"><b>Note:</b></font> Your IP address will be logged for potential security violations.</div></div>';
}
}
else
{
include_once('./content.php');
}
}
echo '<div class="path"><a href="/">Home</a> &raquo;</div>';
include_once("./footer.php");