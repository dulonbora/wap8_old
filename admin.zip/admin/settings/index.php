<?php
define('IN_SS', true);
include('../inc/init.php');
if($ss->settings['show_ipblocker'])
{
include_once('../iplist.php');
if(!in_array($_SERVER['REMOTE_ADDR'], $safelist)) 
{
header('Location: '.$ss->settings['url'].'');
exit;
}
}
if(!is_admin())
{
header('Location: '.$ss->settings['url'].'');
exit;
}

$title = 'Settings Manager';
include('../header.php');

echo '<div class="top">Edit or change, the choice is yours!</div>';
include_once('../time.php');
echo'<h2>Settings Manager</h2>';

$options = ['order_by'=>'disporder', 'order_dir'=>'asc'];

$query = $db->simple_select("settingsgroups", "*", "", $options);
while($setting = $db->fetch_array($query))
{
echo '<div class="catRow"><a href="setting.php?gid='.$setting['gid'].'"><b>'.$setting['title'].'</b></a>
</div>';
}

echo '<div class="path"><a href="'.$ss->settings['url'].'">Home</a> &raquo; <a href="'.$ss->settings['adminurl'].'">Admin Panel</a></div>';

include('../footer.php');