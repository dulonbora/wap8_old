<?php
define('IN_SS', true);
include_once("./inc/init.php");

include_once(SS_ROOT."/inc/class_watermark.php");
if($ss->settings['show_ipblocker'])
{
include_once('./iplist.php');
if(!in_array($_SERVER['REMOTE_ADDR'], $safelist)) 
{
header('Location: '.$ss->settings['url'].'');
exit;
}
}
if(!is_admin())
{
header('Location: '.$ss->settings['url'].'');
exit;
}

$fid = 0;
$title = 'Upload File';
$pid = $ss->get_input('pid', 0);

if($pid != 0)
{
$query = $db->simple_select("files", "path", "fid='{$pid}'");
$path = $db->fetch_field($query, 'path');
}

if(empty($path))
{
$pid = 0;
}

include_once('./header.php');

echo '<div class="top">Here you can upload a new file for this directory!</div>';
include_once('./time.php');
echo'<h2>Upload File</h2>';

if(isset($ss->input['action']) && $ss->input['action'] == 'do_upload' && $ss->request_method == 'post')
{
if($pid == 0)
{
$path = '/files'.$ss->get_input('path').'';
}

if(isset($_FILES['file']) && $_FILES['file']['name'] != '')
{
$fid = upload_file('file', $path);
}
elseif(isset($ss->input ['url']) && !empty($ss->input ['url']) && $ss->input ['url'] != 'http://')
{
$fid = import_file($ss->get_input('url'), $path);
}
else
{
echo '<div class="toptitle">No file is selected</div>';
}

if($fid > 0 && isset($_FILES['icon']) && $_FILES['icon']['name'] != '')
{
upload_icon('icon', $fid);
}
elseif(isset($ss->input ['url_icon']) && !empty($ss->input ['url_icon']) && $ss->input ['url_icon'] != 'http://')
{
import_icon($ss->get_input('url_icon'), $fid);
}
}
echo '<div>
<form action="#" method="post"
enctype="multipart/form-data">
<div class="toptitle">
<div>File Location:</div>';

if($pid != 0)
{
echo '<div>'.escape($path).'</div>';
}

else
{
echo '<div><select name="path">
<option value="">./</option>';

$query = $db->simple_select("files", "path", "isdir=1");
while($folder = $db->fetch_array($query))
{
$folder2 = substr($folder['path'], 6);

echo '<option value="'.$folder2.'">'.$folder2.'</option>';
}

echo '</select></div>';
}

echo '</div>
<div class="toptitle">
<div>File Name:</div>
<div><input type="text" name="name" value="" /></div>
</div><div class="toptitle">
<div>Description:</div>
<div><textarea name="description" value=""></textarea></div>
</div>
<div class="toptitle">
<div>Upload From PC:</div>
<div><input type="file" name="file" /></div>
</div>
<div class="toptitle">
<div>Import From URL:</div>
<div><input type="text" name="url" value="http://" /></div>
</div>
<div class="toptitle">
<div>Upload Thumb From PC: (250x250 recommended)</div>
<div><input type="file" name="icon" value="" /></div>
</div><div class="toptitle">
<div>Import Thumb From URL: (250x250 recommended)</div>
<div><input type="text" name="url_icon" value="http://" /></div>
</div><div class="toptitle">
<div><input type="hidden" name="action" value="do_upload">
<input type="submit" value="Upload" /></div>
</div>
</form>
</div>';

echo '<div class="pgn"><a href="'.$ss->settings['adminurl'].'/files/index.php?pid='.$_GET['pid'].'">Go back to the Category</a></div><div class="path"><a href="'.$ss->settings['url'].'">Home</a> &raquo; <a href="'.$ss->settings['adminurl'].'">Admin Panel</a></div>';

include_once('./footer.php');