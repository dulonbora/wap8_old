<?php
define('IN_SS', true);
include('./inc/init.php');
if($ss->settings['show_ipblocker'])
{
include_once('./iplist.php');
if(!in_array($_SERVER['REMOTE_ADDR'], $safelist)) 
{
header('Location: '.$ss->settings['url'].'');
exit;
}
}
if(!is_admin())
{
header('Location: '.$ss->settings['url'].'');
exit;
}

$title = 'Ping Your Sitemap';
include('./header.php');

$sitemap_url = "http://mazaming.in/sitemap.php";

$google="http://google.com/ping?sitemap=";

$bing="http://www.bing.com/ping?sitemap=";


$data= file_get_contents("$google$sitemap_url");
echo '<div class="top">Ping your sitemap here to increase your page rank on popular search engines!</div>';
include_once('./time.php');
echo'<h2>Response From Google</h2>';
if($data){
echo '<div class="toptitle"><b>Sitemap Notification Received</b><br/>
Your Sitemap has been successfully added to our list of Sitemaps to crawl. If this is the first time you are notifying Google about this Sitemap, please add it via <a href="http://www.google.com/webmasters/tools/">http://www.google.com/webmasters/tools/</a> so you can track its status. Please note that we do not add all submitted URLs to our index, and we cannot make any predictions or guarantees about when or if they will appear.</div>';
}
else
{
echo '<div class="error">Failed to submit your sitemap in Google!</div>';
}

$data2= file_get_contents("$bing$sitemap_url");
echo '<h2>Response From Bing</h2>';
if($data2)
{
echo '<div class="toptitle">Thanks for submitting your Sitemap. Join the <a href="http://bing.com/webmaster">Bing Webmaster Tools</a> to see your Sitemaps status and more reports on how you are doing on Bing.</div>';
}
else
{
echo '<div class="error">Failed to add your sitemap in Bing!</div>';
}
echo '<div class="path"><a href="/">Home</a> &raquo; <a href="/admin">Admin Panel</a></div>';
include_once("footer.php");
?>