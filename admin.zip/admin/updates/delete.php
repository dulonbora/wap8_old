<?php
define('IN_SS', true);
include("../inc/init.php");
if($ss->settings['show_ipblocker'])
{
include_once('../iplist.php');
if(!in_array($_SERVER['REMOTE_ADDR'], $safelist)) 
{
header('Location: '.$ss->settings['url'].'');
exit;
}
}
if(!is_admin())
{
header('Location: '.$ss->settings['url'].'');
exit;
}

$uid = $ss->get_input('uid', 1);

if(isset($ss->input['action']) && $ss->input['action'] == 'do_delete' && $ss->request_method == 'post')
{
$query = $db->delete_query("updates", "uid='{$uid}'");

header('Location: '.$ss->settings['adminurl'].'/updates/index.php');
exit;
}

$query = $db->simple_select("updates", "uid", "uid='{$uid}'");
$total = $db->num_rows($query);

if($total == 0)
{
header('Location: '.$ss->settings['adminurl'].'');
exit;
}

$title = 'Delete Update';
include_once('../header.php');

echo '<div class="top">Wrong update found? Dont worry, just delete them!</div>';
include_once('../time.php');
echo'<h2>Delete Update</h2>
<div class="toptitle">
<form method="post" action="#">
<div>Do you want to delete this update record?</div>
<div><input type="hidden" name="action" value="do_delete" />
<input type="submit" value="Delete" /> <a href="'.$ss->settings['adminurl'].'/updates/index.php">No</a></div>
</form>
</div>';

echo '<div class="path"><a href="'.$ss->settings['url'].'">Home</a> &raquo; <a href="'.$ss->settings['adminurl'].'">Admin Panel</a> &raquo; <a href="'.$ss->settings['adminurl'].'/updates">Updates Manager</a></div>';

include_once('../footer.php');