<?php
define('IN_SS', true);
include("../inc/init.php"); 
if($ss->settings['show_ipblocker'])
{
include_once('../iplist.php');
if(!in_array($_SERVER['REMOTE_ADDR'], $safelist)) 
{
header('Location: '.$ss->settings['url'].'');
exit;
}
}
if(!is_admin())
{
header('Location: '.$ss->settings['url'].'');
exit;
}

$uid = $ss->get_input('uid', 1);
$message = '';

if(isset($ss->input['action']) && $ss->input['action'] == 'do_edit' && $ss->request_method == 'post')
{
$iconid = $ss->get_input('iconid'); 
$url = $ss->get_input('url'); 
$text = $ss->get_input('text'); 
$update_time = strtotime("{$ss->get_input('update_time')}"); 
$status = $ss->get_input('status');

if($status != 'A')
{
$status = 'D';
}

if(!empty($text))
{
$data = ['iconid' => $db->escape_string($iconid), 'url' => $db->escape_string($url), 'text' => $db->escape_string($text), 'update_time' => $db->escape_string($update_time), 'created_at' => TIME_NOW, 'status' => $status];
$db->update_query("updates", $data, "uid='{$uid}'");

$message = 'Update record edited sucessfully!';
}
else
{
$message = 'Please enter html code!';
}
}

$query = $db->simple_select("updates", "iconid, text, url, update_time, status", "uid='{$uid}'");
$update = $db->fetch_array($query);

$uptimeval = date('m/d/Y H:i:s A', $update['update_time']);

if(!$update)
{
header('Location: '.$ss->settings['url'].'');
exit;
}

$title = 'Edit Update';
include_once('../header.php');

echo '<div class="top">Edit your previous site update from here!</div>';
include_once('../time.php');
echo'<h2>Edit Update</h2>';
if(!empty($message))
{
echo '<div class="toptitle">'.$message.'</div>';
}
echo '<div class="toptitle"> 
<form method="post" action="#"> <div>Icon ID:</div> 
<div><input name="iconid" type="text" value="'.escape($update['iconid']).'"/></div><div>Title:</div> 
<div><input name="text" type="text" value="'.escape($update['text']).'"/></div>
<div>Url:</div> 
<div><input type="text" name="url" value="'.escape($update['url']).'"/></div><div>Schedule:</div> 
<div><input name="update_time" type="text" value="'.$uptimeval.'"/></div> 
<div><input type="checkbox" name="status" value="A" '.($update['status'] == 'A' ? 'checked' : '').'> Active (Show on Index)?</div>
<div><input type="hidden" name="action" value="do_edit" />
<input type="submit" value="Edit" /></div>
</form>
</div>';

echo '<div class="path"><a href="'.$ss->settings['url'].'">Home</a> &raquo; <a href="'.$ss->settings['adminurl'].'">Admin Panel</a> &raquo; <a href="'.$ss->settings['adminurl'].'/updates">Updates Manager</a></div>'; 

include_once('../footer.php');