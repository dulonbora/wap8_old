<?php
define('IN_SS', true);
include_once('../inc/init.php');
if($ss->settings['show_ipblocker'])
{
include_once('../iplist.php');
if(!in_array($_SERVER['REMOTE_ADDR'], $safelist)) 
{
header('Location: '.$ss->settings['url'].'');
exit;
}
}
if(!is_admin())
{
header('Location: '.$ss->settings['url'].'');
exit;
}

$title = 'Updates Manager';
include_once('../header.php');

if(isset($ss->input['page']))
{
$page = (int)$ss->input['page'];
}
else
{
$page = 1;
}

$start = ($page-1)*$ss->settings['updates_per_page'];

$query = $db->simple_select("updates", "uid");
$total = $db->num_rows($query);

echo '<div class="top">Add, edit or delete your site updates from here!</div>';
include_once('../time.php');
echo'<h2>Updates Manager</h2>
<div class="catRow"><a href="'.$ss->settings['adminurl'].'/updates/add.php">Add New Update</a></div><div style="border-top: 1px solid #ccc;"></div>
<div class="updates">';

if($total != 0)
{
$options = ['order_by' => 'uid', 'order_dir' => 'desc', 'limit_start' => $start, 'limit' => $ss->settings['updates_per_page']];

$query = $db->simple_select("updates", "uid, iconid, text, url, created_at, update_time, status", "", $options);
while($update = $db->fetch_array($query))
{
echo '<div><b>HTML Code:</b> '.escape($update['description']).'<br/>
<b>Created At:</b> '.date("h:i:s a d-M-y", $update['created_at']).'<br/>
<b>Status:</b> '.(($update['status'] == 'A') ? 'Active' : 'Inactive').'<br/>
<a href="'.$ss->settings['adminurl'].'/updates/edit.php?uid='.$update['uid'].'">Edit</a> | <a href="'.$ss->settings['adminurl'].'/updates/delete.php?uid='.$update['uid'].'">Delete</a></div>';
}
}
else
{
echo '<div>Sorry, No updates available!</div>';
}
echo '</div>';

$url = "{$ss->settings['adminurl']}/updates/index.php?page={page}";

echo pagination($page, $ss->settings['updates_per_page'], $total, $url);
echo '<form method="get" action="'.$ss->settings['adminurl'].'/updates/index.php">Jump to Page <input type="text" name="page" id="page" value="" size="3" /><input type="submit" value="Go&raquo;" /></form></div></div>';
echo '<div class="path"><a href="'.$ss->settings['url'].'">Home</a> &raquo; <a href="'.$ss->settings['adminurl'].'">Admin Panel</a></div>';

include_once('../footer.php');