<?php
define('IN_SS', true);

include_once("../inc/init.php");
$time = time();
if($ss->settings['show_ipblocker'])
{
include_once('../iplist.php');
if(!in_array($_SERVER['REMOTE_ADDR'], $safelist)) 
{
header('Location: '.$ss->settings['url'].'');
exit;
}
}
if(!is_admin())
{
header('Location: '.$ss->settings['url'].'');
exit;
}

$message = '';
$title = 'Add New Update';

if(isset($ss->input['action']) && $ss->input['action'] == 'do_add' && $ss->request_method == 'post')
{
$iconid = $ss->get_input('iconid');
$url = $ss->get_input('url');
$text = $ss->get_input('text'); 
$update_time = strtotime("{$ss->get_input('update_time')}");
$status = $ss->get_input('status');

if($status != 'A')
{
$status = 'D';
}

if(!empty($text))
{
$data = ['iconid' => $db->escape_string($iconid), 'url' => $db->escape_string($url), 'text' => $db->escape_string($text), 'created_at' => TIME_NOW, 'update_time' => $db->escape_string($update_time), 'status' => $status];

$db->insert_query("updates", $data);
$message = 'Update record added successfully!';

header('Location: '.$ss->settings['adminurl'].'/updates/index.php');
}
else
{
$message = 'Please enter html code!';
}
}

include_once('../header.php');

echo '<div class="top">Here you can add a new update for your site!</div>';
include_once('../time.php');
echo'<h2>Add New Update</h2>';

if(!empty($message))
{
echo '<div class="toptitle">'.$message.'</div>';
}

echo '<div class="toptitle">
<form method="post" action="#"> <div>Icon ID:</div> 
<div><input name="iconid" type="text" value=""/></div><div>Title:</div> 
<div><input name="text" type="text" value=""/></div>
<div>Url:</div>
<div><input type="text" name="url" value="http://"/></div><div>Schedule:</div> 
<div><input name="update_time" type="text" value="'.date("m/d/Y H:i:s A", $time).'"/></div>
<div><input type="checkbox" name="status" value="A" checked/> Active (Show on Index)?
</div>
<div><input type="hidden" name="action" value="do_add" />
<input type="submit" value="Add" /></div>
</form>
</div>';

echo '<div class="path"><a href="'.$ss->settings['url'].'">Home</a> &raquo; <a href="'.$ss->settings['adminurl'].'">Admin Panel</a> &raquo; <a href="'.$ss->settings['adminurl'].'/updates">Updates Manager</a></div>';

include_once('../footer.php');