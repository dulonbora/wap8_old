<?php
define('IN_SS', true);
include_once('../inc/init.php');
if($ss->settings['show_ipblocker'])
{
include_once('../iplist.php');
if(!in_array($_SERVER['REMOTE_ADDR'], $safelist)) 
{
header('Location: '.$ss->settings['url'].'');
exit;
}
}
if(!is_admin())
{
header('Location: '.$ss->settings['url'].'');
exit;
}

$title = 'Codes Manager';
include_once('../header.php');

if(isset($ss->input['page']))
{
$page = (int)$ss->input['page'];
}
else
{
$page = 1;
}

$start = ($page-1)*$ss->settings['updates_per_page'];

$query = $db->simple_select("codes", "cid");
$total = $db->num_rows($query);

echo '<div class="top">Here you can store your important codes for future usage!</div>';
include_once('../time.php');
echo'<h2>Codes Manager</h2>
<div class="catRowHome"><a href="'.$ss->settings['adminurl'].'/codes/add.php">Add New Code</a></div><div style="border-top: 1px solid #ccc;"></div>
<div class="updates">';

if($total != 0)
{
$options = ['order_by' => 'cid', 'order_dir' => 'desc', 'limit_start' => $start, 'limit' => $ss->settings['updates_per_page']];

$query = $db->simple_select("codes", "created_at, description, status, cid", "", $options);
while($soon = $db->fetch_array($query))
{
echo '<div><b>HTML Code:</b> '.escape($soon['description']).'<br/>
<b>Created At:</b> '.date("h:i:s d-M-y", $soon['created_at']).'<br/>
<b>Status:</b> '.($soon['status'] == 'A' ? 'Active' : 'Inactive').'<br/>
<a href="'.$ss->settings['adminurl'].'/codes/edit.php?cid='.$soon['cid'].'">Edit</a> | <a href="'.$ss->settings['adminurl'].'/codes/delete.php?cid='.$soon['cid'].'">Delete</a></div>';
}
}
else
{
echo '<div>Sorry, No records available!</div>';
}
echo '</div>';

$url = "{$ss->settings['adminurl']}/codes/index.php?page={page}";

echo pagination($page, $ss->settings['updates_per_page'], $total, $url);
echo '<form method="get" action="'.$ss->settings['adminurl'].'/codes/index.php">Jump to Page <input type="text" name="page" id="page" value="" size="3" /><input type="submit" value="Go&raquo;" /></form></div></div>';
echo '<div class="path"><a href="'.$ss->settings['url'].'">Home</a> &raquo; <a href="'.$ss->settings['adminurl'].'">Admin Panel</a></div>';

include_once('../footer.php');