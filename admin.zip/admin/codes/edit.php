<?php
define('IN_SS', true);
include("../inc/init.php");
if($ss->settings['show_ipblocker'])
{
include_once('../iplist.php');
if(!in_array($_SERVER['REMOTE_ADDR'], $safelist)) 
{
header('Location: '.$ss->settings['url'].'');
exit;
}
}
if(!is_admin())
{
header('Location: '.$ss->settings['url'].'');
exit;
}

$cid = $ss->get_input('cid', 1);
$message = '';

if(isset($ss->input['action']) && $ss->input['action'] == 'do_edit' && $ss->request_method == 'post')
{
$description = $ss->get_input('description');
$status = $ss->get_input('status');

if($status != 'A')
{
$status = 'D';
}

if(!empty($description))
{
$data = ['description' => $db->escape_string($description), 'status' => $status];

$db->update_query("codes", $data, "cid='{$cid}'");

$message = 'Your code has been edited sucessfully!';
}
else
{
$message = 'Please enter html code!';
}
}

$query = $db->simple_select("codes", "description, status", "cid='{$cid}'");
$soon = $db->fetch_array($query);

if(!$soon)
{
header('Location: '.$ss->settings['url'].'');
exit;
}

$title = 'Edit Your Code';
include_once('../header.php');

echo '<div class="top">Edit your previous code from here!</div>';
include_once('../time.php');
echo'<h2>Edit Your Code</h2>';
if(!empty($message))
{
echo '<div class="toptitle">'.$message.'</div>';
}

echo '<div class="toptitle">
<form method="post" action="#">
<div>HTML Code:</div>
<div><textarea name="description">'.escape($soon['description']).'</textarea></div>
<div><input type="checkbox" name="status" value="A" '.($soon['status'] == 'A' ? 'checked' : '').' /> Active (Show on Index)?</div>
<div><input type="hidden" name="action" value="do_edit" />
<input type="submit" name="edit" value="Edit" /></div>
</form>
</div>';

echo '<div class="path"><a href="'.$ss->settings['url'].'">Home</a> &raquo; <a href="'.$ss->settings['adminurl'].'">Admin Panel</a> &raquo; <a href="'.$ss->settings['adminurl'].'/codes">Codes Manager</a></div>';

include_once('../footer.php');