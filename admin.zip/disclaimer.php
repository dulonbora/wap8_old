<?php
define('IN_SS', true);
include_once('./inc/init.php');

$title = 'Disclaimer';
include_once('./header.php');
echo '<h2>Disclaimer</h2>';
include_once('./assets/includes/disclaimer.php');
echo'<br/><hr/><br/><br/><div class="ftrLink"> <a href="/" class="siteLink">'.$ss->settings['title'].'</a></div></body> </html>';
?>