<?php
echo '<footer class="footer">
<div class="copyright aligncenter">'.$ss->settings['title'].'</div>
</footer></div>		<script type="text/javascript" src="/assets/js/zepto.min.js"></script>
<script type="text/javascript" src="/assets/js/common.js"></script>
<script type="text/javascript" src="/assets/js/jquery.flexslider.js"></script>';
echo'<!-- Development By : Nextwave Solutions --></body>
</html>';