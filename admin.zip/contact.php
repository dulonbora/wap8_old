<?php
define('IN_SS', true);
include_once('./inc/init.php');

$title = 'Contact Us';
include_once('./header.php');
echo'<div class="ad1 tCenter"><a href="/info/contact">Errors? Suggestion? Ideas? Tell Us!</a></div>';
 $admin_mail = $ss->settings['email'];
$name = $_POST['name'];
$from = $_POST['from'];
$about = $_POST['about'];
$message = $_POST['message'];
$ip = $_SERVER['REMOTE_ADDR'];
$errors = array();
if(!empty($_POST['submit']))
{
if(empty($_POST['name']) || empty($_POST['from']) || empty($_POST['about']) || empty($_POST['message']))
echo '<div class="error">All fields are required!</div>';
}
if(!empty($_POST['name']) && !empty($_POST['from']) && !empty($_POST['about']) && !empty($_POST['message']) && !empty($_POST['submit']))
{
$mailmsg = 'Name: '.$_POST['name'].'
.
.
About: '.$_POST['about'].'
.
.
Message: '.$_POST['message'].'
.
.
Email: '.$_POST['from'].'
.
.
IP Address: '.$ip.'';
if(mail($admin_mail, $_POST['about'], $mailmsg, 'From: '.$_POST['from'].''))
echo "<div class='description'><div>Thank You $name ($from)</div>
<div>Your Mail About $about</div><div>
And The Message $message Has Been Sent To Admin!</div><div>
You'll Get A Response
As Soon As Possible</div><div>
We Have Logged Your IP,
To Avoid Misuse Of This Service!</div><div>
Your IP Address Is : $ip</div></div>";
}
else
{
echo'<br/><div class="ad tCenter"><form method="post" action="#">Your Name:<br/><input type="text" name="name"><br/>Your E-mail: <br/>*Please use a Valid Email Address:<br/>
<input type="text" name="from"><br/> Whats It About?:<br />
<select name="about"><option value="General Question">General Question</option>
<option value="Support">Support</option><option value="Problem">Problem</option>
<option value="Suggestion">Suggestion</option>
<option value="Advertise">Advertise</option></select>
<br />
Mail Message:<br/> <textarea rows="4" cols="40" name="message"></textarea><br/><input type="submit" name="submit" value="Send Mail"/></form></div><br/>';
}
echo'<hr/><br/><a href="/">Go Back To Main Page</a><br/><br/><div class="ftrLink"> <a href="/" class="siteLink">'.$ss->settings['title'].'</a></div></body></html>';
?>