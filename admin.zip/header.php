<?php
error_reporting(0);
define('IN_SS', true);
include_once("./inc/init.php");
if(empty($title))
{
$title = $ss->settings['default_title'];
}
else
{
$title .= " :: {$ss->settings['title']}";
}

$title = escape($title);

echo '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>'.$title2.'';
if(escape($folder['title']) == '')
{
$_dr='';
$tcat='';
foreach(explode('/', substr($folder['path'], 7)) as $dr)
{
$_dr .= "/".$dr;
$path = "/files{$_dr}";
$query = $db->simple_select("files", "fid, name", "path='".$db->escape_string($path)."'");
$id = $db->fetch_array($query);
if($pid == $id['fid'])
{
}
else
{
echo ''.escape($id['name']).' > ';
}
}
}
echo''.$title.'</title>
<meta name="title" content="'.$title2.''.$title.' - Bollywood HD Videos, Funny videos, Mp3 Songs, Ringtones, Wallpapers, Themes, Games, Softwares Free Download" />
<meta name="robots" content="index, follow" />
<meta name="language" content="en" />
<meta name="keywords" content="mp3 songs, hd videos, ringtones, wallpapers, '.$title.'">
<meta name="description" content="Free Mobile Ringtones, Desh Bhakti Songs, Old Sonngs, Bollywood Songs, Wallpaper, Videos, Animations And More services :: '.$title.'">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">';
include_once('./assets/includes/headtag.php');
echo'<link rel="shortcut icon" href="/assets/images/favicon.ico" />
<link href="'.$ss->settings['css'].'" rel="stylesheet"/><link href="/assets/css/flexslider.css" rel="stylesheet"/> 
</head>
<body>
<div class="main">
<header class="header swtrow">
<div class="swtcol6"><a href="/" class="logo"><img alt="'.$site.'" src="'.$ss->settings['logo'].'" height ="38"/></a></div>
<div class="swtcol6">
</div></header>';
?>