<?php

session_start();
header("Pragma: public");
header("Cache-Control: max-age = 604800");
header("Expires: ".gmdate("D, d M Y H:i:s", time() + 604800)." GMT");

$id = $_GET['id'];
$img = '/thumbs/'.$_GET['id'].'.png';

function thumbnail($image, $width, $height) {

	if($image[0] != "/") { // Decide where to look for the image if a full path is not given
		if(!isset($_SERVER["HTTP_REFERER"])) { // Try to find image if accessed directly from this script in a browser
			$image = $_SERVER["DOCUMENT_ROOT"].implode("/", (explode('/', $_SERVER["PHP_SELF"], -1)))."/".$image;
		} else {
			$image = implode("/", (explode('/', $_SERVER["HTTP_REFERER"], -1)))."/".$image;
		}
	} else {
		$image = $_SERVER["DOCUMENT_ROOT"].$image;
	}
	$image_properties = getimagesize($image);
	$image_width = $image_properties[0];
	$image_height = $image_properties[1];
	$image_ratio = $image_width / $image_height;
	$type = $image_properties["mime"];

	if(!$width && !$height) {
		$width = $image_width;
		$height = $image_height;
	}
	if(!$width) {
		$width = round($height * $image_ratio);
	}
	if(!$height) {
		$height = round($width / $image_ratio);
	}

	if($type == "image/jpeg") {
		header('Content-type: image/jpg');
		$thumb = imagecreatefromjpeg($image);
	} elseif($type == "image/png") {
		header('Content-type: image/png');
		$thumb = imagecreatefrompng($image);
	} else {
		return false;
	}

	$temp_image = imagecreatetruecolor($width, $height);
	imagecopyresampled($temp_image, $thumb, 0, 0, 0, 0, $width, $height, $image_width, $image_height);
	$thumbnail = imagecreatetruecolor($width, $height);
	imagecopyresampled($thumbnail, $temp_image, 0, 0, 0, 0, $width, $height, $width, $height);

	if($type == "image/jpeg") {
		imagepng($thumbnail);
	} else {
		imagepng($thumbnail);
	}

	imagedestroy($temp_image);
	imagedestroy($thumbnail);

}
$type= $_GET['type'];
if($type == 0)
{
$w ='0';
$h ='0';
}
else if($type == 1)
{ 
$w= '85';
$h= '85';
}
else if($type == 2)
{ 
$w= '125';
$h= '125';
}
else if($type == 3)
{ 
$w= '177';
$h= '177';
}
else if($type == 4)
{ 
$w= '320';
$h= '320';
}
else if($type == 5)
{ 
$w= '500';
$h= '500';
}
else
{
die("<center><h1>404 Not Found</h1></center><hr/><center>nginx</center>");
}
thumbnail($img, $w, $h, 100);

?>