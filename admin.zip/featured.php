<?php
define('IN_SS', true);
include_once('./inc/init.php');

$title = 'Featured Files';
$folder = [];
$page = isset($ss->input['page']) ? (int)$ss->input['page'] : 1;
$folder['name'] = 'Home';
$folder['use_icon'] = 0;
$sort = isset($ss->input['sort']) ? $ss->input['sort'] : $ss->settings['sort'];

include_once('./header.php');
include_once('./searchbox.php');
echo'<div class="topadvt advertisment">'; 
include_once('./assets/ads/header.php'); 
echo'</div>'; 
// Category title
echo '
<section class="section_header aligncenter bgcolor_main">Featured</section>';

if($_GET['sort'] == 'default') 
{ 
echo '<section class="sorting_section aligncenter">Sort by : <a href="/featured/new2old/1.html" class="main-bg active">New 2 Old</a>&nbsp;|&nbsp;<a href="/featured/popular/1.html" class="main-bg">Popular</a>&nbsp;|&nbsp;<a href="/featured/a2z/1.html" class="main-bg">A to Z</a>&nbsp;|&nbsp;<a href="/featured/z2a/1.html" class="main-bg">Z to A</a></section>'; 
} 
if($_GET['sort'] == 'new2old') 
{ 
echo '<section class="sorting_section aligncenter"> Sort by : <a href="/featured/new2old/1.html" class="main-bg active">New 2 Old</a>&nbsp;|&nbsp;<a href="/featured/popular/1.html" class="main-bg">Popular</a>&nbsp;|&nbsp;<a href="/featured/a2z/1.html" class="main-bg">A to Z</a>&nbsp;|&nbsp;<a href="/featured/z2a/1.html" class="main-bg">Z to A</a></section>'; 
} 
if($_GET['sort'] == 'popular') 
{ 
echo '<section class="sorting_section aligncenter">Sort by : <a href="/featured/new2old/1.html" class="main-bg" 
>New 2 Old</a>&nbsp;|&nbsp;<a href="/featured/popular/1.html" class="main-bg active">Popular</a> 
&nbsp;|&nbsp;<a href="/featured/a2z/1.html" class="main-bg">A to Z</a>&nbsp;|&nbsp;<a href="/featured/z2a/1.html" class="main-bg">Z to A</a></section>'; 
} 
if($_GET['sort'] == 'a2z') 
{echo '<section class="sorting_section aligncenter">Sort by : <a href="/featured/new2old/1.html" class="main-bg">New 2 Old</a>&nbsp;|&nbsp;<a href="/featured/popular/1.html" class="main-bg">Popular</a>&nbsp;|&nbsp;<a href="/featured/a2z/1.html" class="main-bg active">A to Z</a>&nbsp;|&nbsp;<a href="/featured/z2a/1.html" class="main-bg">Z to A</a></section>'; 
} 
if($_GET['sort'] == 'z2a') 
{ 
echo '<section class="sorting_section aligncenter">Sort by : <a href="/featured/new2old/1.html" class="main-bg" 
>New 2 Old</a>&nbsp;|&nbsp;<a href="/featured/popular/1.html" class="main-bg" 
>Popular</a>&nbsp;|&nbsp;<a href="/featured/a2z/1.html" class="main-bg">A to Z</a>&nbsp;|&nbsp;<a href="/featured/z2a/1.html" class="main-bg active">Z to A</a></section>'; 
} 

echo'<!-- Nextwave Solutions :: Display Featured List -->';
echo'<div class="download-middle-advt advertisment">'; 
include_once('./assets/ads/bfilelist.php'); 
echo'</div><section class="item_list">';
switch($sort) 
{ 
case 'new2old': 
$order = 'fid DESC'; 
break; 
case 'a2z': 
$order = 'name ASC'; 
break; 

case 'z2a': 
$order = 'name DESC'; 
break; 
case 'popular': 
$order = 'dcount DESC'; 
break; 
default: 
$order = 'time DESC'; 
break; 
} 
$query = $db->simple_select("files", "fid", "isdir='0'");
$total = $db->num_rows($query);

if($total != 0)
{
$start = ($page-1)*$ss->settings['files_per_page'];
$options = ['order_by' => 'disporder ASC, '.$order.'', 'limit_start' => $start, 'limit' => $ss->settings['files_per_page']];

$query = $db->simple_select("files", "fid, name, tag, size, path, pid, dcount, description, time", "isdir='0'", $options);
while($file = $db->fetch_array($query))
{
if($file['pid'] != 0)
{
$query2 = $db->simple_select("files", "fid, use_icon", "fid='{$file['pid']}'");
$folder = $db->fetch_array($query2);
}
echo '<a href="/download/'.$file['fid'].'/'.convert_name($file['name']).'.html" class="listitem boxshadow"><div class="listdetail">'; 
$strname = $ss->settings['title']; 
$filename = str_replace("($strname)", "", escape($file['name'])); 
$fext = pathinfo($filename, PATHINFO_EXTENSION); 
$ftitle = preg_replace('/\.[^.]+$/','', $filename); 

if(file_exists(SS_ROOT.'/thumbs/'.$file['fid'].'.png')) 
{ 
$filethumb = '<div class="listimg leftside"><img src="/siteuploads/thumb/'.$file['fid'].'_1.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
} 
else if($fext == 'mp3') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-mp3.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
} 

else if($fext == 'mp4') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-vid.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
} 

else if($fext == '3gp') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-vid.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
} 
else if($fext == 'avi') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-vid.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
} 

else if($fext == 'apk') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-apk.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
} 
else if($fext == 'zip') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-arch.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
} 
else if($fext == 'rar') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-arch.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
} 
else if($fext == '7z') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-arch.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
} 
else if($fext == 'jpg') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-img.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
} 
else if($fext == 'jpeg') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-img.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
} 
else if($fext == 'png') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-img.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
} 

else if($fext == 'gif') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-img.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
} 
else if($fext == 'jar') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-java.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
} 

else if($fext == 'jad') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-java.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
} 
else 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-doc.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
} 
$strname = $ss->settings['title']; 
$filename = str_replace("($strname)", "", escape($file['name'])); 
if(escape($file['description']) == ''){ 
$singer = ''; 
}else 
{ 
$singer = ''.$file['description'].'<br/>'; 
}echo ''.$filethumb.'<div class="list_title">'.$filename.'</div><div class="list_desc">'.$singer.''.convert_filesize($file['size']).'&nbsp;&nbsp;&nbsp;<span class="download-icon"> '.$file['dcount'].'</span></div>'; 
echo '</div> <div class="clear"></div> </a>'; 
}
echo'</section><div class="download-middle-advt">'; 
include_once('./assets/ads/afilelist.php'); 
echo'</div>'; 
echo '<!-- Nextwave Solutions :: End Featured List -->';
$url = "{$ss->settings['url']}/featured/{$sort}"; 

$paging = pagination($page, $ss->settings['files_per_page'], $total, $url); 
echo $paging; 
if($paging != '') 
{ 
echo '</div> 
<div class="jumptopage aligncenter"> 
<form method="get" action="/featured"><input type="hidden" name="action" id="action" value="6" /><input type="hidden" name="sort" id="sort" value="'.$_GET['sort'].'" /><span class="jumpfrmlbl">Jump to Page</span> <input type="text" name="page" id="page" value="" class="jumpfrmtxt"/> <input type="submit" value="GO" class="jumpfrmbut bgcolor_main"/></form></div></section>'; 
} 
}
echo'<div class="bottomadvt advertisment">'; 
include_once('./assets/ads/footer.php'); 
echo'</div>';

echo '<section class="breadcrumb"><a href="/">Home</a> &raquo;</section>';

include_once('./footer.php');
?>