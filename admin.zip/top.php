<?php
define('IN_SS', true);
include_once('./inc/init.php');
if($_GET['id'] == 'today')
{
$act = '0'; 
$title = 'Today\'s Top Downloaded Files';
$var = 'today\'s Most Popular Downloads';
$sort = '<div class="dtype"> <span>Today</span> | <a href="/top/yesterday.html">Yesterday</a> | <a href="/top/week.html">This Week</a> | <a href="/top/month.html">This Month</a> | <a href="/top/all.html">All Time</a></div>';
}
if($_GET['id'] == 'yesterday')
{
$act = '1'; 
$title = 'Yesterday\'s Top Downloaded Files';
$var = 'yesterday\'s Most Popular Downloads';
$sort = '<div class="dtype"> <a href="/top/today.html">Today</a> | <span>Yesterday</span> | <a href="/top/week.html">This Week</a> | <a href="/top/month.html">This Month</a> | <a href="/top/all.html">All Time</a></div>';
}
if($_GET['id'] == 'week')
{
$act = '2'; 
$title = 'This Week\'s Top Downloaded Files';
$var = 'This week\'s Most Popular Downloads';
$sort = '<div class="dtype"> <a href="/top/today.html">Today</a> | <a href="/top/yesterday.html">Yesterday</a> | <span>Week</span> | <a href="/top/month.html">This Month</a> | <a href="/top/all.html">All Time</a></div>';
}
if($_GET['id'] == 'month')
{
$act = '3'; 
$title = 'This month\'s Top Downloaded Files';
$var = 'this month\'s Most Popular Downloads';
$sort = '<div class="dtype"> <a href="/top/today.html">Today</a> | <a href="/top/yesterday.html">Yesterday</a> | <a href="/top/week.html">This Week</a> | <span>Month</span> | <a href="/top/all.html">All Time</a></div>';
}
if($_GET['id'] == 'all')
{
$act = '4'; 
$title = 'All Time\'s Top Downloaded Files';
$var = 'All Time\'s Most Popular Downloads';
$sort = '<div class="dtype"> <a href="/top/today.html">Today</a> | <a href="/top/yesterday.html">Yesterday</a> | <a href="/top/week.html">This Week</a> | <a href="/top/month.html">This Month</a> | <span>All Time</span></div>';
}

$folder = [];
$folder['name'] = 'Home';
$folder['use_icon'] = 0;
include_once('./header.php');
include_once('./assets/ads/header.php');
include_once('./searchbox.php');
include_once('./assets/ads/bcategory.php');

$options = ['order_by' => 'hits DESC', 'limit' => 21];

switch($act)
{
case '1':
$verb ='Yesterday';
$date = date("dmY",  TIME_NOW-86400);
$query = $db->simple_select("download_history", "fid, hits", "date='{$date}'", $options);
break;

case '2':
$verb ='Week';
$date = date("dmY",  TIME_NOW-604800);

$query = $db->simple_select("download_history", "fid, hits", "date>={$date}", $options);
break;
case '3':
$verb = 'Month';
$date = date("dmY",  TIME_NOW-2592000);

$query = $db->simple_select("download_history", "fid, hits", "date>={$date}", $options);
break;

default:
$verb =' Today ';
$date = date("dmY",  TIME_NOW);

$query = $db->simple_select("download_history", "fid, hits", "date='{$date}'", $options);
break;
}

// Category title
echo '<div id="category"><h2>'.$var.'</h2></div>';

include_once('./assets/ads/acategory.php');

echo $sort;

include_once('./assets/ads/bfilelist.php');

$total = $db->num_rows($query);

if($total != 0)
{
while($top = $db->fetch_array($query))
{
$query2 = $db->simple_select("files", "fid, name, size, path, pid, description, time", "fid='{$top['fid']}'");
$file = $db->fetch_array($query2);

if($file['pid'] != 0)
{
echo '<!-- Nextwave Solutions :: Display File List -->';
}

echo '<div class="fl odd"><a href="/download/'.$file['fid'].'/'.convert_name($file['name']).'.html" class="fileName"><div><div>';

if(file_exists(SS_ROOT.'/thumbs/'.$file['fid'].'.png'))
{
$strname = $ss->settings['title'];
$filename = str_replace("($strname)", "", escape($file['name']));
$ftitle = preg_replace('/\.[^.]+$/','', $filename);
echo '<img src="/siteuploads/thumb/'.$file['fid'].'_2.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_2"/>';
}
else if($folder['use_icon'] == 1 && file_exists(SS_ROOT.'/thumbs/'.$folder['fid'].'.png'))
{
echo '';
}
else 
{
echo '';
}
$strname = $ss->settings['title'];
$filename = str_replace("($strname)", "", escape($file['name']));
if(escape($file['description']) == '')
{
$singer = ''; 
}
else
{ 
$singer = '<br/><span class="ar">'.$file['description'].'</span>';
}
echo '</div><div>'.$filename.''.$singer.'<br /><span>'.convert_filesize($file['size']).'</span> | <span>'.$top['hits'].' Hits</span></div></div></a></div>';
}
echo'<!-- Nextwave Solutions :: End File List -->';
}
else
{
echo '';
}

include_once('./assets/ads/footer.php');
echo '<div class="path"><a href="'.$ss->settings['url'].'">Home</a> &raquo;</div>';

include_once('./footer.php');