-- Wap PhpMyAdmin 211
-- http://master-land.net/phpmyadmin 
-- Generation Time: 2016-05-07 14:44
-- MySQL Server Version: 5.5.45-cll-lve
-- PHP Version: 5.4.45

-- Database: `mazaming`


-- --------------------------------------------------------
-- 
-- Table structure for table `sm_codes`
-- 

DROP TABLE IF EXISTS `sm_codes`;
CREATE TABLE `sm_codes` (
  `cid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` text NOT NULL,
  `created_at` int(10) unsigned NOT NULL DEFAULT '0',
  `status` varchar(1) NOT NULL DEFAULT 'A',
  PRIMARY KEY (`cid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `sm_comingsoon`
-- 

DROP TABLE IF EXISTS `sm_comingsoon`;
CREATE TABLE `sm_comingsoon` (
  `cid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` text NOT NULL,
  `created_at` int(10) unsigned NOT NULL DEFAULT '0',
  `status` varchar(1) NOT NULL DEFAULT 'A',
  PRIMARY KEY (`cid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `sm_download_history`
-- 

DROP TABLE IF EXISTS `sm_download_history`;
CREATE TABLE `sm_download_history` (
  `did` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fid` int(10) unsigned NOT NULL,
  `date` varchar(8) NOT NULL,
  `hits` int(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`did`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `sm_files`
-- 

DROP TABLE IF EXISTS `sm_files`;
CREATE TABLE `sm_files` (
  `fid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `path` text NOT NULL,
  `size` int(10) unsigned NOT NULL DEFAULT '0',
  `description` text NOT NULL,
  `views` int(10) unsigned NOT NULL DEFAULT '0',
  `dcount` int(10) unsigned NOT NULL DEFAULT '0',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `disporder` smallint(5) unsigned NOT NULL,
  `isdir` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `tag` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `use_icon` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` text NOT NULL,
  `link` varchar(455) NOT NULL,
  `ptag` text NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `pageurl` text NOT NULL,
  `flagtime` text NOT NULL,
  PRIMARY KEY (`fid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Table structure for table `sm_settings`
-- 

DROP TABLE IF EXISTS `sm_settings`;
CREATE TABLE `sm_settings` (
  `sid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `gid` smallint(5) unsigned NOT NULL,
  `title` varchar(120) NOT NULL,
  `name` varchar(120) NOT NULL,
  `value` text NOT NULL,
  `type` varchar(250) NOT NULL,
  `description` text NOT NULL,
  `optionscode` text NOT NULL,
  `disporder` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`sid`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=50 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `sm_settings`
-- 

INSERT INTO `sm_settings` VALUES ('1','1','Cookie Prefix','cookieprefix','sm_kingbuzz','text','Prefix to be added in cookies','','1');
INSERT INTO `sm_settings` VALUES ('2','1','Cookie Domain','cookiedomain','kingbuzz.in','text','Cookie domain for which cookies will work','','2');
INSERT INTO `sm_settings` VALUES ('3','1','Cookie Path','cookiepath','/cookies','text','Path where the cookies will work','','3');
INSERT INTO `sm_settings` VALUES ('4','2','Site URL','url','http://kingbuzz.in/','text','Site url to be used','','1');
INSERT INTO `sm_settings` VALUES ('5','2','Site Name','title','KingBuzz.in','text','Site name will be displayed on title bar,header,footer etc..','','2');
INSERT INTO `sm_settings` VALUES ('6','2','Site Logo','logo','/assets/images/kingbuzz_m.png','text','Logo image path or url...','','3');
INSERT INTO `sm_settings` VALUES ('7','2','Email','email','admin@kingbuzz.in','text','Your contact email to be used','','4');
INSERT INTO `sm_settings` VALUES ('8','2','Show Searchbox','show_searchbox','1','yesno','Show searchbox on index & filelist pages?','','5');
INSERT INTO `sm_settings` VALUES ('9','2','Maximum Paging Link','maxmultipagelinks','5','select','Number of page links to show','1=1\r\n2=2\r\n3=3\r\n4=4\r\n5=5\r\n6=6','6');
INSERT INTO `sm_settings` VALUES ('11','3','Updates on Page','updates_per_page','10','select','Total number of updates to show on updates page?','7=7\r\n8=8\r\n9=9\r\n10=10\r\n11=11\r\n12=12\r\n13=13\r\n14=14\r\n15=15\r\n16=16\r\n17=17\r\n18=18\r\n19=19\r\n20=20\r\n21=21\r\n22=22\r\n23=23\r\n24=24\r\n25=25\r\n26=26\r\n27=27\r\n28=28\r\n29=29\r\n30=30','2');
INSERT INTO `sm_settings` VALUES ('10','3','Updates on Index','updates_on_index','30','select','Total number of updates to show on index page?','7=7\r\n8=8\r\n9=9\r\n10=10\r\n11=11\r\n12=12\r\n13=13\r\n14=14\r\n15=15\r\n16=16\r\n17=17\r\n18=18\r\n19=19\r\n20=20\r\n21=21\r\n22=22\r\n23=23\r\n24=24\r\n25=25\r\n26=26\r\n27=27\r\n28=28\r\n29=29\r\n30=30','1');
INSERT INTO `sm_settings` VALUES ('12','4','Related files per Page','related_files_per_page','3','select','Select total number of related files to show','0=0\r\n1=1\r\n2=2\r\n3=3\r\n4=4\r\n5=5','1');
INSERT INTO `sm_settings` VALUES ('13','4','Files Per Page','files_per_page','8','select','Number of files to show in filelist page','7=7\r\n8=8\r\n9=9\r\n10=10\r\n11=11\r\n12=12\r\n13=13\r\n14=14\r\n15=15','3');
INSERT INTO `sm_settings` VALUES ('14','4','Default Sort Option','sort','new2old','select','Select default sorting option for files','default=Default\r\nnew2old=New to Old\r\ndownload=Popular\r\na2z=A to Z\r\nz2a=Z to A','3');
INSERT INTO `sm_settings` VALUES ('15','0','Admin Password','adminpass','348162101fc6f7e624681b7400b085eeac6df7bd','ap','The admincp password','','1');
INSERT INTO `sm_settings` VALUES ('16','4','Show Total File','show_filecount','1','yesno','Show total number of files after folder name?','','3');
INSERT INTO `sm_settings` VALUES ('17','5','Watermark Thumb','watermark_thumb','1','yesno','Watermark generated/uploaded thumbs','','1');
INSERT INTO `sm_settings` VALUES ('18','5','Watermark Images','watermark_images','1','yesno','Watermark uploaded images?','','2');
INSERT INTO `sm_settings` VALUES ('19','5','Watermark Videos','watermark_videos','1','yesno','Watermark uploaded videos?','','3');
INSERT INTO `sm_settings` VALUES ('20','5','Watermark Image','watermark_image','/assets/images/watermark.png','text','Image to be watermarked on video...','','4');
INSERT INTO `sm_settings` VALUES ('22','6',' Auto Tag','auto_tag','1','yesno','Auto tags mp3 files with default tags','','1');
INSERT INTO `sm_settings` VALUES ('24','6','Song Year','mp3_year','2016','text','','','3');
INSERT INTO `sm_settings` VALUES ('23','6','Auto Bitrate','auto_bitrate','1','yesno','Auto convert bitrate of MP3 files','','2');
INSERT INTO `sm_settings` VALUES ('25','6','Composer','mp3_composer','www.KingBuzz.in','text','','','4');
INSERT INTO `sm_settings` VALUES ('21','5','Watermark text','watermark_text','KINGBUZZ.IN','text','Text to be watermarked on thumbs/images','','5');
INSERT INTO `sm_settings` VALUES ('26','6','Publishers','mp3_publisher','www.KingBuzz.in','text','','','5');
INSERT INTO `sm_settings` VALUES ('27','6','Artist','mp3_artist','www.KingBuzz.in','text','','','6');
INSERT INTO `sm_settings` VALUES ('28','6','Album Art','mp3_albumart','/assets/images/cover.jpg','text','','','7');
INSERT INTO `sm_settings` VALUES ('29','6','Genre','mp3_genre','www.KingBuzz.in','text','','','7');
INSERT INTO `sm_settings` VALUES ('30','6','Band','mp3_band','www.KingBuzz.in','text','','','8');
INSERT INTO `sm_settings` VALUES ('31','6','Track','mp3_track','1','text','','','9');
INSERT INTO `sm_settings` VALUES ('32','4','Related Files','related_files','1','yesno','','','2');
INSERT INTO `sm_settings` VALUES ('33','6','Encoded By','mp3_encoded_by','www.KingBuzz.in','text','','','11');
INSERT INTO `sm_settings` VALUES ('34','6','Original Artist','mp3_original_artist','www.KingBuzz.in','text','','','12');
INSERT INTO `sm_settings` VALUES ('35','6','Comment','mp3_comment','www.KingBuzz.in','text','','','13');
INSERT INTO `sm_settings` VALUES ('36','6','User url','mp3_url_user','http://www.KingBuzz.in','text','','','14');
INSERT INTO `sm_settings` VALUES ('37','4','Featured files per Page','featured_files_per_page','3','select','Select total number of featured files to show','0=0\r\n1=1\r\n2=2\r\n3=3\r\n4=4\r\n5=5','1');
INSERT INTO `sm_settings` VALUES ('38','4','Featured Files','show_featuredfiles','1','yesno','','','2');
INSERT INTO `sm_settings` VALUES ('39','4','Top 21 Files','show_topfiles','1','yesno','','','2');
INSERT INTO `sm_settings` VALUES ('40','7','IP Blocker Protection','show_ipblocker','0','yesno','','','1');
INSERT INTO `sm_settings` VALUES ('42','8','Upcoming Items on Index','upcoming_on_index','3','select','&nbsp;Total number of upcoming items to show on index page?','0=0\r\n1=1\r\n2=2\r\n3=3\r\n4=4\r\n5=5','2');
INSERT INTO `sm_settings` VALUES ('43','8','Upcoming Items','show_upcoming','1','yesno','','','1');
INSERT INTO `sm_settings` VALUES ('44','2','Homepage Title','default_title','KingBuzz.in :: Unlimited Free Mobile Downloads','text','Site default title to be used','','2');
INSERT INTO `sm_settings` VALUES ('45','2','Site CSS','css','/assets/css/kingbuzz.css?1.4','text','css path or url...','','3');
INSERT INTO `sm_settings` VALUES ('46','8','Upcoming Header','upcomingheader','::.. Special Downloads ..::','text','This text will be shown as upcoming header','','3');
INSERT INTO `sm_settings` VALUES ('47','2','Logo Tagline','tagline','','text','This text will be shown under the logo','','4');
INSERT INTO `sm_settings` VALUES ('48','4','Categories Per Page','cats_per_page','10','select','Number of categories to show in categorylist page','7=7\r\n8=8\r\n9=9\r\n10=10\r\n11=11\r\n12=12\r\n13=13\r\n14=14\r\n15=15','3');
INSERT INTO `sm_settings` VALUES ('49','2','Download Server URL','dlserver','http://dl.kingbuzz.in/','text','File download url to be used','','1');

-- --------------------------------------------------------
-- 
-- Table structure for table `sm_settingsgroups`
-- 

DROP TABLE IF EXISTS `sm_settingsgroups`;
CREATE TABLE `sm_settingsgroups` (
  `gid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(120) NOT NULL,
  `description` text NOT NULL,
  `disporder` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`gid`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `sm_settingsgroups`
-- 

INSERT INTO `sm_settingsgroups` VALUES ('1','Cookie Settings','Set cookie prefix,path or domain...','1');
INSERT INTO `sm_settingsgroups` VALUES ('2','General Settings','Edit various settings like title,url etc..','2');
INSERT INTO `sm_settingsgroups` VALUES ('3','Update Settings','Updates settings like updates per page etc...','3');
INSERT INTO `sm_settingsgroups` VALUES ('4','Filelist Settings','Change file per page,sort order etc..','4');
INSERT INTO `sm_settingsgroups` VALUES ('5','Watermark Settings','Set various options for watermark','5');
INSERT INTO `sm_settingsgroups` VALUES ('6','Mp3 Tag Settings','Set various options for mp3 files','6');
INSERT INTO `sm_settingsgroups` VALUES ('7','Login Security Settings','','7');
INSERT INTO `sm_settingsgroups` VALUES ('8','Upcoming Settings','','3');

-- --------------------------------------------------------
-- 
-- Table structure for table `sm_updates`
-- 

DROP TABLE IF EXISTS `sm_updates`;
CREATE TABLE `sm_updates` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` text NOT NULL,
  `created_at` int(10) unsigned NOT NULL DEFAULT '0',
  `status` varchar(1) NOT NULL DEFAULT 'A',
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
