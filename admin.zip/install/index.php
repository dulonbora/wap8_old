<?php
echo '<html><head><title>Install Smart Autoindex</title>
<link href="/assets/images/favicon.png" rel= "shortcut icon"/>
<link href="/assets/css/apanel.css" type= "text/css" rel="stylesheet"/>
</head>
<body><h2>Install Smart Autoindex</h2>';
if(file_exists('lock'))
{
echo'<meta http-equiv="refresh" content="0; url= /">';
}
?>
<?php
if($_POST){
$check = $_POST['nxtkey'];
$nxtinst = $_SERVER['HTTP_HOST'];
$nxtinst = str_replace("www.", "", $nxtinst);
$nxtinst2 = base64_encode($nxtinst);
$nxtinst3 = base64_encode($nxtinst2);
$nxtinst4 = base64_encode($nxtinst3);
if($nxtinst4 == $check)
{
$sql = new mysqli($_POST['host'], $_POST['user'], $_POST['pass'], $_POST['name']);
if($sql->connect_error) 
{
die("<div class='toptitle'>Installation failed! Please <a href=''>go back</a> and try to reinstall again.</div><h2>&copy; Nextwave Solutions</h2>");
}
mysqli_query($sql,"USE vmail");
$sqlSource = file_get_contents('SmartAI.sql');
mysqli_multi_query($sql, $sqlSource);
mysqli_close($sql);
echo ("");
$fp = fopen('../inc/dbsetup.php','w');
$content = '<?php
$dbhost = "'.$_POST['host'].'";
$dbtype = "mysqli";
$dbname = "'.$_POST['name'].'";
$dbuser = "'.$_POST['user'].'";
$dbpass = "'.$_POST['pass'].'";
$dbprefix = "sm_";
$admin_dir ="admin";
$api_key = "'.$_POST['nxtkey'].'";
$dbencoding = "utf8";
?>';
if(!fwrite($fp,trim($content)))
$error = 1;
fclose($fp);
if($error){ echo "<div class='toptitle'>Some error camed up. Check /inc/dbsetup.php is writable or not.</div><h2>&copy; Nextwave Solutions</h2>";
} 
else {
fopen(lock, 'w')
or
die("<div class='top'>Failed to create installation locker file!'</div><h2>&copy; Nextwave Solutions</h2>");
echo'<meta http-equiv="refresh" content="0; url= /">';
}
}
else
die("<div class='toptitle'>Sorry, your api key is invalid!</div><h2>&copy; Nextwave Solutions</h2>");
}
else
{
echo "<form action='#' method='post'><div class='toptitle'><div>
DB Host:</div><div><input type='text' name='host' value='localhost'></div></div><div class='toptitle'><div>
DB Name:</div><div><input type='text' name='name'></div></div><div class='toptitle'><div>
DB User:</div><div><input type='text' name='user'></div></div><div class='toptitle'><div>DB Password:</div><div><input type='text' name='pass'></div></div><div class='toptitle'><div>API Key:</div><div><input type='text' name='nxtkey'></div></div><h2>Login Details</h2><div class='toptitle'><div>Password: 54321</div><div><input type='submit' value='Install'/></div></div>";
}
?>
<?php
echo
'<h2>&copy; Nextwave Solutions</h2><br/><center>Development By : <a href="http://suvadipm.usa.cc">SuvaDip Mukherjee</a></center></body></html>';
?>