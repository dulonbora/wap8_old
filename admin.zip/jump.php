<?php
$action = $_GET['action'];
$parent = $_GET['parent'];
$find = $_GET['find'];
$find = str_replace(" ", "_", $find);
$find = strtolower($find);
$singer = $_GET['singer'];
$album = $_GET['album'];
$sort = $_GET['sort'];
$page = $_GET['page'];
$commit = $_GET['commit'];
if($action == '1')
{
header('Location: /categorylist/'.$parent.'/'.$sort.'/'.$page.'.html');
}
if($action == '2')
{
header('Location: /fileList/'.$parent.'/'.$sort.'/'.$page.'.html');
}
if($action == '3')
{
header('Location: /search/'.$find.'/'.$sort.'/'.$page.'.html');
}
if($action == '4')
{
header('Location: /singer/'.$singer.'/'.$sort.'/'.$page.'.html');
}
if($action == '5')
{
header('Location: /latest_updates/'.$sort.'/'.$page.'.html');
}
if($commit == 'Search')
{
header('Location: /search/'.$find.'/new2old/1.html');
}
if($commit == 'Album')
{
header('Location: /album/'.$find.'/new2old/1.html');
}
if($commit == 'Singer')
{
header('Location: /singer/'.$find.'/new2old/1.html');
}
if($action == '6')
{
header('Location: /featured/'.$sort.'/'.$page.'.html');
}
if($action == '7')
{
header('Location: /album/'.$album.'/'.$sort.'/'.$page.'.html');
}
?>