<h2>MyMp3King Custom Search : By Google</h2><center><b>Type Anything Here. Ex:</b> Bollywood Songs, Sunny Leone Wallpaper, Jai Ho Ringtone, Angry Bird Game, Android Apps.</center><script>
  (function() {
    var cx = '000854168311830509863:rwdau7oix8a';
    var gcse = document.createElement('script');
    gcse.type = 'text/javascript';
    gcse.async = true;
    gcse.src = 'https://cse.google.com/cse.js?cx=' + cx;
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(gcse, s);
  })();
</script>
<gcse:search></gcse:search>