<?php
if($ss->settings['show_featuredfiles'])
{
$fpage = mt_rand(1,30);
$folder['use_icon'] = 0;
echo '<section class="section_header aligncenter bgcolor_main">Featured</section>
<!-- Nextwave Solutions :: Display Featured List --><section class="item_list">';

$query = $db->simple_select("files", "fid", "isdir='0'");
$total = $db->num_rows($query);

if($total != 0)
{
$start = ($fpage-1)*$ss->settings['files_per_page'];

$options = ['order_by' => 'dcount DESC', 'limit_start' => $start, 'limit' => $ss->settings['featured_files_per_page']];

$query = $db->simple_select("files", "fid, name, tag, size, path, pid, dcount, description", "isdir='0'", $options);
while($file = $db->fetch_array($query))
{
if($file['pid'] != 0)
{
$query2 = $db->simple_select("files", "fid, use_icon", "fid='{$file['pid']}'");
$folder = $db->fetch_array($query2);
if(escape($file['description']) == '')
{
$singer ='';
}
else
{
$singer = '<br/><span class="ar">'.escape($file['description']).'</span>';
}
}
$strname = $ss->settings['title'];
$filename = str_replace("($strname)", "", escape($file['name']));

$fext = pathinfo($filename, PATHINFO_EXTENSION);
echo '<a href="/download/'.$file['fid'].'/'.convert_name($file['name']).'.html" class="listitem boxshadow"><div class="listdetail">';

if(file_exists(SS_ROOT.'/thumbs/'.$file['fid'].'.png'))
{
$ftitle = preg_replace('/\.[^.]+$/','', $filename);
$filethumb = '<div class="listimg leftside"><img src="/siteuploads/thumb/'.$file['fid'].'_1.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>';
}
else if($fext == 'mp3')
{
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-mp3.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>';
}

else if($fext == 'mp4') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-vid.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
}

else if($fext == '3gp') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-vid.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
}
else if($fext == 'avi') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-vid.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
}

else if($fext == 'apk') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-apk.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
}
else if($fext == 'zip') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-arch.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
}
else if($fext == 'rar') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-arch.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
}
else if($fext == '7z') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-arch.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
}
else if($fext == 'jpg') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-img.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
}
else if($fext == 'jpeg') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-img.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
}
else if($fext == 'png') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-img.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
}

else if($fext == 'gif') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-img.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
}
else if($fext == 'jar') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-java.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
}

else if($fext == 'jad') 
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-java.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
}
else
{ 
$filethumb = '<div class="listimg leftside"><img src="/assets/images/65-doc.jpg" title="'.$ftitle.'" alt="'.$file['fid'].'_1"/></div>'; 
}

echo ''.$filethumb.'<div class="list_title">'.$filename.'</div><div class="list_desc">'.convert_filesize($file['size']).'&nbsp;&nbsp;&nbsp;<span class="download-icon"> '.$file['dcount'].'</span></div>';
echo '</div> <div class="clear"></div> </a>';
}
echo '
<!-- Nextwave Solutions :: End Featured List -->';
}
echo '</section><a class="but_more_update aligncenter" href="/featured/new2old/1.html">More Files »</a>';
}
?>