****** Smart Autoindex ******


Developer: SuvaDip Mukherjee

License Source: Nextwave Solutions

Current Version: 2.0

Projected On: 01/05/2016

Updated On: 08/05/2016

Copyright: (c) Nextwave Solutions


****** Features ******

1. Auto MP3 Convert in 64 KBPS, 128 KBPS and 320 KBPS format.

2. Auto Image Watermark and Video Watermark.

3. Auto Thumbnail convert in 5 quality.

4.  Mobile and PC optimized control panel for admin.

5. IP Blocker protection for admin panel.

6. One click installer for beginers. Just 5 sec time needed to install.

7. Full page customization, with custom page title, description, page tag and thumbnail also.

8. Folder hidden function to hide your unwanted directories from your site.

9. Customizable flag icon display times.

10. Thumbnail on / off function to show or hide page header thumbnail within sec.

11. Automatic or manual mp3 tag function, the choice is yours!

12. Included with 3 popular services (1. Weather information, 2. Live cricket score, 3. Phone information)

13. Auto sitemap generator, and specially added a new link in admin panel to ping your sitemap manually, and all of this withing 1 click.

14. Customizable logo, page head tag, header footer for better experience to use your site as your choice.

15. Usefull tools like folder scanner, html source viewer, image editor, seo are included in admin panel.

16. Complete manageble from admin panel.

17. Light weight and fast loading interface.

18. 100% Hassle free.

19. 24/7 Consumer support.

*More features are coming in our next update. Just wait and see.

****** Installation Help ******

First open your site from browser, then you will be redirected to smart autioindex installer page. Then you will need to input your mysql db details and installer api key carefully. Now after clicking on install button you will be redirected to your site home page. That means the script was succesfully installed on your server. Otherwise you will get an error message while installation process. Now login to your ftp server and create two folder with this names, as shown here (thumbs and files). Thats it. Now login to your admin panel with our default password. And change all settings with your choice. Thanks a lot for buying our script. Enjoy!

****** Contact Us ******

Developer: SuvaDip Mukherjee

Email: suvadipmukherjee1996@gmail.com

Phone: 9134379350

Facebook: http://suvadipm.usa.cc