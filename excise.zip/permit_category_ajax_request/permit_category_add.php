<?php

include '../classes/PermitItemCategory.php';

$__percat = new PermitItemCategory();

$_category_name = filter_input(INPUT_POST , 'CATEGORY_NAME');
$_parent_id = filter_input(INPUT_POST , 'PARENT_ID');
$_description = filter_input(INPUT_POST , 'DESCRIPTION');
$_status = filter_input(INPUT_POST , 'STATUS');
$_post_on = filter_input(INPUT_POST , 'POST_ON');
$_post_by = filter_input(INPUT_POST , 'POST_BY');
$_update_on = filter_input(INPUT_POST , 'UPDATE_ON');
$_update_by = filter_input(INPUT_POST , 'UPDATE_BY');


$__percat->setCATEGORY_NAME($_category_name);
$__percat->setPARENT_ID($_parent_id);
$__percat->setDESCRIPTION($_description);
$__percat->setSTATUS($_status);
$__percat->setPOST_ON($_post_on);
$__percat->setPOST_BY($_post_by);
$__percat->setUPDATE_ON($_update_on);
$__percat->setUPDATE_BY($_update_by);

if($__percat->Insert()==1){echo 'Successfully Added';}
else {echo 'Error';}
?>