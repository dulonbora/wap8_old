<?php
include '../classes/payment.php';
$__pay = new Payment();

$ID = filter_input(INPUT_POST , 'ID');
$USER_ID = filter_input(INPUT_POST , 'USER_ID');
$PERMIT_ID = filter_input(INPUT_POST , 'PERMIT_ID');
$LIC_ID = filter_input(INPUT_POST , 'LIC_ID');
$DEPT_CODE = filter_input(INPUT_POST , 'DEPT_CODE');
$ECHALLAN_NO = filter_input(INPUT_POST , 'ECHALLAN_NO');
$LIC_NO = filter_input(INPUT_POST , 'LIC_NO');
$PERMIT_NO = filter_input(INPUT_POST , 'PERMIT_NO');
$AMT = filter_input(INPUT_POST , 'AMT');
$TREASURY_CODE = filter_input(INPUT_POST , 'TREASURY_CODE');
$TREASURY_H_AC = filter_input(INPUT_POST , 'TREASURY_H_AC');
$TREASURY_SH_AC = filter_input(INPUT_POST , 'TREASURY_SH_AC');
$IFSC_CODE = filter_input(INPUT_POST , 'IFSC_CODE');
$BANK_NAME = filter_input(INPUT_POST , 'BANK_NAME');
$BANK_CODE = filter_input(INPUT_POST , 'BANK_CODE');
$TRANS_ID = filter_input(INPUT_POST , 'TRANS_ID');
 
$WALLET_ID = filter_input(INPUT_POST , 'WALLET_ID');
$MOBILE_NO = filter_input(INPUT_POST , 'MOBILE_NO');






$STATUS = 0;
$DATE_TIME_TRANS = time()*1000;
$POST_BY= $_SESSION['USER_ID'];

$already = TRUE;

$__loc->setLOCATION_NAME($_location_name);
$__loc->setPARENT_ID($_parent_id);
$__loc->setDESCRIPTION($_description);
$__loc->setSTATUS($_status);
$__loc->setTYPE($_type);
$__loc->setPOST_ON($_post_on);
$__loc->setPOST_BY($_post_by);
$__loc->setUPDATE_ON($_update_on);
$__loc->setUPDATE_BY($_update_by);


if($_location_name==NULL  || $_location_name==""){echo 'Location name is empty'; $already = FALSE;}

if($_type==1){if($__loc->AlreadyExitDistric($_location_name)==1){echo 'District is already exits'; $already = FALSE;}}
 else {
if($__loc->AlreadyExitPoliceStation($_location_name, $_type, $_parent_id)==1){echo 'Entered Police Station is already exits'; $already = FALSE;}
}




if($already){
    if($__loc->Insert()==1){echo 'Location successfully added';}
else {echo 'Error';}
}


?>

