<?php

include '../classes/User.php';
$__user = new User();

$_email = filter_input(INPUT_POST, 'login_email');
$_password = filter_input(INPUT_POST, 'login_password');

if($__user->login($_email, $_password)==1){
    echo 'Login Successfull';
    $__user->pageRedirect("index.php");
}
 else {
    echo 'Something Went Wrong';    
}

?>





