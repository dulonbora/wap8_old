<?php

include '../classes/User.php';
include '../classes/Location.php';
$__use = new User();
$__location = new Location();

$_email = filter_input(INPUT_POST, 'register_email');
$_password = filter_input(INPUT_POST, 'register_password');
$_cpassword = filter_input(INPUT_POST, 'register_password_repeat');
$_first_name = filter_input(INPUT_POST, 'register_fname');
$_last_name = filter_input(INPUT_POST, 'register_lname');
$_phone = filter_input(INPUT_POST, 'register_phone');
$_access = filter_input(INPUT_POST, 'register_afor');
//$_access_code = filter_input(INPUT_POST, 'ACCESS_CODE');
$_access_code = "YES|YES|YES";
$_act = filter_input(INPUT_POST, 'register_afor');
$_ip = filter_input(INPUT_POST, 'IP');
$_create_on = time() * 1000;
$_last_login = 0;
$_update_on = time() * 1000;
$_active = 1;
//$_active = filter_input(INPUT_POST, 'ACTIVE');

$_dist_code = filter_input(INPUT_POST, 'register_district');
$_dist = $__location->returnLocationId($_dist_code);

$__use->setEMAIL($_email);
$__use->setPASSWORD($_password);
$__use->setFIRST_NAME($_first_name);
$__use->setLAST_NAME($_last_name);
$__use->setPHONE($_phone);
$__use->setACCESS($_access);
$__use->setACCESS_CODE($_access_code);
$__use->setACT($_act);
$__use->setIP($_ip);
$__use->setCREATE_ON($_create_on);
$__use->setLAST_LOGIN($_last_login);
$__use->setUPDATE_ON($_update_on);
$__use->setACTIVE($_active);
$__use->setDIST_CODE($_dist);

if($_password!=$_cpassword){echo 'Password Not Matched';} else {
    
if ($__use->EmailIsUniq($_email) == 1) {echo 'Email Address Is Already Exits';}

else {
    
if ($__use->phoneIsUniq($_phone)==1) {echo 'Phone Number Is Already Exits';}
else {
        if ($__use->Insert() == 1) {echo 'Successfully Inserted';}
 else {
        echo 'Somthing Error';}
    }
    
    
}    

}





