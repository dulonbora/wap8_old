<form action="#" data-parsley-validate="" novalidate="">
                                <div data-dynamic-fields="field_template_a" dynamic-fields-counter="0">
                                <div class="uk-grid uk-grid-medium form_section" data-uk-grid-match="">
                                    <div class="uk-width-9-10" style="min-height: 287px;">
                                        
                                        <h4 class="">Change User Access</h4>
                                        <div class="uk-grid">
                                            <div class="uk-width-1-2">
                                                <div class="parsley-row">
                                                    <select id="Access" class="md-input">
                                <option value="USER">USER</option>
                                <option value="EMPLOYEE">EMPLOYEE</option>
                                <option value="MEMBER">MEMBER</option>
                                <option value="ADVERTISER">ADVERTISER</option>
                            </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                                <div class="uk-grid uk-margin-medium-top">
                                    <div class="uk-width-1-1">
                                        <button id="" type="button" class="md-btn md-btn-primary">Validate</button>
                                    </div>
                                </div>
                            </form>