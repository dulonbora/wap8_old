<?php include '../include/header_site.php';
include '../classes/Mobile_Detect.php';
$mobile = new Mobile_Detect(); 
$id = filter_input(INPUT_GET , 'i');

?>

<a name="top"></a>
<!---------------------------------------------------------------------------->
<?php if($mobile->isMobile()){?>
<div class="android-more-section">
    <div style="text-align: left; font-size: 2em; color: #006400; padding: 10px;" class="mdl-typography--display-1-color-contrast ">You are browsing this site from mobile now, If you want to apply license please fill this form from desktop or laptop</div>  
  </div>
<?php } ?>

        
 
 
 <!---------------------------------------------------------------------------->
        <div style="border: #00695c solid medium; margin-top: 10px; padding-left: 5px; padding-right: 5px;" class="android-more-section">
    <div style="" class="android-section-title mdl-typography--display-1-color-contrast ">Enter Company Details</div>  
    <form action="../license_add/company_add.php" method="POST" id="Applicant_Details" enctype="multipart/form-data">
    
    
    <div class="android-card-container mdl-grid">
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--12-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
      <input class="mdl-textfield__input" type="text" name="COMPANY_NAME" id="COMPANY_NAME" required>
    <label class="mdl-textfield__label" for="COMPANY_NAME">Company Name</label>
  </div>
<input type="hidden" value="<?php echo $id;?>" name="BASIC_ID">

  </div>
    
    
    <div class="android-card-container mdl-grid">
        
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
        <textarea class="mdl-textfield__input" name="POD" type="text" id="POD" required></textarea>
    <label class="mdl-textfield__label" for="POD">Particulars of Directors</label>
  </div>
        
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
        <textarea class="mdl-textfield__input" name="ADDRESS" type="text" id="ADDRESS" required></textarea>
    <label class="mdl-textfield__label" for="ADDRESS">Company Address</label>
  </div>
          
  </div>
    
    <div class="android-card-container mdl-grid">
        
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--12-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
        <textarea class="mdl-textfield__input" name="PARTICULARS_OF_BANK" type="text" id="PARTICULARS_OF_BANK" required></textarea>
    <label class="mdl-textfield__label" for="PARTICULARS_OF_BANK">Particulars of bank account of the company as well as the individual Directors</label>
  </div>
        
   
  </div>
    
        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">
                    1/ Certificate of incorporation issued by the Registrar of Companies and <br/>Memorandum of Articles of Association</label> 
            </div>
            <div class="mdl-textfield mdl-js-textfield mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
        <input class="mdl-textfield__input" type="file" name="COMPANY_CERTIFICATE" id="COMPANY_CERTIFICATE">
        <span class="mdl-textfield__error">Upload</span>
  </div>
        </div>
        
    
        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">
                    1/ Proof of filing the documents with the Registrar of Companies</label> 
            </div>
            <div class="mdl-textfield mdl-js-textfield mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
        <input class="mdl-textfield__input" type="file" name="PROOF_OF_DOC_COMPANY" id="PROOF_OF_DOC_COMPANY">
        <span class="mdl-textfield__error">Upload</span>
  </div>
        </div>
        
    
        
        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">
                    1/ A photocopy of the PAN Card of the company as well as those of the individual<br/> Directors duly attested</label> 
            </div>
            <div class="mdl-textfield mdl-js-textfield mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
        <input class="mdl-textfield__input" type="file" name="PANCARD" id="PANCARD">
        <span class="mdl-textfield__error">Upload</span>
  </div>
        </div>
        
    
        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">
                    1/ A copy of the Board’s resolution, if any, relevant to the application</label> 
            </div>
            <div class="mdl-textfield mdl-js-textfield mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
        <input class="mdl-textfield__input" type="file" name="BORD_RESOLUTION" id="BORD_RESOLUTION">
        <span class="mdl-textfield__error">Upload</span>
  </div>
        </div>
        
    
        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">
                    1/ Income Tax Returns filed by the company for the last three years along with <br/>acknowledgement of the Income Tax Returns</label> 
            </div>
            <div class="mdl-textfield mdl-js-textfield mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
        <input class="mdl-textfield__input" type="file" name="INCOME_TAX_RETURNS" id="INCOME_TAX_RETURNS">
        <span class="mdl-textfield__error">Upload</span>
  </div>
        </div>
        
    
        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">
                    1/ Copy of the latest audited financial statements such as the Balance Sheet<br/> and the Profit & Loss Accounts</label> 
            </div>
            <div class="mdl-textfield mdl-js-textfield mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
        <input class="mdl-textfield__input" type="file" name="BALANCE_SHEET" id="BALANCE_SHEET">
        <span class="mdl-textfield__error">Upload</span>
  </div>
        </div>
        
    
        
    <div class="android-card-container mdl-grid">
        <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                
            </div>
        
    <div class="mdl-textfield mdl-js-textfield mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
        

  </div>
        
    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
        <button type="submit" class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--accent">
  Submit To Process This Application
</button>
  </div>
  </div>

  </form>

 
  </div>
 

 



<script type="text/javascript">
    $(document).ready(CheckCat());
    $(document).ready(CheckDist());
    $(document).ready(HibeBarDatails());
    $(document).ready(HibeCriminalBar());
    $(document).ready(SameAddress());


    function CheckCat() {
        $(document).on("change", "#lcategory", function () {
            var id = $(this).val();
            $.ajax({
                type: 'GET',
                url: "../license_category_ajax_request/loadalsubl_in_apply.php",
                data: {id: id},
                error: function (html) {
                    $("#AllSubCat").html(html);
                },
                success: function (html) {
                    $("#AllSubCat").html(html);
                }

            });

        });

    }
    function CheckDist() {
        $(document).on("change", "#District", function () {
            var id = $(this).val();
            //alert(id);
            $.ajax({
                type: 'GET',
                url: "../location_ajax_request/load_add_subdist_apply.php",
                data: {id: id},
                error: function (html) {
                    $("#Police_Station_html").html(html);
                },
                success: function (html) {
                    $("#Police_Station_html").html(html);
                }

            });

        });

    }
    
    function HibeBarDatails() {
        $("#OtherLicenseDetails").hide(); 
        $(document).on("click", "#OtherLicenseDetailsYes", function(){
   if( $(this).is(':checked')){
      $("#OtherLicenseDetails").show(); 
   }
   else{
       $("#OtherLicenseDetails").hide(); 
   }
    });
    }
    
    function HibeCriminalBar() {
        $("#Criminal_Case_YesHtml").hide(); 
        $(document).on("click", "#Criminal_Case_Yes", function(){
   if( $(this).is(':checked')){
      $("#Criminal_Case_YesHtml").show(); 
   }
   else{
       $("#Criminal_Case_YesHtml").hide(); 
   }
    });
    }
    
    function SameAddress() {
        $(document).on("click", "#AddressDo", function(){
   if( $(this).is(':checked')){
      var i = $("#ADDRESS_P").val(); 
      $("#ADDRESS_C").html(i); 
   }
   else{
       $("#ADDRESS_C").html(""); 
   }
    });
    }
    
    
    function SameAddress() {
        $(document).on("focusout", "#AGE", function(){
    if($("#AGE").text() < 18){
       $("#AgeError").html("you must be 18+");
   }
   
    });
    }


</script>
<?php include '../include/footer_site.php'; ?>
