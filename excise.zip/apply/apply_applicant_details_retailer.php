<?php include '../include/header_site.php';
include '../classes/Mobile_Detect.php';
$mobile = new Mobile_Detect(); 
$id = filter_input(INPUT_GET , 'i');

?>

<a name="top"></a>
<!---------------------------------------------------------------------------->
<?php if($mobile->isMobile()){?>
<div class="android-more-section">
    <div style="text-align: left; font-size: 2em; color: #006400; padding: 10px;" class="mdl-typography--display-1-color-contrast ">You are browsing this site from mobile now, If you want to apply license please fill this form from desktop or laptop</div>  
  </div>
<?php } ?>

        
<div class="container-head">
    <div class="android-section-title mdl-typography--display-1-color-contrast" style="text-align: center; color: #EEE;">Applicant Details</div>  
</div> 
 <!---------------------------------------------------------------------------->
<div class="android-more-section containermet" style="margin-top: -250px; z-index: 1; border: #607D8B solid medium;">
    <div style="" class="android-section-title mdl-typography--display-1-color-contrast ">Enter Applicant Details</div>  
    
    <div class="mdl-tabs mdl-js-tabs mdl-js-ripple-effect">
  <!-- Tab Bars -->
  <div class="mdl-tabs__tab-bar">
      <a class="mdl-tabs__tab is-active">Applicant Details</a>
      <a class="mdl-tabs__tab">Site Details</a>
      <a class="mdl-tabs__tab">Company Details</a>
      <a class="mdl-tabs__tab">Partners Details</a>
      <a class="mdl-tabs__tab">Challan Details</a>
  </div>
  </div>
    
    <form action="../license_add/applicant_details_add.php" method="POST" id="Applicant_Details" enctype="multipart/form-data">
    
    
    <div class="android-card-container mdl-grid">
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
      <input class="mdl-textfield__input" type="text" name="FIRST_NAME" id="FIRST_NAME" required>
    <label class="mdl-textfield__label" for="FIRST_NAME">First Name</label>
  </div>
<input type="hidden" value="<?php echo $id;?>" name="BASIC_ID">

<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
      <input class="mdl-textfield__input" type="text" name="MIDDLE_NAME" id="MIDDLE_NAME" required>
    <label class="mdl-textfield__label" for="MIDDLE_NAME">Middle Name</label>
  </div>
      
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
      <input class="mdl-textfield__input" type="text" name="LAST_NAME" id="LAST_NAME" required>
    <label class="mdl-textfield__label" for="LAST_NAME">Last Name</label>
  </div>
  </div>
    
    
    <div class="android-card-container mdl-grid">
  <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
      <input class="mdl-textfield__input" type="text" name="PHONE" id="PHONE" required>
    <label class="mdl-textfield__label" for="PHONE">Phone No</label>
  </div>
      
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
      <input class="mdl-textfield__input" type="text" name="EMAIL" id="EMAIL" required>
    <label class="mdl-textfield__label" for="EMAIL">Email Address</label>
  </div>
  
  </div>
    
    <div class="android-card-container mdl-grid">
  <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
      <input class="mdl-textfield__input" type="text" name="PARENTS_NAME" id="PARENTS_NAME" required>
    <label class="mdl-textfield__label" for="PARENTS_NAME">Father Name</label>
  </div>
  
        
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--3-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
      <input class="mdl-textfield__input" type="text" name="AGE" id="AGE" pattern="-?[0-9]*(\.[0-9]+)?" required>
    <label class="mdl-textfield__label" for="AGE">Applicant Age</label>
    <span id="AgeError" class="mdl-textfield__error">Input is not a number!</span>
  </div>
  
      
        
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--2-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
      <select id="SiteType" name="RESIDENTIAL" class="mdl-textfield__input" required>
                    <option value="" disabled selected>Residential Status</option>
                    <option value="Resident">Resident</option>
                    <option value="Non-Resident">Non-Resident</option>
                </select>       
            </div>
      
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--3-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
      <select id="SiteType" name="NATIONALITY" class="mdl-textfield__input" required>
                    <option value="" disabled selected>Nationality</option>
                    <option value="Indian">Indian</option>
                    <option value="Person of Indian Nation">Person of Indian Nation</option>
                </select>       
            </div>
      
  
  </div>
    
    <div class="android-card-container mdl-grid">
    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
        <textarea class="mdl-textfield__input" name="ADDRESS_P" type="text" id="ADDRESS_P" required></textarea>
    <label class="mdl-textfield__label" for="ADDRESS_P">Permanent Address</label>
  </div>
        
    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--1-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <label id="aby" class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="AddressDo">
                    <input type="checkbox" id="AddressDo" class="mdl-checkbox__input addtional_bar">
                    <span class="mdl-checkbox__label">Do</span>
                </label>
  </div>
    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--5-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
        <textarea class="mdl-textfield__input" type="text" name="ADDRESS_C" id="ADDRESS_C" required></textarea>
    <label class="mdl-textfield__label" for="ADDRESS_C">Current Address</label>
  </div>
  </div>
    
    
    <div class="android-card-container mdl-grid">
    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--12-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
        <textarea class="mdl-textfield__input" type="text" name="QULIFICATION" id="QULIFICATION" required></textarea>
    <label class="mdl-textfield__label" for="QULIFICATION">Highest Educational qualification</label>
  </div>
        
  </div>
    
    <div class="android-card-container mdl-grid">
  <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
      <input class="mdl-textfield__input" type="text" name="PAN_NO" id="PAN_NO" required>
    <label class="mdl-textfield__label" for="PAN_NO">Pan No</label>
  </div>
      
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
      <input class="mdl-textfield__input" type="text" name="ANNUAL_INCOME" id="ANNUAL_INCOME" required>
    <label class="mdl-textfield__label" for="ANNUAL_INCOME">Annual Income</label>
  </div>
  
  </div>
            
        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">Whether the Applicant holds or held any Excise license(s) in Assam/in<br/>any other State of India</label> 

            </div>

        <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label id="aby" class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="OtherLicenseDetailsYes">
                    <input type="checkbox" id="OtherLicenseDetailsYes" class="mdl-checkbox__input addtional_bar">
                    <span class="mdl-checkbox__label">If yes mark it</span>
                </label>
            </div>


        </div>
        
        <div id="OtherLicenseDetails" class="android-card-container mdl-grid">
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--2-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <textarea class="mdl-textfield__input" type="text" name="OTHER_LICENSE_NO" id="OTHER_LICENSE_NO"></textarea>
                <label class="mdl-textfield__label" for="OTHER_LICENSE_NO">Licensee Id</label>
            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--10-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <textarea class="mdl-textfield__input" type="text" name="OTHER_LICENSE_DEC" id="OTHER_LICENSE_DEC"></textarea>
                <label class="mdl-textfield__label" for="OTHER_LICENSE_DEC">If so, Full Particulars thereof and if the License(s) is/are not in Force now, how it/they Terminated</label>
            </div>
        </div>
        
     
        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">Whether any of the following Relatives hold any Excise License in Assam</label> 

            </div>
            
    
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <select id="SiteType" name="IS_RELLATIV_LICENSE" class="mdl-textfield__input" required>
                    <option value="" disabled selected>Select Here</option>
                    <option value="1">Yes</option>
                    <option value="0">No</option>
                </select>       
            </div>

        </div>
        
        <div class="android-card-container mdl-grid">
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c; text-wrap: inherit;" class="mdl-textfield__label" for="First_Name">Whether the Applicant was ever convicted by a criminal court<br/> for a non-bailable offence</label> 

            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label id="aby" class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="Criminal_Case_Yes">
                    <input type="checkbox" id="Criminal_Case_Yes" class="mdl-checkbox__input addtional_bar">
                    <span class="mdl-checkbox__label">if Yes Mark it</span>
                </label>
            </div>
        </div>
        
        <div id="Criminal_Case_YesHtml" class="android-card-container mdl-grid">
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--12-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <textarea class="mdl-textfield__input" type="text" name="INVLOPMENT_IN_CRIMINALISIM" id="INVLOPMENT_IN_CRIMINALISIM"></textarea>
                <label class="mdl-textfield__label" for="INVLOPMENT_IN_CRIMINALISIM">If so, full particulars thereof If so,</label>
            </div>

        </div>
        
        <div class="android-card-container mdl-grid">
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--12-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <textarea class="mdl-textfield__input" type="text" name="SPECIAL_CLAIM" id="SPECIAL_CLAIM"></textarea>
                <label class="mdl-textfield__label" for="SPECIAL_CLAIM">Special Claim, if any</label>
            </div>

        </div>
        
        
        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">
                    1/ Proof of financial capacity of the applicant</label> 
            </div>
            <div class="mdl-textfield mdl-js-textfield mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
        <input class="mdl-textfield__input" type="file" name="PROOF_OF_CAPACITY" id="PROOF_OF_CAPACITY">
        <span class="mdl-textfield__error">Upload</span>
  </div>
        </div>
        
        
        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">
                    1/ Medical Fitness certificate</label> 
            </div>
            <div class="mdl-textfield mdl-js-textfield mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
        <input class="mdl-textfield__input" type="file" name="PROOF_OF_MEDICAL" id="PROOF_OF_MEDICAL">
        <span class="mdl-textfield__error">Upload</span>
  </div>
        </div>
        
        
        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">
                    1/ Proof of solvency of the applicant</label> 
            </div>
            <div class="mdl-textfield mdl-js-textfield mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
        <input class="mdl-textfield__input" type="file" name="PROOF_OF_SOLVENCY" id="PROOF_OF_SOLVENCY">
        <span class="mdl-textfield__error">Upload</span>
  </div>
        </div>
        
        
        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">
                    1/ Police report on character and antecedents of the applicant</label> 
            </div>
            <div class="mdl-textfield mdl-js-textfield mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
        <input class="mdl-textfield__input" type="file" name="PROOF_OF_POLICE" id="PROOF_OF_POLICE">
        <span class="mdl-textfield__error">Upload</span>
  </div>
        </div>
        
        
    
        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">
                    1/ No-objection certificate from the Municipal Corporation, Municipality, Town Committee, Gaon Panchayat concerned</label> 
            </div>
            <div class="mdl-textfield mdl-js-textfield mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
        <input class="mdl-textfield__input" type="file" name="OTHER_LICENSE_TAX" id="OTHER_LICENSE_TAX">
        <span class="mdl-textfield__error">Upload</span>
  </div>
        </div>
        
        
    
    <div class="android-card-container mdl-grid">
    <div class="mdl-textfield mdl-js-textfield mdl-cell mdl-cell--8-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
        <input class="mdl-textfield__input" type="file" name="PHOTO_LINK" id="PHOTO_LINK">
        <span class="mdl-textfield__error">Upload Your Passport Photo</span>

  </div>
        
    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
        <a href="apply_sitebasic_info_retailer.php" class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--accent">
  Submit To Process This Application
</a>
  </div>
  </div>

  </form>

 
  </div>
 

 



<script type="text/javascript">
    $(document).ready(CheckCat());
    $(document).ready(CheckDist());
    $(document).ready(HibeBarDatails());
    $(document).ready(HibeCriminalBar());
    $(document).ready(SameAddress());


    function CheckCat() {
        $(document).on("change", "#lcategory", function () {
            var id = $(this).val();
            $.ajax({
                type: 'GET',
                url: "../license_category_ajax_request/loadalsubl_in_apply.php",
                data: {id: id},
                error: function (html) {
                    $("#AllSubCat").html(html);
                },
                success: function (html) {
                    $("#AllSubCat").html(html);
                }

            });

        });

    }
    function CheckDist() {
        $(document).on("change", "#District", function () {
            var id = $(this).val();
            //alert(id);
            $.ajax({
                type: 'GET',
                url: "../location_ajax_request/load_add_subdist_apply.php",
                data: {id: id},
                error: function (html) {
                    $("#Police_Station_html").html(html);
                },
                success: function (html) {
                    $("#Police_Station_html").html(html);
                }

            });

        });

    }
    
    function HibeBarDatails() {
        $("#OtherLicenseDetails").hide(); 
        $(document).on("click", "#OtherLicenseDetailsYes", function(){
   if( $(this).is(':checked')){
      $("#OtherLicenseDetails").show(); 
   }
   else{
       $("#OtherLicenseDetails").hide(); 
   }
    });
    }
    
    function HibeCriminalBar() {
        $("#Criminal_Case_YesHtml").hide(); 
        $(document).on("click", "#Criminal_Case_Yes", function(){
   if( $(this).is(':checked')){
      $("#Criminal_Case_YesHtml").show(); 
   }
   else{
       $("#Criminal_Case_YesHtml").hide(); 
   }
    });
    }
    
    function SameAddress() {
        $(document).on("click", "#AddressDo", function(){
   if( $(this).is(':checked')){
      var i = $("#ADDRESS_P").val(); 
      $("#ADDRESS_C").html(i); 
   }
   else{
       $("#ADDRESS_C").html(""); 
   }
    });
    }
    
    
    function SameAddress() {
        $(document).on("focusout", "#AGE", function(){
    if($("#AGE").text() < 18){
       $("#AgeError").html("you must be 18+");
   }
   
    });
    }


</script>
<?php include '../include/footer_site.php'; ?>
