<?php include '../include/header_site.php';
include '../classes/Mobile_Detect.php';
$mobile = new Mobile_Detect(); 
$id = filter_input(INPUT_GET , 'i');

?>

<a name="top"></a>
<!---------------------------------------------------------------------------->
<?php if($mobile->isMobile()){?>
<div class="android-more-section">
    <div style="text-align: left; font-size: 2em; color: #006400; padding: 10px;" class="mdl-typography--display-1-color-contrast ">You are browsing this site from mobile now, If you want to apply license please fill this form from desktop or laptop</div>  
  </div>
<?php } ?>

        
 
 
 <!---------------------------------------------------------------------------->
        <div style="border: #00695c solid medium; margin-top: 10px; padding-left: 5px; padding-right: 5px;" class="android-more-section">
    <div style="" class="android-section-title mdl-typography--display-1-color-contrast ">Enter Pratner Details</div>  
    <form action="../license_add/partners_add.php" method="POST" id="Applicant_Details" enctype="multipart/form-data">
    
    
    <div class="android-card-container mdl-grid">
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
      <input class="mdl-textfield__input" type="text" name="FIRST_NAME" id="FIRST_NAME" required>
    <label class="mdl-textfield__label" for="FIRST_NAME">First Name</label>
  </div>
<input type="hidden" value="<?php echo $id;?>" name="BASIC_ID">

<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
      <input class="mdl-textfield__input" type="text" name="MIDDLE_NAME" id="MIDDLE_NAME" required>
    <label class="mdl-textfield__label" for="MIDDLE_NAME">Middle Name</label>
  </div>
      
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
      <input class="mdl-textfield__input" type="text" name="LAST_NAME" id="LAST_NAME" required>
    <label class="mdl-textfield__label" for="LAST_NAME">Last Name</label>
  </div>
  </div>
    
    
    <div class="android-card-container mdl-grid">
        
  <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
      <select id="TYPE" name="TYPE" class="mdl-textfield__input" required>
                    <option value="" disabled selected>Select he shall deal with Excise matters</option>
                    <option value="1">Yes</option>
                    <option value="0">No he is Pratner only</option>
                </select>       
            </div>
        
  <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
      <input class="mdl-textfield__input" type="text" name="PHONE" id="PHONE" required>
    <label class="mdl-textfield__label" for="PHONE">Phone No</label>
  </div>
      
  
  
  </div>
    
    <div class="android-card-container mdl-grid">
        
        <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
      <input class="mdl-textfield__input" type="text" name="EMAIL" id="EMAIL" required>
    <label class="mdl-textfield__label" for="EMAIL">Email Address</label>
  </div>
  
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--3-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
      <input class="mdl-textfield__input" type="text" name="AGE" id="AGE" pattern="-?[0-9]*(\.[0-9]+)?" required>
    <label class="mdl-textfield__label" for="AGE">Applicant Age</label>
    <span id="AgeError" class="mdl-textfield__error">Input is not a number!</span>
  </div>
  
              
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--3-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
      <select id="SiteType" name="NATIONALITY" class="mdl-textfield__input" required>
                    <option value="" disabled selected>Nationality</option>
                    <option value="Indian">Indian</option>
                    <option value="Person of Indian Nation">Person of Indian Nation</option>
                </select>       
            </div>
      
  
  </div>
    
    <div class="android-card-container mdl-grid">
    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
        <textarea class="mdl-textfield__input" name="ADDRESS_P" type="text" id="ADDRESS_P" required></textarea>
    <label class="mdl-textfield__label" for="ADDRESS_P">Permanent Address</label>
  </div>
        
    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--1-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <label id="aby" class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="AddressDo">
                    <input type="checkbox" id="AddressDo" class="mdl-checkbox__input addtional_bar">
                    <span class="mdl-checkbox__label">Do</span>
                </label>
  </div>
    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--5-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
        <textarea class="mdl-textfield__input" type="text" name="ADDRESS_C" id="ADDRESS_C" required></textarea>
    <label class="mdl-textfield__label" for="ADDRESS_C">Current Address</label>
  </div>
  </div>
    
    
    <div class="android-card-container mdl-grid">
    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--12-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
        <textarea class="mdl-textfield__input" type="text" name="QULIFICATION" id="QULIFICATION" required></textarea>
    <label class="mdl-textfield__label" for="QULIFICATION">Highest Educational qualification</label>
  </div>
        
  </div>
    
   
     
        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">
                    1/ Upload a copy of the partnership deed, if any</label> 
            </div>
            <div class="mdl-textfield mdl-js-textfield mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
        <input class="mdl-textfield__input" type="file" name="PARTNERSHIP_DEED" id="PARTNERSHIP_DEED">
        <span class="mdl-textfield__error">Upload</span>
  </div>
        </div>
        
        
        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">
                   2/ A copy of the registration certificate duly notarized by a Notary showing <br/>the registration of the Partnership Deed</label> 
            </div>
            <div class="mdl-textfield mdl-js-textfield mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
        <input class="mdl-textfield__input" type="file" name="PARTNERSHIP_CERTIFICATE" id="PARTNERSHIP_CERTIFICATE">
        <span class="mdl-textfield__error">Upload</span>
  </div>
        </div>
        
        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">
                   3/ Statement of net worth of partners duly certified by a Chartered Accountant</label> 
            </div>
            <div class="mdl-textfield mdl-js-textfield mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
        <input class="mdl-textfield__input" type="file" name="STATEMENT_OF_NET_WORTH" id="STATEMENT_OF_NET_WORTH">
        <span class="mdl-textfield__error">Upload</span>
  </div>
        </div>
        
        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">
                   4/ A photocopy of the PAN Card duly attested by a gazetted officer</label> 
            </div>
            <div class="mdl-textfield mdl-js-textfield mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
        <input class="mdl-textfield__input" type="file" name="PANCARD" id="PANCARD">
        <span class="mdl-textfield__error">Upload</span>
  </div>
        </div>
        
    
        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">
                   4/ Copies of Income Tax Returns for the last three years<br/> along with acknowledgement certificates</label> 
            </div>
            <div class="mdl-textfield mdl-js-textfield mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
        <input class="mdl-textfield__input" type="file" name="INCOME_TAX_RETURNS" id="INCOME_TAX_RETURNS">
        <span class="mdl-textfield__error">Upload</span>
  </div>
        </div>
        
    
        
        
    
    <div class="android-card-container mdl-grid">
        <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">
                    5/ Upload Passport Photo</label> 
            </div>
        
    <div class="mdl-textfield mdl-js-textfield mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
        <input class="mdl-textfield__input" type="file" name="PHOTO_LINK" id="PHOTO_LINK">
        <span class="mdl-textfield__error">Upload Your Passport Photo</span>

  </div>
    
  </div>
        
    <div class="android-card-container mdl-grid">
        <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <button type="submit" class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--accent">
  Add More Partner
</button>
            </div>
        
    <div class="mdl-textfield mdl-js-textfield mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
        

  </div>
        
    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
        <button type="submit" class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--accent">
  Submit To Process This Application
</button>
  </div>
  </div>

  </form>

 
  </div>
 

 



<script type="text/javascript">
    $(document).ready(CheckCat());
    $(document).ready(CheckDist());
    $(document).ready(HibeBarDatails());
    $(document).ready(HibeCriminalBar());
    $(document).ready(SameAddress());


    function CheckCat() {
        $(document).on("change", "#lcategory", function () {
            var id = $(this).val();
            $.ajax({
                type: 'GET',
                url: "../license_category_ajax_request/loadalsubl_in_apply.php",
                data: {id: id},
                error: function (html) {
                    $("#AllSubCat").html(html);
                },
                success: function (html) {
                    $("#AllSubCat").html(html);
                }

            });

        });

    }
    function CheckDist() {
        $(document).on("change", "#District", function () {
            var id = $(this).val();
            //alert(id);
            $.ajax({
                type: 'GET',
                url: "../location_ajax_request/load_add_subdist_apply.php",
                data: {id: id},
                error: function (html) {
                    $("#Police_Station_html").html(html);
                },
                success: function (html) {
                    $("#Police_Station_html").html(html);
                }

            });

        });

    }
    
    function HibeBarDatails() {
        $("#OtherLicenseDetails").hide(); 
        $(document).on("click", "#OtherLicenseDetailsYes", function(){
   if( $(this).is(':checked')){
      $("#OtherLicenseDetails").show(); 
   }
   else{
       $("#OtherLicenseDetails").hide(); 
   }
    });
    }
    
    function HibeCriminalBar() {
        $("#Criminal_Case_YesHtml").hide(); 
        $(document).on("click", "#Criminal_Case_Yes", function(){
   if( $(this).is(':checked')){
      $("#Criminal_Case_YesHtml").show(); 
   }
   else{
       $("#Criminal_Case_YesHtml").hide(); 
   }
    });
    }
    
    function SameAddress() {
        $(document).on("click", "#AddressDo", function(){
   if( $(this).is(':checked')){
      var i = $("#ADDRESS_P").val(); 
      $("#ADDRESS_C").html(i); 
   }
   else{
       $("#ADDRESS_C").html(""); 
   }
    });
    }
    
    
    function SameAddress() {
        $(document).on("focusout", "#AGE", function(){
    if($("#AGE").text() < 18){
       $("#AgeError").html("you must be 18+");
   }
   
    });
    }


</script>
<?php include '../include/footer_site.php'; ?>
