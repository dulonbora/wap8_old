<?php
include '../classes/LicenceCategory.php';
$id = filter_input(INPUT_GET, 'id');

$lcat = new LicenceCategory();
$location_ViewRs = $lcat->allFecthByParent($id);
    ?>            

<select id="lscategory" class="mdl-textfield__input">
          <option value="" disabled selected>Select Category For</option>
          <?php foreach($location_ViewRs as $rows){ ?>
              <option value="<?php echo  $rows['ID'];?>"><?php echo  $rows['CATEGORY_NAME'];?></option>
    <?php } ?>

        </select>
    
