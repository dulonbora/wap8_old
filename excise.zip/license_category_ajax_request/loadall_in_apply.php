<?php
include '../classes/LicenceCategory.php';
$id = filter_input(INPUT_GET , 'id');

$lcat = new LicenceCategory();
$lcat_ViewRs = $lcat->allFecth();
    ?>                             
    <?php foreach($lcat_ViewRs as $rows){ ?>
              <option value="<?php echo  $rows['ID'];?>"><?php echo  $rows['CATEGORY_NAME'];?></option>

    <?php } ?>



?>