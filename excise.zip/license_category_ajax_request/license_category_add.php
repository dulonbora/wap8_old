<?php

include '../classes/LicenceCategory.php';

$__lic = new LicenceCategory();

$_category_name = filter_input(INPUT_POST , 'CATEGORY_NAME');
$_parent_id = filter_input(INPUT_POST , 'PARENT_ID');
//$_description = filter_input(INPUT_POST , 'DESCRIPTION');
$_description = "";
$_status = 1;
//$_status = filter_input(INPUT_POST , 'STATUS');
$_post_on = time()*1000;
//$_post_by = filter_input(INPUT_POST , 'POST_BY');
$_post_by = 1;
$_update_on = time()*1000;
$_update_by = 1;
//$_update_by = filter_input(INPUT_POST , 'UPDATE_BY');
$_type = filter_input(INPUT_POST , 'TYPE');

$already = TRUE;

$__lic->setCATEGORY_NAME($_category_name);
$__lic->setPARENT_ID($_parent_id);
$__lic->setDESCRIPTION($_description);
$__lic->setSTATUS($_status);
$__lic->setPOST_ON($_post_on);
$__lic->setPOST_BY($_post_by);
$__lic->setUPDATE_ON($_update_on);
$__lic->setUPDATE_BY($_update_by);


if($_category_name==NULL  || $_category_name==""){echo 'Category name is empty'; $already = FALSE;}

if($_type==1){if($__lic->AlreadyExitCategory($_category_name)==1){echo 'Category is already exits'; $already = FALSE;}}
 else {
if($__lic->AlreadyExitSubcategory($_category_name, $_parent_id)==1){echo 'Subcategory is already exits'; $already = FALSE;}
}




if($already){
    if($__lic->Insert()==1){echo 'Category successfully added';}
else {echo 'Error';}
}
?>