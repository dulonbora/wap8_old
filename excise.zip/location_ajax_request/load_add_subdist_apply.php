<?php
include '../classes/Location.php';
$id = filter_input(INPUT_GET , 'id');

$lcat = new Location();
$lcat_ViewRs = $lcat->allFecthByParent($id);
    ?>   

 
<select id="lscategory" name="Police_STATION" class="mdl-textfield__input">
          <option value="" disabled selected>Select Police Station</option>
          <?php foreach($lcat_ViewRs as $rows){ ?>
              <option value="<?php echo  $rows['ID'];?>"><?php echo  $rows['LOCATION_NAME'];?></option>
    <?php } ?>

        </select>
    

