<?php
include '../classes/Location.php';
$id = filter_input(INPUT_GET , 'id');

$location = new Location();
$location_ViewRs = $location->allFecth(1);

if($id==1){
    echo '<input type="hidden" id="PARENT_ID" value="0" name="PARENT_ID"/>';
}else {
    ?>                             
<label for="PARENT_ID" class="uk-form-label">Select District</label>
<select class="uk-form-width-large md-input" name="PARENT_ID" id="PARENT_ID">
    <?php foreach($location_ViewRs as $rows){ ?>
<option value="<?php echo  $rows['ID'];?>"><?php echo  $rows['LOCATION_NAME'];?></option>
    <?php } ?>
</select>

<?php    
}

?>