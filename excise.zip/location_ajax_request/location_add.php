<?php
include '../classes/Location.php';
$__loc = new Location();

$_location_name = filter_input(INPUT_POST , 'LOCATION_NAME');
$_parent_id = filter_input(INPUT_POST , 'PARENT_ID');
$_description = "";
$_status = 1;
$_type = filter_input(INPUT_POST , 'TYPE');
$_post_on = time()*1000;
$_post_by = 0;
//$_post_by = filter_input(INPUT_POST , 'POST_BY');
$_update_on = time()*1000;
//$_update_by = filter_input(INPUT_POST , 'UPDATE_BY');
$_update_by = 0;
$already = TRUE;

$__loc->setLOCATION_NAME($_location_name);
$__loc->setPARENT_ID($_parent_id);
$__loc->setDESCRIPTION($_description);
$__loc->setSTATUS($_status);
$__loc->setTYPE($_type);
$__loc->setPOST_ON($_post_on);
$__loc->setPOST_BY($_post_by);
$__loc->setUPDATE_ON($_update_on);
$__loc->setUPDATE_BY($_update_by);


if($_location_name==NULL  || $_location_name==""){echo 'Location name is empty'; $already = FALSE;}

if($_type==1){if($__loc->AlreadyExitDistric($_location_name)==1){echo 'District is already exits'; $already = FALSE;}}
 else {
if($__loc->AlreadyExitPoliceStation($_location_name, $_type, $_parent_id)==1){echo 'Entered Police Station is already exits'; $already = FALSE;}
}




if($already){
    if($__loc->Insert()==1){echo 'Location successfully added';}
else {echo 'Error';}
}


?>