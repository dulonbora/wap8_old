<?php
include '../classes/Location.php';
$location = new Location();
$location_ViewRs = $location->allFecth(1);
    ?>                             
    <?php foreach($location_ViewRs as $rows){ ?>
    <li class="mdl-menu__item" data-val="<?php echo  $rows['LOCATION_NAME'];?>"><?php echo  $rows['LOCATION_NAME'];?></li>
    <?php } ?>

