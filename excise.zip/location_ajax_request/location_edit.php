<?php
include '../classes/Location.php';

$__loc = new Location();

$_location_name = filter_input(INPUT_POST , 'LOCATION_NAME');
$_parent_id = filter_input(INPUT_POST , 'PARENT_ID');
$_description = filter_input(INPUT_POST , 'DESCRIPTION');
$_status = filter_input(INPUT_POST , 'STATUS');
$_type = filter_input(INPUT_POST , 'TYPE');
$_update_on = time()*1000;
$_update_by = filter_input(INPUT_POST , 'UPDATE_BY');


$__loc->setLOCATION_NAME($_location_name);
$__loc->setPARENT_ID($_parent_id);
$__loc->setDESCRIPTION($_description);
$__loc->setSTATUS($_status);
$__loc->setTYPE($_type);
$__loc->setUPDATE_ON($_update_on);
$__loc->setUPDATE_BY($_update_by);

if($__loc->Update($_update_by)==1){echo 'Successfully Updated';}
else {echo 'Error';}

?>