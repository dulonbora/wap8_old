<?php
include '../classes/Pages.php';
$__pag = new Pages();

$_headline = filter_input(INPUT_POST , 'HEADLINE');
$_content = filter_input(INPUT_POST , 'CONTENT');
$_category = filter_input(INPUT_POST , 'CATEGORY');
$_status = filter_input(INPUT_POST , 'STATUS');
$_type = filter_input(INPUT_POST , 'TYPE');
$_comment = filter_input(INPUT_POST , 'COMMENT');
$_id = filter_input(INPUT_POST , 'ID');


$__pag->setHEADLINE($_headline);
$__pag->setCONTENT($_content);
$__pag->setCATEGORY($_category);
$__pag->setSTATUS($_status);
$__pag->setTYPE($_type);
$__pag->setCOMMENT($_comment);
$__pag->setID($_id);

if($__pag->Update($_id)==1){echo 'Successfully Added';}


?>