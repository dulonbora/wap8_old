<?php
include '../classes/Pages.php';
$__pag = new Pages();

$_headline = filter_input(INPUT_GET , 'page_name');
$_content = filter_input(INPUT_GET , 'pageContant');
$_img_id = 0;
$_total_visit = 0;
$_category = 1;
//$_category = filter_input(INPUT_POST , 'CATEGORY');
$_post_on = time()*1000;
$_post_by = 1;
//$_post_by = filter_input(INPUT_POST , 'POST_BY');
//$_status = filter_input(INPUT_POST , 'STATUS');
$_status = 1;
//$_type = filter_input(INPUT_POST , 'TYPE');
$_type = 1;
//$_comment = filter_input(INPUT_POST , 'COMMENT');
$_comment = 1;


$__pag->setHEADLINE($_headline);
$__pag->setCONTENT($_content);
$__pag->setIMAGE_ID($_img_id);
$__pag->setTOTAL_VISIT($_total_visit);
$__pag->setCATEGORY($_category);
$__pag->setPOST_ON($_post_on);
$__pag->setPOST_BY($_post_by);
$__pag->setSTATUS($_status);
$__pag->setTYPE($_type);
$__pag->setCOMMENT($_comment);


if($__pag->Insert()==1){echo 'Successfully Inserted';}
 else {echo $_headline."+".$_content;}
 
    ?>