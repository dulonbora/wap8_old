<?php
if(!isset($_SESSION)){session_start();}
include '../classes/Company.php';
$__com = new Company();

$_basic_id = filter_input(INPUT_POST , 'BASIC_ID');
$_company_name = filter_input(INPUT_POST , 'COMPANY_NAME');
$_address = filter_input(INPUT_POST , 'ADDRESS');
$_pod = filter_input(INPUT_POST , 'POD');
$_company_certificate = "";
$_proof_of_doc_company = "";
$_particulars_of_bank = filter_input(INPUT_POST , 'PARTICULARS_OF_BANK');
$_pancard = "";
$_balance_sheet = "";
$_income_tax_returns = "";
$_bord_resolution = "";
$_photo_link = "";
$_post_on = time()*1000;;
$_post_by = $_SESSION['USER_ID'];
$_update_on = time()*1000;;
$_update_by = $_SESSION['USER_ID'];


if(isset($_FILES['COMPANY_CERTIFICATE'])){
$file_name=$_FILES["COMPANY_CERTIFICATE"]["name"];
$temp_name=$_FILES["COMPANY_CERTIFICATE"]["tmp_name"];
$ext= end((explode(".", $file_name)));
$imagename = time().$ext;
$target_path = "../user_doc/".$imagename;
if(move_uploaded_file($temp_name, $target_path)) {
$_company_certificate = $imagename;
}
}

if(isset($_FILES['PROOF_OF_DOC_COMPANY'])){
$file_name=$_FILES["PROOF_OF_DOC_COMPANY"]["name"];
$temp_name=$_FILES["PROOF_OF_DOC_COMPANY"]["tmp_name"];
$ext= end((explode(".", $file_name)));
$imagename = time().$ext;
$target_path = "../user_doc/".$imagename;
if(move_uploaded_file($temp_name, $target_path)) {
$_proof_of_doc_company = $imagename;
}
}

if(isset($_FILES['PANCARD'])){
$file_name=$_FILES["PANCARD"]["name"];
$temp_name=$_FILES["PANCARD"]["tmp_name"];
$ext= end((explode(".", $file_name)));
$imagename = time().$ext;
$target_path = "../user_doc/".$imagename;
if(move_uploaded_file($temp_name, $target_path)) {
$_pancard = $imagename;
}
}

if(isset($_FILES['PANCARD'])){
$file_name=$_FILES["PANCARD"]["name"];
$temp_name=$_FILES["PANCARD"]["tmp_name"];
$ext= end((explode(".", $file_name)));
$imagename = time().$ext;
$target_path = "../user_doc/".$imagename;
if(move_uploaded_file($temp_name, $target_path)) {
$_pancard = $imagename;
}
}

if(isset($_FILES['BALANCE_SHEET'])){
$file_name=$_FILES["BALANCE_SHEET"]["name"];
$temp_name=$_FILES["BALANCE_SHEET"]["tmp_name"];
$ext= end((explode(".", $file_name)));
$imagename = time().$ext;
$target_path = "../user_doc/".$imagename;
if(move_uploaded_file($temp_name, $target_path)) {
$_balance_sheet = $imagename;
}
}

if(isset($_FILES['INCOME_TAX_RETURNS'])){
$file_name=$_FILES["INCOME_TAX_RETURNS"]["name"];
$temp_name=$_FILES["INCOME_TAX_RETURNS"]["tmp_name"];
$ext= end((explode(".", $file_name)));
$imagename = time().$ext;
$target_path = "../user_doc/".$imagename;
if(move_uploaded_file($temp_name, $target_path)) {
$_income_tax_returns = $imagename;
}
}

if(isset($_FILES['BORD_RESOLUTION'])){
$file_name=$_FILES["BORD_RESOLUTION"]["name"];
$temp_name=$_FILES["BORD_RESOLUTION"]["tmp_name"];
$ext= end((explode(".", $file_name)));
$imagename = time().$ext;
$target_path = "../user_doc/".$imagename;
if(move_uploaded_file($temp_name, $target_path)) {
$_bord_resolution = $imagename;
}
}


$__com->setBASIC_ID($_basic_id);
$__com->setCOMPANY_NAME($_company_name);
$__com->setADDRESS($_address);
$__com->setPOD($_pod);
$__com->setCOMPANY_CERTIFICATE($_company_certificate);
$__com->setPROOF_OF_DOC_COMPANY($_proof_of_doc_company);
$__com->setPARTICULARS_OF_BANK($_particulars_of_bank);
$__com->setPANCARD($_pancard);
$__com->setBALANCE_SHEET($_balance_sheet);
$__com->setINCOME_TAX_RETURNS($_income_tax_returns);
$__com->setBORD_RESOLUTION($_bord_resolution);
$__com->setPHOTO_LINK($_photo_link);
$__com->setPOST_ON($_post_on);
$__com->setPOST_BY($_post_by);
$__com->setUPDATE_ON($_update_on);
$__com->setUPDATE_BY($_update_by);

if($__com->Insert()==1){echo 'Successfully Added';

    $__com->pageRedirect("../apply/payment.php?i=".$lastid);


}



