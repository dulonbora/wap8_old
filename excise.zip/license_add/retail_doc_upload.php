<?php

$pic1=($_FILES['file']['name']);
$pic2=($_FILES['file2']['name']);
$pic3=($_FILES['file3']['name']);


for($i=1;$i<=3;$i++)
{
if(move_uploaded_file($_FILES['photo'.$i]['tmp_name'], $target))
{

//Tells you if its all ok
echo "The file ". basename( $_FILES['uploadedfile']['name']). " has been uploaded, and your information has been added to the directory";
}
else {

//Gives and error if its not
echo "Sorry, there was a problem uploading your file.";
}
}