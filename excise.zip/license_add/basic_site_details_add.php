<?php
if(!isset($_SESSION)){session_start();}
include '../classes/BasicInfo.php';
include '../classes/Document.php';
$__bas = new BasicInfo();
$__doc = new Document();

$_date = time()*1000;;
$_license_no = 1;
//$_license_no = filter_input(INPUT_POST , 'LICENSE_NO');
$_distanc_from_education = filter_input(INPUT_POST , 'DISTANC_FROM_EDUCATION');
$_distanc_from_highway = filter_input(INPUT_POST , 'DISTANC_FROM_HIGHWAY');
$_purpose_to_open = filter_input(INPUT_POST , 'PURPOSE_TO_OPEN');
$_name_of_place = filter_input(INPUT_POST , 'NAME_OF_PLACE');
$_additional_details = "";
$_district_code = filter_input(INPUT_POST , 'DISTRICT_CODE');
$_police_station_code = filter_input(INPUT_POST , 'POLICE_STATION_CODE');
$_plote_no = filter_input(INPUT_POST , 'PLOTE_NO');
$_site_type = filter_input(INPUT_POST , 'SITE_TYPE');
$_status = 0;
$_now_here = 1;
$_post_on = time()*1000;
$_post_by = $_SESSION['USER_ID'];
$_update_on = time()*1000;
$_update_by = $_SESSION['USER_ID'];


$_other_certificate = "";
$_license_for = filter_input(INPUT_POST , 'LICENSE_FOR');
$_license_type = filter_input(INPUT_POST , 'LICENSE_TYPE');
$_nonc = "";

if(isset($_FILES['OTHERC'])){
$file_name=$_FILES["OTHERC"]["name"];
$temp_name=$_FILES["OTHERC"]["tmp_name"];
$ext= end((explode(".", $file_name)));
$imagename = time().".".$ext;
$target_path = "../user_doc/".$imagename;
//echo $file_name;
if(move_uploaded_file($temp_name, $target_path)) {

$_other_certificate = $imagename;
}
}


if(isset($_FILES['NONC'])){
$file_name=$_FILES["NONC"]["name"];
$temp_name=$_FILES["NONC"]["tmp_name"];
$ext= end((explode(".", $file_name)));
$imagename = time().".".$ext;
$target_path = "../user_doc/".$imagename;
//echo $file_name;
if(move_uploaded_file($temp_name, $target_path)) {
$__doc->InsertPeram("fgdf", 1, "image/gif", $target_path, 1, $_post_by, $_post_on);
$_nonc = $imagename;
}
}

$__bas->setDATE($_date);
$__bas->setLICENSE_NO($_license_no);
$__bas->setDISTANC_FROM_EDUCATION($_distanc_from_education);
$__bas->setDISTANC_FROM_HIGHWAY($_distanc_from_highway);
$__bas->setPURPOSE_TO_OPEN($_purpose_to_open);
$__bas->setNAME_OF_PLACE($_name_of_place);
$__bas->setADDITIONAL_DETAILS($_additional_details);
$__bas->setDISTRICT_CODE($_district_code);
$__bas->setPOLICE_STATION_CODE($_police_station_code);
$__bas->setPLOTE_NO($_plote_no);
$__bas->setSTATUS($_status);
$__bas->setNOW_HERE($_now_here);
$__bas->setPOST_ON($_post_on);
$__bas->setPOST_BY($_post_by);
$__bas->setUPDATE_ON($_update_on);
$__bas->setUPDATE_BY($_update_by);
$__bas->setSITE_TYPE($_site_type);
$__bas->setOTHERC($_other_certificate);
$__bas->setLICENSE_FOR($_license_for);
$__bas->setLICENSE_TYPE($_license_type);
$__bas->setNONC($_nonc);


if($__bas->Insert()==1){
    echo 'Successfully Added';
if($__doc->InsertPeram("", 1, "image/gif", "../user_doc/".$_other_certificate, 1, $_post_by, $_post_on)==1){echo 'Done';}
if($__doc->InsertPeram("", 1, "application/pdf", "../user_doc/".$_nonc, 1, $_post_by, $_post_on)==1){echo 'Done';}
echo $lastid = $__bas->getID();
$__bas->pageRedirect("../apply/apply_applicant_details_retailer.php?i=".$lastid);

}




