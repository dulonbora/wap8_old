<?php
if(!isset($_SESSION)){session_start();}

include '../classes/ApplicantInfo.php';
include '../classes/BasicInfo.php';

$__app = new ApplicantInfo();
$__binfo = new BasicInfo();

function GetImageExtension($imagetype)
   	 {
       if(empty($imagetype)) return false;
       switch($imagetype)
       {
           case 'image/bmp': return '.bmp';
           case 'image/gif': return '.gif';
           case 'image/jpeg': return '.jpg';
           case 'image/png': return '.png';
           default: return false;
       }
     }

$_basic_id = filter_input(INPUT_POST , 'BASIC_ID');
$_first_name = filter_input(INPUT_POST , 'FIRST_NAME');
$_middle_name = filter_input(INPUT_POST , 'MIDDLE_NAME');
$_last_name = filter_input(INPUT_POST , 'LAST_NAME');
$_parents_name = filter_input(INPUT_POST , 'PARENTS_NAME');
$_age = filter_input(INPUT_POST , 'AGE');
$_nationality = filter_input(INPUT_POST , 'NATIONALITY');
$_residential = filter_input(INPUT_POST , 'RESIDENTIAL');
$_email = filter_input(INPUT_POST , 'EMAIL');
$_phone = filter_input(INPUT_POST , 'PHONE');
$_address_p = filter_input(INPUT_POST , 'ADDRESS_P');
$_address_c = filter_input(INPUT_POST , 'ADDRESS_C');
$_qulification = filter_input(INPUT_POST , 'QULIFICATION');
$_annual_income = filter_input(INPUT_POST , 'ANNUAL_INCOME');
$_pan_no = filter_input(INPUT_POST , 'PAN_NO');
$_other_license_no = filter_input(INPUT_POST , 'OTHER_LICENSE_NO');
$_other_license_dec = filter_input(INPUT_POST , 'OTHER_LICENSE_DEC');
$_is_rellativ_license = filter_input(INPUT_POST , 'IS_RELLATIV_LICENSE');
$_invlopment_in_criminalisim = filter_input(INPUT_POST , 'INVLOPMENT_IN_CRIMINALISIM');
$_special_claim = filter_input(INPUT_POST , 'SPECIAL_CLAIM');
$_photo_link = "";
$_post_on = time()*1000;
$_post_by = $_SESSION['USER_ID'];
$_update_on = time()*1000;
$_update_by = $_SESSION['USER_ID'];

$_proof_of_capacity = "";
$_proof_of_solvency = "";
$_proof_of_medical = "";
$_proof_of_police = "";
$_other_license_tax = "";


if(isset($_FILES['PROOF_OF_CAPACITY'])){
$file_name=$_FILES["PROOF_OF_CAPACITY"]["name"];
$temp_name=$_FILES["PROOF_OF_CAPACITY"]["tmp_name"];
$ext= end((explode(".", $file_name)));
$imagename = time().$ext;
$target_path = "../user_doc/".$imagename;
if(move_uploaded_file($temp_name, $target_path)) {
$_proof_of_capacity = $imagename;
}
}

if(isset($_FILES['PROOF_OF_SOLVENCY'])){
$file_name=$_FILES["PROOF_OF_SOLVENCY"]["name"];
$temp_name=$_FILES["PROOF_OF_SOLVENCY"]["tmp_name"];
$ext= end((explode(".", $file_name)));
$imagename = time().$ext;
$target_path = "../user_doc/".$imagename;
if(move_uploaded_file($temp_name, $target_path)) {
$_proof_of_solvency = $imagename;
}
}

if(isset($_FILES['PROOF_OF_MEDICAL'])){
$file_name=$_FILES["PROOF_OF_MEDICAL"]["name"];
$temp_name=$_FILES["PROOF_OF_MEDICAL"]["tmp_name"];
$ext= end((explode(".", $file_name)));
$imagename = time().$ext;
$target_path = "../user_doc/".$imagename;
if(move_uploaded_file($temp_name, $target_path)) {
$_proof_of_medical = $imagename;
}
}

if(isset($_FILES['PROOF_OF_POLICE'])){
$file_name=$_FILES["PROOF_OF_POLICE"]["name"];
$temp_name=$_FILES["PROOF_OF_POLICE"]["tmp_name"];
$ext= end((explode(".", $file_name)));
$imagename = time().$ext;
$target_path = "../user_doc/".$imagename;
if(move_uploaded_file($temp_name, $target_path)) {
$_proof_of_police = $imagename;
}
}


if(isset($_FILES['OTHER_LICENSE_TAX'])){
$file_name=$_FILES["OTHER_LICENSE_TAX"]["name"];
$temp_name=$_FILES["OTHER_LICENSE_TAX"]["tmp_name"];
$ext= end((explode(".", $file_name)));
$imagename = time().$ext;
$target_path = "../user_doc/".$imagename;
if(move_uploaded_file($temp_name, $target_path)) {
$_other_license_tax = $imagename;
}
}


if(isset($_FILES['PHOTO_LINK'])){
$file_name=$_FILES["PHOTO_LINK"]["name"];
$temp_name=$_FILES["PHOTO_LINK"]["tmp_name"];
$imgtype=$_FILES["PHOTO_LINK"]["type"];
$ext= GetImageExtension($imgtype);
$imagename = time().$ext;
$target_path = "../user_images/".$imagename;
if(move_uploaded_file($temp_name, $target_path)) {
$_photo_link = $imagename;
}
}
 
 
 
 
$__app->setBASIC_ID($_basic_id);
$__app->setFIRST_NAME($_first_name);
$__app->setMIDDLE_NAME($_middle_name);
$__app->setLAST_NAME($_last_name);
$__app->setPARENTS_NAME($_parents_name);
$__app->setAGE($_age);
$__app->setNATIONALITY($_nationality);
$__app->setRESIDENTIAL($_residential);
$__app->setEMAIL($_email);
$__app->setPHONE($_phone);
$__app->setADDRESS_P($_address_p);
$__app->setADDRESS_C($_address_c);
$__app->setQULIFICATION($_qulification);
$__app->setANNUAL_INCOME($_annual_income);
$__app->setPAN_NO($_pan_no);
$__app->setOTHER_LICENSE_NO($_other_license_no);
$__app->setOTHER_LICENSE_DEC($_other_license_dec);
$__app->setIS_RELLATIV_LICENSE($_is_rellativ_license);
$__app->setINVLOPMENT_IN_CRIMINALISIM($_invlopment_in_criminalisim);
$__app->setSPECIAL_CLAIM($_special_claim);
$__app->setPHOTO_LINK($_photo_link);
$__app->setPOST_ON($_post_on);
$__app->setPOST_BY($_post_by);
$__app->setUPDATE_ON($_update_on);
$__app->setUPDATE_BY($_update_by);


$__app->setPROOF_OF_CAPACITY($_proof_of_capacity);
$__app->setPROOF_OF_SOLVENCY($_proof_of_solvency);
$__app->setPROOF_OF_MEDICAL($_proof_of_medical);
$__app->setPROOF_OF_POLICE($_proof_of_police);
$__app->setOTHER_LICENSE_TAX($_other_license_tax);


if($__app->Insert()==1){
if($__app->Update($__app->getID()==1)){echo 'Successfully Added';

$__binfo->loadValue($_basic_id);

if($__binfo->getLICENSE_FOR()=="Company"){
    $__binfo->pageRedirect("../apply/apply_company_details.php?i=".$_basic_id);

}
else if ($__binfo->getLICENSE_FOR()=="Multiple") {
    $__binfo->pageRedirect("../apply/apply_pratners_details.php?i=".$_basic_id);

}
 else {
    $__binfo->pageRedirect("../apply/payment.php?i=".$_basic_id);
}



}

        
}

        






?>








