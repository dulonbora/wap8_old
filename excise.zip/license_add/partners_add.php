<?php

if(!isset($_SESSION)){session_start();}

include '../classes/Partners.php';
$__par = new Partners();


$_basic_id = filter_input(INPUT_POST , 'BASIC_ID');
$_type = filter_input(INPUT_POST , 'TYPE');
$_first_name = filter_input(INPUT_POST , 'FIRST_NAME');
$_middle_name = filter_input(INPUT_POST , 'MIDDLE_NAME');
$_last_name = filter_input(INPUT_POST , 'LAST_NAME');
$_age = filter_input(INPUT_POST , 'AGE');
$_nationality = filter_input(INPUT_POST , 'NATIONALITY');
$_email = filter_input(INPUT_POST , 'EMAIL');
$_phone = filter_input(INPUT_POST , 'PHONE');
$_address_p = filter_input(INPUT_POST , 'ADDRESS_P');
$_address_c = filter_input(INPUT_POST , 'ADDRESS_C');
$_qulification = filter_input(INPUT_POST , 'QULIFICATION');
$_partnership_deed = "";
//$_partnership_deed = filter_input(INPUT_POST , 'PARTNERSHIP_DEED');
$_partnership_certificate = "";
//$_partnership_certificate = filter_input(INPUT_POST , 'PARTNERSHIP_CERTIFICATE');
$_statement_of_net_worth = "";
//$_statement_of_net_worth = filter_input(INPUT_POST , 'STATEMENT_OF_NET_WORTH');
$_pancard = "";
//$_pancard = filter_input(INPUT_POST , 'PANCARD');
$_income_tax_returns = "";
//$_income_tax_returns = filter_input(INPUT_POST , 'INCOME_TAX_RETURNS');
$_photo_link = "";
$_post_on = time()*1000;;
$_post_by = $_SESSION['USER_ID'];
$_update_on = time()*1000;
$_update_by = $_SESSION['USER_ID'];

if(isset($_FILES['PHOTO_LINK'])){
$file_name=$_FILES["PHOTO_LINK"]["name"];
$temp_name=$_FILES["PHOTO_LINK"]["tmp_name"];
$ext= end((explode(".", $file_name)));
$imagename = time().$ext;
$target_path = "../user_images/".$imagename;
//echo $file_name;
if(move_uploaded_file($temp_name, $target_path)) {
$_photo_link = $imagename;
}
}

if(isset($_FILES['INCOME_TAX_RETURNS'])){
$file_name=$_FILES["INCOME_TAX_RETURNS"]["name"];
$temp_name=$_FILES["INCOME_TAX_RETURNS"]["tmp_name"];
$ext= end((explode(".", $file_name)));
$imagename = time().$ext;
$target_path = "../user_doc/".$imagename;
//echo $file_name;
if(move_uploaded_file($temp_name, $target_path)) {
$_income_tax_returns = $imagename;
}
}

if(isset($_FILES['PANCARD'])){
$file_name=$_FILES["PANCARD"]["name"];
$temp_name=$_FILES["PANCARD"]["tmp_name"];
$ext= end((explode(".", $file_name)));
$imagename = time().$ext;
$target_path = "../user_doc/".$imagename;
//echo $file_name;
if(move_uploaded_file($temp_name, $target_path)) {
$_pancard = $imagename;
}
}

if(isset($_FILES['STATEMENT_OF_NET_WORTH'])){
$file_name=$_FILES["STATEMENT_OF_NET_WORTH"]["name"];
$temp_name=$_FILES["STATEMENT_OF_NET_WORTH"]["tmp_name"];
$ext= end((explode(".", $file_name)));
$imagename = time().$ext;
$target_path = "../user_doc/".$imagename;
//echo $file_name;
if(move_uploaded_file($temp_name, $target_path)) {
$_statement_of_net_worth = $imagename;
}
}

if(isset($_FILES['PARTNERSHIP_CERTIFICATE'])){
$file_name=$_FILES["PARTNERSHIP_CERTIFICATE"]["name"];
$temp_name=$_FILES["PARTNERSHIP_CERTIFICATE"]["tmp_name"];
$ext= end((explode(".", $file_name)));
$imagename = time().$ext;
$target_path = "../user_doc/".$imagename;
//echo $file_name;
if(move_uploaded_file($temp_name, $target_path)) {
$_partnership_certificate = $imagename;
}
}

if(isset($_FILES['PARTNERSHIP_DEED'])){
$file_name=$_FILES["PARTNERSHIP_DEED"]["name"];
$temp_name=$_FILES["PARTNERSHIP_DEED"]["tmp_name"];
$ext= end((explode(".", $file_name)));
$imagename = time().$ext;
$target_path = "../user_doc/".$imagename;
//echo $file_name;
if(move_uploaded_file($temp_name, $target_path)) {
$_partnership_deed = $imagename;
}
}


$__par->setBASIC_ID($_basic_id);
$__par->setTYPE($_type);
$__par->setFIRST_NAME($_first_name);
$__par->setMIDDLE_NAME($_middle_name);
$__par->setLAST_NAME($_last_name);
$__par->setAGE($_age);
$__par->setNATIONALITY($_nationality);
$__par->setEMAIL($_email);
$__par->setPHONE($_phone);
$__par->setADDRESS_P($_address_p);
$__par->setADDRESS_C($_address_c);
$__par->setQULIFICATION($_qulification);
$__par->setPARTNERSHIP_DEED($_partnership_deed);
$__par->setPARTNERSHIP_CERTIFICATE($_partnership_certificate);
$__par->setSTATEMENT_OF_NET_WORTH($_statement_of_net_worth);
$__par->setPANCARD($_pancard);
$__par->setINCOME_TAX_RETURNS($_income_tax_returns);
$__par->setPHOTO_LINK($_photo_link);
$__par->setPOST_ON($_post_on);
$__par->setPOST_BY($_post_by);
$__par->setUPDATE_ON($_update_on);
$__par->setUPDATE_BY($_update_by);

if($__par->Insert()==1){echo 'Successfully Added';

    $__par->pageRedirect("../apply/payment.php?i=".$lastid);

}
