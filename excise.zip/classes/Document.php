<?php
require_once '../include/db.php';

class Document {
    private $conn = null;
    public function __construct() {
        $Data = new Kanexon();
        $this->conn = $Data->getDb();
    }
        
public function Insert(){
$query = "INSERT INTO DOCUMENTS(LICENSE_NO , FILE_NO , FORMAT_TYPE , FILE , TYPE , CREATE_BY , CREATE_ON) 
	VALUES ( ? , ? , ? , ? , ? , ? , ?) " ; 
$success = 0;
try{
	$stmt = $this->conn->prepare($query);
	$stmt->bindParam (1 , $this->LICENSE_NO); 
	$stmt->bindParam (2 , $this->FILE_NO); 
	$stmt->bindParam (3 , $this->FORMAT_TYPE); 
	$stmt->bindParam (4 , $this->FILE); 
	$stmt->bindParam (5 , $this->TYPE); 
	$stmt->bindParam (6 , $this->CREATE_BY); 
	$stmt->bindParam (7 , $this->CREATE_ON); 

	$stmt->execute(); 
	$success = 1;}
catch(PDOException $ex){ echo  $ex->getMessage(); } 
return $success;}


public function InsertPeram($licenseNo, $fileNo, $formatType, $filePath, $type, $createBy, $createNo){
$query = "INSERT INTO DOCUMENTS(LICENSE_NO , FILE_NO , FORMAT_TYPE , FILE , TYPE , CREATE_BY , CREATE_ON) 
	VALUES ( ? , ? , ? , ? , ? , ? , ?) " ; 
$success = 0;
try{
	$stmt = $this->conn->prepare($query);
	$stmt->bindParam (1 , $licenseNo); 
	$stmt->bindParam (2 , $fileNo); 
	$stmt->bindParam (3 , $formatType); 
	$stmt->bindParam (4 , $filePath, PDO::PARAM_LOB); 
	$stmt->bindParam (5 , $type);
	$stmt->bindParam (6 , $createBy); 
	$stmt->bindParam (7 , $createNo); 
	$stmt->execute(); 
	$success = 1;}
catch(PDOException $ex){ echo  $ex->getMessage(); } 
return $success;}

 /*----------------------------------------------------------*/

/*
$response = array(); 
$response['SUCCESS'] = 0;

$__doc = new Document();

$_license_no = filter_input(INPUT_POST , 'LICENSE_NO');
$_file_no = filter_input(INPUT_POST , 'FILE_NO');
$_format_type = filter_input(INPUT_POST , 'FORMAT_TYPE');
$_file = filter_input(INPUT_POST , 'FILE');
$_type = filter_input(INPUT_POST , 'TYPE');
$_create_by = filter_input(INPUT_POST , 'CREATE_BY');
$_create_on = filter_input(INPUT_POST , 'CREATE_ON');


$__doc->setLICENSE_NO($_license_no);
$__doc->setFILE_NO($_file_no);
$__doc->setFORMAT_TYPE($_format_type);
$__doc->setFILE($_file);
$__doc->setTYPE($_type);
$__doc->setCREATE_BY($_create_by);
$__doc->setCREATE_ON($_create_on);

if($__doc->Insert()==1){$response['SUCCESS'] = 1;}

echo json_encode($response);
exit();
    */


private $ID;
private $LICENSE_NO;
private $FILE_NO;
private $FORMAT_TYPE;
private $FILE;
private $TYPE;
private $CREATE_BY;
private $CREATE_ON;

function setID($ID) { $this->ID = $ID; }
function getID() { return $this->ID; }
function setLICENSE_NO($LICENSE_NO) { $this->LICENSE_NO = $LICENSE_NO; }
function getLICENSE_NO() { return $this->LICENSE_NO; }
function setFILE_NO($FILE_NO) { $this->FILE_NO = $FILE_NO; }
function getFILE_NO() { return $this->FILE_NO; }
function setFORMAT_TYPE($FORMAT_TYPE) { $this->FORMAT_TYPE = $FORMAT_TYPE; }
function getFORMAT_TYPE() { return $this->FORMAT_TYPE; }
function setFILE($FILE) { $this->FILE = $FILE; }
function getFILE() { return $this->FILE; }
function setTYPE($TYPE) { $this->TYPE = $TYPE; }
function getTYPE() { return $this->TYPE; }
function setCREATE_BY($CREATE_BY) { $this->CREATE_BY = $CREATE_BY; }
function getCREATE_BY() { return $this->CREATE_BY; }
function setCREATE_ON($CREATE_ON) { $this->CREATE_ON = $CREATE_ON; }
function getCREATE_ON() { return $this->CREATE_ON; }

}
