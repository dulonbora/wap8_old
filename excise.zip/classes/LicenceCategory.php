<?php

require_once '../include/db.php';

class LicenceCategory {
    private $conn = null;
    public function __construct() {
        $Data = new Kanexon();
        $this->conn = $Data->getDb();
    }
    
 /*----------------------------------------------------------*/
    
public function Insert(){
$query = "INSERT INTO LICENSE_CATEGORY(CATEGORY_NAME , PARENT_ID , DESCRIPTION , STATUS , POST_ON , POST_BY , UPDATE_ON , UPDATE_BY) 
	VALUES ( ? , ? , ? , ? , ? , ? , ? , ?) " ; 
$success = 0;
try{
	$stmt = $this->conn->prepare($query);
	$stmt->bindParam (1 , $this->CATEGORY_NAME); 
	$stmt->bindParam (2 , $this->PARENT_ID); 
	$stmt->bindParam (3 , $this->DESCRIPTION); 
	$stmt->bindParam (4 , $this->STATUS); 
	$stmt->bindParam (5 , $this->POST_ON); 
	$stmt->bindParam (6 , $this->POST_BY); 
	$stmt->bindParam (7 , $this->UPDATE_ON); 
	$stmt->bindParam (8 , $this->UPDATE_BY); 

	$stmt->execute(); 
	$success = 1;}
catch(PDOException $ex){ echo  $ex->getMessage(); } 
return $success;}

 /*----------------------------------------------------------*/

public function Update($id){
$query = "UPDATE LICENSE_CATEGORY SET CATEGORY_NAME = ? , PARENT_ID = ? , DESCRIPTION = ? , STATUS = ? , UPDATE_ON = ? , UPDATE_BY = ? 
	WHERE ID = ? ";
$success = 0;
try{
	$stmt = $this->conn->prepare($query);
	$stmt->bindParam (1 , $this->CATEGORY_NAME); 
	$stmt->bindParam (2 , $this->PARENT_ID); 
	$stmt->bindParam (3 , $this->DESCRIPTION); 
	$stmt->bindParam (4 , $this->STATUS); 
	$stmt->bindParam (5 , $this->UPDATE_ON); 
	$stmt->bindParam (6 , $this->UPDATE_BY); 
	$stmt->bindParam (7 , $id); 

	$stmt->execute(); 
	$success = 1;}
catch(PDOException $ex){ echo  $ex->getMessage(); } 
return $success;}

/*----------------------------------------------------------*/

public function UpdateSingle($col, $val, $id){
$query = "UPDATE LICENSE_CATEGORY SET '$col' = ? WHERE ID = ? ";
$success = 0;
try{
	$stmt = $this->conn->prepare($query);
	$stmt->bindParam (1 , $val); 
	$stmt->bindParam (2 , $id); 

	$stmt->execute(); 
	$success = 1;}
catch(PDOException $ex){ echo  $ex->getMessage(); } 
return $success;}

 /*----------------------------------------------------------*/

    public function loadValue($id) {
        $Q = "SELECT * FROM LICENSE_CATEGORY WHERE ID = $id";
        $result = null;
        try {
            $stmt = $this->conn->prepare($Q);
            $stmt->bindParam(1, $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $this->ID = $row['ID'];
            $this->CATEGORY_NAME = $row['CATEGORY_NAME'];
            $this->PARENT_ID = $row['PARENT_ID'];
            $this->DESCRIPTION = $row['DESCRIPTION'];
            $this->STATUS = $row['STATUS'];
            $this->POST_ON = $row['POST_ON'];
            $this->POST_BY = $row['POST_BY'];
            $this->UPDATE_ON = $row['UPDATE_ON'];
            $this->UPDATE_BY = $row['UPDATE_BY'];
        } catch (PDOException $ex) {
            echo $ex->getMessage();
        }
        return $result;
    }
 
 /*----------------------------------------------------------*/
    
    public function AlreadyExitCategory($category_name){
    $ok = 0;
    $query = "SELECT ID FROM LICENSE_CATEGORY WHERE CATEGORY_NAME = ? ";
    try{
    $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $category_name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            $ok = 1;
        }
     } catch(PDOException $ex){echo $ex->getMessage();}
    
    return $ok;
    }

 /*----------------------------------------------------------*/
    
    public function AlreadyExitSubcategory($category_name, $pid){
    $ok = 0;
    $query = "SELECT ID FROM LICENSE_CATEGORY WHERE CATEGORY_NAME = ? AND PARENT_ID = ? ";
    try{
    $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $category_name);
        $stmt->bindParam(2, $pid);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            $ok = 1;
        }
     } catch(PDOException $ex){echo $ex->getMessage();}
    
return $ok;
}
    
    
 /*----------------------------------------------------------*/
    public function allFecth() {
        $Q = "SELECT * FROM LICENSE_CATEGORY WHERE PARENT_ID = 0";
        $result = null;
        try {
            $stmt = $this->conn->prepare($Q);
            $stmt->execute();
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $ex) {
            echo $ex->getMessage();
        }
        return $result;
    }
    
 /*----------------------------------------------------------*/
    
    public function allFecthByParent($id) {
        $Q = "SELECT * FROM LICENSE_CATEGORY WHERE PARENT_ID = ?";
        $result = null;
        try {
            $stmt = $this->conn->prepare($Q);
            $stmt->bindParam(1, $id);
            $stmt->execute();
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $ex) {
            echo $ex->getMessage();
        }
        return $result;
    }
    
 /*----------------------------------------------------------*/
    public function date($dt){
        $dat = $dt / 1000;
        $daaat = date('d-m-Y', $dat);
        $date = "";
        $category = "";
        $ddt = explode('-', $daaat);
        switch ($ddt[1]){
        case 1: $category = "Jan"; break;
        case 2: $category = "Feb"; break;
        case 3: $category = "Mar"; break;
        case 4: $category = "Apr"; break;
        case 5: $category = "May"; break;
        case 6: $category = "Jun"; break;
        case 7: $category = "Jul"; break;
        case 8: $category = "Aug"; break;
        case 9: $category = "Sep"; break;
        case 10: $category = "Oct"; break;
        case 11: $category = "Nov"; break;
        default : $category = "Dec";
    }
    $date = $category." ".$ddt[0]." ".$ddt[2];
        return $date;
    }

    
    
 /*----------------------------------------------------------*/

    
private $ID;
private $CATEGORY_NAME;
private $PARENT_ID;
private $DESCRIPTION;
private $STATUS;
private $POST_ON;
private $POST_BY;
private $UPDATE_ON;
private $UPDATE_BY;

function setID($ID) { $this->ID = $ID; }
function getID() { return $this->ID; }
function setCATEGORY_NAME($CATEGORY_NAME) { $this->CATEGORY_NAME = $CATEGORY_NAME; }
function getCATEGORY_NAME() { return $this->CATEGORY_NAME; }
function setPARENT_ID($PARENT_ID) { $this->PARENT_ID = $PARENT_ID; }
function getPARENT_ID() { return $this->PARENT_ID; }
function setDESCRIPTION($DESCRIPTION) { $this->DESCRIPTION = $DESCRIPTION; }
function getDESCRIPTION() { return $this->DESCRIPTION; }
function setSTATUS($STATUS) { $this->STATUS = $STATUS; }
function getSTATUS() { return $this->STATUS; }
function setPOST_ON($POST_ON) { $this->POST_ON = $POST_ON; }
function getPOST_ON() { return $this->POST_ON; }
function setPOST_BY($POST_BY) { $this->POST_BY = $POST_BY; }
function getPOST_BY() { return $this->POST_BY; }
function setUPDATE_ON($UPDATE_ON) { $this->UPDATE_ON = $UPDATE_ON; }
function getUPDATE_ON() { return $this->UPDATE_ON; }
function setUPDATE_BY($UPDATE_BY) { $this->UPDATE_BY = $UPDATE_BY; }
function getUPDATE_BY() { return $this->UPDATE_BY; }

}
