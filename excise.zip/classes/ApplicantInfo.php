<?php
require_once '../include/db.php';
class ApplicantInfo {
     private $conn = null;
    public function __construct() {
        $Data = new Kanexon();
        $this->conn = $Data->getDb();
    }
    
    public function Insert(){
$query = "INSERT INTO APPLICANTINFO(BASIC_ID , FIRST_NAME , MIDDLE_NAME , LAST_NAME , PARENTS_NAME , AGE , NATIONALITY , RESIDENTIAL , EMAIL , PHONE , ADDRESS_P , ADDRESS_C , QULIFICATION , ANNUAL_INCOME , PAN_NO , OTHER_LICENSE_NO , OTHER_LICENSE_DEC , IS_RELLATIV_LICENSE , INVLOPMENT_IN_CRIMINALISIM , SPECIAL_CLAIM , PHOTO_LINK , POST_ON , POST_BY , UPDATE_ON , UPDATE_BY) 
	VALUES ( ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ?) " ; 
$success = 0;
try{
	$stmt = $this->conn->prepare($query);
	$stmt->bindParam (1 , $this->BASIC_ID); 
	$stmt->bindParam (2 , $this->FIRST_NAME); 
	$stmt->bindParam (3 , $this->MIDDLE_NAME); 
	$stmt->bindParam (4 , $this->LAST_NAME); 
	$stmt->bindParam (5 , $this->PARENTS_NAME); 
	$stmt->bindParam (6 , $this->AGE); 
	$stmt->bindParam (7 , $this->NATIONALITY); 
	$stmt->bindParam (8 , $this->RESIDENTIAL); 
	$stmt->bindParam (9 , $this->EMAIL); 
	$stmt->bindParam (10 , $this->PHONE); 
	$stmt->bindParam (11 , $this->ADDRESS_P); 
	$stmt->bindParam (12 , $this->ADDRESS_C); 
	$stmt->bindParam (13 , $this->QULIFICATION); 
	$stmt->bindParam (14 , $this->ANNUAL_INCOME); 
	$stmt->bindParam (15 , $this->PAN_NO); 
	$stmt->bindParam (16 , $this->OTHER_LICENSE_NO); 
	$stmt->bindParam (17 , $this->OTHER_LICENSE_DEC); 
	$stmt->bindParam (18 , $this->IS_RELLATIV_LICENSE); 
	$stmt->bindParam (19 , $this->INVLOPMENT_IN_CRIMINALISIM); 
	$stmt->bindParam (20 , $this->SPECIAL_CLAIM); 
	$stmt->bindParam (21 , $this->PHOTO_LINK); 
	$stmt->bindParam (22 , $this->POST_ON); 
	$stmt->bindParam (23 , $this->POST_BY); 
	$stmt->bindParam (24 , $this->UPDATE_ON); 
	$stmt->bindParam (25 , $this->UPDATE_BY); 

	$stmt->execute(); 
        $this->ID = $this->conn->lastInsertId();
	$success = 1;}
catch(PDOException $ex){ echo  $ex->getMessage(); } 
return $success;}

 /*----------------------------------------------------------*/

public function Update($id){
$query = "UPDATE APPLICANTINFO SET PROOF_OF_CAPACITY = ? , PROOF_OF_SOLVENCY = ? , PROOF_OF_MEDICAL = ? , PROOF_OF_POLICE = ? , OTHER_LICENSE_TAX = ? 
	WHERE ID = ? ";
$success = 0;
try{
	$stmt = $this->conn->prepare($query);
	$stmt->bindParam (1 , $this->PROOF_OF_CAPACITY); 
	$stmt->bindParam (2 , $this->PROOF_OF_SOLVENCY); 
	$stmt->bindParam (3 , $this->PROOF_OF_MEDICAL); 
	$stmt->bindParam (4 , $this->PROOF_OF_POLICE); 
	$stmt->bindParam (5 , $this->OTHER_LICENSE_TAX); 
	$stmt->bindParam (6 , $id); 

	$stmt->execute(); 
	$success = 1;}
catch(PDOException $ex){ echo  $ex->getMessage(); } 
return $success;}

 /*----------------------------------------------------------*/

    
    
    //This javascript function will redirect a another page
//after the execution of a function.
public function pageRedirect($page){
echo "<script type=\"text/javascript\">	";
echo "document.location = '".$page."' ";
echo "</script>";
}

 
private $ID;
private $BASIC_ID;
private $FIRST_NAME;
private $MIDDLE_NAME;
private $LAST_NAME;
private $PARENTS_NAME;
private $AGE;
private $NATIONALITY;
private $RESIDENTIAL;
private $EMAIL;
private $PHONE;
private $ADDRESS_P;
private $ADDRESS_C;
private $QULIFICATION;
private $ANNUAL_INCOME;
private $PAN_NO;
private $OTHER_LICENSE_NO;
private $OTHER_LICENSE_DEC;
private $IS_RELLATIV_LICENSE;
private $INVLOPMENT_IN_CRIMINALISIM;
private $SPECIAL_CLAIM;
private $PHOTO_LINK;
private $POST_ON;
private $POST_BY;
private $UPDATE_ON;
private $UPDATE_BY;
private $PROOF_OF_CAPACITY;
private $PROOF_OF_SOLVENCY;
private $PROOF_OF_MEDICAL;
private $PROOF_OF_POLICE;
private $OTHER_LICENSE_TAX;


function setID($ID) { $this->ID = $ID; }
function getID() { return $this->ID; }
function setBASIC_ID($BASIC_ID) { $this->BASIC_ID = $BASIC_ID; }
function getBASIC_ID() { return $this->BASIC_ID; }
function setFIRST_NAME($FIRST_NAME) { $this->FIRST_NAME = $FIRST_NAME; }
function getFIRST_NAME() { return $this->FIRST_NAME; }
function setMIDDLE_NAME($MIDDLE_NAME) { $this->MIDDLE_NAME = $MIDDLE_NAME; }
function getMIDDLE_NAME() { return $this->MIDDLE_NAME; }
function setLAST_NAME($LAST_NAME) { $this->LAST_NAME = $LAST_NAME; }
function getLAST_NAME() { return $this->LAST_NAME; }
function setPARENTS_NAME($PARENTS_NAME) { $this->PARENTS_NAME = $PARENTS_NAME; }
function getPARENTS_NAME() { return $this->PARENTS_NAME; }
function setAGE($AGE) { $this->AGE = $AGE; }
function getAGE() { return $this->AGE; }
function setNATIONALITY($NATIONALITY) { $this->NATIONALITY = $NATIONALITY; }
function getNATIONALITY() { return $this->NATIONALITY; }
function setRESIDENTIAL($RESIDENTIAL) { $this->RESIDENTIAL = $RESIDENTIAL; }
function getRESIDENTIAL() { return $this->RESIDENTIAL; }
function setEMAIL($EMAIL) { $this->EMAIL = $EMAIL; }
function getEMAIL() { return $this->EMAIL; }
function setPHONE($PHONE) { $this->PHONE = $PHONE; }
function getPHONE() { return $this->PHONE; }
function setADDRESS_P($ADDRESS_P) { $this->ADDRESS_P = $ADDRESS_P; }
function getADDRESS_P() { return $this->ADDRESS_P; }
function setADDRESS_C($ADDRESS_C) { $this->ADDRESS_C = $ADDRESS_C; }
function getADDRESS_C() { return $this->ADDRESS_C; }
function setQULIFICATION($QULIFICATION) { $this->QULIFICATION = $QULIFICATION; }
function getQULIFICATION() { return $this->QULIFICATION; }
function setANNUAL_INCOME($ANNUAL_INCOME) { $this->ANNUAL_INCOME = $ANNUAL_INCOME; }
function getANNUAL_INCOME() { return $this->ANNUAL_INCOME; }
function setPAN_NO($PAN_NO) { $this->PAN_NO = $PAN_NO; }
function getPAN_NO() { return $this->PAN_NO; }
function setOTHER_LICENSE_NO($OTHER_LICENSE_NO) { $this->OTHER_LICENSE_NO = $OTHER_LICENSE_NO; }
function getOTHER_LICENSE_NO() { return $this->OTHER_LICENSE_NO; }
function setOTHER_LICENSE_DEC($OTHER_LICENSE_DEC) { $this->OTHER_LICENSE_DEC = $OTHER_LICENSE_DEC; }
function getOTHER_LICENSE_DEC() { return $this->OTHER_LICENSE_DEC; }
function setIS_RELLATIV_LICENSE($IS_RELLATIV_LICENSE) { $this->IS_RELLATIV_LICENSE = $IS_RELLATIV_LICENSE; }
function getIS_RELLATIV_LICENSE() { return $this->IS_RELLATIV_LICENSE; }
function setINVLOPMENT_IN_CRIMINALISIM($INVLOPMENT_IN_CRIMINALISIM) { $this->INVLOPMENT_IN_CRIMINALISIM = $INVLOPMENT_IN_CRIMINALISIM; }
function getINVLOPMENT_IN_CRIMINALISIM() { return $this->INVLOPMENT_IN_CRIMINALISIM; }
function setSPECIAL_CLAIM($SPECIAL_CLAIM) { $this->SPECIAL_CLAIM = $SPECIAL_CLAIM; }
function getSPECIAL_CLAIM() { return $this->SPECIAL_CLAIM; }
function setPHOTO_LINK($PHOTO_LINK) { $this->PHOTO_LINK = $PHOTO_LINK; }
function getPHOTO_LINK() { return $this->PHOTO_LINK; }
function setPOST_ON($POST_ON) { $this->POST_ON = $POST_ON; }
function getPOST_ON() { return $this->POST_ON; }
function setPOST_BY($POST_BY) { $this->POST_BY = $POST_BY; }
function getPOST_BY() { return $this->POST_BY; }
function setUPDATE_ON($UPDATE_ON) { $this->UPDATE_ON = $UPDATE_ON; }
function getUPDATE_ON() { return $this->UPDATE_ON; }
function setUPDATE_BY($UPDATE_BY) { $this->UPDATE_BY = $UPDATE_BY; }
function getUPDATE_BY() { return $this->UPDATE_BY; }


function setPROOF_OF_CAPACITY($PROOF_OF_CAPACITY) { $this->PROOF_OF_CAPACITY = $PROOF_OF_CAPACITY; }
function getPROOF_OF_CAPACITY() { return $this->PROOF_OF_CAPACITY; }
function setPROOF_OF_SOLVENCY($PROOF_OF_SOLVENCY) { $this->PROOF_OF_SOLVENCY = $PROOF_OF_SOLVENCY; }
function getPROOF_OF_SOLVENCY() { return $this->PROOF_OF_SOLVENCY; }
function setPROOF_OF_MEDICAL($PROOF_OF_MEDICAL) { $this->PROOF_OF_MEDICAL = $PROOF_OF_MEDICAL; }
function getPROOF_OF_MEDICAL() { return $this->PROOF_OF_MEDICAL; }
function setPROOF_OF_POLICE($PROOF_OF_POLICE) { $this->PROOF_OF_POLICE = $PROOF_OF_POLICE; }
function getPROOF_OF_POLICE() { return $this->PROOF_OF_POLICE; }
function setOTHER_LICENSE_TAX($OTHER_LICENSE_TAX) { $this->OTHER_LICENSE_TAX = $OTHER_LICENSE_TAX; }
function getOTHER_LICENSE_TAX() { return $this->OTHER_LICENSE_TAX; }


}
