<?php
require_once '../include/db.php';
class BasicInfo {
     private $conn = null;
    public function __construct() {
        $Data = new Kanexon();
        $this->conn = $Data->getDb();
    }
    
    
    
    public function Insert(){
$query = "INSERT INTO BASICINFOSITE(DATE , LICENSE_NO , DISTANC_FROM_EDUCATION , 
    DISTANC_FROM_HIGHWAY , PURPOSE_TO_OPEN , NAME_OF_PLACE , ADDITIONAL_DETAILS , 
    DISTRICT_CODE , POLICE_STATION_CODE , PLOTE_NO , STATUS , NOW_HERE , POST_ON , 
    POST_BY , UPDATE_ON , UPDATE_BY, SITE_TYPE,
    LICENSE_FOR, LICENSE_TYPE, OTHERC, NONC) 
	VALUES ( ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ?, ?, ?, ?, ?, ?) " ; 
$success = 0;
try{
	$stmt = $this->conn->prepare($query);
	$stmt->bindParam (1 , $this->DATE); 
	$stmt->bindParam (2 , $this->LICENSE_NO); 
	$stmt->bindParam (3 , $this->DISTANC_FROM_EDUCATION); 
	$stmt->bindParam (4 , $this->DISTANC_FROM_HIGHWAY); 
	$stmt->bindParam (5 , $this->PURPOSE_TO_OPEN); 
	$stmt->bindParam (6 , $this->NAME_OF_PLACE); 
	$stmt->bindParam (7 , $this->ADDITIONAL_DETAILS); 
	$stmt->bindParam (8 , $this->DISTRICT_CODE); 
	$stmt->bindParam (9 , $this->POLICE_STATION_CODE); 
	$stmt->bindParam (10 , $this->PLOTE_NO); 
	$stmt->bindParam (11 , $this->STATUS); 
	$stmt->bindParam (12 , $this->NOW_HERE); 
	$stmt->bindParam (13 , $this->POST_ON); 
	$stmt->bindParam (14 , $this->POST_BY); 
	$stmt->bindParam (15 , $this->UPDATE_ON); 
	$stmt->bindParam (16 , $this->UPDATE_BY); 
	$stmt->bindParam (17 , $this->SITE_TYPE); 
	$stmt->bindParam (18 , $this->LICENSE_FOR); 
	$stmt->bindParam (19 , $this->LICENSE_TYPE); 
	$stmt->bindParam (20 , $this->OTHERC); 
	$stmt->bindParam (21 , $this->NONC); 

	$stmt->execute(); 
	$success = 1;
        $this->ID = $this->conn->lastInsertId();
}
catch(PDOException $ex){ echo  $ex->getMessage(); } 
return $success;}

 /*----------------------------------------------------------*/

    public function loadValue($id) {
        $Q = "SELECT * FROM BASICINFOSITE WHERE ID = $id";
        $result = null;
        try {
            $stmt = $this->conn->prepare($Q);
            $stmt->bindParam(1, $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $this->ID = $row['ID'];
            $this->LICENSE_FOR = $row['LICENSE_FOR'];
            $this->LICENSE_TYPE = $row['LICENSE_TYPE'];
        } catch (PDOException $ex) {
            echo $ex->getMessage();
        }
        return $result;
    }



 /*----------------------------------------------------------*/

//This javascript function will redirect a another page
//after the execution of a function.
public function pageRedirect($page){
echo "<script type=\"text/javascript\">	";
echo "document.location = '".$page."' ";
echo "</script>";
}

    
    
private $ID;
private $DATE;
private $LICENSE_NO;
private $SERIAL_NO;
private $DISTANC_FROM_EDUCATION;
private $DISTANC_FROM_HIGHWAY;
private $PURPOSE_TO_OPEN;
private $NAME_OF_PLACE;
private $ADDITIONAL_DETAILS;
private $DISTRICT_CODE;
private $POLICE_STATION_CODE;
private $PLOTE_NO;
private $STATUS;
private $NOW_HERE;
private $POST_ON;
private $POST_BY;
private $UPDATE_ON;
private $UPDATE_BY;
private $SITE_TYPE;
private $NONC;
private $LICENSE_FOR;
private $LICENSE_TYPE;
private $OTHERC;

function setID($ID) { $this->ID = $ID; }
function getID() { return $this->ID; }
function setNONC($NONC) { $this->NONC = $NONC; }
function getNONC() { return $this->NONC; }
function setOTHERC($OTHERC) { $this->OTHERC = $OTHERC; }
function getOTHERC() { return $this->OTHERC; }
function setLICENSE_FOR($LICENSE_FOR) { $this->LICENSE_FOR = $LICENSE_FOR; }
function getLICENSE_FOR() { return $this->LICENSE_FOR; }
function setLICENSE_TYPE($LICENSE_TYPE) { $this->LICENSE_TYPE = $LICENSE_TYPE; }
function getLICENSE_TYPE() { return $this->LICENSE_TYPE; }
function setSITE_TYPE($SITE_TYPE) { $this->SITE_TYPE = $SITE_TYPE; }
function getSITE_TYPE() { return $this->SITE_TYPE; }
function setDATE($DATE) { $this->DATE = $DATE; }
function getDATE() { return $this->DATE; }
function setLICENSE_NO($LICENSE_NO) { $this->LICENSE_NO = $LICENSE_NO; }
function getLICENSE_NO() { return $this->LICENSE_NO; }
function setSERIAL_NO($SERIAL_NO) { $this->SERIAL_NO = $SERIAL_NO; }
function getSERIAL_NO() { return $this->SERIAL_NO; }
function setDISTANC_FROM_EDUCATION($DISTANC_FROM_EDUCATION) { $this->DISTANC_FROM_EDUCATION = $DISTANC_FROM_EDUCATION; }
function getDISTANC_FROM_EDUCATION() { return $this->DISTANC_FROM_EDUCATION; }
function setDISTANC_FROM_HIGHWAY($DISTANC_FROM_HIGHWAY) { $this->DISTANC_FROM_HIGHWAY = $DISTANC_FROM_HIGHWAY; }
function getDISTANC_FROM_HIGHWAY() { return $this->DISTANC_FROM_HIGHWAY; }
function setPURPOSE_TO_OPEN($PURPOSE_TO_OPEN) { $this->PURPOSE_TO_OPEN = $PURPOSE_TO_OPEN; }
function getPURPOSE_TO_OPEN() { return $this->PURPOSE_TO_OPEN; }
function setNAME_OF_PLACE($NAME_OF_PLACE) { $this->NAME_OF_PLACE = $NAME_OF_PLACE; }
function getNAME_OF_PLACE() { return $this->NAME_OF_PLACE; }
function setADDITIONAL_DETAILS($ADDITIONAL_DETAILS) { $this->ADDITIONAL_DETAILS = $ADDITIONAL_DETAILS; }
function getADDITIONAL_DETAILS() { return $this->ADDITIONAL_DETAILS; }
function setDISTRICT_CODE($DISTRICT_CODE) { $this->DISTRICT_CODE = $DISTRICT_CODE; }
function getDISTRICT_CODE() { return $this->DISTRICT_CODE; }
function setPOLICE_STATION_CODE($POLICE_STATION_CODE) { $this->POLICE_STATION_CODE = $POLICE_STATION_CODE; }
function getPOLICE_STATION_CODE() { return $this->POLICE_STATION_CODE; }
function setPLOTE_NO($PLOTE_NO) { $this->PLOTE_NO = $PLOTE_NO; }
function getPLOTE_NO() { return $this->PLOTE_NO; }
function setSTATUS($STATUS) { $this->STATUS = $STATUS; }
function getSTATUS() { return $this->STATUS; }
function setNOW_HERE($NOW_HERE) { $this->NOW_HERE = $NOW_HERE; }
function getNOW_HERE() { return $this->NOW_HERE; }
function setPOST_ON($POST_ON) { $this->POST_ON = $POST_ON; }
function getPOST_ON() { return $this->POST_ON; }
function setPOST_BY($POST_BY) { $this->POST_BY = $POST_BY; }
function getPOST_BY() { return $this->POST_BY; }
function setUPDATE_ON($UPDATE_ON) { $this->UPDATE_ON = $UPDATE_ON; }
function getUPDATE_ON() { return $this->UPDATE_ON; }
function setUPDATE_BY($UPDATE_BY) { $this->UPDATE_BY = $UPDATE_BY; }
function getUPDATE_BY() { return $this->UPDATE_BY; }

}
