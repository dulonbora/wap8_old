<?php

require_once '../include/db.php';

class Location {
    private $conn = null;
    public function __construct() {
        $Data = new Kanexon();
        $this->conn = $Data->getDb();
    }
    
    public function Insert(){
$query = "INSERT INTO LOCATION(LOCATION_NAME , PARENT_ID , DESCRIPTION , STATUS , TYPE , POST_ON , POST_BY , UPDATE_ON , UPDATE_BY) 
	VALUES ( ? , ? , ? , ? , ? , ? , ? , ? , ?) " ; 
$success = 0;
try{
	$stmt = $this->conn->prepare($query);
	$stmt->bindParam (1 , $this->LOCATION_NAME); 
	$stmt->bindParam (2 , $this->PARENT_ID); 
	$stmt->bindParam (3 , $this->DESCRIPTION); 
	$stmt->bindParam (4 , $this->STATUS); 
	$stmt->bindParam (5 , $this->TYPE); 
	$stmt->bindParam (6 , $this->POST_ON); 
	$stmt->bindParam (7 , $this->POST_BY); 
	$stmt->bindParam (8 , $this->UPDATE_ON); 
	$stmt->bindParam (9 , $this->UPDATE_BY); 

	$stmt->execute(); 
	$success = 1;}
catch(PDOException $ex){ echo  $ex->getMessage(); } 
return $success;}

 /*----------------------------------------------------------*/

public function Update($update_by){
$query = "UPDATE LOCATION SET LOCATION_NAME = ? , PARENT_ID = ? , DESCRIPTION = ? , STATUS = ? , TYPE = ? , UPDATE_ON = ? 
	WHERE UPDATE_BY = ? ";
$success = 0;
try{
	$stmt = $this->conn->prepare($query);
	$stmt->bindParam (1 , $this->LOCATION_NAME); 
	$stmt->bindParam (2 , $this->PARENT_ID); 
	$stmt->bindParam (3 , $this->DESCRIPTION); 
	$stmt->bindParam (4 , $this->STATUS); 
	$stmt->bindParam (5 , $this->TYPE); 
	$stmt->bindParam (6 , $this->UPDATE_ON); 
	$stmt->bindParam (7 , $update_by); 

	$stmt->execute(); 
	$success = 1;}
catch(PDOException $ex){ echo  $ex->getMessage(); } 
return $success;}

 /*----------------------------------------------------------*/

public function UpdateSingle($col, $val, $id){
$query = "UPDATE LOCATION SET '$col' = ? WHERE ID = ? ";
$success = 0;
try{
	$stmt = $this->conn->prepare($query);
	$stmt->bindParam (1 , $val); 
	$stmt->bindParam (2 , $id); 

	$stmt->execute(); 
	$success = 1;}
catch(PDOException $ex){ echo  $ex->getMessage(); } 
return $success;}

 /*----------------------------------------------------------*/

    public function loadValue($id) {
        $Q = "SELECT * FROM LOCATION WHERE ID = $id";
        $result = null;
        try {
            $stmt = $this->conn->prepare($Q);
            $stmt->bindParam(1, $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $this->ID = $row['ID'];
            $this->LOCATION_NAME = $row['LOCATION_NAME'];
            $this->PARENT_ID = $row['PARENT_ID'];
            $this->DESCRIPTION = $row['DESCRIPTION'];
            $this->STATUS = $row['STATUS'];
            $this->TYPE = $row['TYPE'];
            $this->POST_ON = $row['POST_ON'];
            $this->POST_BY = $row['POST_BY'];
            $this->UPDATE_ON = $row['UPDATE_ON'];
            $this->UPDATE_BY = $row['UPDATE_BY'];
        } catch (PDOException $ex) {
            echo $ex->getMessage();
        }
        return $result;
    }
    
    
    public function returnLocationId($locationName) {
        $Q = "SELECT * FROM LOCATION WHERE LOCATION_NAME = ?";
        $result = "";
        try {
            $stmt = $this->conn->prepare($Q);
            $stmt->bindParam(1, $locationName);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if($row > 0){$result = $row['ID'];}
            
        } catch (PDOException $ex) {
            echo $ex->getMessage();
        }
        return $result;
    }
    
 /*----------------------------------------------------------*/
    
    public function AlreadyExitDistric($location_name){
    $ok = 0;
    $query = "SELECT ID FROM LOCATION WHERE LOCATION_NAME = ? ";
    try{
    $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $location_name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            $ok = 1;
        }
     } catch(PDOException $ex){echo $ex->getMessage();}
    
    return $ok;
    }
    
 /*----------------------------------------------------------*/
    public function AlreadyExitPoliceStation($location_name, $dist_id, $pid){
    $ok = 0;
    $query = "SELECT ID FROM LOCATION WHERE LOCATION_NAME = ? AND TYPE = ? AND PARENT_ID = ? ";
    try{
    $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $location_name);
        $stmt->bindParam(2, $dist_id);
        $stmt->bindParam(3, $pid);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            $ok = 1;
        }
     } catch(PDOException $ex){echo $ex->getMessage();}
    
return $ok;
}
    
    
 /*----------------------------------------------------------*/

    public function getTotal($id, $pid) {
        $Q = "SELECT COUNT(*) AS TOTAL FROM LOCATION WHERE TYPE = ? AND PARENT_ID = ? ";
        $total = 0;
        try {
            $stmt = $this->conn->prepare($Q);
            $stmt->bindParam(1, $id);
            $stmt->bindParam(2, $pid);
            $stmt->execute();
            $total = $stmt->fetchColumn();
        } catch (PDOException $ex) {
            echo $ex->getMessage();
        }
        return $total;
    }

 /*----------------------------------------------------------*/
    
    
    public function allFecth($type) {
        $Q = "SELECT * FROM LOCATION WHERE TYPE = ? ORDER BY ID DESC";
        $result = null;
        try {
            $stmt = $this->conn->prepare($Q);
            $stmt->bindParam(1, $type);
            $stmt->execute();
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $ex) {
            echo $ex->getMessage();
        }
        return $result;
    }
    
 /*----------------------------------------------------------*/
    
        public function allFecthByParent($id) {
        $Q = "SELECT * FROM LOCATION WHERE PARENT_ID = ?";
        $result = null;
        try {
            $stmt = $this->conn->prepare($Q);
            $stmt->bindParam(1, $id);
            $stmt->execute();
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $ex) {
            echo $ex->getMessage();
        }
        return $result;
    }
    
        public function date($dt){
        $dat = $dt / 1000;
        $daaat = date('d-m-Y', $dat);
        $date = "";
        $category = "";
        $ddt = explode('-', $daaat);
        switch ($ddt[1]){
        case 1: $category = "Jan"; break;
        case 2: $category = "Feb"; break;
        case 3: $category = "Mar"; break;
        case 4: $category = "Apr"; break;
        case 5: $category = "May"; break;
        case 6: $category = "Jun"; break;
        case 7: $category = "Jul"; break;
        case 8: $category = "Aug"; break;
        case 9: $category = "Sep"; break;
        case 10: $category = "Oct"; break;
        case 11: $category = "Nov"; break;
        default : $category = "Dec";
    }
    $date = $category." ".$ddt[0]." ".$ddt[2];
        return $date;
    }


    
private $ID;
private $LOCATION_NAME;
private $PARENT_ID;
private $DESCRIPTION;
private $STATUS;
private $TYPE;
private $POST_ON;
private $POST_BY;
private $UPDATE_ON;
private $UPDATE_BY;

function setID($ID) { $this->ID = $ID; }
function getID() { return $this->ID; }
function setLOCATION_NAME($LOCATION_NAME) { $this->LOCATION_NAME = $LOCATION_NAME; }
function getLOCATION_NAME() { return $this->LOCATION_NAME; }
function setPARENT_ID($PARENT_ID) { $this->PARENT_ID = $PARENT_ID; }
function getPARENT_ID() { return $this->PARENT_ID; }
function setDESCRIPTION($DESCRIPTION) { $this->DESCRIPTION = $DESCRIPTION; }
function getDESCRIPTION() { return $this->DESCRIPTION; }
function setSTATUS($STATUS) { $this->STATUS = $STATUS; }
function getSTATUS() { return $this->STATUS; }
function setTYPE($TYPE) { $this->TYPE = $TYPE; }
function getTYPE() { return $this->TYPE; }
function setPOST_ON($POST_ON) { $this->POST_ON = $POST_ON; }
function getPOST_ON() { return $this->POST_ON; }
function setPOST_BY($POST_BY) { $this->POST_BY = $POST_BY; }
function getPOST_BY() { return $this->POST_BY; }
function setUPDATE_ON($UPDATE_ON) { $this->UPDATE_ON = $UPDATE_ON; }
function getUPDATE_ON() { return $this->UPDATE_ON; }
function setUPDATE_BY($UPDATE_BY) { $this->UPDATE_BY = $UPDATE_BY; }
function getUPDATE_BY() { return $this->UPDATE_BY; }

}
