<?php

require_once '../include/db.php';
class Partners {
     private $conn = null;
    public function __construct() {
        $Data = new Kanexon();
        $this->conn = $Data->getDb();
    }
    
    
    
    public function Insert(){
$query = "INSERT INTO PARTNERSHIP(BASIC_ID , TYPE , FIRST_NAME , MIDDLE_NAME , LAST_NAME , AGE , NATIONALITY , EMAIL , PHONE , ADDRESS_P , ADDRESS_C , QULIFICATION , PARTNERSHIP_DEED , PARTNERSHIP_CERTIFICATE , STATEMENT_OF_NET_WORTH , PANCARD , INCOME_TAX_RETURNS , PHOTO_LINK , POST_ON , POST_BY , UPDATE_ON , UPDATE_BY) 
	VALUES ( ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ?) " ; 
$success = 0;
try{
	$stmt = $this->conn->prepare($query);
	$stmt->bindParam (1 , $this->BASIC_ID); 
	$stmt->bindParam (2 , $this->TYPE); 
	$stmt->bindParam (3 , $this->FIRST_NAME); 
	$stmt->bindParam (4 , $this->MIDDLE_NAME); 
	$stmt->bindParam (5 , $this->LAST_NAME); 
	$stmt->bindParam (6 , $this->AGE); 
	$stmt->bindParam (7 , $this->NATIONALITY); 
	$stmt->bindParam (8 , $this->EMAIL); 
	$stmt->bindParam (9 , $this->PHONE); 
	$stmt->bindParam (10 , $this->ADDRESS_P); 
	$stmt->bindParam (11 , $this->ADDRESS_C); 
	$stmt->bindParam (12 , $this->QULIFICATION); 
	$stmt->bindParam (13 , $this->PARTNERSHIP_DEED); 
	$stmt->bindParam (14 , $this->PARTNERSHIP_CERTIFICATE); 
	$stmt->bindParam (15 , $this->STATEMENT_OF_NET_WORTH); 
	$stmt->bindParam (16 , $this->PANCARD); 
	$stmt->bindParam (17 , $this->INCOME_TAX_RETURNS); 
	$stmt->bindParam (18 , $this->PHOTO_LINK); 
	$stmt->bindParam (19 , $this->POST_ON); 
	$stmt->bindParam (20 , $this->POST_BY); 
	$stmt->bindParam (21 , $this->UPDATE_ON); 
	$stmt->bindParam (22 , $this->UPDATE_BY); 

	$stmt->execute(); 
	$success = 1;}
catch(PDOException $ex){ echo  $ex->getMessage(); } 
return $success;}

 /*----------------------------------------------------------*/

//This javascript function will redirect a another page
//after the execution of a function.
public function pageRedirect($page){
echo "<script type=\"text/javascript\">	";
echo "document.location = '".$page."' ";
echo "</script>";
}
    
    
private $ID;
private $BASIC_ID;
private $TYPE;
private $FIRST_NAME;
private $MIDDLE_NAME;
private $LAST_NAME;
private $AGE;
private $NATIONALITY;
private $EMAIL;
private $PHONE;
private $ADDRESS_P;
private $ADDRESS_C;
private $QULIFICATION;
private $PARTNERSHIP_DEED;
private $PARTNERSHIP_CERTIFICATE;
private $STATEMENT_OF_NET_WORTH;
private $PANCARD;
private $INCOME_TAX_RETURNS;
private $PHOTO_LINK;
private $POST_ON;
private $POST_BY;
private $UPDATE_ON;
private $UPDATE_BY;

function setID($ID) { $this->ID = $ID; }
function getID() { return $this->ID; }
function setBASIC_ID($BASIC_ID) { $this->BASIC_ID = $BASIC_ID; }
function getBASIC_ID() { return $this->BASIC_ID; }
function setTYPE($TYPE) { $this->TYPE = $TYPE; }
function getTYPE() { return $this->TYPE; }
function setFIRST_NAME($FIRST_NAME) { $this->FIRST_NAME = $FIRST_NAME; }
function getFIRST_NAME() { return $this->FIRST_NAME; }
function setMIDDLE_NAME($MIDDLE_NAME) { $this->MIDDLE_NAME = $MIDDLE_NAME; }
function getMIDDLE_NAME() { return $this->MIDDLE_NAME; }
function setLAST_NAME($LAST_NAME) { $this->LAST_NAME = $LAST_NAME; }
function getLAST_NAME() { return $this->LAST_NAME; }
function setAGE($AGE) { $this->AGE = $AGE; }
function getAGE() { return $this->AGE; }
function setNATIONALITY($NATIONALITY) { $this->NATIONALITY = $NATIONALITY; }
function getNATIONALITY() { return $this->NATIONALITY; }
function setEMAIL($EMAIL) { $this->EMAIL = $EMAIL; }
function getEMAIL() { return $this->EMAIL; }
function setPHONE($PHONE) { $this->PHONE = $PHONE; }
function getPHONE() { return $this->PHONE; }
function setADDRESS_P($ADDRESS_P) { $this->ADDRESS_P = $ADDRESS_P; }
function getADDRESS_P() { return $this->ADDRESS_P; }
function setADDRESS_C($ADDRESS_C) { $this->ADDRESS_C = $ADDRESS_C; }
function getADDRESS_C() { return $this->ADDRESS_C; }
function setQULIFICATION($QULIFICATION) { $this->QULIFICATION = $QULIFICATION; }
function getQULIFICATION() { return $this->QULIFICATION; }
function setPARTNERSHIP_DEED($PARTNERSHIP_DEED) { $this->PARTNERSHIP_DEED = $PARTNERSHIP_DEED; }
function getPARTNERSHIP_DEED() { return $this->PARTNERSHIP_DEED; }
function setPARTNERSHIP_CERTIFICATE($PARTNERSHIP_CERTIFICATE) { $this->PARTNERSHIP_CERTIFICATE = $PARTNERSHIP_CERTIFICATE; }
function getPARTNERSHIP_CERTIFICATE() { return $this->PARTNERSHIP_CERTIFICATE; }
function setSTATEMENT_OF_NET_WORTH($STATEMENT_OF_NET_WORTH) { $this->STATEMENT_OF_NET_WORTH = $STATEMENT_OF_NET_WORTH; }
function getSTATEMENT_OF_NET_WORTH() { return $this->STATEMENT_OF_NET_WORTH; }
function setPANCARD($PANCARD) { $this->PANCARD = $PANCARD; }
function getPANCARD() { return $this->PANCARD; }
function setINCOME_TAX_RETURNS($INCOME_TAX_RETURNS) { $this->INCOME_TAX_RETURNS = $INCOME_TAX_RETURNS; }
function getINCOME_TAX_RETURNS() { return $this->INCOME_TAX_RETURNS; }
function setPHOTO_LINK($PHOTO_LINK) { $this->PHOTO_LINK = $PHOTO_LINK; }
function getPHOTO_LINK() { return $this->PHOTO_LINK; }
function setPOST_ON($POST_ON) { $this->POST_ON = $POST_ON; }
function getPOST_ON() { return $this->POST_ON; }
function setPOST_BY($POST_BY) { $this->POST_BY = $POST_BY; }
function getPOST_BY() { return $this->POST_BY; }
function setUPDATE_ON($UPDATE_ON) { $this->UPDATE_ON = $UPDATE_ON; }
function getUPDATE_ON() { return $this->UPDATE_ON; }
function setUPDATE_BY($UPDATE_BY) { $this->UPDATE_BY = $UPDATE_BY; }
function getUPDATE_BY() { return $this->UPDATE_BY; }

}
