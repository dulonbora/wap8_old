<?php

class otherFunctions {

    /**
     * Function getAgeFromDateFormat()
     * This Function Return Age From Date format
     * date in mm/dd/yyyy format; or it can be in other formats as well
     * Parameters:
     *     ($dateFormat) - Sent This Param To This Function In data format
     */
    
    public function getAgeFromDateFormat($dateFormat) {
        $age = 0;
        $birthDate = explode("/", $dateFormat); //explode the date to get month, day and year
        $age = (date("md", date("U", mktime(0, 0, 0, $birthDate[0], $birthDate[1], $birthDate[2]))) > date("md") ? ((date("Y") - $birthDate[2]) - 1) : (date("Y") - $birthDate[2]));
        return $age;
    }
    
    
        public function date($dt){
        $d = $dt / 1000;
        $dat = date('d-m-Y', $d);  
        $date = "";
        $category = "";
        $ddt = explode('-', $dat);
        switch ($ddt[1]){
        case 1: $category = "Jan"; break;
        case 2: $category = "Feb"; break;
        case 3: $category = "Mar"; break;
        case 4: $category = "Apr"; break;
        case 5: $category = "May"; break;
        case 6: $category = "Jun"; break;
        case 7: $category = "Jul"; break;
        case 8: $category = "Aug"; break;
        case 9: $category = "Sep"; break;
        case 10: $category = "Oct"; break;
        case 11: $category = "Nov"; break;
    default : $category = "Dec";
}
$date = $category." ".$ddt[0]." ".$ddt[2];
        return $date;
    }


}
