<?php


require_once '../include/db.php';
class Company {
     private $conn = null;
    public function __construct() {
        $Data = new Kanexon();
        $this->conn = $Data->getDb();
    }    
    
    
    public function Insert(){
$query = "INSERT INTO COMPANY(BASIC_ID , COMPANY_NAME , ADDRESS , COMPANY_CERTIFICATE , BALANCE_SHEET , PROOF_OF_DOC_COMPANY , PARTICULARS_OF_BANK , PANCARD , INCOME_TAX_RETURNS , BORD_RESOLUTION , PHOTO_LINK , POST_ON , POST_BY , UPDATE_ON , UPDATE_BY, POD) 
	VALUES ( ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ?, ?) " ; 
$success = 0;
try{
	$stmt = $this->conn->prepare($query);
	$stmt->bindParam (1 , $this->BASIC_ID); 
	$stmt->bindParam (2 , $this->COMPANY_NAME); 
	$stmt->bindParam (3 , $this->ADDRESS); 
	$stmt->bindParam (4 , $this->COMPANY_CERTIFICATE); 
	$stmt->bindParam (5 , $this->BALANCE_SHEET); 
	$stmt->bindParam (6 , $this->PROOF_OF_DOC_COMPANY); 
	$stmt->bindParam (7 , $this->PARTICULARS_OF_BANK); 
	$stmt->bindParam (8 , $this->PANCARD); 
	$stmt->bindParam (9 , $this->INCOME_TAX_RETURNS); 
	$stmt->bindParam (10 , $this->BORD_RESOLUTION); 
	$stmt->bindParam (11 , $this->PHOTO_LINK); 
	$stmt->bindParam (12 , $this->POST_ON); 
	$stmt->bindParam (13 , $this->POST_BY); 
	$stmt->bindParam (14 , $this->UPDATE_ON); 
	$stmt->bindParam (15 , $this->UPDATE_BY); 
	$stmt->bindParam (16 , $this->POD); 

	$stmt->execute(); 
	$success = 1;}
catch(PDOException $ex){ echo  $ex->getMessage(); } 
return $success;}

 /*----------------------------------------------------------*/
//This javascript function will redirect a another page
//after the execution of a function.
public function pageRedirect($page){
echo "<script type=\"text/javascript\">	";
echo "document.location = '".$page."' ";
echo "</script>";
}

private $ID;
private $BASIC_ID;
private $COMPANY_NAME;
private $ADDRESS;
private $POD;
private $COMPANY_CERTIFICATE;
private $BALANCE_SHEET;
private $PROOF_OF_DOC_COMPANY;
private $PARTICULARS_OF_BANK;
private $PANCARD;
private $INCOME_TAX_RETURNS;
private $BORD_RESOLUTION;
private $PHOTO_LINK;
private $POST_ON;
private $POST_BY;
private $UPDATE_ON;
private $UPDATE_BY;


function setID($ID) { $this->ID = $ID; }
function getID() { return $this->ID; }
function setBASIC_ID($BASIC_ID) { $this->BASIC_ID = $BASIC_ID; }
function getBASIC_ID() { return $this->BASIC_ID; }

function setPOD($POD) { $this->POD = $POD; }
function getPOD() { return $this->POD; }
function setTYPE($TYPE) { $this->TYPE = $TYPE; }
function getTYPE() { return $this->TYPE; }
function setCOMPANY_NAME($COMPANY_NAME) { $this->COMPANY_NAME = $COMPANY_NAME; }
function getCOMPANY_NAME() { return $this->COMPANY_NAME; }
function setADDRESS($ADDRESS) { $this->ADDRESS = $ADDRESS; }
function getADDRESS() { return $this->ADDRESS; }
function setCOMPANY_CERTIFICATE($COMPANY_CERTIFICATE) { $this->COMPANY_CERTIFICATE = $COMPANY_CERTIFICATE; }
function getCOMPANY_CERTIFICATE() { return $this->COMPANY_CERTIFICATE; }
function setBALANCE_SHEET($BALANCE_SHEET) { $this->BALANCE_SHEET = $BALANCE_SHEET; }
function getBALANCE_SHEET() { return $this->BALANCE_SHEET; }
function setPROOF_OF_DOC_COMPANY($PROOF_OF_DOC_COMPANY) { $this->PROOF_OF_DOC_COMPANY = $PROOF_OF_DOC_COMPANY; }
function getPROOF_OF_DOC_COMPANY() { return $this->PROOF_OF_DOC_COMPANY; }
function setPARTICULARS_OF_BANK($PARTICULARS_OF_BANK) { $this->PARTICULARS_OF_BANK = $PARTICULARS_OF_BANK; }
function getPARTICULARS_OF_BANK() { return $this->PARTICULARS_OF_BANK; }
function setPANCARD($PANCARD) { $this->PANCARD = $PANCARD; }
function getPANCARD() { return $this->PANCARD; }
function setINCOME_TAX_RETURNS($INCOME_TAX_RETURNS) { $this->INCOME_TAX_RETURNS = $INCOME_TAX_RETURNS; }
function getINCOME_TAX_RETURNS() { return $this->INCOME_TAX_RETURNS; }
function setBORD_RESOLUTION($BORD_RESOLUTION) { $this->BORD_RESOLUTION = $BORD_RESOLUTION; }
function getBORD_RESOLUTION() { return $this->BORD_RESOLUTION; }
function setPHOTO_LINK($PHOTO_LINK) { $this->PHOTO_LINK = $PHOTO_LINK; }
function getPHOTO_LINK() { return $this->PHOTO_LINK; }
function setPOST_ON($POST_ON) { $this->POST_ON = $POST_ON; }
function getPOST_ON() { return $this->POST_ON; }
function setPOST_BY($POST_BY) { $this->POST_BY = $POST_BY; }
function getPOST_BY() { return $this->POST_BY; }
function setUPDATE_ON($UPDATE_ON) { $this->UPDATE_ON = $UPDATE_ON; }
function getUPDATE_ON() { return $this->UPDATE_ON; }
function setUPDATE_BY($UPDATE_BY) { $this->UPDATE_BY = $UPDATE_BY; }
function getUPDATE_BY() { return $this->UPDATE_BY; }

}
