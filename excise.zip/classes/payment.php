<?php

require_once '../include/db.php';

class Payment {
    private $conn = null;
    public function __construct() {
        $Data = new Kanexon();
        $this->conn = $Data->getDb();
    }
    
  public function Insert(){
        
$query = "INSERT INTO PAYMENT ( ID, USER_ID , PERMIT_ID , LIC_ID , DEPT_CODE ,  ECHALLAN_NO ,LIC_NO ,PERMIT_NO ,
    AMT, TREASURY_CODE , TREASURY_H_AC , TREASURY_SH_AC ,IFSC_CODE ,  BANK_NAME , BANK_CODE , TRANS_ID ,
    DATE_TIME_TRANS , WALLET_ID ,MOBILE_NO , POST_ON , POST_BY ) 
	VALUES ( ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ?) " ; 
$success = 0;
try{
	$stmt = $this->conn->prepare($query);
	$stmt->bindParam (1 , $this->ID); 
	$stmt->bindParam (2 , $this->USER_ID); 
	$stmt->bindParam (3 , $this->PERMIT_ID); 
	$stmt->bindParam (4 , $this->LIC_ID); 
	$stmt->bindParam (5 , $this->DEPT_CODE); 
	$stmt->bindParam (6 , $this->ECHALLAN_NO); 
	$stmt->bindParam (7 , $this->LIC_NO); 
	$stmt->bindParam (8 , $this->PERMIT_NO); 
	$stmt->bindParam (9 , $this->AMT);
        $stmt->bindParam (10 , $this->TREASURY_CODE);
        $stmt->bindParam (11 , $this->TREASURY_H_AC);
        $stmt->bindParam (12 , $this->TREASURY_SH_AC);
        $stmt->bindParam (13 , $this->IFSC_CODE);
        $stmt->bindParam (14 , $this->BANK_NAME);
        $stmt->bindParam (15 , $this->BANK_CODE);
        $stmt->bindParam (16 , $this->TRANS_ID);
        $stmt->bindParam (17 , $this->DATE_TIME_TRANS);
        $stmt->bindParam (18 , $this->WALLET_ID);
        $stmt->bindParam (19 , $this->MOBILE_NO);
        $stmt->bindParam (20 , $this->POST_ON);
        $stmt->bindParam (21 , $this->POST_BY);

	$stmt->execute(); 
	$success = 1;}
catch(PDOException $ex){ echo  $ex->getMessage(); } 
return $success;}

 /*----------------------------------------------------------*/

public function Update($update_by){
$query = "UPDATE PAYEMENT SET STATUS = ? WHERE TRANS_ID = ? ";
$success = 0;
try{
	$stmt = $this->conn->prepare($query);
	$stmt->bindParam (1 , $this->STATUS); 
	$stmt->bindParam (2 , $this->TRANS_ID); 
	$stmt->execute(); 
	$success = 1;}
catch(PDOException $ex){ echo  $ex->getMessage(); } 
return $success;}

    
    
    
        
   

    
private $ID;
private $USER_ID;
private $PERMIT_ID;
private $LIC_ID;
private $DEPT_CODE;
private $ECHALLAN_NO;
private $LIC_NO;
private $PERMIT_NO;
private $AMT;
private $TREASURY_CODE;
private $TREASURY_H_AC;
private $TREASURY_SH_AC;
private $IFSC_CODE;
private $BANK_NAME;
private $BANK_CODE;
private $TRANS_ID;
private $DATE_TIME_TRANS;
private $WALLET_ID;
private $MOBILE_NO;

private $POST_BY;
private $STATUS;

function setSTATUS($STATUS) { $this->STATUS = $STATUS; }
function getSTATUS() { return $this->STATUS; } 

function setID($ID) { $this->ID = $ID; }
function getID() { return $this->ID; }
function setUSER_ID($USER_ID) { $this->USER_ID = $USER_ID; }
function getUSER_ID() { return $this->USER_ID; }
function setPERMIT_ID($PERMIT_ID) { $this->PERMIT_ID = $PERMIT_ID; }
function getPERMIT_ID() { return $this->PERMIT_ID; }
function setLIC_ID($LIC_ID) { $this->LIC_ID = $LIC_ID; }
function getLIC_ID() { return $this->LIC_ID; }
function setDEPT_CODE($DEPT_CODE) { $this->DEPT_CODE = $DEPT_CODE; }
function getDEPT_CODE() { return $this->DEPT_CODE; }
function setECHALLAN_NO($ECHALLAN_NO) { $this->ECHALLAN_NO = $ECHALLAN_NO; }
function getECHALLAN_NO() { return $this->ECHALLAN_NO; }
function setLIC_NO($LIC_NO) { $this->LIC_NO = $LIC_NO; }
function getLIC_NO() { return $this->LIC_NO; }
function setPERMIT_NO($PERMIT_NO) { $this->PERMIT_NO = $PERMIT_NO; }
function getPERMIT_NO() { return $this->PERMIT_NO; }
function setAMT($AMT) { $this->AMT = $AMT; }
function getAMT() { return $this->AMT; }
function setTREASURY_CODE($TREASURY_CODE) { $this->TREASURY_CODE = $TREASURY_CODE; }
function getTREASURY_CODE() { return $this->TREASURY_CODE; }
function setTREASURY_H_AC($TREASURY_H_AC) { $this->TREASURY_H_AC = $TREASURY_H_AC; }
function getTREASURY_H_AC() { return $this->TREASURY_H_AC; }
function setTREASURY_SH_AC($TREASURY_SH_AC) { $this->TREASURY_SH_AC = $TREASURY_SH_AC; }
function getTREASURY_SH_AC() { return $this->TREASURY_SH_AC; }
function setIFSC_CODE($IFSC_CODE) { $this->IFSC_CODE = $IFSC_CODE; }
function getIFSC_CODE() { return $this->IFSC_CODE; }
function setBANK_NAME($BANK_NAME) { $this->BANK_NAME = $BANK_NAME; }
function getBANK_NAME() { return $this->BANK_NAME; }
function setBANK_CODE($BANK_CODE) { $this->BANK_CODE = $BANK_CODE; }
function getBANK_CODE() { return $this->BANK_CODE; }
function setTRANS_ID($TRANS_ID) { $this->TRANS_ID = $TRANS_ID; }
function getTRANS_ID() { return $this->TRANS_ID; }
function setDATE_TIME_TRANS($DATE_TIME_TRANS) { $this->DATE_TIME_TRANS = $DATE_TIME_TRANS; }
function getDATE_TIME_TRANS() { return $this->DATE_TIME_TRANS; }
function setWALLET_ID($WALLET_ID) { $this->WALLET_ID = $WALLET_ID; }
function getWALLET_ID() { return $this->WALLET_ID; }
function setMOBILE_NO($MOBILE_NO) { $this->MOBILE_NO = $MOBILE_NO; }
function getMOBILE_NO() { return $this->MOBILE_NO; }

function setPOST_BY($POST_BY) { $this->POST_BY = $POST_BY; }
function getPOST_BY() { return $this->POST_BY; }



}
