<?php
include '../classes/Create_Tables.php';
$db = new Create_Table();
$db->Pages();
$db->User();
$db->Category();
$db->Location();
$db->payment();
$db->BasicInfo();
$db->ApplicantInfo();
$db->PARTNERSHIP();
$db->COMPANY();
$db->DocumentDetails();
//$db->BasicInfo();
//$db->SiteDetails();

?>
