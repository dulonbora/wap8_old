<?php ob_start();
if(!isset($_SESSION)){session_start();}
include '../classes/User.php';
$user = new User();
?>
<!doctype html>

<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="Introducing Lollipop, a sweet new take on Android.">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
    <title>Assame Excise Department</title>

    <!-- Page styles -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:regular,bold,italic,thin,light,bolditalic,black,medium&amp;lang=en">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="../css/material.blue_grey-green.min.css" />
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="../css/dropdown.css">
    <link rel="stylesheet" href="../css/tables.css">
    <link rel="stylesheet" href="../css/getmdl-select.min.css">
    <link rel="stylesheet" href="../css/material.components.ext.min.css">
    <script src="../js/jquery-1.11.3.min.js"></script>
    <script src="../js/material.components.ext.min.js"></script>
    <script src="../js/getmdl-select.min.js"></script>
  </head>
  
  <style type="text/css">
        .containermet{width: 95%; background:white}
        .container-head{width: 100%;
            background: #00BBD3;
            color: white;
            height:300px;
            padding: 2%;
            }
        </style>
  <body>
    <div class="mdl-layout mdl-js-layout mdl-layout--fixed-header">

        <div class="android-header mdl-layout__header mdl-layout__header--waterfall">
        <div class="mdl-layout__header-row">
          <span class="android-title mdl-layout-title">
              <img class="android-logo-image" src="">
          </span>
          <!-- Add spacer, to align navigation to the right in desktop -->
          <div class="android-header-spacer mdl-layout-spacer"></div>
          <!-- Navigation -->
          <div class="android-navigation-container">
            <nav class="android-navigation mdl-navigation">
              
              <li class="mdl-navigation__link mdl-typography--text-uppercase drop">Customers
                  <ul style="background: #006064; margin-top: 22px;">
                      <div style="margin-left: -40px;">
                      <li class=""><a href="page.php?i=4">Acts</a></li>
                      <li class=""><a href="page.php?i=4">Rules</a></li>
                      <li class=""><a href="page.php?i=4">Regulations</a></li>
                      <li class=""><a href="page.php?i=4">Manuals</a></li>
                      <li class=""><a href="page.php?i=4">Notifications</a></li>
                      <li class=""><a href="page.php?i=4">Case Law-ECS</a></li>
                      <li class=""><a href="page.php?i=4">SEZ</a></li>
                      <li class=""><a href="page.php?i=4">Drawback Schedule</a></li>
                      <li class=""><a href="page.php?i=4">Customs Duty Calculator</a></li>
                      <li class=""><a href="page.php?i=4">FAQ on warehousing</a></li>
                      </div>
                  </ul> 
              </li>
              
              <li class="mdl-navigation__link mdl-typography--text-uppercase drop">ABOUT US
                  <ul style="background: #006064; margin-top: 22px;">
                      <div style="margin-left: -40px;">
                      <li class=""><a href="page.php?i=4">History</a></li>
                      <li class=""><a href="page.php?i=4">Administratitive Setup</a></li>
                      <li class=""><a href="page.php?i=4">Jurisdiction</a></li>
                      <li class=""><a href="page.php?i=4">Power & Duties</a></li>
                      <li class=""><a href="page.php?i=4">Function</a></li>
                      <li class=""><a href="page.php?i=4">Our Mission</a></li>
                      <li class=""><a href="page.php?i=4">Citizen Charter</a></li>
                      </div>
                  </ul> 
              </li>
              
              <li class="mdl-navigation__link mdl-typography--text-uppercase drop">SERVICE TAX
                  <ul style="background: #006064; margin-top: 22px;">
                      <div style="margin-left: -40px;">
                      <li class=""><a href="page.php?i=4">Overview</a></li>
                      <li class=""><a href="page.php?i=4">FAQs</a></li>
                      <li class=""><a href="page.php?i=4">ACT</a></li>
                      <li class=""><a href="page.php?i=4">Rules</a></li>
                      <li class=""><a href="page.php?i=4">Notifications</a></li>
                      <li class=""><a href="page.php?i=4">Circular/Instructions</a></li>
                      <li class=""><a href="page.php?i=4">E-Payment</a></li>
                      <li class=""><a href="page.php?i=4">Accounting Codes for New Services</a></li>
                      <li class=""><a href="page.php?i=4">Procedure for E-Payment</a></li>
                      <li class=""><a href="page.php?i=4">Service Tax Procedure</a></li>
                      <li class=""><a href="page.php?i=4">Service Profile</a></li>
                      </div>
                  </ul> 
              </li>
              
              <li class="mdl-navigation__link mdl-typography--text-uppercase drop">New & Media
                  <ul style="background: #006064; margin-top: 22px;">
                      <div style="margin-left: -40px;">
                      <li class=""><a href="page.php?i=4">Press Release</a></li>
                      <li class=""><a href="page.php?i=4">Photo Gallery</a></li>
                      <li class=""><a href="page.php?i=4">Media</a></li>
                      </div>
                  </ul> 
              </li>
              
              <a class="mdl-navigation__link mdl-typography--text-uppercase" href="page.php?i=4">CONTACT US</a>
            </nav>
          </div>
          <span class="android-mobile-title mdl-layout-title">
            <img class="android-logo-image" src="">
          </span>
          <button class="android-more-button mdl-button mdl-js-button mdl-button--icon mdl-js-ripple-effect" id="more-button">
            <i class="material-icons">more_vert</i>
          </button>
          <ul class="mdl-menu mdl-js-menu mdl-menu--bottom-right mdl-js-ripple-effect" for="more-button">
              <?php $user->showLogin();?>
          </ul>
        </div>
      </div>

      <div class="android-drawer mdl-layout__drawer">
        <span class="mdl-layout-title">
          <img class="android-logo-image" src="">
        </span>
          
          
        <nav class="mdl-navigation">
            <a class="mdl-navigation__link" href="../site/login.php">Login</a>
          <span class="mdl-navigation__link" href="">Versions</span>
          <span class="mdl-navigation__link" href="">Resources</span>
          <div class="android-drawer-separator"></div>
          <span class="mdl-navigation__link" href="">For developers</span>
        </nav>
      </div>
        
              <div class="android-content mdl-layout__content">
