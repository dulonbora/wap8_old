
        <!--- Javascript Lib-->

        <script src="../assets/js/common.min.js"></script>
        <script src="../assets/js/uikit_custom.min.js"></script>
        <script src="../assets/js/altair_admin_common.min.js"></script>
        <script src="../assets/js/pages/login.min.js"></script>



    </body>
</html>