<?php
include '../classes/User.php';
$user = new User();
$user->logOut();
$user->pageRedirect("index.php");
?>