<?php

1:	Soft Copies ("jpg") of following items will be required to Submit Application :-
i. Passport Size Photograph of Applicant
 
2:	Applicant Specific Documents ("doc", "docx", "pdf", "PDF", "DOC", "jpg", "JPG"):-
2.i.Self Attested Photocopy of Nationality Proof (Voter Id Card or Passport) / P.I.O. Status (Certificate from Competent Authority).
2.ii.Self Attested Photocopy of Proof of Date of Birth (Birth Certificate / Admit Card of Madhyamik Pariksha or Equivalent Secondary School level Examination / PAN Card).
2.iii.Self Attested Photocopy in support of Highest Educational Qualification.
2.iv.Medical Fitness Certificate from a Registered Medical Practitioner.
2.v.Self Attested Photocopy of Income Tax Return Acknowledgement Slip for the last Assessment Year.
2.vi.Affidavit affirmed by the Individual before the Competent Authority regarding his/her Non-Conviction by a Criminal Court in a Non-Bailable Offence.
2.vii.Self Attested Photocopy of PAN Card.
 
3:	Proposed Site Specific Documents ("doc", "docx", "pdf", "PDF", "DOC", "jpg", "JPG"):-
3.i.Copy of Record of Rights (ROR) of Land / Parcha.
3.ii.Copy of NOC of Land Owner/ Competent Authority if the Offered Site is not owned by the Applicant.
3.iii.Document in Support of Commercial use of Land (ROR / Parcha with endorsement regarding Commercial use / Commercial Land use Certificate from the Competent L & LR Authority).
3.iv.Site Plan Prepared by Approved Surveyor(Signature with Seal) and duly Signed by the Applicant(s), Owner(s) of the Premises.
3.v.Copy of Trade License / Certificate of Enlistment.
3.vi.Copy of VAT Registration Certificate.
3.vii.Copy of Current Food License issued by Competent Authority (FSSAI) , if applicable.
 
4:	Application Fee
Payment Details of Application fee paid Online through GRIPS