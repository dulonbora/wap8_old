<?php include '../include/header_site.php';?>
        <a name="top"></a>

<?php if(isset($_SESSION['USER_ID'])==null)
    { header('Location: index.php'); }
    else {?>
        
        
        <div class="android-more-section" style="width: 90%;">
            <h3 class="android-section-title mdl-typography--display-1-color-contrast" style="text-align: center;">Apply License</h3>

            <p class="mdl-typography--font-light">
                Select Your
            </p>
            
        <div class="android-card-container mdl-grid">
            <a href="../apply/apply_applicant_details_retailer.php" class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--accent mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
  Manufactory
            </a>

<button class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--accent mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
  Wholesaler
</button>
      
  <button class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--accent mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
  Retailer
  </button>
            </div>
        </div>
     <?php
    }
?>


        

        
<?php include '../include/footer_site.php';?>
