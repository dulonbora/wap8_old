<?php include '../include/gen_Header.php';?>
 <link rel="stylesheet" href="https://cdn.rawgit.com/CreativeIT/getmdl-select/master/getmdl-select.min.css">
   <script defer src="https://cdn.rawgit.com/CreativeIT/getmdl-select/master/getmdl-select.min.js"></script>
        <div class="login_page_wrapper">
            <div class="md-card" id="login_card">



                <!--- Login Form Html Code-->
                <div class="md-card-content large-padding" id="login_form">
                    <div class="login_heading">
                        <div class="user_avatar"></div>
                    </div>
                    <h4 style="color: #039be5; text-align: center;" id="logmassage" class="heading_a uk-margin-medium-bottom"></h4>
                    <form id="Login_from_id" action="">
                        <div class="uk-form-row">
                            <label for="login_email">Email</label>
                            <input class="md-input" type="email" id="login_email" name="login_email" required/>
                        </div>
                        <div class="uk-form-row">
                            <label for="login_password">Password</label>
                            <input class="md-input" type="password" id="login_password" name="login_password" required/>
                        </div>
                        
                        <div class="uk-margin-medium-top">
                            <button type="button" id="login_btn" class="md-btn md-btn-primary md-btn-block md-btn-large">Sign In</button>
                        </div>
                        
                        <div class="uk-margin-top">
                            <a href="#" id="login_help_show" class="uk-float-right">Forget Password?</a>
                            <span class="icheck-inline">
                                <input type="checkbox" name="login_page_stay_signed" id="login_page_stay_signed" data-md-icheck />
                                <label for="login_page_stay_signed" class="inline-label">Stay signed in</label>
                            </span>
                        </div>
                    </form>
                </div>


                <!--- Forget Password Html Code-->
                <div class="md-card-content large-padding uk-position-relative" id="login_help" style="display: none">
                    <button type="button" class="uk-position-top-right uk-close uk-margin-right uk-margin-top back_to_login"></button>
                    <h2 class="heading_b uk-text-success">Can't log in?</h2>
                    <p>Here’s the info to get you back in to your account as quickly as possible.</p>
                    <p>First, try the easiest thing: if you remember your password but it isn’t working, make sure that Caps Lock is turned off, and that your username is spelled correctly, and then try again.</p>
                    <p>If your password still isn’t working, it’s time to <a href="#" id="password_reset_show">reset your password</a>.</p>
                </div>


                <!--- Forget Email Entry Html Code-->

                <div class="md-card-content large-padding" id="login_password_reset" style="display: none">
                    <button type="button" class="uk-position-top-right uk-close uk-margin-right uk-margin-top back_to_login"></button>
                    <h2 class="heading_a uk-margin-large-bottom">Reset password</h2>
                    <form>
                        <div class="uk-form-row">
                            <label for="login_email_reset">Your email address</label>
                            <input class="md-input" type="text" id="login_email_reset" name="login_email_reset" />
                        </div>
                        <div class="uk-margin-medium-top">
                            <button type="button" class="md-btn md-btn-primary md-btn-block">Reset password</button>
                        </div>
                    </form>
                </div>

                <!--- Register Form Html Code-->

                <div class="md-card-content large-padding" id="register_form" style="display: none">
                    <button type="button" class="uk-position-top-right uk-close uk-margin-right uk-margin-top back_to_login"></button>
                    <h2 class="heading_a uk-margin-medium-bottom">Create an account</h2>
                    <h4 style="color: #db2d20; text-align: center;" id="regmassage" class="heading_a uk-margin-medium-bottom"></h4>
                    <div id="rgFrom">
                    <form action="" id="signup_form_id">
                        
                        <div class="uk-form-row">
                            <label for="register_fname">First Name</label>
                            <input class="md-input" type="text" id="register_username" name="register_fname" required/>
                        </div>
                        
                        <div class="uk-form-row">
                            <label for="register_lname">Last Name</label>
                            <input class="md-input" type="text" id="register_username" name="register_lname" required/>
                        </div>
                        
                        <div class="uk-form-row">
                            <label for="register_password">Password</label>
                            <input class="md-input" type="password" id="register_password" name="register_password" required/>
                        </div>
                        <div class="uk-form-row">
                            <label for="register_password_repeat">Repeat Password</label>
                            <input class="md-input" type="password" id="register_password_repeat" name="register_password_repeat" required/>
                        </div>
                        <div class="uk-form-row">
                            <label for="register_email">E-mail</label>
                            <input class="md-input" type="text" id="register_email" name="register_email" required/>
                        </div>
                        
                        <div class="uk-form-row">
                            <label for="register_phone">Phone No</label>
                            <input class="md-input" type="text" id="register_phone" name="register_phone" required/>
                        </div>
                                                
                        <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label getmdl-select getmdl-select__fix-height uk-form-row">
                            <input class="mdl-textfield__input" type="text" name="register_afor" id="register_afor" value="Select Register For" readonly tabIndex="-1">
                        <label for="register_afor">
                        <i class="mdl-icon-toggle__label material-icons">keyboard_arrow_down</i>
                        </label>
                        <label for="register_afor" class="mdl-textfield__label">Apply For</label>
                        <ul for="register_afor" class="mdl-menu mdl-menu--bottom-left mdl-js-menu">
                        <li class="mdl-menu__item" data-val="DE">Department</li>
                        <li class="mdl-menu__item" data-val="BY">MANUFACTORY</li>
                        <li class="mdl-menu__item" data-val="RU">WHOLESALE</li>
                        <li class="mdl-menu__item" data-val="RU">RETAIL</li>
                        </ul>
                        </div>
        
                        
                        <div style="margin-top: -5px;" class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label getmdl-select getmdl-select__fix-height uk-form-row">
                        <input class="mdl-textfield__input" type="text" name="register_district" id="register_district" value="Select District" readonly tabIndex="-1">
                        <label for="register_district">
                        <i class="mdl-icon-toggle__label material-icons">keyboard_arrow_down</i>
                        </label>
                        <label for="register_district" class="mdl-textfield__label">District</label>
                        <ul for="register_district" class="mdl-menu mdl-menu--bottom-left mdl-js-menu">
                        <?php include '../location_ajax_request/loadall_in_signup.php';?>
                        
                        </ul>
                        </div>
        
                        <div class="uk-margin-medium-top">
                            <button type="button" id="register_btn" class="md-btn md-btn-primary md-btn-block md-btn-large">Register</button>
                        </div>
                        
                        <div class="uk-margin-medium-top">
                        <button type="button" class="md-btn md-btn-primary md-btn-block md-btn-large back_to_login">Cancel</button>                        
                        </div>
                        
                    </form>
                        </div>
                </div>
            </div>
            
            
            <div class="uk-margin-top uk-text-center">
                <button type="button" id="signup_form_show" class="md-btn md-btn-primary md-btn-block md-btn-large">Create an account</button>
            </div>
        </div>

<script type="text/javascript">
    $(document).ready(SignUp());
    $(document).ready(Login());
    
 
function SignUp(){
    $(document).on("click", "#register_btn", function(){        
    $.ajax({
            type: 'POST',
            url : "../user_ajax_request/user_add.php",
            data : $("#signup_form_id").serialize(),
            error: function (html) {
            $("#regmassage").html(html);    
            },
            success: function (html){
            $("#regmassage").html(html); 
            $('#signup_form_id')[0].reset();
            }
        });
        
    }); 
    
}

function Login(){
    $(document).on("click", "#login_btn", function(){
    $.ajax({
            type: 'POST',
            url : "../user_ajax_request/login.php",
            data : $("#Login_from_id").serialize(),
            error: function (html) {
            $("#logmassage").html(html);    
            },
            success: function (html){
            $("#logmassage").html(html);
            $("#rgFrom").hide();
            
            }
        });
    }); 
}
 



</script>

<?php include '../include/gen_Footer.php';?>
