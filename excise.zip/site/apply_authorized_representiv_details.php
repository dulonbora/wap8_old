<?php include '../include/header_site.php';
include '../classes/Mobile_Detect.php';
$mobile = new Mobile_Detect(); 

?>

<a name="top"></a>
<!---------------------------------------------------------------------------->
<?php if($mobile->isMobile()){?>
<div class="android-more-section">
    <div style="text-align: left; font-size: 2em; color: #006400; padding: 10px;" class="mdl-typography--display-1-color-contrast ">You are browsing this site from mobile now, If you want to apply license please fill this form from desktop or laptop</div>  
  </div>
<?php } ?>

<div style="border: #00695c solid medium; margin-top: 10px; padding-left: 5px; padding-right: 5px;" class="android-more-section">
    <div style="" class="android-section-title mdl-typography--display-1-color-contrast ">Enter Authorized Representative Details
</div>  
<form>
    
    
    <div class="android-card-container mdl-grid">
  <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="First_Name">
    <label class="mdl-textfield__label" for="First_Name">First Name</label>
  </div>
      
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="Middle_Name">
    <label class="mdl-textfield__label" for="Middle_Name">Middle Name</label>
  </div>
      
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="Last_Name">
    <label class="mdl-textfield__label" for="Last_Name">Last Name</label>
  </div>
  </div>
    
    
    <div class="android-card-container mdl-grid">
  <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="First_Name">
    <label class="mdl-textfield__label" for="First_Name">Phone No</label>
  </div>
      
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="Middle_Name">
    <label class="mdl-textfield__label" for="Middle_Name">Email Address</label>
  </div>
  
  </div>
    
    <div class="android-card-container mdl-grid">
  <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="First_Name">
    <label class="mdl-textfield__label" for="First_Name">Father Name</label>
  </div>
      
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--3-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="Middle_Name">
    <label class="mdl-textfield__label" for="Middle_Name">Date of Birth (<21 not eligible)</label>
  </div>
      
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--2-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="Middle_Name">
    <label class="mdl-textfield__label" for="Middle_Name">Residential Status</label>
  </div>
      
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--3-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="Last_Name">
    <label class="mdl-textfield__label" for="Last_Name">Nationality</label>
  </div>
  </div>
    
    <div class="android-card-container mdl-grid">
    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <textarea class="mdl-textfield__input" type="text" id="Last_Name"></textarea>
    <label class="mdl-textfield__label" for="Last_Name">Permanent Address</label>
  </div>
        
    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <textarea class="mdl-textfield__input" type="text" id="Last_Name"></textarea>
    <label class="mdl-textfield__label" for="Last_Name">Permanent Address</label>
  </div>
  </div>
    
    <div class="android-card-container mdl-grid">
    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <textarea class="mdl-textfield__input" type="text" id="Last_Name"></textarea>
    <label class="mdl-textfield__label" for="Last_Name">Past Occupation</label>
  </div>
        
    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <textarea class="mdl-textfield__input" type="text" id="Last_Name"></textarea>
    <label class="mdl-textfield__label" for="Last_Name">Parents Occupation</label>
  </div>
  </div>
    
    <div class="android-card-container mdl-grid">
    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--12-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <textarea class="mdl-textfield__input" type="text" id="Last_Name"></textarea>
    <label class="mdl-textfield__label" for="Last_Name">Highest Educational qualification</label>
  </div>
        
  </div>
    
   
    
    
    <div class="android-card-container mdl-grid">
    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
  </div>
        
    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <button class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--accent">
  Submit To Process This Application
</button>
  </div>
  </div>

  </form>

 
  </div>





<script type="text/javascript">
    $(document).ready(CheckCat());
    $(document).ready(CheckDist());
    $(document).ready(HibeBarDatails());


    function CheckCat() {
        $(document).on("change", "#lcategory", function () {
            var id = $(this).val();
            $.ajax({
                type: 'GET',
                url: "../license_category_ajax_request/loadalsubl_in_apply.php",
                data: {id: id},
                error: function (html) {
                    $("#AllSubCat").html(html);
                },
                success: function (html) {
                    $("#AllSubCat").html(html);
                }

            });

        });

    }
    function CheckDist() {
        $(document).on("change", "#District", function () {
            var id = $(this).val();
            //alert(id);
            $.ajax({
                type: 'GET',
                url: "../location_ajax_request/load_add_subdist_apply.php",
                data: {id: id},
                error: function (html) {
                    $("#Police_Station_html").html(html);
                },
                success: function (html) {
                    $("#Police_Station_html").html(html);
                }

            });

        });

    }
    
    function HibeBarDatails() {
        $("#BarDetails").hide(); 
        $(document).on("click", "#Additional_Bar_Yes", function(){
   if( $(this).is(':checked')){
      $("#BarDetails").show(); 
   }
   else{
       $("#BarDetails").hide(); 
   }
    });
    }


</script>
<?php include '../include/footer_site.php'; ?>
