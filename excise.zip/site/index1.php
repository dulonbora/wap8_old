<?php include '../include/header_site.php';?>
<?php if(isset($_SESSION['USER_ID'])==null)
    {include '../html_index/nonlogged.php'; }
    else {
     include '../html_index/logged.php';
    }
?>
<?php include '../include/footer_site.php';?>
