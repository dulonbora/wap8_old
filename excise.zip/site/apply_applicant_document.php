<?php include '../include/header_site.php';
include '../classes/Mobile_Detect.php';
$mobile = new Mobile_Detect(); 

?>

<link rel="stylesheet" href="../css/material.components.ext.min.css">
<script src="../js/material.components.ext.min.js"></script>
<a name="top"></a>

<!---------------------------------------------------------------------------->
<?php if($mobile->isMobile()){?>
<div class="android-more-section">
    <div style="text-align: left; font-size: 2em; color: #006400; padding: 10px;" class="mdl-typography--display-1-color-contrast ">You are browsing this site from mobile now, If you want to apply license please fill this form from desktop or laptop</div>  
  </div>
<?php } ?>
        
 
 


<!---------------------------------------------------------------------------->





<!---------------------------------------------------------------------------->









<div style="border: #00695c solid medium; margin-top: 10px; padding-left: 5px; padding-right: 5px;" class="android-more-section">
    <div style="font-size: 3em;" class="android-section-title mdl-typography--display-1-color-contrast ">Upload Document</div> 
    
    <div style="" class="android-section-title mdl-typography--display-1-color-contrast ">Applicant Document</div>  
    <form>
        <!---------------------------------------------------------------------------->
        
        
        
        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--8-col-tablet mdl-cell--12-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">
                    Proof of financial capacity of the applicant</label> 

            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-file--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--10-col-phone">
                <input class="mdl-textfield__input" type="file" name="avatar" id="avatar">
            </div>
      
        </div>
        
        
        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--8-col-tablet mdl-cell--12-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">
                    Medical Fitness certificate</label> 

            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-file--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--10-col-phone">
                <input class="mdl-textfield__input" type="file" name="avatar" id="avatar">
            </div>
      
        </div>
        
        
        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--8-col-tablet mdl-cell--12-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">
                    Police report on character and antecedents of the applicant</label> 

            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-file--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--10-col-phone">
                <input class="mdl-textfield__input" type="file" name="avatar" id="avatar">
            </div>
        </div>
        
        
        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--8-col-tablet mdl-cell--12-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">
                    Income Tax, Sales Tax and Professional Tax Clearance Certificate, as the case may be</label> 

            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-file--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--10-col-phone">
                <input class="mdl-textfield__input" type="file" name="avatar" id="avatar">
            </div>      
        </div>
        
            <div style="" class="android-section-title mdl-typography--display-1-color-contrast ">Site Document</div>  

        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--8-col-tablet mdl-cell--12-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">
                    Copy of the document showing the applicant’s right,<br/>title and interest on the proposed site or the land</label> 

            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-file--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--10-col-phone">
                <input class="mdl-textfield__input" type="file" name="avatar" id="avatar">
            </div>
           
        </div>
        
        <div class="android-card-container mdl-grid">
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <button class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--accent">
  Submit To Process This Application
</button>
  </div>
        </div>

    </form>


</div>





<script type="text/javascript">




</script>

<script type="text/javascript">
    $(document).ready(CheckDist());
    $(document).ready(file());
    
    


    function CheckDist() {
        $(document).on("change", "#lcategory", function () {
            var id = $(this).val();
            $.ajax({
                type: 'GET',
                url: "../license_category_ajax_request/loadalsubl_in_apply.php",
                data: {id: id},
                error: function (html) {
                    $("#AllSubCat").html(html);
                },
                success: function (html) {
                    $("#AllSubCat").html(html);
                }

            });

        });

    }

    function file() {
    document.getElementById("uploadBtn").onchange = function () {
    document.getElementById("uploadFile").value = this.files[0].name;
    };

    }
    



</script>
<?php include '../include/footer_site.php'; ?>
