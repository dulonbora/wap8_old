<?php include '../include/header_site.php';?>
        <a name="top"></a>

<?php if(isset($_SESSION['USER_ID'])==null)
    { header('Location: index.php'); }
    else {?>
        
        
        <div style="border: #00695c solid medium; margin-top: 10px; padding-left: 5px; padding-right: 5px;" class="android-more-section">
    <div style="text-align: center; font-size: 2em" class="android-section-title mdl-typography--display-1-color-contrast ">Your Not Authorized To Apply Permit</div>  

 
  </div>
     <?php
    }
?>


        

        
<?php include '../include/footer_site.php';?>
