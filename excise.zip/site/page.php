<?php

$id = filter_input(INPUT_GET , 'i');
include '../classes/Pages.php';
$page = new Pages();
$page->loadValue($id);
include '../include/header_site.php';



?>
        <a name="top"></a>


<div class="android-more-section">
          <div class="android-card-container mdl-grid">
            
              <div style="width: 100%;" class="mdl-cell mdl-cell--3-col mdl-cell--4-col-tablet mdl-cell--4-col-phone mdl-card mdl-shadow--3dp">
              <div class="mdl-card__media">
                  <img style="height: 500px;" src="../images/more-from-3.png">
              </div>
              <div class="mdl-card__title">
                  <h4 class="mdl-card__title-text"><?php echo $page->getHEADLINE();?></h4>
              </div>
              <div class="mdl-card__supporting-text">
                  <span class="mdl-typography--font-light mdl-typography--subhead"><?php echo $page->getCONTENT();?></span>
              </div>
              <div class="mdl-card__actions">
                 <a class="android-link mdl-button mdl-js-button mdl-typography--text-uppercase" href="">
                   Visit For More
                   <i class="material-icons">chevron_right</i>
                 </a>
              </div>
            </div>
          </div>
        </div>
        
        <?php include '../include/footer_site.php';?>
