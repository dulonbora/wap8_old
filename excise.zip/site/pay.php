<?php include '../include/header_site.php';?>
   
        <a name="top"></a>

        <div style="" class="android-more-section">
    <div style="" class="android-section-title mdl-typography--display-1-color-contrast ">FEES PAYMENT</div>  
              <div class="android-card-container mdl-grid">
              
              </div>
  
  </div>

 <!---------------------------------------------------------------------------->
  <form>
    
    <div class="android-card-container mdl-grid">
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
    <input class="mdl-textfield__input" type="text" id="First_Name">
    <label class="mdl-textfield__label" for="First_Name">First Name</label>
  </div>
      
  
      
  
                      
                

  </form>

 
  </div>
        

        <script type="text/javascript">
            $(document).ready(CheckDist());

        
        function CheckDist(){
	$(document).on("change", ".lcategory", function(){
        var id = $(this).val();
        $.ajax({
            type: 'GET',
            url : "../license_category_ajax_request/loadalsubl_in_apply.php",
            data : {id : id},
            error: function (html) {
            $("#AllSubCat").html(html);    
            },
            success: function (html){
            $("#AllSubCat").html(html);    
            }
        }); 
    
        });
        
        }


</script>
<?php include '../include/footer_site.php';?>
