<?php include '../include/header_site.php';?>
        <a name="top"></a>

<?php if(isset($_SESSION['USER_ID'])==null)
    { header('Location: index.php'); }
    else {?>
        
        
        <div style="border: #00695c solid medium; margin-top: 10px; padding-left: 5px; padding-right: 5px;" class="android-more-section">
    <div style="text-align: center;" class="android-section-title mdl-typography--display-1-color-contrast ">Select Your License Type</div>  
<form>
    
    
    <div style="margin-top: -10px" class="android-card-container mdl-grid">
  
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--2-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
  </div>
  
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--2-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <label class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="Yes">
            <input type="checkbox" id="Yes" class="mdl-checkbox__input">
            <span class="mdl-checkbox__label">Distillery</span>
         </label>
  </div>
  
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--2-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <label class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="No">
            <input type="checkbox" id="No" class="mdl-checkbox__input">
            <span class="mdl-checkbox__label">Brewery</span>
         </label>
  </div>
  
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--2-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <label class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="No">
            <input type="checkbox" id="No" class="mdl-checkbox__input">
            <span class="mdl-checkbox__label">Whole Saller</span>
         </label>
  </div>
        
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--2-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <label class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="No">
            <input type="checkbox" id="No" class="mdl-checkbox__input">
            <span class="mdl-checkbox__label">Retailer</span>
         </label>
  </div>
        
<div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--2-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
  </div>  
  </div>
    
    
    
    
    
    <div style="margin-top: 10px;" class="android-card-container mdl-grid">
    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
  </div>
        
    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
        <a href="apply_sitebasic_info.php" class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--accent">
  Submit To Process This Application
</a>
  </div>
        
        <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
  </div>
  </div>

  </form>

 
  </div>
     <?php
    }
?>


        

        
<?php include '../include/footer_site.php';?>
