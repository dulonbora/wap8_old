<?php include '../include/header_site.php';
include '../classes/Mobile_Detect.php';
$mobile = new Mobile_Detect(); 

?>

<a name="top"></a>
<!---------------------------------------------------------------------------->
<?php if($mobile->isMobile()){?>
<div class="android-more-section">
    <div style="text-align: left; font-size: 2em; color: #006400; padding: 10px;" class="mdl-typography--display-1-color-contrast ">You are browsing this site from mobile now, If you want to apply license please fill this form from desktop or laptop</div>  
  </div>
<?php } ?>

        
<!---------------------------------------------------------------------------->

<div style="border: #00695c solid medium; margin-top: 10px; padding-left: 5px; padding-right: 5px;" class="android-more-section">
    <div style="" class="android-section-title mdl-typography--display-1-color-contrast ">Co-ordinates of the site offered</div>  
    <form>
        <!---------------------------------------------------------------------------->
        
        
        <div class="android-card-container mdl-grid">
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="Middle_Name">
    <label class="mdl-textfield__label" for="Middle_Name">Location Category</label>
  </div>
            
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="Middle_Name">
    <label class="mdl-textfield__label" for="Middle_Name">Latitude</label>
  </div>

        </div>
        <div class="android-card-container mdl-grid">
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="Middle_Name">
    <label class="mdl-textfield__label" for="Middle_Name">Longitude</label>
  </div>
            
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="Middle_Name">
    <label class="mdl-textfield__label" for="Middle_Name">Latitude</label>
  </div>

        </div>

        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">
                    Whether the Site / Premises is covered by a Trade License /Certificate of Enlistment</label> 

            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label id="aby" class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="Additional_Bar_Yes">
                    <input type="checkbox" id="Additional_Bar_Yes" class="mdl-checkbox__input addtional_bar">
                    <span class="mdl-checkbox__label">if Yes Mark it</span>
                </label>
            </div>


        </div>

        <div class="android-card-container mdl-grid">
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--12-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <textarea class="mdl-textfield__input" type="text" id="Last_Name"></textarea>
                <label class="mdl-textfield__label" for="Last_Name">Enter Trade License /Certificate of Enlistment No</label>
            </div>
        </div>
        <!---------------------------------------------------------------------------->

        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">
                    Whether the Site is covered by a VAT License</label> 

            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label id="aby" class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="Additional_Bar_Yes">
                    <input type="checkbox" id="Additional_Bar_Yes" class="mdl-checkbox__input addtional_bar">
                    <span class="mdl-checkbox__label">if Yes Mark it</span>
                </label>
            </div>

        </div>

        <div class="android-card-container mdl-grid">
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--12-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <textarea class="mdl-textfield__input" type="text" id="Last_Name"></textarea>
                <label class="mdl-textfield__label" for="Last_Name">Enter VAT Regestration no</label>
            </div>

        </div>
        
        
        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--10-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">
                    Do you have a Valid Food License for the Proposed Site ? (If Applicable)</label> 

            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label id="aby" class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="Additional_Bar_Yes">
                    <input type="checkbox" id="Additional_Bar_Yes" class="mdl-checkbox__input addtional_bar">
                    <span class="mdl-checkbox__label">if Yes Mark it</span>
                </label>
            </div>
        </div>
        
        <div class="android-card-container mdl-grid">
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--12-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <textarea class="mdl-textfield__input" type="text" id="Last_Name"></textarea>
                <label class="mdl-textfield__label" for="Last_Name">Enter Food License no</label>
            </div>

        </div>
        
        

        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">
                    Is the Proposed Site Owned by the Applicant</label> 

            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label id="aby" class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="Additional_Bar_Yes">
                    <input type="checkbox" id="Additional_Bar_Yes" class="mdl-checkbox__input addtional_bar">
                    <span class="mdl-checkbox__label">if Yes Mark it</span>
                </label>
            </div>

        </div>
        
        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">
                    Whether Commercial Conversion Certificate in respect of Land has been obtained</label> 

            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label id="aby" class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="Additional_Bar_Yes">
                    <input type="checkbox" id="Additional_Bar_Yes" class="mdl-checkbox__input addtional_bar">
                    <span class="mdl-checkbox__label">if Yes Mark it</span>
                </label>
            </div>

        </div>
        
        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--10-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">
                    Whether the Proposed Site is situated within an IT/ Electronics Park</label> 

            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--1-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="Yes">
                    <input type="checkbox" id="Yes" class="mdl-checkbox__input">
                    <span class="mdl-checkbox__label">Yes</span>
                </label>
            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--1-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="No">
                    <input type="checkbox" id="No" class="mdl-checkbox__input">
                    <span class="mdl-checkbox__label">No</span>
                </label>
            </div>


        </div>
        
        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--10-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">
                    Whether the Proposed Site is within 20% of the total built up area of such IT/ Electronics Park<br/> meant for eateries etc. as per Government norms.</label> 

            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--1-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="Yes">
                    <input type="checkbox" id="Yes" class="mdl-checkbox__input">
                    <span class="mdl-checkbox__label">Yes</span>
                </label>
            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--1-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="No">
                    <input type="checkbox" id="No" class="mdl-checkbox__input">
                    <span class="mdl-checkbox__label">No</span>
                </label>
            </div>


        </div>
        
        
        
        
        


        <div class="android-card-container mdl-grid">
            
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="Last_Name">Estimated Amount of Monthly sales of Foreign Liquor as assessed by the Applicant</label>
            </div>
            
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--2-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
            <input class="mdl-textfield__input" type="text" id="Middle_Name">
            <label class="mdl-textfield__label" for="Middle_Name">Enter Foreign Liquor (Liters)</label>
            </div>
            
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--2-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
            <input class="mdl-textfield__input" type="text" id="Middle_Name">
            <label class="mdl-textfield__label" for="Middle_Name">Enter Beer (Liters)</label>
            </div>
            

        </div>
        

        <div class="android-card-container mdl-grid">
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <a href="apply_applicant_document.php" class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--accent">
  Submit To Process This Application
</a>
  </div>
        </div>

    </form>


</div>







<script type="text/javascript">
    $(document).ready(CheckCat());
    $(document).ready(CheckDist());
    $(document).ready(HibeBarDatails());


    function CheckCat() {
        $(document).on("change", "#lcategory", function () {
            var id = $(this).val();
            $.ajax({
                type: 'GET',
                url: "../license_category_ajax_request/loadalsubl_in_apply.php",
                data: {id: id},
                error: function (html) {
                    $("#AllSubCat").html(html);
                },
                success: function (html) {
                    $("#AllSubCat").html(html);
                }

            });

        });

    }
    function CheckDist() {
        $(document).on("change", "#District", function () {
            var id = $(this).val();
            //alert(id);
            $.ajax({
                type: 'GET',
                url: "../location_ajax_request/load_add_subdist_apply.php",
                data: {id: id},
                error: function (html) {
                    $("#Police_Station_html").html(html);
                },
                success: function (html) {
                    $("#Police_Station_html").html(html);
                }

            });

        });

    }
    
    function HibeBarDatails() {
        $("#BarDetails").hide(); 
        $(document).on("click", "#Additional_Bar_Yes", function(){
   if( $(this).is(':checked')){
      $("#BarDetails").show(); 
   }
   else{
       $("#BarDetails").hide(); 
   }
    });
    }


</script>
<?php include '../include/footer_site.php'; ?>
