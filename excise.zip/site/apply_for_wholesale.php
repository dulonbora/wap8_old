<?php include '../include/header_site.php';
include '../classes/Mobile_Detect.php';
$mobile = new Mobile_Detect(); 

?>

<a name="top"></a>

<!---------------------------------------------------------------------------->
<?php if($mobile->isMobile()){?>
<div class="android-more-section">
    <div style="text-align: left; font-size: 2em; color: #006400; padding: 10px;" class="mdl-typography--display-1-color-contrast ">You are browsing this site from mobile now, If you want to apply license please fill this form from desktop or laptop</div>  
  </div>
<?php } ?>
<div style="border: #00695c solid medium; margin-top: 10px; padding-left: 5px; padding-right: 5px;" class="android-more-section">
    <div style="" class="android-section-title mdl-typography--display-1-color-contrast ">Basic Information</div>  
<form>
    
    
    <div class="android-card-container mdl-grid">
  <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="First_Name">
    <label class="mdl-textfield__label" for="First_Name">Category of License Applied for*</label>
  </div>
      
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="Middle_Name">
    <label class="mdl-textfield__label" for="Middle_Name">Sub Category*</label>
  </div>
   
  </div>
    
    
  <div class="android-card-container mdl-grid">
    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--12-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <textarea class="mdl-textfield__input" type="text" id="Last_Name"></textarea>
    <label class="mdl-textfield__label" for="Last_Name">Name & Style of the Premises / Site</label>
  </div>
        
  </div>
    
    <div class="android-card-container mdl-grid">
  <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="First_Name">
    <label class="mdl-textfield__label" for="First_Name">District</label>
  </div>
      
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="Middle_Name">
    <label class="mdl-textfield__label" for="Middle_Name">Police Station</label>
  </div>
  
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="Middle_Name">
    <label class="mdl-textfield__label" for="Middle_Name">Site Type</label>
  </div>
  
  </div>
    
    
    <div class="android-card-container mdl-grid">
  <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">Do You want to apply for any Additional Bar(s) in addition to the Main Bar?</label> 
    
  </div>
      
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--2-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <label class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="Yes">
            <input type="checkbox" id="Yes" class="mdl-checkbox__input">
            <span class="mdl-checkbox__label">Yes</span>
         </label>
  </div>
  
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--2-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <label class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="No">
            <input type="checkbox" id="No" class="mdl-checkbox__input">
            <span class="mdl-checkbox__label">No</span>
         </label>
  </div>
  
  
  </div>
    
    <div class="android-card-container mdl-grid">
  <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--2-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="First_Name">
    <label class="mdl-textfield__label" for="First_Name">No of Additional Bar applied for?</label>
  </div>
      
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--10-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="Middle_Name">
    <label class="mdl-textfield__label" for="Middle_Name">Names of Additional Bar(s) if any ?</label>
  </div>
  
  
  </div>
    
    
    
    
    <div class="android-card-container mdl-grid">
    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
  </div>
        
    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <button class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--accent">
  Submit To Process This Application
</button>
  </div>
  </div>

  </form>

 
  </div>
        
 
 
 <!---------------------------------------------------------------------------->
        <div style="border: #00695c solid medium; margin-top: 10px; padding-left: 5px; padding-right: 5px;" class="android-more-section">
    <div style="" class="android-section-title mdl-typography--display-1-color-contrast ">Enter Applicant Details</div>  
<form>
    
    
    <div class="android-card-container mdl-grid">
  <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="First_Name">
    <label class="mdl-textfield__label" for="First_Name">First Name</label>
  </div>
      
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="Middle_Name">
    <label class="mdl-textfield__label" for="Middle_Name">Middle Name</label>
  </div>
      
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="Last_Name">
    <label class="mdl-textfield__label" for="Last_Name">Last Name</label>
  </div>
  </div>
    
    
    <div class="android-card-container mdl-grid">
  <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="First_Name">
    <label class="mdl-textfield__label" for="First_Name">Phone No</label>
  </div>
      
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="Middle_Name">
    <label class="mdl-textfield__label" for="Middle_Name">Email Address</label>
  </div>
  
  </div>
    
    <div class="android-card-container mdl-grid">
  <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="First_Name">
    <label class="mdl-textfield__label" for="First_Name">Father Name</label>
  </div>
      
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--3-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="Middle_Name">
    <label class="mdl-textfield__label" for="Middle_Name">Date of Birth (<21 not eligible)</label>
  </div>
      
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--2-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="Middle_Name">
    <label class="mdl-textfield__label" for="Middle_Name">Residential Status</label>
  </div>
      
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--3-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="Last_Name">
    <label class="mdl-textfield__label" for="Last_Name">Nationality</label>
  </div>
  </div>
    
    <div class="android-card-container mdl-grid">
    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <textarea class="mdl-textfield__input" type="text" id="Last_Name"></textarea>
    <label class="mdl-textfield__label" for="Last_Name">Permanent Address</label>
  </div>
        
    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <textarea class="mdl-textfield__input" type="text" id="Last_Name"></textarea>
    <label class="mdl-textfield__label" for="Last_Name">Permanent Address</label>
  </div>
  </div>
    
    <div class="android-card-container mdl-grid">
    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <textarea class="mdl-textfield__input" type="text" id="Last_Name"></textarea>
    <label class="mdl-textfield__label" for="Last_Name">Past Occupation</label>
  </div>
        
    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <textarea class="mdl-textfield__input" type="text" id="Last_Name"></textarea>
    <label class="mdl-textfield__label" for="Last_Name">Parents Occupation</label>
  </div>
  </div>
    
    <div class="android-card-container mdl-grid">
    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--12-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <textarea class="mdl-textfield__input" type="text" id="Last_Name"></textarea>
    <label class="mdl-textfield__label" for="Last_Name">Highest Educational qualification</label>
  </div>
        
  </div>
    
    <div class="android-card-container mdl-grid">
  <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="First_Name">
    <label class="mdl-textfield__label" for="First_Name">Pan No</label>
  </div>
      
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="Middle_Name">
    <label class="mdl-textfield__label" for="Middle_Name">Annual Income</label>
  </div>
  
  </div>
    
    <div class="android-card-container mdl-grid">
    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <textarea class="mdl-textfield__input" type="text" id="Last_Name"></textarea>
    <label class="mdl-textfield__label" for="Last_Name">How the Applicant will Arrange the Capital Necessary for Financing the Business Properly</label>
  </div>
        
    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <textarea class="mdl-textfield__input" type="text" id="Last_Name"></textarea>
    <label class="mdl-textfield__label" for="Last_Name">Business/Sales Experience, if any,with Full Particulars</label>
  </div>
  </div>
    
    <div class="android-card-container mdl-grid">
    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
  </div>
        
    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <button class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--accent">
  Submit To Process This Application
</button>
  </div>
  </div>

  </form>

 
  </div>
        


<!---------------------------------------------------------------------------->

<div style="border: #00695c solid medium; margin-top: 10px; padding-left: 5px; padding-right: 5px;" class="android-more-section">
    <form>
        <!---------------------------------------------------------------------------->

        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--10-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">Whether the Applicant holds or held any Excise license(s) in Assam/in any other State of India</label> 

            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--1-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="Yes">
                    <input type="checkbox" id="Yes" class="mdl-checkbox__input">
                    <span class="mdl-checkbox__label">Yes</span>
                </label>
            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--1-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="No">
                    <input type="checkbox" id="No" class="mdl-checkbox__input">
                    <span class="mdl-checkbox__label">No</span>
                </label>
            </div>


        </div>

        <div class="android-card-container mdl-grid">
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--2-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <textarea class="mdl-textfield__input" type="text" id="Last_Name"></textarea>
                <label class="mdl-textfield__label" for="Last_Name">Licensee Id</label>
            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--10-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <textarea class="mdl-textfield__input" type="text" id="Last_Name"></textarea>
                <label class="mdl-textfield__label" for="Last_Name">If so, Full Particulars thereof and if the License(s) is/are not in Force now, how it/they Terminated</label>
            </div>
        </div>
        <!---------------------------------------------------------------------------->

        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--10-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">Whether the Applicant is holding or ever held any Temporary Bar License</label> 

            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--1-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="Yes">
                    <input type="checkbox" id="Yes" class="mdl-checkbox__input">
                    <span class="mdl-checkbox__label">Yes</span>
                </label>
            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--1-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="No">
                    <input type="checkbox" id="No" class="mdl-checkbox__input">
                    <span class="mdl-checkbox__label">No</span>
                </label>
            </div>


        </div>

        <div class="android-card-container mdl-grid">
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--12-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <textarea class="mdl-textfield__input" type="text" id="Last_Name"></textarea>
                <label class="mdl-textfield__label" for="Last_Name">Enter Full Particulars</label>
            </div>

        </div>
        
        
        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--10-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">Whether the Applicant is involved , Either Directly or Indirectly in the Manufacture or Sale of any Intoxicant in a Foreign Territory or any State Bordering upon the State of West Bengal</label> 

            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--1-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="Yes">
                    <input type="checkbox" id="Yes" class="mdl-checkbox__input">
                    <span class="mdl-checkbox__label">Yes</span>
                </label>
            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--1-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="No">
                    <input type="checkbox" id="No" class="mdl-checkbox__input">
                    <span class="mdl-checkbox__label">No</span>
                </label>
            </div>


        </div>

        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--10-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">Whether the Applicant holds or held a License for the sale of foreign liquor by wholesale</label> 

            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--1-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="Yes">
                    <input type="checkbox" id="Yes" class="mdl-checkbox__input">
                    <span class="mdl-checkbox__label">Yes</span>
                </label>
            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--1-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="No">
                    <input type="checkbox" id="No" class="mdl-checkbox__input">
                    <span class="mdl-checkbox__label">No</span>
                </label>
            </div>


        </div>
        
        <div class="android-card-container mdl-grid">
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--12-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <textarea class="mdl-textfield__input" type="text" id="Last_Name"></textarea>
                <label class="mdl-textfield__label" for="Last_Name">If so, full particulars are to be furnished</label>
            </div>

        </div>
        
        
        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">Whether any of the following Relatives hold any Excise License in Assam</label> 

            </div>
            
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="Middle_Name">
    <label class="mdl-textfield__label" for="Middle_Name">Relativ Drop Down</label>
  </div>

        </div>


<div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--10-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">Whether the Applicant was ever convicted by a criminal court for a non-bailable offence</label> 

            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--1-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="Yes">
                    <input type="checkbox" id="Yes" class="mdl-checkbox__input">
                    <span class="mdl-checkbox__label">Yes</span>
                </label>
            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--1-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="No">
                    <input type="checkbox" id="No" class="mdl-checkbox__input">
                    <span class="mdl-checkbox__label">No</span>
                </label>
            </div>
        </div>
        
        <div class="android-card-container mdl-grid">
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--12-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <textarea class="mdl-textfield__input" type="text" id="Last_Name"></textarea>
                <label class="mdl-textfield__label" for="Last_Name">If so, full particulars thereof If so,</label>
            </div>

        </div>
        
        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--10-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">Whether the Applicant will be in a position to attend and manage the Business Personally<br/> and Independently in his/her own Interest</label> 

            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--1-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="Yes">
                    <input type="checkbox" id="Yes" class="mdl-checkbox__input">
                    <span class="mdl-checkbox__label">Yes</span>
                </label>
            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--1-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="No">
                    <input type="checkbox" id="No" class="mdl-checkbox__input">
                    <span class="mdl-checkbox__label">No</span>
                </label>
            </div>
        </div>
        
        <div class="android-card-container mdl-grid">
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--12-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <textarea class="mdl-textfield__input" type="text" id="Last_Name"></textarea>
                <label class="mdl-textfield__label" for="Last_Name">Special Claim, if any</label>
            </div>

        </div>

        <div class="android-card-container mdl-grid">
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <button class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--accent">
                    Submit To Process This Application
                </button>
            </div>
        </div>

    </form>


</div>



<!---------------------------------------------------------------------------->

<div style="border: #00695c solid medium; margin-top: 10px; padding-left: 5px; padding-right: 5px;" class="android-more-section">
    <div style="" class="android-section-title mdl-typography--display-1-color-contrast ">Co-ordinates of the site offered</div>  
    <form>
        <!---------------------------------------------------------------------------->
        
        
        <div class="android-card-container mdl-grid">
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="Middle_Name">
    <label class="mdl-textfield__label" for="Middle_Name">Location Category</label>
  </div>
            
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="Middle_Name">
    <label class="mdl-textfield__label" for="Middle_Name">Latitude</label>
  </div>

        </div>
        <div class="android-card-container mdl-grid">
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="Middle_Name">
    <label class="mdl-textfield__label" for="Middle_Name">Longitude</label>
  </div>
            
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="Middle_Name">
    <label class="mdl-textfield__label" for="Middle_Name">Latitude</label>
  </div>

        </div>

        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--10-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">
                    Whether the Site / Premises is covered by a Trade License /Certificate of Enlistment</label> 

            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--1-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="Yes">
                    <input type="checkbox" id="Yes" class="mdl-checkbox__input">
                    <span class="mdl-checkbox__label">Yes</span>
                </label>
            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--1-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="No">
                    <input type="checkbox" id="No" class="mdl-checkbox__input">
                    <span class="mdl-checkbox__label">No</span>
                </label>
            </div>


        </div>

        <div class="android-card-container mdl-grid">
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--12-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <textarea class="mdl-textfield__input" type="text" id="Last_Name"></textarea>
                <label class="mdl-textfield__label" for="Last_Name">Enter Trade License /Certificate of Enlistment No</label>
            </div>
        </div>
        <!---------------------------------------------------------------------------->

        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--10-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">
                    Whether the Site is covered by a VAT License</label> 

            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--1-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="Yes">
                    <input type="checkbox" id="Yes" class="mdl-checkbox__input">
                    <span class="mdl-checkbox__label">Yes</span>
                </label>
            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--1-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="No">
                    <input type="checkbox" id="No" class="mdl-checkbox__input">
                    <span class="mdl-checkbox__label">No</span>
                </label>
            </div>


        </div>

        <div class="android-card-container mdl-grid">
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--12-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <textarea class="mdl-textfield__input" type="text" id="Last_Name"></textarea>
                <label class="mdl-textfield__label" for="Last_Name">Enter VAT Regestration no</label>
            </div>

        </div>
        
        
        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--10-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">
                    Do you have a Valid Food License for the Proposed Site ? (If Applicable)</label> 

            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--1-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="Yes">
                    <input type="checkbox" id="Yes" class="mdl-checkbox__input">
                    <span class="mdl-checkbox__label">Yes</span>
                </label>
            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--1-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="No">
                    <input type="checkbox" id="No" class="mdl-checkbox__input">
                    <span class="mdl-checkbox__label">No</span>
                </label>
            </div>


        </div>
        
        <div class="android-card-container mdl-grid">
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--12-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <textarea class="mdl-textfield__input" type="text" id="Last_Name"></textarea>
                <label class="mdl-textfield__label" for="Last_Name">Enter Food License no</label>
            </div>

        </div>
        
        

        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--10-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">
                    Is the Proposed Site Owned by the Applicant</label> 

            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--1-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="Yes">
                    <input type="checkbox" id="Yes" class="mdl-checkbox__input">
                    <span class="mdl-checkbox__label">Yes</span>
                </label>
            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--1-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="No">
                    <input type="checkbox" id="No" class="mdl-checkbox__input">
                    <span class="mdl-checkbox__label">No</span>
                </label>
            </div>


        </div>
        
        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--10-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">
                    Whether Commercial Conversion Certificate in respect of Land has been obtained</label> 

            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--1-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="Yes">
                    <input type="checkbox" id="Yes" class="mdl-checkbox__input">
                    <span class="mdl-checkbox__label">Yes</span>
                </label>
            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--1-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="No">
                    <input type="checkbox" id="No" class="mdl-checkbox__input">
                    <span class="mdl-checkbox__label">No</span>
                </label>
            </div>


        </div>
        
        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--10-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">
                    Whether the Proposed Site is situated within an IT/ Electronics Park</label> 

            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--1-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="Yes">
                    <input type="checkbox" id="Yes" class="mdl-checkbox__input">
                    <span class="mdl-checkbox__label">Yes</span>
                </label>
            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--1-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="No">
                    <input type="checkbox" id="No" class="mdl-checkbox__input">
                    <span class="mdl-checkbox__label">No</span>
                </label>
            </div>


        </div>
        
        <div class="android-card-container mdl-grid">
            <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--10-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="First_Name">
                    Whether the Proposed Site is within 20% of the total built up area of such IT/ Electronics Park<br/> meant for eateries etc. as per Government norms.</label> 

            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--1-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="Yes">
                    <input type="checkbox" id="Yes" class="mdl-checkbox__input">
                    <span class="mdl-checkbox__label">Yes</span>
                </label>
            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--1-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="No">
                    <input type="checkbox" id="No" class="mdl-checkbox__input">
                    <span class="mdl-checkbox__label">No</span>
                </label>
            </div>


        </div>
        
        
        
        
        


        <div class="android-card-container mdl-grid">
            
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #00695c;" class="mdl-textfield__label" for="Last_Name">Estimated Amount of Monthly sales of Foreign Liquor as assessed by the Applicant</label>
            </div>
            
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--2-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
            <input class="mdl-textfield__input" type="text" id="Middle_Name">
            <label class="mdl-textfield__label" for="Middle_Name">Enter Foreign Liquor (Liters)</label>
            </div>
            
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--2-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
            <input class="mdl-textfield__input" type="text" id="Middle_Name">
            <label class="mdl-textfield__label" for="Middle_Name">Enter Beer (Liters)</label>
            </div>
            

        </div>
        

        <div class="android-card-container mdl-grid">
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <button class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--accent">
                    Submit To Process This Application
                </button>
            </div>
        </div>

    </form>


</div>


<div style="border: #00695c solid medium; margin-top: 10px; padding-left: 5px; padding-right: 5px;" class="android-more-section">
    <div style="" class="android-section-title mdl-typography--display-1-color-contrast ">Enter Authorized Representative Details
</div>  
<form>
    
    
    <div class="android-card-container mdl-grid">
  <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="First_Name">
    <label class="mdl-textfield__label" for="First_Name">First Name</label>
  </div>
      
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="Middle_Name">
    <label class="mdl-textfield__label" for="Middle_Name">Middle Name</label>
  </div>
      
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="Last_Name">
    <label class="mdl-textfield__label" for="Last_Name">Last Name</label>
  </div>
  </div>
    
    
    <div class="android-card-container mdl-grid">
  <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="First_Name">
    <label class="mdl-textfield__label" for="First_Name">Phone No</label>
  </div>
      
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="Middle_Name">
    <label class="mdl-textfield__label" for="Middle_Name">Email Address</label>
  </div>
  
  </div>
    
    <div class="android-card-container mdl-grid">
  <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="First_Name">
    <label class="mdl-textfield__label" for="First_Name">Father Name</label>
  </div>
      
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--3-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="Middle_Name">
    <label class="mdl-textfield__label" for="Middle_Name">Date of Birth (<21 not eligible)</label>
  </div>
      
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--2-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="Middle_Name">
    <label class="mdl-textfield__label" for="Middle_Name">Residential Status</label>
  </div>
      
  <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--3-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <input class="mdl-textfield__input" type="text" id="Last_Name">
    <label class="mdl-textfield__label" for="Last_Name">Nationality</label>
  </div>
  </div>
    
    <div class="android-card-container mdl-grid">
    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <textarea class="mdl-textfield__input" type="text" id="Last_Name"></textarea>
    <label class="mdl-textfield__label" for="Last_Name">Permanent Address</label>
  </div>
        
    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <textarea class="mdl-textfield__input" type="text" id="Last_Name"></textarea>
    <label class="mdl-textfield__label" for="Last_Name">Permanent Address</label>
  </div>
  </div>
    
    <div class="android-card-container mdl-grid">
    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <textarea class="mdl-textfield__input" type="text" id="Last_Name"></textarea>
    <label class="mdl-textfield__label" for="Last_Name">Past Occupation</label>
  </div>
        
    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--6-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <textarea class="mdl-textfield__input" type="text" id="Last_Name"></textarea>
    <label class="mdl-textfield__label" for="Last_Name">Parents Occupation</label>
  </div>
  </div>
    
    <div class="android-card-container mdl-grid">
    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--12-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <textarea class="mdl-textfield__input" type="text" id="Last_Name"></textarea>
    <label class="mdl-textfield__label" for="Last_Name">Highest Educational qualification</label>
  </div>
        
  </div>
    
   
    
    
    <div class="android-card-container mdl-grid">
    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
  </div>
        
    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
    <button class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--accent">
  Submit To Process This Application
</button>
  </div>
  </div>

  </form>

 
  </div>





<script type="text/javascript">
    $(document).ready(CheckDist());


    function CheckDist() {
        $(document).on("change", "#lcategory", function () {
            var id = $(this).val();
            $.ajax({
                type: 'GET',
                url: "../license_category_ajax_request/loadalsubl_in_apply.php",
                data: {id: id},
                error: function (html) {
                    $("#AllSubCat").html(html);
                },
                success: function (html) {
                    $("#AllSubCat").html(html);
                }

            });

        });

    }


</script>
<?php include '../include/footer_site.php'; ?>
