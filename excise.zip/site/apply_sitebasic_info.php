<?php
include '../include/header_site.php';
include '../classes/Mobile_Detect.php';
$mobile = new Mobile_Detect();
?>

<a name="top"></a>
<!---------------------------------------------------------------------------->
<?php if ($mobile->isMobile()) { ?>
    <div class="android-more-section">
        <div style="text-align: left; font-size: 2em; color: #006400; padding: 10px;" class="mdl-typography--display-1-color-contrast ">You are browsing this site from mobile now, If you want to apply license please fill this form from desktop or laptop</div>  
    </div>
<?php } ?>
<div style="border: #00695c solid medium; margin-top: 10px; padding-left: 5px; padding-right: 5px;" class="android-more-section">
    <div style="" class="android-section-title mdl-typography--display-1-color-contrast ">Basic Information</div>  
    <form id="Basic_Information" method="POST" action="../license_add/basic_site_details_add.php">

        <div class="android-card-container mdl-grid">
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--12-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <textarea class="mdl-textfield__input" type="text" name="NAME_OF_PLACE" id="NAME_OF_PLACE" required></textarea>
                <label class="mdl-textfield__label" for="NAME_OF_PLACE">Name of the place in which, the site on which and the building in which the plant is to be set up</label>
            </div>

        </div>

        <div class="android-card-container mdl-grid">
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--12-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <textarea class="mdl-textfield__input" type="text" name="PURPOSE_TO_OPEN" id="PURPOSE_TO_OPEN" required></textarea>
                <label class="mdl-textfield__label" for="PURPOSE_TO_OPEN">Purpose for which the plant proposed to be opened, specifying in detail the nature of business which the applicant desires to carry on therein</label>
            </div>

        </div>
        
        <div class="android-card-container mdl-grid">
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--12-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <textarea class="mdl-textfield__input" type="text" name="DISTANC_FROM_EDUCATION" id="DISTANC_FROM_EDUCATION" required></textarea>
                <label class="mdl-textfield__label" for="DISTANC_FROM_EDUCATION">Distance of the proposed site from educational/ religious/ medical institution</label>
            </div>
        </div>
        
        <div class="android-card-container mdl-grid">
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--12-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <textarea class="mdl-textfield__input" type="text" name="DISTANC_FROM_HIGHWAY" id="DISTANC_FROM_HIGHWAY" required></textarea>
                <label class="mdl-textfield__label" for="DISTANC_FROM_HIGHWAY">Distance of the proposed site from National and State Highway including service lanes</label>
            </div>
        </div>

        <div class="android-card-container mdl-grid">

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label getmdl-select mdl-cell mdl-cell--3-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <select id="DISTRICT_CODE" name="DISTRICT_CODE" class="mdl-textfield__input" required>
                    <option value="0" disabled selected>Select District</option>
                    <?php include '../location_ajax_request/load_add_dist_apply.php'; ?>
                </select>
            </div>

            <div id="Police_Station_html" class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label getmdl-select mdl-cell mdl-cell--3-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <select id="POLICE_STATION_CODE" name="POLICE_STATION_CODE" class="mdl-textfield__input" required>
                    <option value="">Select Police Station</option>
                    <option value="" disabled selected>Select district first</option>
                </select>
            </div>

            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label getmdl-select mdl-cell mdl-cell--3-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <select id="SITE_TYPE" name="SITE_TYPE" class="mdl-textfield__input" required>
                    <option value="0">Site type</option>
                    <option value="NEW">New</option>
                    <option value="EXISTING">Existing</option>
                </select>       
            </div>
            
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--3-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <input class="mdl-textfield__input" type="text" name="PLOTE_NO" id="PLOTE_NO" required>
            <label class="mdl-textfield__label" for="PLOTE_NO">Plote No</label>
            </div>
        </div>

        <div class="android-card-container mdl-grid">
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--8-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <label style="color: #ac2925;" id="errorMassage" class="mdl-textfield__label"></label>
            </div>
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label mdl-cell mdl-cell--4-col mdl-cell--4-col-tablet mdl-cell--4-col-phone">
                <button type="submit" id="Basic_Information_btn" class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--accent">
                    Submit To Process This Application
                </button>
            </div>
        </div>
    </form>
</div>


<script type="text/javascript">
    $(document).ready(CheckDist());
    $(document).ready(InsertBasicDetails());


    
    function CheckDist() {
        $(document).on("change", "#DISTRICT_CODE", function () {
            var id = $(this).val();
            //alert(id);
            $.ajax({
                type: 'GET',
                url: "../location_ajax_request/load_add_subdist_apply.php",
                data: {id: id},
                error: function (html) {
                    $("#Police_Station_html").html(html);
                },
                success: function (html) {
                    $("#Police_Station_html").html(html);
                }

            });

        });

    }
    
    function InsertBasicDetails(){
    $(document).on("click", "#Basic_Information_btn", function(){
        /*
        var dcode = $('#DISTRICT_CODE :selected').text();
        var pcode = $("#POLICE_STATION_CODE :selected").text();
        var stype = $("#SITE_TYPE :selected").text();
        //alert(dcode);
        
        var ok = true;
        if($("#NAME_OF_PLACE").val()==""){
            $("#errorMassage").html("Name of the place in which, <br/>the site on which and the building in which the plant is to be set up field is Empty"); 
            $("#NAME_OF_PLACE").focus();
            ok = false;
            return ok;
        }
        else if($("#PURPOSE_TO_OPEN").val()==""){
            $("#errorMassage").html("Purpose for which the plant proposed to be opened, <br/>specifying in detail the nature of business which the applicant desires to carry on therein"); 
            $("#PURPOSE_TO_OPEN").focus();
            ok = false;
            return ok;
        }
        
        else if($("#DISTANC_FROM_EDUCATION").val()==""){
            $("#errorMassage").html("Distance of the proposed site from educational/ religious/ medical institution fiedl is Empty"); 
            $("#DISTANC_FROM_EDUCATION").focus();
            ok = false;
            return ok;
        }
        
        else if($("#DISTANC_FROM_HIGHWAY").val()==""){
            $("#errorMassage").html("Distance of the proposed site from National and State Highway including service lanes Field Is Empty"); 
            $("#DISTANC_FROM_HIGHWAY").focus();
            ok = false;
            return ok;
        }
        
        else if(dcode=="Select District"){
            $("#errorMassage").html("Please Select District"); 
            $("#DISTRICT_CODE").focus();
            ok = false;
            return ok;
        }
        
        else if(pcode=="Select Police Station"){
            $("#errorMassage").html("Please Select Police Station"); 
            $("#POLICE_STATION_CODE").focus();
            ok = false;
            return ok;
        }
        
        else if(stype=="Site type"){
            $("#errorMassage").html("Please Select Site Type"); 
            $("#SITE_TYPE").focus();
            ok = false;
            return ok;
        }
        
        else if($("#PLOTE_NO").val()==""){
            $("#errorMassage").html("Please Enter Plote No"); 
            $("#PLOTE_NO").focus();
            ok = false;
            return ok;
        }
        */
        
    if(ok){
        $.ajax({
            type: 'POST',
            url : "../license_add/basic_site_details_add.php",
            data : $("#Basic_Information").serialize(),
            error: function (html) {
            $("#errorMassage").html(html);    
            },
            success: function (html){
            $("#errorMassage").html(html); 
            //$('#signup_form_id')[0].reset();
            }
        });
        
    }
    }); 
    
}
  
  
</script>

<?php include '../include/footer_site.php'; ?>
