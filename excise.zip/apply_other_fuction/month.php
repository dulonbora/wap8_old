<?php
$month_names = array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec");
$monthpos = 1;
foreach ($month_names as $month) {
    echo "<option value=\"" . $monthpos . "\">" . $month . "</option>";
    $monthpos++;
}
