<?php
$years = array();
for($i = 1800; $i<= 1995; $i++)
echo "<option value=\"" . $i . "\">" . $i . "</option>";
