<?php
for ($i = 1; $i <= 31; $i++) {
    echo "<option value=\"" . $i . "\">" . $i . "</option>";
}
